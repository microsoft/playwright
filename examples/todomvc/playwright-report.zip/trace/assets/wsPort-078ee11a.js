var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity)
      fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy)
      fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous")
      fetchOpts.credentials = "omit";
    else
      fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
function getDefaultExportFromCjs(x2) {
  return x2 && x2.__esModule && Object.prototype.hasOwnProperty.call(x2, "default") ? x2["default"] : x2;
}
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
var react = { exports: {} };
var react_production_min = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l$1 = Symbol.for("react.element"), n$1 = Symbol.for("react.portal"), p$2 = Symbol.for("react.fragment"), q$1 = Symbol.for("react.strict_mode"), r = Symbol.for("react.profiler"), t$1 = Symbol.for("react.provider"), u = Symbol.for("react.context"), v = Symbol.for("react.forward_ref"), w = Symbol.for("react.suspense"), x = Symbol.for("react.memo"), y = Symbol.for("react.lazy"), z$1 = Symbol.iterator;
function A$1(a) {
  if (null === a || "object" !== typeof a)
    return null;
  a = z$1 && a[z$1] || a["@@iterator"];
  return "function" === typeof a ? a : null;
}
var B$1 = { isMounted: function() {
  return false;
}, enqueueForceUpdate: function() {
}, enqueueReplaceState: function() {
}, enqueueSetState: function() {
} }, C$1 = Object.assign, D$1 = {};
function E$1(a, b, e) {
  this.props = a;
  this.context = b;
  this.refs = D$1;
  this.updater = e || B$1;
}
E$1.prototype.isReactComponent = {};
E$1.prototype.setState = function(a, b) {
  if ("object" !== typeof a && "function" !== typeof a && null != a)
    throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
  this.updater.enqueueSetState(this, a, b, "setState");
};
E$1.prototype.forceUpdate = function(a) {
  this.updater.enqueueForceUpdate(this, a, "forceUpdate");
};
function F() {
}
F.prototype = E$1.prototype;
function G$1(a, b, e) {
  this.props = a;
  this.context = b;
  this.refs = D$1;
  this.updater = e || B$1;
}
var H$1 = G$1.prototype = new F();
H$1.constructor = G$1;
C$1(H$1, E$1.prototype);
H$1.isPureReactComponent = true;
var I$1 = Array.isArray, J = Object.prototype.hasOwnProperty, K$1 = { current: null }, L$1 = { key: true, ref: true, __self: true, __source: true };
function M$1(a, b, e) {
  var d, c = {}, k2 = null, h = null;
  if (null != b)
    for (d in void 0 !== b.ref && (h = b.ref), void 0 !== b.key && (k2 = "" + b.key), b)
      J.call(b, d) && !L$1.hasOwnProperty(d) && (c[d] = b[d]);
  var g = arguments.length - 2;
  if (1 === g)
    c.children = e;
  else if (1 < g) {
    for (var f2 = Array(g), m2 = 0; m2 < g; m2++)
      f2[m2] = arguments[m2 + 2];
    c.children = f2;
  }
  if (a && a.defaultProps)
    for (d in g = a.defaultProps, g)
      void 0 === c[d] && (c[d] = g[d]);
  return { $$typeof: l$1, type: a, key: k2, ref: h, props: c, _owner: K$1.current };
}
function N$1(a, b) {
  return { $$typeof: l$1, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner };
}
function O$1(a) {
  return "object" === typeof a && null !== a && a.$$typeof === l$1;
}
function escape$1(a) {
  var b = { "=": "=0", ":": "=2" };
  return "$" + a.replace(/[=:]/g, function(a2) {
    return b[a2];
  });
}
var P$1 = /\/+/g;
function Q$1(a, b) {
  return "object" === typeof a && null !== a && null != a.key ? escape$1("" + a.key) : b.toString(36);
}
function R$1(a, b, e, d, c) {
  var k2 = typeof a;
  if ("undefined" === k2 || "boolean" === k2)
    a = null;
  var h = false;
  if (null === a)
    h = true;
  else
    switch (k2) {
      case "string":
      case "number":
        h = true;
        break;
      case "object":
        switch (a.$$typeof) {
          case l$1:
          case n$1:
            h = true;
        }
    }
  if (h)
    return h = a, c = c(h), a = "" === d ? "." + Q$1(h, 0) : d, I$1(c) ? (e = "", null != a && (e = a.replace(P$1, "$&/") + "/"), R$1(c, b, e, "", function(a2) {
      return a2;
    })) : null != c && (O$1(c) && (c = N$1(c, e + (!c.key || h && h.key === c.key ? "" : ("" + c.key).replace(P$1, "$&/") + "/") + a)), b.push(c)), 1;
  h = 0;
  d = "" === d ? "." : d + ":";
  if (I$1(a))
    for (var g = 0; g < a.length; g++) {
      k2 = a[g];
      var f2 = d + Q$1(k2, g);
      h += R$1(k2, b, e, f2, c);
    }
  else if (f2 = A$1(a), "function" === typeof f2)
    for (a = f2.call(a), g = 0; !(k2 = a.next()).done; )
      k2 = k2.value, f2 = d + Q$1(k2, g++), h += R$1(k2, b, e, f2, c);
  else if ("object" === k2)
    throw b = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
  return h;
}
function S$1(a, b, e) {
  if (null == a)
    return a;
  var d = [], c = 0;
  R$1(a, d, "", "", function(a2) {
    return b.call(e, a2, c++);
  });
  return d;
}
function T$1(a) {
  if (-1 === a._status) {
    var b = a._result;
    b = b();
    b.then(function(b2) {
      if (0 === a._status || -1 === a._status)
        a._status = 1, a._result = b2;
    }, function(b2) {
      if (0 === a._status || -1 === a._status)
        a._status = 2, a._result = b2;
    });
    -1 === a._status && (a._status = 0, a._result = b);
  }
  if (1 === a._status)
    return a._result.default;
  throw a._result;
}
var U$1 = { current: null }, V$1 = { transition: null }, W$1 = { ReactCurrentDispatcher: U$1, ReactCurrentBatchConfig: V$1, ReactCurrentOwner: K$1 };
react_production_min.Children = { map: S$1, forEach: function(a, b, e) {
  S$1(a, function() {
    b.apply(this, arguments);
  }, e);
}, count: function(a) {
  var b = 0;
  S$1(a, function() {
    b++;
  });
  return b;
}, toArray: function(a) {
  return S$1(a, function(a2) {
    return a2;
  }) || [];
}, only: function(a) {
  if (!O$1(a))
    throw Error("React.Children.only expected to receive a single React element child.");
  return a;
} };
react_production_min.Component = E$1;
react_production_min.Fragment = p$2;
react_production_min.Profiler = r;
react_production_min.PureComponent = G$1;
react_production_min.StrictMode = q$1;
react_production_min.Suspense = w;
react_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W$1;
react_production_min.cloneElement = function(a, b, e) {
  if (null === a || void 0 === a)
    throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
  var d = C$1({}, a.props), c = a.key, k2 = a.ref, h = a._owner;
  if (null != b) {
    void 0 !== b.ref && (k2 = b.ref, h = K$1.current);
    void 0 !== b.key && (c = "" + b.key);
    if (a.type && a.type.defaultProps)
      var g = a.type.defaultProps;
    for (f2 in b)
      J.call(b, f2) && !L$1.hasOwnProperty(f2) && (d[f2] = void 0 === b[f2] && void 0 !== g ? g[f2] : b[f2]);
  }
  var f2 = arguments.length - 2;
  if (1 === f2)
    d.children = e;
  else if (1 < f2) {
    g = Array(f2);
    for (var m2 = 0; m2 < f2; m2++)
      g[m2] = arguments[m2 + 2];
    d.children = g;
  }
  return { $$typeof: l$1, type: a.type, key: c, ref: k2, props: d, _owner: h };
};
react_production_min.createContext = function(a) {
  a = { $$typeof: u, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
  a.Provider = { $$typeof: t$1, _context: a };
  return a.Consumer = a;
};
react_production_min.createElement = M$1;
react_production_min.createFactory = function(a) {
  var b = M$1.bind(null, a);
  b.type = a;
  return b;
};
react_production_min.createRef = function() {
  return { current: null };
};
react_production_min.forwardRef = function(a) {
  return { $$typeof: v, render: a };
};
react_production_min.isValidElement = O$1;
react_production_min.lazy = function(a) {
  return { $$typeof: y, _payload: { _status: -1, _result: a }, _init: T$1 };
};
react_production_min.memo = function(a, b) {
  return { $$typeof: x, type: a, compare: void 0 === b ? null : b };
};
react_production_min.startTransition = function(a) {
  var b = V$1.transition;
  V$1.transition = {};
  try {
    a();
  } finally {
    V$1.transition = b;
  }
};
react_production_min.unstable_act = function() {
  throw Error("act(...) is not supported in production builds of React.");
};
react_production_min.useCallback = function(a, b) {
  return U$1.current.useCallback(a, b);
};
react_production_min.useContext = function(a) {
  return U$1.current.useContext(a);
};
react_production_min.useDebugValue = function() {
};
react_production_min.useDeferredValue = function(a) {
  return U$1.current.useDeferredValue(a);
};
react_production_min.useEffect = function(a, b) {
  return U$1.current.useEffect(a, b);
};
react_production_min.useId = function() {
  return U$1.current.useId();
};
react_production_min.useImperativeHandle = function(a, b, e) {
  return U$1.current.useImperativeHandle(a, b, e);
};
react_production_min.useInsertionEffect = function(a, b) {
  return U$1.current.useInsertionEffect(a, b);
};
react_production_min.useLayoutEffect = function(a, b) {
  return U$1.current.useLayoutEffect(a, b);
};
react_production_min.useMemo = function(a, b) {
  return U$1.current.useMemo(a, b);
};
react_production_min.useReducer = function(a, b, e) {
  return U$1.current.useReducer(a, b, e);
};
react_production_min.useRef = function(a) {
  return U$1.current.useRef(a);
};
react_production_min.useState = function(a) {
  return U$1.current.useState(a);
};
react_production_min.useSyncExternalStore = function(a, b, e) {
  return U$1.current.useSyncExternalStore(a, b, e);
};
react_production_min.useTransition = function() {
  return U$1.current.useTransition();
};
react_production_min.version = "18.1.0";
{
  react.exports = react_production_min;
}
var reactExports = react.exports;
const React = /* @__PURE__ */ getDefaultExportFromCjs(reactExports);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = reactExports, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p$1 = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a)
    m.call(a, b) && !p$1.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps)
    for (b in a = c.defaultProps, a)
      void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const Fragment = jsxRuntimeExports.Fragment;
const jsx = jsxRuntimeExports.jsx;
const jsxs = jsxRuntimeExports.jsxs;
const common = "";
function useAsyncMemo(fn, deps, initialValue, resetValue) {
  const [value, setValue] = React.useState(initialValue);
  React.useEffect(() => {
    let canceled = false;
    if (resetValue !== void 0)
      setValue(resetValue);
    fn().then((value2) => {
      if (!canceled)
        setValue(value2);
    });
    return () => {
      canceled = true;
    };
  }, deps);
  return value;
}
function useMeasure() {
  const ref = React.useRef(null);
  const [measure, setMeasure] = React.useState(new DOMRect(0, 0, 10, 10));
  React.useLayoutEffect(() => {
    const target2 = ref.current;
    if (!target2)
      return;
    const resizeObserver = new ResizeObserver((entries) => {
      const entry = entries[entries.length - 1];
      if (entry && entry.contentRect)
        setMeasure(entry.contentRect);
    });
    resizeObserver.observe(target2);
    return () => resizeObserver.disconnect();
  }, [ref]);
  return [measure, ref];
}
function msToString(ms) {
  if (!isFinite(ms))
    return "-";
  if (ms === 0)
    return "0";
  if (ms < 1e3)
    return ms.toFixed(0) + "ms";
  const seconds = ms / 1e3;
  if (seconds < 60)
    return seconds.toFixed(1) + "s";
  const minutes = seconds / 60;
  if (minutes < 60)
    return minutes.toFixed(1) + "m";
  const hours = minutes / 60;
  if (hours < 24)
    return hours.toFixed(1) + "h";
  const days = hours / 24;
  return days.toFixed(1) + "d";
}
function upperBound(array, object, comparator, left, right) {
  let l2 = left || 0;
  let r2 = right !== void 0 ? right : array.length;
  while (l2 < r2) {
    const m2 = l2 + r2 >> 1;
    if (comparator(object, array[m2]) >= 0)
      l2 = m2 + 1;
    else
      r2 = m2;
  }
  return r2;
}
function copy$2(text) {
  const textArea = document.createElement("textarea");
  textArea.style.position = "absolute";
  textArea.style.zIndex = "-1000";
  textArea.value = text;
  document.body.appendChild(textArea);
  textArea.select();
  document.execCommand("copy");
  textArea.remove();
}
function useSetting(name, defaultValue) {
  const value = settings.getObject(name, defaultValue);
  const [state, setState] = React.useState(value);
  const setStateWrapper = (value2) => {
    settings.setObject(name, value2);
    setState(value2);
  };
  return [state, setStateWrapper];
}
class Settings {
  getString(name, defaultValue) {
    return localStorage[name] || defaultValue;
  }
  setString(name, value) {
    localStorage[name] = value;
    if (window.saveSettings)
      window.saveSettings();
  }
  getObject(name, defaultValue) {
    if (!localStorage[name])
      return defaultValue;
    try {
      return JSON.parse(localStorage[name]);
    } catch {
      return defaultValue;
    }
  }
  setObject(name, value) {
    localStorage[name] = JSON.stringify(value);
    if (window.saveSettings)
      window.saveSettings();
  }
}
const settings = new Settings();
function applyTheme() {
  if (document.playwrightThemeInitialized)
    return;
  document.playwrightThemeInitialized = true;
  document.defaultView.addEventListener("focus", (event) => {
    if (event.target.document.nodeType === Node.DOCUMENT_NODE)
      document.body.classList.remove("inactive");
  }, false);
  document.defaultView.addEventListener("blur", (event) => {
    document.body.classList.add("inactive");
  }, false);
  const currentTheme2 = settings.getString("theme", "light-mode");
  const prefersDarkScheme = window.matchMedia("(prefers-color-scheme: dark)");
  if (currentTheme2 === "dark-mode" || prefersDarkScheme.matches)
    document.body.classList.add("dark-mode");
}
const listeners = /* @__PURE__ */ new Set();
function toggleTheme() {
  const oldTheme = settings.getString("theme", "light-mode");
  let newTheme;
  if (oldTheme === "dark-mode")
    newTheme = "light-mode";
  else
    newTheme = "dark-mode";
  if (oldTheme)
    document.body.classList.remove(oldTheme);
  document.body.classList.add(newTheme);
  settings.setString("theme", newTheme);
  for (const listener of listeners)
    listener(newTheme);
}
function addThemeListener(listener) {
  listeners.add(listener);
}
function removeThemeListener(listener) {
  listeners.delete(listener);
}
function currentTheme() {
  return document.body.classList.contains("dark-mode") ? "dark-mode" : "light-mode";
}
const codicon = "";
var reactDom = { exports: {} };
var reactDom_production_min = {};
var scheduler = { exports: {} };
var scheduler_production_min = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(exports) {
  function f2(a, b) {
    var c = a.length;
    a.push(b);
    a:
      for (; 0 < c; ) {
        var d = c - 1 >>> 1, e = a[d];
        if (0 < g(e, b))
          a[d] = b, a[c] = e, c = d;
        else
          break a;
      }
  }
  function h(a) {
    return 0 === a.length ? null : a[0];
  }
  function k2(a) {
    if (0 === a.length)
      return null;
    var b = a[0], c = a.pop();
    if (c !== b) {
      a[0] = c;
      a:
        for (var d = 0, e = a.length, w2 = e >>> 1; d < w2; ) {
          var m2 = 2 * (d + 1) - 1, C2 = a[m2], n2 = m2 + 1, x2 = a[n2];
          if (0 > g(C2, c))
            n2 < e && 0 > g(x2, C2) ? (a[d] = x2, a[n2] = c, d = n2) : (a[d] = C2, a[m2] = c, d = m2);
          else if (n2 < e && 0 > g(x2, c))
            a[d] = x2, a[n2] = c, d = n2;
          else
            break a;
        }
    }
    return b;
  }
  function g(a, b) {
    var c = a.sortIndex - b.sortIndex;
    return 0 !== c ? c : a.id - b.id;
  }
  if ("object" === typeof performance && "function" === typeof performance.now) {
    var l2 = performance;
    exports.unstable_now = function() {
      return l2.now();
    };
  } else {
    var p2 = Date, q2 = p2.now();
    exports.unstable_now = function() {
      return p2.now() - q2;
    };
  }
  var r2 = [], t2 = [], u2 = 1, v2 = null, y2 = 3, z2 = false, A2 = false, B2 = false, D2 = "function" === typeof setTimeout ? setTimeout : null, E2 = "function" === typeof clearTimeout ? clearTimeout : null, F2 = "undefined" !== typeof setImmediate ? setImmediate : null;
  "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function G2(a) {
    for (var b = h(t2); null !== b; ) {
      if (null === b.callback)
        k2(t2);
      else if (b.startTime <= a)
        k2(t2), b.sortIndex = b.expirationTime, f2(r2, b);
      else
        break;
      b = h(t2);
    }
  }
  function H2(a) {
    B2 = false;
    G2(a);
    if (!A2)
      if (null !== h(r2))
        A2 = true, I2(J2);
      else {
        var b = h(t2);
        null !== b && K2(H2, b.startTime - a);
      }
  }
  function J2(a, b) {
    A2 = false;
    B2 && (B2 = false, E2(L2), L2 = -1);
    z2 = true;
    var c = y2;
    try {
      G2(b);
      for (v2 = h(r2); null !== v2 && (!(v2.expirationTime > b) || a && !M2()); ) {
        var d = v2.callback;
        if ("function" === typeof d) {
          v2.callback = null;
          y2 = v2.priorityLevel;
          var e = d(v2.expirationTime <= b);
          b = exports.unstable_now();
          "function" === typeof e ? v2.callback = e : v2 === h(r2) && k2(r2);
          G2(b);
        } else
          k2(r2);
        v2 = h(r2);
      }
      if (null !== v2)
        var w2 = true;
      else {
        var m2 = h(t2);
        null !== m2 && K2(H2, m2.startTime - b);
        w2 = false;
      }
      return w2;
    } finally {
      v2 = null, y2 = c, z2 = false;
    }
  }
  var N2 = false, O2 = null, L2 = -1, P2 = 5, Q2 = -1;
  function M2() {
    return exports.unstable_now() - Q2 < P2 ? false : true;
  }
  function R2() {
    if (null !== O2) {
      var a = exports.unstable_now();
      Q2 = a;
      var b = true;
      try {
        b = O2(true, a);
      } finally {
        b ? S2() : (N2 = false, O2 = null);
      }
    } else
      N2 = false;
  }
  var S2;
  if ("function" === typeof F2)
    S2 = function() {
      F2(R2);
    };
  else if ("undefined" !== typeof MessageChannel) {
    var T2 = new MessageChannel(), U2 = T2.port2;
    T2.port1.onmessage = R2;
    S2 = function() {
      U2.postMessage(null);
    };
  } else
    S2 = function() {
      D2(R2, 0);
    };
  function I2(a) {
    O2 = a;
    N2 || (N2 = true, S2());
  }
  function K2(a, b) {
    L2 = D2(function() {
      a(exports.unstable_now());
    }, b);
  }
  exports.unstable_IdlePriority = 5;
  exports.unstable_ImmediatePriority = 1;
  exports.unstable_LowPriority = 4;
  exports.unstable_NormalPriority = 3;
  exports.unstable_Profiling = null;
  exports.unstable_UserBlockingPriority = 2;
  exports.unstable_cancelCallback = function(a) {
    a.callback = null;
  };
  exports.unstable_continueExecution = function() {
    A2 || z2 || (A2 = true, I2(J2));
  };
  exports.unstable_forceFrameRate = function(a) {
    0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P2 = 0 < a ? Math.floor(1e3 / a) : 5;
  };
  exports.unstable_getCurrentPriorityLevel = function() {
    return y2;
  };
  exports.unstable_getFirstCallbackNode = function() {
    return h(r2);
  };
  exports.unstable_next = function(a) {
    switch (y2) {
      case 1:
      case 2:
      case 3:
        var b = 3;
        break;
      default:
        b = y2;
    }
    var c = y2;
    y2 = b;
    try {
      return a();
    } finally {
      y2 = c;
    }
  };
  exports.unstable_pauseExecution = function() {
  };
  exports.unstable_requestPaint = function() {
  };
  exports.unstable_runWithPriority = function(a, b) {
    switch (a) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        a = 3;
    }
    var c = y2;
    y2 = a;
    try {
      return b();
    } finally {
      y2 = c;
    }
  };
  exports.unstable_scheduleCallback = function(a, b, c) {
    var d = exports.unstable_now();
    "object" === typeof c && null !== c ? (c = c.delay, c = "number" === typeof c && 0 < c ? d + c : d) : c = d;
    switch (a) {
      case 1:
        var e = -1;
        break;
      case 2:
        e = 250;
        break;
      case 5:
        e = 1073741823;
        break;
      case 4:
        e = 1e4;
        break;
      default:
        e = 5e3;
    }
    e = c + e;
    a = { id: u2++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1 };
    c > d ? (a.sortIndex = c, f2(t2, a), null === h(r2) && a === h(t2) && (B2 ? (E2(L2), L2 = -1) : B2 = true, K2(H2, c - d))) : (a.sortIndex = e, f2(r2, a), A2 || z2 || (A2 = true, I2(J2)));
    return a;
  };
  exports.unstable_shouldYield = M2;
  exports.unstable_wrapCallback = function(a) {
    var b = y2;
    return function() {
      var c = y2;
      y2 = b;
      try {
        return a.apply(this, arguments);
      } finally {
        y2 = c;
      }
    };
  };
})(scheduler_production_min);
{
  scheduler.exports = scheduler_production_min;
}
var schedulerExports = scheduler.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var aa = reactExports, ba = schedulerExports;
function p(a) {
  for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++)
    b += "&args[]=" + encodeURIComponent(arguments[c]);
  return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
var da = /* @__PURE__ */ new Set(), ea = {};
function fa(a, b) {
  ha(a, b);
  ha(a + "Capture", b);
}
function ha(a, b) {
  ea[a] = b;
  for (a = 0; a < b.length; a++)
    da.add(b[a]);
}
var ia = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement), ja = Object.prototype.hasOwnProperty, ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, la = {}, ma = {};
function na(a) {
  if (ja.call(ma, a))
    return true;
  if (ja.call(la, a))
    return false;
  if (ka.test(a))
    return ma[a] = true;
  la[a] = true;
  return false;
}
function oa(a, b, c, d) {
  if (null !== c && 0 === c.type)
    return false;
  switch (typeof b) {
    case "function":
    case "symbol":
      return true;
    case "boolean":
      if (d)
        return false;
      if (null !== c)
        return !c.acceptsBooleans;
      a = a.toLowerCase().slice(0, 5);
      return "data-" !== a && "aria-" !== a;
    default:
      return false;
  }
}
function pa(a, b, c, d) {
  if (null === b || "undefined" === typeof b || oa(a, b, c, d))
    return true;
  if (d)
    return false;
  if (null !== c)
    switch (c.type) {
      case 3:
        return !b;
      case 4:
        return false === b;
      case 5:
        return isNaN(b);
      case 6:
        return isNaN(b) || 1 > b;
    }
  return false;
}
function t(a, b, c, d, e, f2, g) {
  this.acceptsBooleans = 2 === b || 3 === b || 4 === b;
  this.attributeName = d;
  this.attributeNamespace = e;
  this.mustUseProperty = c;
  this.propertyName = a;
  this.type = b;
  this.sanitizeURL = f2;
  this.removeEmptyString = g;
}
var z = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
  z[a] = new t(a, 0, false, a, null, false, false);
});
[["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
  var b = a[0];
  z[b] = new t(b, 1, false, a[1], null, false, false);
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
  z[a] = new t(a, 2, false, a.toLowerCase(), null, false, false);
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
  z[a] = new t(a, 2, false, a, null, false, false);
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
  z[a] = new t(a, 3, false, a.toLowerCase(), null, false, false);
});
["checked", "multiple", "muted", "selected"].forEach(function(a) {
  z[a] = new t(a, 3, true, a, null, false, false);
});
["capture", "download"].forEach(function(a) {
  z[a] = new t(a, 4, false, a, null, false, false);
});
["cols", "rows", "size", "span"].forEach(function(a) {
  z[a] = new t(a, 6, false, a, null, false, false);
});
["rowSpan", "start"].forEach(function(a) {
  z[a] = new t(a, 5, false, a.toLowerCase(), null, false, false);
});
var qa = /[\-:]([a-z])/g;
function ra(a) {
  return a[1].toUpperCase();
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
  var b = a.replace(
    qa,
    ra
  );
  z[b] = new t(b, 1, false, a, null, false, false);
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
  var b = a.replace(qa, ra);
  z[b] = new t(b, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
});
["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
  var b = a.replace(qa, ra);
  z[b] = new t(b, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
});
["tabIndex", "crossOrigin"].forEach(function(a) {
  z[a] = new t(a, 1, false, a.toLowerCase(), null, false, false);
});
z.xlinkHref = new t("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
["src", "href", "action", "formAction"].forEach(function(a) {
  z[a] = new t(a, 1, false, a.toLowerCase(), null, true, true);
});
function sa(a, b, c, d) {
  var e = z.hasOwnProperty(b) ? z[b] : null;
  if (null !== e ? 0 !== e.type : d || !(2 < b.length) || "o" !== b[0] && "O" !== b[0] || "n" !== b[1] && "N" !== b[1])
    pa(b, c, e, d) && (c = null), d || null === e ? na(b) && (null === c ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = null === c ? 3 === e.type ? false : "" : c : (b = e.attributeName, d = e.attributeNamespace, null === c ? a.removeAttribute(b) : (e = e.type, c = 3 === e || 4 === e && true === c ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)));
}
var ta = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, ua = Symbol.for("react.element"), va = Symbol.for("react.portal"), wa = Symbol.for("react.fragment"), xa = Symbol.for("react.strict_mode"), za = Symbol.for("react.profiler"), Aa = Symbol.for("react.provider"), Ba = Symbol.for("react.context"), Ca = Symbol.for("react.forward_ref"), Da = Symbol.for("react.suspense"), Ea = Symbol.for("react.suspense_list"), Fa = Symbol.for("react.memo"), Ga = Symbol.for("react.lazy");
var Ha = Symbol.for("react.offscreen");
var Ia = Symbol.iterator;
function Ja(a) {
  if (null === a || "object" !== typeof a)
    return null;
  a = Ia && a[Ia] || a["@@iterator"];
  return "function" === typeof a ? a : null;
}
var A = Object.assign, Ka;
function La(a) {
  if (void 0 === Ka)
    try {
      throw Error();
    } catch (c) {
      var b = c.stack.trim().match(/\n( *(at )?)/);
      Ka = b && b[1] || "";
    }
  return "\n" + Ka + a;
}
var Ma = false;
function Na(a, b) {
  if (!a || Ma)
    return "";
  Ma = true;
  var c = Error.prepareStackTrace;
  Error.prepareStackTrace = void 0;
  try {
    if (b)
      if (b = function() {
        throw Error();
      }, Object.defineProperty(b.prototype, "props", { set: function() {
        throw Error();
      } }), "object" === typeof Reflect && Reflect.construct) {
        try {
          Reflect.construct(b, []);
        } catch (l2) {
          var d = l2;
        }
        Reflect.construct(a, [], b);
      } else {
        try {
          b.call();
        } catch (l2) {
          d = l2;
        }
        a.call(b.prototype);
      }
    else {
      try {
        throw Error();
      } catch (l2) {
        d = l2;
      }
      a();
    }
  } catch (l2) {
    if (l2 && d && "string" === typeof l2.stack) {
      for (var e = l2.stack.split("\n"), f2 = d.stack.split("\n"), g = e.length - 1, h = f2.length - 1; 1 <= g && 0 <= h && e[g] !== f2[h]; )
        h--;
      for (; 1 <= g && 0 <= h; g--, h--)
        if (e[g] !== f2[h]) {
          if (1 !== g || 1 !== h) {
            do
              if (g--, h--, 0 > h || e[g] !== f2[h]) {
                var k2 = "\n" + e[g].replace(" at new ", " at ");
                a.displayName && k2.includes("<anonymous>") && (k2 = k2.replace("<anonymous>", a.displayName));
                return k2;
              }
            while (1 <= g && 0 <= h);
          }
          break;
        }
    }
  } finally {
    Ma = false, Error.prepareStackTrace = c;
  }
  return (a = a ? a.displayName || a.name : "") ? La(a) : "";
}
function Oa(a) {
  switch (a.tag) {
    case 5:
      return La(a.type);
    case 16:
      return La("Lazy");
    case 13:
      return La("Suspense");
    case 19:
      return La("SuspenseList");
    case 0:
    case 2:
    case 15:
      return a = Na(a.type, false), a;
    case 11:
      return a = Na(a.type.render, false), a;
    case 1:
      return a = Na(a.type, true), a;
    default:
      return "";
  }
}
function Pa(a) {
  if (null == a)
    return null;
  if ("function" === typeof a)
    return a.displayName || a.name || null;
  if ("string" === typeof a)
    return a;
  switch (a) {
    case wa:
      return "Fragment";
    case va:
      return "Portal";
    case za:
      return "Profiler";
    case xa:
      return "StrictMode";
    case Da:
      return "Suspense";
    case Ea:
      return "SuspenseList";
  }
  if ("object" === typeof a)
    switch (a.$$typeof) {
      case Ba:
        return (a.displayName || "Context") + ".Consumer";
      case Aa:
        return (a._context.displayName || "Context") + ".Provider";
      case Ca:
        var b = a.render;
        a = a.displayName;
        a || (a = b.displayName || b.name || "", a = "" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
        return a;
      case Fa:
        return b = a.displayName || null, null !== b ? b : Pa(a.type) || "Memo";
      case Ga:
        b = a._payload;
        a = a._init;
        try {
          return Pa(a(b));
        } catch (c) {
        }
    }
  return null;
}
function Qa(a) {
  var b = a.type;
  switch (a.tag) {
    case 24:
      return "Cache";
    case 9:
      return (b.displayName || "Context") + ".Consumer";
    case 10:
      return (b._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return a = b.render, a = a.displayName || a.name || "", b.displayName || ("" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
    case 7:
      return "Fragment";
    case 5:
      return b;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return Pa(b);
    case 8:
      return b === xa ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if ("function" === typeof b)
        return b.displayName || b.name || null;
      if ("string" === typeof b)
        return b;
  }
  return null;
}
function Ra(a) {
  switch (typeof a) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return a;
    case "object":
      return a;
    default:
      return "";
  }
}
function Sa(a) {
  var b = a.type;
  return (a = a.nodeName) && "input" === a.toLowerCase() && ("checkbox" === b || "radio" === b);
}
function Ta(a) {
  var b = Sa(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
  if (!a.hasOwnProperty(b) && "undefined" !== typeof c && "function" === typeof c.get && "function" === typeof c.set) {
    var e = c.get, f2 = c.set;
    Object.defineProperty(a, b, { configurable: true, get: function() {
      return e.call(this);
    }, set: function(a2) {
      d = "" + a2;
      f2.call(this, a2);
    } });
    Object.defineProperty(a, b, { enumerable: c.enumerable });
    return { getValue: function() {
      return d;
    }, setValue: function(a2) {
      d = "" + a2;
    }, stopTracking: function() {
      a._valueTracker = null;
      delete a[b];
    } };
  }
}
function Ua(a) {
  a._valueTracker || (a._valueTracker = Ta(a));
}
function Va(a) {
  if (!a)
    return false;
  var b = a._valueTracker;
  if (!b)
    return true;
  var c = b.getValue();
  var d = "";
  a && (d = Sa(a) ? a.checked ? "true" : "false" : a.value);
  a = d;
  return a !== c ? (b.setValue(a), true) : false;
}
function Wa(a) {
  a = a || ("undefined" !== typeof document ? document : void 0);
  if ("undefined" === typeof a)
    return null;
  try {
    return a.activeElement || a.body;
  } catch (b) {
    return a.body;
  }
}
function Xa(a, b) {
  var c = b.checked;
  return A({}, b, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: null != c ? c : a._wrapperState.initialChecked });
}
function Ya(a, b) {
  var c = null == b.defaultValue ? "" : b.defaultValue, d = null != b.checked ? b.checked : b.defaultChecked;
  c = Ra(null != b.value ? b.value : c);
  a._wrapperState = { initialChecked: d, initialValue: c, controlled: "checkbox" === b.type || "radio" === b.type ? null != b.checked : null != b.value };
}
function Za(a, b) {
  b = b.checked;
  null != b && sa(a, "checked", b, false);
}
function $a(a, b) {
  Za(a, b);
  var c = Ra(b.value), d = b.type;
  if (null != c)
    if ("number" === d) {
      if (0 === c && "" === a.value || a.value != c)
        a.value = "" + c;
    } else
      a.value !== "" + c && (a.value = "" + c);
  else if ("submit" === d || "reset" === d) {
    a.removeAttribute("value");
    return;
  }
  b.hasOwnProperty("value") ? bb(a, b.type, c) : b.hasOwnProperty("defaultValue") && bb(a, b.type, Ra(b.defaultValue));
  null == b.checked && null != b.defaultChecked && (a.defaultChecked = !!b.defaultChecked);
}
function cb(a, b, c) {
  if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
    var d = b.type;
    if (!("submit" !== d && "reset" !== d || void 0 !== b.value && null !== b.value))
      return;
    b = "" + a._wrapperState.initialValue;
    c || b === a.value || (a.value = b);
    a.defaultValue = b;
  }
  c = a.name;
  "" !== c && (a.name = "");
  a.defaultChecked = !!a._wrapperState.initialChecked;
  "" !== c && (a.name = c);
}
function bb(a, b, c) {
  if ("number" !== b || Wa(a.ownerDocument) !== a)
    null == c ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
}
var db = Array.isArray;
function eb(a, b, c, d) {
  a = a.options;
  if (b) {
    b = {};
    for (var e = 0; e < c.length; e++)
      b["$" + c[e]] = true;
    for (c = 0; c < a.length; c++)
      e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = true);
  } else {
    c = "" + Ra(c);
    b = null;
    for (e = 0; e < a.length; e++) {
      if (a[e].value === c) {
        a[e].selected = true;
        d && (a[e].defaultSelected = true);
        return;
      }
      null !== b || a[e].disabled || (b = a[e]);
    }
    null !== b && (b.selected = true);
  }
}
function fb(a, b) {
  if (null != b.dangerouslySetInnerHTML)
    throw Error(p(91));
  return A({}, b, { value: void 0, defaultValue: void 0, children: "" + a._wrapperState.initialValue });
}
function gb(a, b) {
  var c = b.value;
  if (null == c) {
    c = b.children;
    b = b.defaultValue;
    if (null != c) {
      if (null != b)
        throw Error(p(92));
      if (db(c)) {
        if (1 < c.length)
          throw Error(p(93));
        c = c[0];
      }
      b = c;
    }
    null == b && (b = "");
    c = b;
  }
  a._wrapperState = { initialValue: Ra(c) };
}
function hb(a, b) {
  var c = Ra(b.value), d = Ra(b.defaultValue);
  null != c && (c = "" + c, c !== a.value && (a.value = c), null == b.defaultValue && a.defaultValue !== c && (a.defaultValue = c));
  null != d && (a.defaultValue = "" + d);
}
function ib(a) {
  var b = a.textContent;
  b === a._wrapperState.initialValue && "" !== b && null !== b && (a.value = b);
}
function jb(a) {
  switch (a) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function kb(a, b) {
  return null == a || "http://www.w3.org/1999/xhtml" === a ? jb(b) : "http://www.w3.org/2000/svg" === a && "foreignObject" === b ? "http://www.w3.org/1999/xhtml" : a;
}
var lb, mb = function(a) {
  return "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
    MSApp.execUnsafeLocalFunction(function() {
      return a(b, c, d, e);
    });
  } : a;
}(function(a, b) {
  if ("http://www.w3.org/2000/svg" !== a.namespaceURI || "innerHTML" in a)
    a.innerHTML = b;
  else {
    lb = lb || document.createElement("div");
    lb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
    for (b = lb.firstChild; a.firstChild; )
      a.removeChild(a.firstChild);
    for (; b.firstChild; )
      a.appendChild(b.firstChild);
  }
});
function nb(a, b) {
  if (b) {
    var c = a.firstChild;
    if (c && c === a.lastChild && 3 === c.nodeType) {
      c.nodeValue = b;
      return;
    }
  }
  a.textContent = b;
}
var ob = {
  animationIterationCount: true,
  aspectRatio: true,
  borderImageOutset: true,
  borderImageSlice: true,
  borderImageWidth: true,
  boxFlex: true,
  boxFlexGroup: true,
  boxOrdinalGroup: true,
  columnCount: true,
  columns: true,
  flex: true,
  flexGrow: true,
  flexPositive: true,
  flexShrink: true,
  flexNegative: true,
  flexOrder: true,
  gridArea: true,
  gridRow: true,
  gridRowEnd: true,
  gridRowSpan: true,
  gridRowStart: true,
  gridColumn: true,
  gridColumnEnd: true,
  gridColumnSpan: true,
  gridColumnStart: true,
  fontWeight: true,
  lineClamp: true,
  lineHeight: true,
  opacity: true,
  order: true,
  orphans: true,
  tabSize: true,
  widows: true,
  zIndex: true,
  zoom: true,
  fillOpacity: true,
  floodOpacity: true,
  stopOpacity: true,
  strokeDasharray: true,
  strokeDashoffset: true,
  strokeMiterlimit: true,
  strokeOpacity: true,
  strokeWidth: true
}, pb = ["Webkit", "ms", "Moz", "O"];
Object.keys(ob).forEach(function(a) {
  pb.forEach(function(b) {
    b = b + a.charAt(0).toUpperCase() + a.substring(1);
    ob[b] = ob[a];
  });
});
function qb(a, b, c) {
  return null == b || "boolean" === typeof b || "" === b ? "" : c || "number" !== typeof b || 0 === b || ob.hasOwnProperty(a) && ob[a] ? ("" + b).trim() : b + "px";
}
function rb(a, b) {
  a = a.style;
  for (var c in b)
    if (b.hasOwnProperty(c)) {
      var d = 0 === c.indexOf("--"), e = qb(c, b[c], d);
      "float" === c && (c = "cssFloat");
      d ? a.setProperty(c, e) : a[c] = e;
    }
}
var sb = A({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
function tb(a, b) {
  if (b) {
    if (sb[a] && (null != b.children || null != b.dangerouslySetInnerHTML))
      throw Error(p(137, a));
    if (null != b.dangerouslySetInnerHTML) {
      if (null != b.children)
        throw Error(p(60));
      if ("object" !== typeof b.dangerouslySetInnerHTML || !("__html" in b.dangerouslySetInnerHTML))
        throw Error(p(61));
    }
    if (null != b.style && "object" !== typeof b.style)
      throw Error(p(62));
  }
}
function ub(a, b) {
  if (-1 === a.indexOf("-"))
    return "string" === typeof b.is;
  switch (a) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return false;
    default:
      return true;
  }
}
var vb = null;
function wb(a) {
  a = a.target || a.srcElement || window;
  a.correspondingUseElement && (a = a.correspondingUseElement);
  return 3 === a.nodeType ? a.parentNode : a;
}
var xb = null, yb = null, zb = null;
function Ab(a) {
  if (a = Bb(a)) {
    if ("function" !== typeof xb)
      throw Error(p(280));
    var b = a.stateNode;
    b && (b = Cb(b), xb(a.stateNode, a.type, b));
  }
}
function Db(a) {
  yb ? zb ? zb.push(a) : zb = [a] : yb = a;
}
function Eb() {
  if (yb) {
    var a = yb, b = zb;
    zb = yb = null;
    Ab(a);
    if (b)
      for (a = 0; a < b.length; a++)
        Ab(b[a]);
  }
}
function Fb(a, b) {
  return a(b);
}
function Gb() {
}
var Hb = false;
function Ib(a, b, c) {
  if (Hb)
    return a(b, c);
  Hb = true;
  try {
    return Fb(a, b, c);
  } finally {
    if (Hb = false, null !== yb || null !== zb)
      Gb(), Eb();
  }
}
function Jb(a, b) {
  var c = a.stateNode;
  if (null === c)
    return null;
  var d = Cb(c);
  if (null === d)
    return null;
  c = d[b];
  a:
    switch (b) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (d = !d.disabled) || (a = a.type, d = !("button" === a || "input" === a || "select" === a || "textarea" === a));
        a = !d;
        break a;
      default:
        a = false;
    }
  if (a)
    return null;
  if (c && "function" !== typeof c)
    throw Error(p(231, b, typeof c));
  return c;
}
var Kb = false;
if (ia)
  try {
    var Lb = {};
    Object.defineProperty(Lb, "passive", { get: function() {
      Kb = true;
    } });
    window.addEventListener("test", Lb, Lb);
    window.removeEventListener("test", Lb, Lb);
  } catch (a) {
    Kb = false;
  }
function Mb(a, b, c, d, e, f2, g, h, k2) {
  var l2 = Array.prototype.slice.call(arguments, 3);
  try {
    b.apply(c, l2);
  } catch (n2) {
    this.onError(n2);
  }
}
var Nb = false, Ob = null, Pb = false, Qb = null, Rb = { onError: function(a) {
  Nb = true;
  Ob = a;
} };
function Sb(a, b, c, d, e, f2, g, h, k2) {
  Nb = false;
  Ob = null;
  Mb.apply(Rb, arguments);
}
function Tb(a, b, c, d, e, f2, g, h, k2) {
  Sb.apply(this, arguments);
  if (Nb) {
    if (Nb) {
      var l2 = Ob;
      Nb = false;
      Ob = null;
    } else
      throw Error(p(198));
    Pb || (Pb = true, Qb = l2);
  }
}
function Ub(a) {
  var b = a, c = a;
  if (a.alternate)
    for (; b.return; )
      b = b.return;
  else {
    a = b;
    do
      b = a, 0 !== (b.flags & 4098) && (c = b.return), a = b.return;
    while (a);
  }
  return 3 === b.tag ? c : null;
}
function Vb(a) {
  if (13 === a.tag) {
    var b = a.memoizedState;
    null === b && (a = a.alternate, null !== a && (b = a.memoizedState));
    if (null !== b)
      return b.dehydrated;
  }
  return null;
}
function Wb(a) {
  if (Ub(a) !== a)
    throw Error(p(188));
}
function Xb(a) {
  var b = a.alternate;
  if (!b) {
    b = Ub(a);
    if (null === b)
      throw Error(p(188));
    return b !== a ? null : a;
  }
  for (var c = a, d = b; ; ) {
    var e = c.return;
    if (null === e)
      break;
    var f2 = e.alternate;
    if (null === f2) {
      d = e.return;
      if (null !== d) {
        c = d;
        continue;
      }
      break;
    }
    if (e.child === f2.child) {
      for (f2 = e.child; f2; ) {
        if (f2 === c)
          return Wb(e), a;
        if (f2 === d)
          return Wb(e), b;
        f2 = f2.sibling;
      }
      throw Error(p(188));
    }
    if (c.return !== d.return)
      c = e, d = f2;
    else {
      for (var g = false, h = e.child; h; ) {
        if (h === c) {
          g = true;
          c = e;
          d = f2;
          break;
        }
        if (h === d) {
          g = true;
          d = e;
          c = f2;
          break;
        }
        h = h.sibling;
      }
      if (!g) {
        for (h = f2.child; h; ) {
          if (h === c) {
            g = true;
            c = f2;
            d = e;
            break;
          }
          if (h === d) {
            g = true;
            d = f2;
            c = e;
            break;
          }
          h = h.sibling;
        }
        if (!g)
          throw Error(p(189));
      }
    }
    if (c.alternate !== d)
      throw Error(p(190));
  }
  if (3 !== c.tag)
    throw Error(p(188));
  return c.stateNode.current === c ? a : b;
}
function Yb(a) {
  a = Xb(a);
  return null !== a ? Zb(a) : null;
}
function Zb(a) {
  if (5 === a.tag || 6 === a.tag)
    return a;
  for (a = a.child; null !== a; ) {
    var b = Zb(a);
    if (null !== b)
      return b;
    a = a.sibling;
  }
  return null;
}
var $b = ba.unstable_scheduleCallback, ac$1 = ba.unstable_cancelCallback, bc = ba.unstable_shouldYield, cc = ba.unstable_requestPaint, B = ba.unstable_now, dc = ba.unstable_getCurrentPriorityLevel, ec = ba.unstable_ImmediatePriority, fc = ba.unstable_UserBlockingPriority, gc = ba.unstable_NormalPriority, hc = ba.unstable_LowPriority, ic$1 = ba.unstable_IdlePriority, jc = null, kc = null;
function lc(a) {
  if (kc && "function" === typeof kc.onCommitFiberRoot)
    try {
      kc.onCommitFiberRoot(jc, a, void 0, 128 === (a.current.flags & 128));
    } catch (b) {
    }
}
var nc = Math.clz32 ? Math.clz32 : mc, oc = Math.log, pc = Math.LN2;
function mc(a) {
  a >>>= 0;
  return 0 === a ? 32 : 31 - (oc(a) / pc | 0) | 0;
}
var qc = 64, rc = 4194304;
function sc$1(a) {
  switch (a & -a) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return a & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return a & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return a;
  }
}
function tc(a, b) {
  var c = a.pendingLanes;
  if (0 === c)
    return 0;
  var d = 0, e = a.suspendedLanes, f2 = a.pingedLanes, g = c & 268435455;
  if (0 !== g) {
    var h = g & ~e;
    0 !== h ? d = sc$1(h) : (f2 &= g, 0 !== f2 && (d = sc$1(f2)));
  } else
    g = c & ~e, 0 !== g ? d = sc$1(g) : 0 !== f2 && (d = sc$1(f2));
  if (0 === d)
    return 0;
  if (0 !== b && b !== d && 0 === (b & e) && (e = d & -d, f2 = b & -b, e >= f2 || 16 === e && 0 !== (f2 & 4194240)))
    return b;
  0 !== (d & 4) && (d |= c & 16);
  b = a.entangledLanes;
  if (0 !== b)
    for (a = a.entanglements, b &= d; 0 < b; )
      c = 31 - nc(b), e = 1 << c, d |= a[c], b &= ~e;
  return d;
}
function uc(a, b) {
  switch (a) {
    case 1:
    case 2:
    case 4:
      return b + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return b + 5e3;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function vc(a, b) {
  for (var c = a.suspendedLanes, d = a.pingedLanes, e = a.expirationTimes, f2 = a.pendingLanes; 0 < f2; ) {
    var g = 31 - nc(f2), h = 1 << g, k2 = e[g];
    if (-1 === k2) {
      if (0 === (h & c) || 0 !== (h & d))
        e[g] = uc(h, b);
    } else
      k2 <= b && (a.expiredLanes |= h);
    f2 &= ~h;
  }
}
function wc(a) {
  a = a.pendingLanes & -1073741825;
  return 0 !== a ? a : a & 1073741824 ? 1073741824 : 0;
}
function xc() {
  var a = qc;
  qc <<= 1;
  0 === (qc & 4194240) && (qc = 64);
  return a;
}
function yc(a) {
  for (var b = [], c = 0; 31 > c; c++)
    b.push(a);
  return b;
}
function zc(a, b, c) {
  a.pendingLanes |= b;
  536870912 !== b && (a.suspendedLanes = 0, a.pingedLanes = 0);
  a = a.eventTimes;
  b = 31 - nc(b);
  a[b] = c;
}
function Ac(a, b) {
  var c = a.pendingLanes & ~b;
  a.pendingLanes = b;
  a.suspendedLanes = 0;
  a.pingedLanes = 0;
  a.expiredLanes &= b;
  a.mutableReadLanes &= b;
  a.entangledLanes &= b;
  b = a.entanglements;
  var d = a.eventTimes;
  for (a = a.expirationTimes; 0 < c; ) {
    var e = 31 - nc(c), f2 = 1 << e;
    b[e] = 0;
    d[e] = -1;
    a[e] = -1;
    c &= ~f2;
  }
}
function Bc(a, b) {
  var c = a.entangledLanes |= b;
  for (a = a.entanglements; c; ) {
    var d = 31 - nc(c), e = 1 << d;
    e & b | a[d] & b && (a[d] |= b);
    c &= ~e;
  }
}
var C = 0;
function Cc(a) {
  a &= -a;
  return 1 < a ? 4 < a ? 0 !== (a & 268435455) ? 16 : 536870912 : 4 : 1;
}
var Dc, Ec, Fc, Gc, Hc, Ic = false, Jc = [], Kc = null, Lc = null, Mc = null, Nc = /* @__PURE__ */ new Map(), Oc = /* @__PURE__ */ new Map(), Pc = [], Qc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function Rc(a, b) {
  switch (a) {
    case "focusin":
    case "focusout":
      Kc = null;
      break;
    case "dragenter":
    case "dragleave":
      Lc = null;
      break;
    case "mouseover":
    case "mouseout":
      Mc = null;
      break;
    case "pointerover":
    case "pointerout":
      Nc.delete(b.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      Oc.delete(b.pointerId);
  }
}
function Sc$1(a, b, c, d, e, f2) {
  if (null === a || a.nativeEvent !== f2)
    return a = { blockedOn: b, domEventName: c, eventSystemFlags: d, nativeEvent: f2, targetContainers: [e] }, null !== b && (b = Bb(b), null !== b && Ec(b)), a;
  a.eventSystemFlags |= d;
  b = a.targetContainers;
  null !== e && -1 === b.indexOf(e) && b.push(e);
  return a;
}
function Tc(a, b, c, d, e) {
  switch (b) {
    case "focusin":
      return Kc = Sc$1(Kc, a, b, c, d, e), true;
    case "dragenter":
      return Lc = Sc$1(Lc, a, b, c, d, e), true;
    case "mouseover":
      return Mc = Sc$1(Mc, a, b, c, d, e), true;
    case "pointerover":
      var f2 = e.pointerId;
      Nc.set(f2, Sc$1(Nc.get(f2) || null, a, b, c, d, e));
      return true;
    case "gotpointercapture":
      return f2 = e.pointerId, Oc.set(f2, Sc$1(Oc.get(f2) || null, a, b, c, d, e)), true;
  }
  return false;
}
function Uc(a) {
  var b = Vc(a.target);
  if (null !== b) {
    var c = Ub(b);
    if (null !== c) {
      if (b = c.tag, 13 === b) {
        if (b = Vb(c), null !== b) {
          a.blockedOn = b;
          Hc(a.priority, function() {
            Fc(c);
          });
          return;
        }
      } else if (3 === b && c.stateNode.current.memoizedState.isDehydrated) {
        a.blockedOn = 3 === c.tag ? c.stateNode.containerInfo : null;
        return;
      }
    }
  }
  a.blockedOn = null;
}
function Wc(a) {
  if (null !== a.blockedOn)
    return false;
  for (var b = a.targetContainers; 0 < b.length; ) {
    var c = Xc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
    if (null === c) {
      c = a.nativeEvent;
      var d = new c.constructor(c.type, c);
      vb = d;
      c.target.dispatchEvent(d);
      vb = null;
    } else
      return b = Bb(c), null !== b && Ec(b), a.blockedOn = c, false;
    b.shift();
  }
  return true;
}
function Yc(a, b, c) {
  Wc(a) && c.delete(b);
}
function Zc() {
  Ic = false;
  null !== Kc && Wc(Kc) && (Kc = null);
  null !== Lc && Wc(Lc) && (Lc = null);
  null !== Mc && Wc(Mc) && (Mc = null);
  Nc.forEach(Yc);
  Oc.forEach(Yc);
}
function $c(a, b) {
  a.blockedOn === b && (a.blockedOn = null, Ic || (Ic = true, ba.unstable_scheduleCallback(ba.unstable_NormalPriority, Zc)));
}
function ad(a) {
  function b(b2) {
    return $c(b2, a);
  }
  if (0 < Jc.length) {
    $c(Jc[0], a);
    for (var c = 1; c < Jc.length; c++) {
      var d = Jc[c];
      d.blockedOn === a && (d.blockedOn = null);
    }
  }
  null !== Kc && $c(Kc, a);
  null !== Lc && $c(Lc, a);
  null !== Mc && $c(Mc, a);
  Nc.forEach(b);
  Oc.forEach(b);
  for (c = 0; c < Pc.length; c++)
    d = Pc[c], d.blockedOn === a && (d.blockedOn = null);
  for (; 0 < Pc.length && (c = Pc[0], null === c.blockedOn); )
    Uc(c), null === c.blockedOn && Pc.shift();
}
var bd = ta.ReactCurrentBatchConfig, cd = true;
function dd$1(a, b, c, d) {
  var e = C, f2 = bd.transition;
  bd.transition = null;
  try {
    C = 1, ed(a, b, c, d);
  } finally {
    C = e, bd.transition = f2;
  }
}
function fd(a, b, c, d) {
  var e = C, f2 = bd.transition;
  bd.transition = null;
  try {
    C = 4, ed(a, b, c, d);
  } finally {
    C = e, bd.transition = f2;
  }
}
function ed(a, b, c, d) {
  if (cd) {
    var e = Xc(a, b, c, d);
    if (null === e)
      gd(a, b, d, hd, c), Rc(a, d);
    else if (Tc(e, a, b, c, d))
      d.stopPropagation();
    else if (Rc(a, d), b & 4 && -1 < Qc.indexOf(a)) {
      for (; null !== e; ) {
        var f2 = Bb(e);
        null !== f2 && Dc(f2);
        f2 = Xc(a, b, c, d);
        null === f2 && gd(a, b, d, hd, c);
        if (f2 === e)
          break;
        e = f2;
      }
      null !== e && d.stopPropagation();
    } else
      gd(a, b, d, null, c);
  }
}
var hd = null;
function Xc(a, b, c, d) {
  hd = null;
  a = wb(d);
  a = Vc(a);
  if (null !== a)
    if (b = Ub(a), null === b)
      a = null;
    else if (c = b.tag, 13 === c) {
      a = Vb(b);
      if (null !== a)
        return a;
      a = null;
    } else if (3 === c) {
      if (b.stateNode.current.memoizedState.isDehydrated)
        return 3 === b.tag ? b.stateNode.containerInfo : null;
      a = null;
    } else
      b !== a && (a = null);
  hd = a;
  return null;
}
function id(a) {
  switch (a) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (dc()) {
        case ec:
          return 1;
        case fc:
          return 4;
        case gc:
        case hc:
          return 16;
        case ic$1:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
var jd = null, kd = null, ld = null;
function md() {
  if (ld)
    return ld;
  var a, b = kd, c = b.length, d, e = "value" in jd ? jd.value : jd.textContent, f2 = e.length;
  for (a = 0; a < c && b[a] === e[a]; a++)
    ;
  var g = c - a;
  for (d = 1; d <= g && b[c - d] === e[f2 - d]; d++)
    ;
  return ld = e.slice(a, 1 < d ? 1 - d : void 0);
}
function nd(a) {
  var b = a.keyCode;
  "charCode" in a ? (a = a.charCode, 0 === a && 13 === b && (a = 13)) : a = b;
  10 === a && (a = 13);
  return 32 <= a || 13 === a ? a : 0;
}
function od() {
  return true;
}
function pd() {
  return false;
}
function qd(a) {
  function b(b2, d, e, f2, g) {
    this._reactName = b2;
    this._targetInst = e;
    this.type = d;
    this.nativeEvent = f2;
    this.target = g;
    this.currentTarget = null;
    for (var c in a)
      a.hasOwnProperty(c) && (b2 = a[c], this[c] = b2 ? b2(f2) : f2[c]);
    this.isDefaultPrevented = (null != f2.defaultPrevented ? f2.defaultPrevented : false === f2.returnValue) ? od : pd;
    this.isPropagationStopped = pd;
    return this;
  }
  A(b.prototype, { preventDefault: function() {
    this.defaultPrevented = true;
    var a2 = this.nativeEvent;
    a2 && (a2.preventDefault ? a2.preventDefault() : "unknown" !== typeof a2.returnValue && (a2.returnValue = false), this.isDefaultPrevented = od);
  }, stopPropagation: function() {
    var a2 = this.nativeEvent;
    a2 && (a2.stopPropagation ? a2.stopPropagation() : "unknown" !== typeof a2.cancelBubble && (a2.cancelBubble = true), this.isPropagationStopped = od);
  }, persist: function() {
  }, isPersistent: od });
  return b;
}
var rd = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
  return a.timeStamp || Date.now();
}, defaultPrevented: 0, isTrusted: 0 }, sd = qd(rd), td = A({}, rd, { view: 0, detail: 0 }), ud = qd(td), vd, wd, xd, zd = A({}, td, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: yd, button: 0, buttons: 0, relatedTarget: function(a) {
  return void 0 === a.relatedTarget ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
}, movementX: function(a) {
  if ("movementX" in a)
    return a.movementX;
  a !== xd && (xd && "mousemove" === a.type ? (vd = a.screenX - xd.screenX, wd = a.screenY - xd.screenY) : wd = vd = 0, xd = a);
  return vd;
}, movementY: function(a) {
  return "movementY" in a ? a.movementY : wd;
} }), Ad = qd(zd), Bd = A({}, zd, { dataTransfer: 0 }), Cd = qd(Bd), Dd = A({}, td, { relatedTarget: 0 }), Ed = qd(Dd), Fd = A({}, rd, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), Gd = qd(Fd), Hd = A({}, rd, { clipboardData: function(a) {
  return "clipboardData" in a ? a.clipboardData : window.clipboardData;
} }), Id = qd(Hd), Jd = A({}, rd, { data: 0 }), Kd = qd(Jd), Ld = {
  Esc: "Escape",
  Spacebar: " ",
  Left: "ArrowLeft",
  Up: "ArrowUp",
  Right: "ArrowRight",
  Down: "ArrowDown",
  Del: "Delete",
  Win: "OS",
  Menu: "ContextMenu",
  Apps: "ContextMenu",
  Scroll: "ScrollLock",
  MozPrintableKey: "Unidentified"
}, Md = {
  8: "Backspace",
  9: "Tab",
  12: "Clear",
  13: "Enter",
  16: "Shift",
  17: "Control",
  18: "Alt",
  19: "Pause",
  20: "CapsLock",
  27: "Escape",
  32: " ",
  33: "PageUp",
  34: "PageDown",
  35: "End",
  36: "Home",
  37: "ArrowLeft",
  38: "ArrowUp",
  39: "ArrowRight",
  40: "ArrowDown",
  45: "Insert",
  46: "Delete",
  112: "F1",
  113: "F2",
  114: "F3",
  115: "F4",
  116: "F5",
  117: "F6",
  118: "F7",
  119: "F8",
  120: "F9",
  121: "F10",
  122: "F11",
  123: "F12",
  144: "NumLock",
  145: "ScrollLock",
  224: "Meta"
}, Nd = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
function Od(a) {
  var b = this.nativeEvent;
  return b.getModifierState ? b.getModifierState(a) : (a = Nd[a]) ? !!b[a] : false;
}
function yd() {
  return Od;
}
var Pd = A({}, td, { key: function(a) {
  if (a.key) {
    var b = Ld[a.key] || a.key;
    if ("Unidentified" !== b)
      return b;
  }
  return "keypress" === a.type ? (a = nd(a), 13 === a ? "Enter" : String.fromCharCode(a)) : "keydown" === a.type || "keyup" === a.type ? Md[a.keyCode] || "Unidentified" : "";
}, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: yd, charCode: function(a) {
  return "keypress" === a.type ? nd(a) : 0;
}, keyCode: function(a) {
  return "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
}, which: function(a) {
  return "keypress" === a.type ? nd(a) : "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
} }), Qd = qd(Pd), Rd = A({}, zd, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), Sd = qd(Rd), Td = A({}, td, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: yd }), Ud = qd(Td), Vd = A({}, rd, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), Wd = qd(Vd), Xd = A({}, zd, {
  deltaX: function(a) {
    return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
  },
  deltaY: function(a) {
    return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
  },
  deltaZ: 0,
  deltaMode: 0
}), Yd = qd(Xd), Zd = [9, 13, 27, 32], $d = ia && "CompositionEvent" in window, ae = null;
ia && "documentMode" in document && (ae = document.documentMode);
var be = ia && "TextEvent" in window && !ae, ce = ia && (!$d || ae && 8 < ae && 11 >= ae), de = String.fromCharCode(32), ee$1 = false;
function fe(a, b) {
  switch (a) {
    case "keyup":
      return -1 !== Zd.indexOf(b.keyCode);
    case "keydown":
      return 229 !== b.keyCode;
    case "keypress":
    case "mousedown":
    case "focusout":
      return true;
    default:
      return false;
  }
}
function ge$1(a) {
  a = a.detail;
  return "object" === typeof a && "data" in a ? a.data : null;
}
var he = false;
function ie(a, b) {
  switch (a) {
    case "compositionend":
      return ge$1(b);
    case "keypress":
      if (32 !== b.which)
        return null;
      ee$1 = true;
      return de;
    case "textInput":
      return a = b.data, a === de && ee$1 ? null : a;
    default:
      return null;
  }
}
function je(a, b) {
  if (he)
    return "compositionend" === a || !$d && fe(a, b) ? (a = md(), ld = kd = jd = null, he = false, a) : null;
  switch (a) {
    case "paste":
      return null;
    case "keypress":
      if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
        if (b.char && 1 < b.char.length)
          return b.char;
        if (b.which)
          return String.fromCharCode(b.which);
      }
      return null;
    case "compositionend":
      return ce && "ko" !== b.locale ? null : b.data;
    default:
      return null;
  }
}
var ke = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
function le$1(a) {
  var b = a && a.nodeName && a.nodeName.toLowerCase();
  return "input" === b ? !!ke[a.type] : "textarea" === b ? true : false;
}
function me(a, b, c, d) {
  Db(d);
  b = ne$1(b, "onChange");
  0 < b.length && (c = new sd("onChange", "change", null, c, d), a.push({ event: c, listeners: b }));
}
var oe = null, pe = null;
function qe(a) {
  re(a, 0);
}
function se(a) {
  var b = te(a);
  if (Va(b))
    return a;
}
function ue(a, b) {
  if ("change" === a)
    return b;
}
var ve = false;
if (ia) {
  var we;
  if (ia) {
    var xe = "oninput" in document;
    if (!xe) {
      var ye = document.createElement("div");
      ye.setAttribute("oninput", "return;");
      xe = "function" === typeof ye.oninput;
    }
    we = xe;
  } else
    we = false;
  ve = we && (!document.documentMode || 9 < document.documentMode);
}
function ze() {
  oe && (oe.detachEvent("onpropertychange", Ae), pe = oe = null);
}
function Ae(a) {
  if ("value" === a.propertyName && se(pe)) {
    var b = [];
    me(b, pe, a, wb(a));
    Ib(qe, b);
  }
}
function Be(a, b, c) {
  "focusin" === a ? (ze(), oe = b, pe = c, oe.attachEvent("onpropertychange", Ae)) : "focusout" === a && ze();
}
function Ce(a) {
  if ("selectionchange" === a || "keyup" === a || "keydown" === a)
    return se(pe);
}
function De(a, b) {
  if ("click" === a)
    return se(b);
}
function Ee(a, b) {
  if ("input" === a || "change" === a)
    return se(b);
}
function Fe(a, b) {
  return a === b && (0 !== a || 1 / a === 1 / b) || a !== a && b !== b;
}
var Ge = "function" === typeof Object.is ? Object.is : Fe;
function He(a, b) {
  if (Ge(a, b))
    return true;
  if ("object" !== typeof a || null === a || "object" !== typeof b || null === b)
    return false;
  var c = Object.keys(a), d = Object.keys(b);
  if (c.length !== d.length)
    return false;
  for (d = 0; d < c.length; d++) {
    var e = c[d];
    if (!ja.call(b, e) || !Ge(a[e], b[e]))
      return false;
  }
  return true;
}
function Ie(a) {
  for (; a && a.firstChild; )
    a = a.firstChild;
  return a;
}
function Je(a, b) {
  var c = Ie(a);
  a = 0;
  for (var d; c; ) {
    if (3 === c.nodeType) {
      d = a + c.textContent.length;
      if (a <= b && d >= b)
        return { node: c, offset: b - a };
      a = d;
    }
    a: {
      for (; c; ) {
        if (c.nextSibling) {
          c = c.nextSibling;
          break a;
        }
        c = c.parentNode;
      }
      c = void 0;
    }
    c = Ie(c);
  }
}
function Ke(a, b) {
  return a && b ? a === b ? true : a && 3 === a.nodeType ? false : b && 3 === b.nodeType ? Ke(a, b.parentNode) : "contains" in a ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : false : false;
}
function Le() {
  for (var a = window, b = Wa(); b instanceof a.HTMLIFrameElement; ) {
    try {
      var c = "string" === typeof b.contentWindow.location.href;
    } catch (d) {
      c = false;
    }
    if (c)
      a = b.contentWindow;
    else
      break;
    b = Wa(a.document);
  }
  return b;
}
function Me(a) {
  var b = a && a.nodeName && a.nodeName.toLowerCase();
  return b && ("input" === b && ("text" === a.type || "search" === a.type || "tel" === a.type || "url" === a.type || "password" === a.type) || "textarea" === b || "true" === a.contentEditable);
}
function Ne(a) {
  var b = Le(), c = a.focusedElem, d = a.selectionRange;
  if (b !== c && c && c.ownerDocument && Ke(c.ownerDocument.documentElement, c)) {
    if (null !== d && Me(c)) {
      if (b = d.start, a = d.end, void 0 === a && (a = b), "selectionStart" in c)
        c.selectionStart = b, c.selectionEnd = Math.min(a, c.value.length);
      else if (a = (b = c.ownerDocument || document) && b.defaultView || window, a.getSelection) {
        a = a.getSelection();
        var e = c.textContent.length, f2 = Math.min(d.start, e);
        d = void 0 === d.end ? f2 : Math.min(d.end, e);
        !a.extend && f2 > d && (e = d, d = f2, f2 = e);
        e = Je(c, f2);
        var g = Je(
          c,
          d
        );
        e && g && (1 !== a.rangeCount || a.anchorNode !== e.node || a.anchorOffset !== e.offset || a.focusNode !== g.node || a.focusOffset !== g.offset) && (b = b.createRange(), b.setStart(e.node, e.offset), a.removeAllRanges(), f2 > d ? (a.addRange(b), a.extend(g.node, g.offset)) : (b.setEnd(g.node, g.offset), a.addRange(b)));
      }
    }
    b = [];
    for (a = c; a = a.parentNode; )
      1 === a.nodeType && b.push({ element: a, left: a.scrollLeft, top: a.scrollTop });
    "function" === typeof c.focus && c.focus();
    for (c = 0; c < b.length; c++)
      a = b[c], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
  }
}
var Oe = ia && "documentMode" in document && 11 >= document.documentMode, Pe = null, Qe = null, Re$1 = null, Se = false;
function Te(a, b, c) {
  var d = c.window === c ? c.document : 9 === c.nodeType ? c : c.ownerDocument;
  Se || null == Pe || Pe !== Wa(d) || (d = Pe, "selectionStart" in d && Me(d) ? d = { start: d.selectionStart, end: d.selectionEnd } : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = { anchorNode: d.anchorNode, anchorOffset: d.anchorOffset, focusNode: d.focusNode, focusOffset: d.focusOffset }), Re$1 && He(Re$1, d) || (Re$1 = d, d = ne$1(Qe, "onSelect"), 0 < d.length && (b = new sd("onSelect", "select", null, b, c), a.push({ event: b, listeners: d }), b.target = Pe)));
}
function Ue(a, b) {
  var c = {};
  c[a.toLowerCase()] = b.toLowerCase();
  c["Webkit" + a] = "webkit" + b;
  c["Moz" + a] = "moz" + b;
  return c;
}
var Ve = { animationend: Ue("Animation", "AnimationEnd"), animationiteration: Ue("Animation", "AnimationIteration"), animationstart: Ue("Animation", "AnimationStart"), transitionend: Ue("Transition", "TransitionEnd") }, We = {}, Xe = {};
ia && (Xe = document.createElement("div").style, "AnimationEvent" in window || (delete Ve.animationend.animation, delete Ve.animationiteration.animation, delete Ve.animationstart.animation), "TransitionEvent" in window || delete Ve.transitionend.transition);
function Ye(a) {
  if (We[a])
    return We[a];
  if (!Ve[a])
    return a;
  var b = Ve[a], c;
  for (c in b)
    if (b.hasOwnProperty(c) && c in Xe)
      return We[a] = b[c];
  return a;
}
var Ze = Ye("animationend"), $e = Ye("animationiteration"), af$1 = Ye("animationstart"), bf = Ye("transitionend"), cf = /* @__PURE__ */ new Map(), df = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function ef(a, b) {
  cf.set(a, b);
  fa(b, [a]);
}
for (var ff = 0; ff < df.length; ff++) {
  var gf = df[ff], hf = gf.toLowerCase(), jf = gf[0].toUpperCase() + gf.slice(1);
  ef(hf, "on" + jf);
}
ef(Ze, "onAnimationEnd");
ef($e, "onAnimationIteration");
ef(af$1, "onAnimationStart");
ef("dblclick", "onDoubleClick");
ef("focusin", "onFocus");
ef("focusout", "onBlur");
ef(bf, "onTransitionEnd");
ha("onMouseEnter", ["mouseout", "mouseover"]);
ha("onMouseLeave", ["mouseout", "mouseover"]);
ha("onPointerEnter", ["pointerout", "pointerover"]);
ha("onPointerLeave", ["pointerout", "pointerover"]);
fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
fa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var kf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), lf = new Set("cancel close invalid load scroll toggle".split(" ").concat(kf));
function mf(a, b, c) {
  var d = a.type || "unknown-event";
  a.currentTarget = c;
  Tb(d, b, void 0, a);
  a.currentTarget = null;
}
function re(a, b) {
  b = 0 !== (b & 4);
  for (var c = 0; c < a.length; c++) {
    var d = a[c], e = d.event;
    d = d.listeners;
    a: {
      var f2 = void 0;
      if (b)
        for (var g = d.length - 1; 0 <= g; g--) {
          var h = d[g], k2 = h.instance, l2 = h.currentTarget;
          h = h.listener;
          if (k2 !== f2 && e.isPropagationStopped())
            break a;
          mf(e, h, l2);
          f2 = k2;
        }
      else
        for (g = 0; g < d.length; g++) {
          h = d[g];
          k2 = h.instance;
          l2 = h.currentTarget;
          h = h.listener;
          if (k2 !== f2 && e.isPropagationStopped())
            break a;
          mf(e, h, l2);
          f2 = k2;
        }
    }
  }
  if (Pb)
    throw a = Qb, Pb = false, Qb = null, a;
}
function D(a, b) {
  var c = b[nf];
  void 0 === c && (c = b[nf] = /* @__PURE__ */ new Set());
  var d = a + "__bubble";
  c.has(d) || (of(b, a, 2, false), c.add(d));
}
function pf(a, b, c) {
  var d = 0;
  b && (d |= 4);
  of(c, a, d, b);
}
var qf = "_reactListening" + Math.random().toString(36).slice(2);
function rf(a) {
  if (!a[qf]) {
    a[qf] = true;
    da.forEach(function(b2) {
      "selectionchange" !== b2 && (lf.has(b2) || pf(b2, false, a), pf(b2, true, a));
    });
    var b = 9 === a.nodeType ? a : a.ownerDocument;
    null === b || b[qf] || (b[qf] = true, pf("selectionchange", false, b));
  }
}
function of(a, b, c, d) {
  switch (id(b)) {
    case 1:
      var e = dd$1;
      break;
    case 4:
      e = fd;
      break;
    default:
      e = ed;
  }
  c = e.bind(null, b, c, a);
  e = void 0;
  !Kb || "touchstart" !== b && "touchmove" !== b && "wheel" !== b || (e = true);
  d ? void 0 !== e ? a.addEventListener(b, c, { capture: true, passive: e }) : a.addEventListener(b, c, true) : void 0 !== e ? a.addEventListener(b, c, { passive: e }) : a.addEventListener(b, c, false);
}
function gd(a, b, c, d, e) {
  var f2 = d;
  if (0 === (b & 1) && 0 === (b & 2) && null !== d)
    a:
      for (; ; ) {
        if (null === d)
          return;
        var g = d.tag;
        if (3 === g || 4 === g) {
          var h = d.stateNode.containerInfo;
          if (h === e || 8 === h.nodeType && h.parentNode === e)
            break;
          if (4 === g)
            for (g = d.return; null !== g; ) {
              var k2 = g.tag;
              if (3 === k2 || 4 === k2) {
                if (k2 = g.stateNode.containerInfo, k2 === e || 8 === k2.nodeType && k2.parentNode === e)
                  return;
              }
              g = g.return;
            }
          for (; null !== h; ) {
            g = Vc(h);
            if (null === g)
              return;
            k2 = g.tag;
            if (5 === k2 || 6 === k2) {
              d = f2 = g;
              continue a;
            }
            h = h.parentNode;
          }
        }
        d = d.return;
      }
  Ib(function() {
    var d2 = f2, e2 = wb(c), g2 = [];
    a: {
      var h2 = cf.get(a);
      if (void 0 !== h2) {
        var k3 = sd, m2 = a;
        switch (a) {
          case "keypress":
            if (0 === nd(c))
              break a;
          case "keydown":
          case "keyup":
            k3 = Qd;
            break;
          case "focusin":
            m2 = "focus";
            k3 = Ed;
            break;
          case "focusout":
            m2 = "blur";
            k3 = Ed;
            break;
          case "beforeblur":
          case "afterblur":
            k3 = Ed;
            break;
          case "click":
            if (2 === c.button)
              break a;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            k3 = Ad;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            k3 = Cd;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            k3 = Ud;
            break;
          case Ze:
          case $e:
          case af$1:
            k3 = Gd;
            break;
          case bf:
            k3 = Wd;
            break;
          case "scroll":
            k3 = ud;
            break;
          case "wheel":
            k3 = Yd;
            break;
          case "copy":
          case "cut":
          case "paste":
            k3 = Id;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            k3 = Sd;
        }
        var w2 = 0 !== (b & 4), J2 = !w2 && "scroll" === a, v2 = w2 ? null !== h2 ? h2 + "Capture" : null : h2;
        w2 = [];
        for (var x2 = d2, r2; null !== x2; ) {
          r2 = x2;
          var F2 = r2.stateNode;
          5 === r2.tag && null !== F2 && (r2 = F2, null !== v2 && (F2 = Jb(x2, v2), null != F2 && w2.push(sf(x2, F2, r2))));
          if (J2)
            break;
          x2 = x2.return;
        }
        0 < w2.length && (h2 = new k3(h2, m2, null, c, e2), g2.push({ event: h2, listeners: w2 }));
      }
    }
    if (0 === (b & 7)) {
      a: {
        h2 = "mouseover" === a || "pointerover" === a;
        k3 = "mouseout" === a || "pointerout" === a;
        if (h2 && c !== vb && (m2 = c.relatedTarget || c.fromElement) && (Vc(m2) || m2[tf]))
          break a;
        if (k3 || h2) {
          h2 = e2.window === e2 ? e2 : (h2 = e2.ownerDocument) ? h2.defaultView || h2.parentWindow : window;
          if (k3) {
            if (m2 = c.relatedTarget || c.toElement, k3 = d2, m2 = m2 ? Vc(m2) : null, null !== m2 && (J2 = Ub(m2), m2 !== J2 || 5 !== m2.tag && 6 !== m2.tag))
              m2 = null;
          } else
            k3 = null, m2 = d2;
          if (k3 !== m2) {
            w2 = Ad;
            F2 = "onMouseLeave";
            v2 = "onMouseEnter";
            x2 = "mouse";
            if ("pointerout" === a || "pointerover" === a)
              w2 = Sd, F2 = "onPointerLeave", v2 = "onPointerEnter", x2 = "pointer";
            J2 = null == k3 ? h2 : te(k3);
            r2 = null == m2 ? h2 : te(m2);
            h2 = new w2(F2, x2 + "leave", k3, c, e2);
            h2.target = J2;
            h2.relatedTarget = r2;
            F2 = null;
            Vc(e2) === d2 && (w2 = new w2(v2, x2 + "enter", m2, c, e2), w2.target = r2, w2.relatedTarget = J2, F2 = w2);
            J2 = F2;
            if (k3 && m2)
              b: {
                w2 = k3;
                v2 = m2;
                x2 = 0;
                for (r2 = w2; r2; r2 = uf(r2))
                  x2++;
                r2 = 0;
                for (F2 = v2; F2; F2 = uf(F2))
                  r2++;
                for (; 0 < x2 - r2; )
                  w2 = uf(w2), x2--;
                for (; 0 < r2 - x2; )
                  v2 = uf(v2), r2--;
                for (; x2--; ) {
                  if (w2 === v2 || null !== v2 && w2 === v2.alternate)
                    break b;
                  w2 = uf(w2);
                  v2 = uf(v2);
                }
                w2 = null;
              }
            else
              w2 = null;
            null !== k3 && vf(g2, h2, k3, w2, false);
            null !== m2 && null !== J2 && vf(g2, J2, m2, w2, true);
          }
        }
      }
      a: {
        h2 = d2 ? te(d2) : window;
        k3 = h2.nodeName && h2.nodeName.toLowerCase();
        if ("select" === k3 || "input" === k3 && "file" === h2.type)
          var Z = ue;
        else if (le$1(h2))
          if (ve)
            Z = Ee;
          else {
            Z = Ce;
            var ya = Be;
          }
        else
          (k3 = h2.nodeName) && "input" === k3.toLowerCase() && ("checkbox" === h2.type || "radio" === h2.type) && (Z = De);
        if (Z && (Z = Z(a, d2))) {
          me(g2, Z, c, e2);
          break a;
        }
        ya && ya(a, h2, d2);
        "focusout" === a && (ya = h2._wrapperState) && ya.controlled && "number" === h2.type && bb(h2, "number", h2.value);
      }
      ya = d2 ? te(d2) : window;
      switch (a) {
        case "focusin":
          if (le$1(ya) || "true" === ya.contentEditable)
            Pe = ya, Qe = d2, Re$1 = null;
          break;
        case "focusout":
          Re$1 = Qe = Pe = null;
          break;
        case "mousedown":
          Se = true;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          Se = false;
          Te(g2, c, e2);
          break;
        case "selectionchange":
          if (Oe)
            break;
        case "keydown":
        case "keyup":
          Te(g2, c, e2);
      }
      var ab;
      if ($d)
        b: {
          switch (a) {
            case "compositionstart":
              var ca = "onCompositionStart";
              break b;
            case "compositionend":
              ca = "onCompositionEnd";
              break b;
            case "compositionupdate":
              ca = "onCompositionUpdate";
              break b;
          }
          ca = void 0;
        }
      else
        he ? fe(a, c) && (ca = "onCompositionEnd") : "keydown" === a && 229 === c.keyCode && (ca = "onCompositionStart");
      ca && (ce && "ko" !== c.locale && (he || "onCompositionStart" !== ca ? "onCompositionEnd" === ca && he && (ab = md()) : (jd = e2, kd = "value" in jd ? jd.value : jd.textContent, he = true)), ya = ne$1(d2, ca), 0 < ya.length && (ca = new Kd(ca, a, null, c, e2), g2.push({ event: ca, listeners: ya }), ab ? ca.data = ab : (ab = ge$1(c), null !== ab && (ca.data = ab))));
      if (ab = be ? ie(a, c) : je(a, c))
        d2 = ne$1(d2, "onBeforeInput"), 0 < d2.length && (e2 = new Kd("onBeforeInput", "beforeinput", null, c, e2), g2.push({ event: e2, listeners: d2 }), e2.data = ab);
    }
    re(g2, b);
  });
}
function sf(a, b, c) {
  return { instance: a, listener: b, currentTarget: c };
}
function ne$1(a, b) {
  for (var c = b + "Capture", d = []; null !== a; ) {
    var e = a, f2 = e.stateNode;
    5 === e.tag && null !== f2 && (e = f2, f2 = Jb(a, c), null != f2 && d.unshift(sf(a, f2, e)), f2 = Jb(a, b), null != f2 && d.push(sf(a, f2, e)));
    a = a.return;
  }
  return d;
}
function uf(a) {
  if (null === a)
    return null;
  do
    a = a.return;
  while (a && 5 !== a.tag);
  return a ? a : null;
}
function vf(a, b, c, d, e) {
  for (var f2 = b._reactName, g = []; null !== c && c !== d; ) {
    var h = c, k2 = h.alternate, l2 = h.stateNode;
    if (null !== k2 && k2 === d)
      break;
    5 === h.tag && null !== l2 && (h = l2, e ? (k2 = Jb(c, f2), null != k2 && g.unshift(sf(c, k2, h))) : e || (k2 = Jb(c, f2), null != k2 && g.push(sf(c, k2, h))));
    c = c.return;
  }
  0 !== g.length && a.push({ event: b, listeners: g });
}
var wf = /\r\n?/g, xf = /\u0000|\uFFFD/g;
function yf(a) {
  return ("string" === typeof a ? a : "" + a).replace(wf, "\n").replace(xf, "");
}
function zf(a, b, c) {
  b = yf(b);
  if (yf(a) !== b && c)
    throw Error(p(425));
}
function Af() {
}
var Bf = null, Cf = null;
function Df(a, b) {
  return "textarea" === a || "noscript" === a || "string" === typeof b.children || "number" === typeof b.children || "object" === typeof b.dangerouslySetInnerHTML && null !== b.dangerouslySetInnerHTML && null != b.dangerouslySetInnerHTML.__html;
}
var Ef = "function" === typeof setTimeout ? setTimeout : void 0, Ff = "function" === typeof clearTimeout ? clearTimeout : void 0, Gf = "function" === typeof Promise ? Promise : void 0, If = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof Gf ? function(a) {
  return Gf.resolve(null).then(a).catch(Hf);
} : Ef;
function Hf(a) {
  setTimeout(function() {
    throw a;
  });
}
function Jf(a, b) {
  var c = b, d = 0;
  do {
    var e = c.nextSibling;
    a.removeChild(c);
    if (e && 8 === e.nodeType)
      if (c = e.data, "/$" === c) {
        if (0 === d) {
          a.removeChild(e);
          ad(b);
          return;
        }
        d--;
      } else
        "$" !== c && "$?" !== c && "$!" !== c || d++;
    c = e;
  } while (c);
  ad(b);
}
function Kf(a) {
  for (; null != a; a = a.nextSibling) {
    var b = a.nodeType;
    if (1 === b || 3 === b)
      break;
    if (8 === b) {
      b = a.data;
      if ("$" === b || "$!" === b || "$?" === b)
        break;
      if ("/$" === b)
        return null;
    }
  }
  return a;
}
function Lf(a) {
  a = a.previousSibling;
  for (var b = 0; a; ) {
    if (8 === a.nodeType) {
      var c = a.data;
      if ("$" === c || "$!" === c || "$?" === c) {
        if (0 === b)
          return a;
        b--;
      } else
        "/$" === c && b++;
    }
    a = a.previousSibling;
  }
  return null;
}
var Mf = Math.random().toString(36).slice(2), Nf = "__reactFiber$" + Mf, Of = "__reactProps$" + Mf, tf = "__reactContainer$" + Mf, nf = "__reactEvents$" + Mf, Pf = "__reactListeners$" + Mf, Qf = "__reactHandles$" + Mf;
function Vc(a) {
  var b = a[Nf];
  if (b)
    return b;
  for (var c = a.parentNode; c; ) {
    if (b = c[tf] || c[Nf]) {
      c = b.alternate;
      if (null !== b.child || null !== c && null !== c.child)
        for (a = Lf(a); null !== a; ) {
          if (c = a[Nf])
            return c;
          a = Lf(a);
        }
      return b;
    }
    a = c;
    c = a.parentNode;
  }
  return null;
}
function Bb(a) {
  a = a[Nf] || a[tf];
  return !a || 5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag ? null : a;
}
function te(a) {
  if (5 === a.tag || 6 === a.tag)
    return a.stateNode;
  throw Error(p(33));
}
function Cb(a) {
  return a[Of] || null;
}
var Rf = [], Sf = -1;
function Tf(a) {
  return { current: a };
}
function E(a) {
  0 > Sf || (a.current = Rf[Sf], Rf[Sf] = null, Sf--);
}
function G(a, b) {
  Sf++;
  Rf[Sf] = a.current;
  a.current = b;
}
var Uf = {}, H = Tf(Uf), Vf = Tf(false), Wf = Uf;
function Xf(a, b) {
  var c = a.type.contextTypes;
  if (!c)
    return Uf;
  var d = a.stateNode;
  if (d && d.__reactInternalMemoizedUnmaskedChildContext === b)
    return d.__reactInternalMemoizedMaskedChildContext;
  var e = {}, f2;
  for (f2 in c)
    e[f2] = b[f2];
  d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
  return e;
}
function Yf(a) {
  a = a.childContextTypes;
  return null !== a && void 0 !== a;
}
function Zf() {
  E(Vf);
  E(H);
}
function $f(a, b, c) {
  if (H.current !== Uf)
    throw Error(p(168));
  G(H, b);
  G(Vf, c);
}
function ag(a, b, c) {
  var d = a.stateNode;
  b = b.childContextTypes;
  if ("function" !== typeof d.getChildContext)
    return c;
  d = d.getChildContext();
  for (var e in d)
    if (!(e in b))
      throw Error(p(108, Qa(a) || "Unknown", e));
  return A({}, c, d);
}
function bg(a) {
  a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Uf;
  Wf = H.current;
  G(H, a);
  G(Vf, Vf.current);
  return true;
}
function cg(a, b, c) {
  var d = a.stateNode;
  if (!d)
    throw Error(p(169));
  c ? (a = ag(a, b, Wf), d.__reactInternalMemoizedMergedChildContext = a, E(Vf), E(H), G(H, a)) : E(Vf);
  G(Vf, c);
}
var dg = null, eg$1 = false, fg = false;
function gg$1(a) {
  null === dg ? dg = [a] : dg.push(a);
}
function hg(a) {
  eg$1 = true;
  gg$1(a);
}
function ig() {
  if (!fg && null !== dg) {
    fg = true;
    var a = 0, b = C;
    try {
      var c = dg;
      for (C = 1; a < c.length; a++) {
        var d = c[a];
        do
          d = d(true);
        while (null !== d);
      }
      dg = null;
      eg$1 = false;
    } catch (e) {
      throw null !== dg && (dg = dg.slice(a + 1)), $b(ec, ig), e;
    } finally {
      C = b, fg = false;
    }
  }
  return null;
}
var jg = ta.ReactCurrentBatchConfig;
function kg(a, b) {
  if (a && a.defaultProps) {
    b = A({}, b);
    a = a.defaultProps;
    for (var c in a)
      void 0 === b[c] && (b[c] = a[c]);
    return b;
  }
  return b;
}
var lg$1 = Tf(null), mg = null, ng = null, og = null;
function pg() {
  og = ng = mg = null;
}
function qg(a) {
  var b = lg$1.current;
  E(lg$1);
  a._currentValue = b;
}
function rg(a, b, c) {
  for (; null !== a; ) {
    var d = a.alternate;
    (a.childLanes & b) !== b ? (a.childLanes |= b, null !== d && (d.childLanes |= b)) : null !== d && (d.childLanes & b) !== b && (d.childLanes |= b);
    if (a === c)
      break;
    a = a.return;
  }
}
function sg(a, b) {
  mg = a;
  og = ng = null;
  a = a.dependencies;
  null !== a && null !== a.firstContext && (0 !== (a.lanes & b) && (tg = true), a.firstContext = null);
}
function ug(a) {
  var b = a._currentValue;
  if (og !== a)
    if (a = { context: a, memoizedValue: b, next: null }, null === ng) {
      if (null === mg)
        throw Error(p(308));
      ng = a;
      mg.dependencies = { lanes: 0, firstContext: a };
    } else
      ng = ng.next = a;
  return b;
}
var vg = null, wg = false;
function xg(a) {
  a.updateQueue = { baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
}
function yg(a, b) {
  a = a.updateQueue;
  b.updateQueue === a && (b.updateQueue = { baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects });
}
function zg(a, b) {
  return { eventTime: a, lane: b, tag: 0, payload: null, callback: null, next: null };
}
function Ag(a, b) {
  var c = a.updateQueue;
  null !== c && (c = c.shared, Bg(a) ? (a = c.interleaved, null === a ? (b.next = b, null === vg ? vg = [c] : vg.push(c)) : (b.next = a.next, a.next = b), c.interleaved = b) : (a = c.pending, null === a ? b.next = b : (b.next = a.next, a.next = b), c.pending = b));
}
function Cg(a, b, c) {
  b = b.updateQueue;
  if (null !== b && (b = b.shared, 0 !== (c & 4194240))) {
    var d = b.lanes;
    d &= a.pendingLanes;
    c |= d;
    b.lanes = c;
    Bc(a, c);
  }
}
function Dg(a, b) {
  var c = a.updateQueue, d = a.alternate;
  if (null !== d && (d = d.updateQueue, c === d)) {
    var e = null, f2 = null;
    c = c.firstBaseUpdate;
    if (null !== c) {
      do {
        var g = { eventTime: c.eventTime, lane: c.lane, tag: c.tag, payload: c.payload, callback: c.callback, next: null };
        null === f2 ? e = f2 = g : f2 = f2.next = g;
        c = c.next;
      } while (null !== c);
      null === f2 ? e = f2 = b : f2 = f2.next = b;
    } else
      e = f2 = b;
    c = { baseState: d.baseState, firstBaseUpdate: e, lastBaseUpdate: f2, shared: d.shared, effects: d.effects };
    a.updateQueue = c;
    return;
  }
  a = c.lastBaseUpdate;
  null === a ? c.firstBaseUpdate = b : a.next = b;
  c.lastBaseUpdate = b;
}
function Eg(a, b, c, d) {
  var e = a.updateQueue;
  wg = false;
  var f2 = e.firstBaseUpdate, g = e.lastBaseUpdate, h = e.shared.pending;
  if (null !== h) {
    e.shared.pending = null;
    var k2 = h, l2 = k2.next;
    k2.next = null;
    null === g ? f2 = l2 : g.next = l2;
    g = k2;
    var n2 = a.alternate;
    null !== n2 && (n2 = n2.updateQueue, h = n2.lastBaseUpdate, h !== g && (null === h ? n2.firstBaseUpdate = l2 : h.next = l2, n2.lastBaseUpdate = k2));
  }
  if (null !== f2) {
    var u2 = e.baseState;
    g = 0;
    n2 = l2 = k2 = null;
    h = f2;
    do {
      var q2 = h.lane, y2 = h.eventTime;
      if ((d & q2) === q2) {
        null !== n2 && (n2 = n2.next = {
          eventTime: y2,
          lane: 0,
          tag: h.tag,
          payload: h.payload,
          callback: h.callback,
          next: null
        });
        a: {
          var m2 = a, w2 = h;
          q2 = b;
          y2 = c;
          switch (w2.tag) {
            case 1:
              m2 = w2.payload;
              if ("function" === typeof m2) {
                u2 = m2.call(y2, u2, q2);
                break a;
              }
              u2 = m2;
              break a;
            case 3:
              m2.flags = m2.flags & -65537 | 128;
            case 0:
              m2 = w2.payload;
              q2 = "function" === typeof m2 ? m2.call(y2, u2, q2) : m2;
              if (null === q2 || void 0 === q2)
                break a;
              u2 = A({}, u2, q2);
              break a;
            case 2:
              wg = true;
          }
        }
        null !== h.callback && 0 !== h.lane && (a.flags |= 64, q2 = e.effects, null === q2 ? e.effects = [h] : q2.push(h));
      } else
        y2 = { eventTime: y2, lane: q2, tag: h.tag, payload: h.payload, callback: h.callback, next: null }, null === n2 ? (l2 = n2 = y2, k2 = u2) : n2 = n2.next = y2, g |= q2;
      h = h.next;
      if (null === h)
        if (h = e.shared.pending, null === h)
          break;
        else
          q2 = h, h = q2.next, q2.next = null, e.lastBaseUpdate = q2, e.shared.pending = null;
    } while (1);
    null === n2 && (k2 = u2);
    e.baseState = k2;
    e.firstBaseUpdate = l2;
    e.lastBaseUpdate = n2;
    b = e.shared.interleaved;
    if (null !== b) {
      e = b;
      do
        g |= e.lane, e = e.next;
      while (e !== b);
    } else
      null === f2 && (e.shared.lanes = 0);
    Fg |= g;
    a.lanes = g;
    a.memoizedState = u2;
  }
}
function Gg$1(a, b, c) {
  a = b.effects;
  b.effects = null;
  if (null !== a)
    for (b = 0; b < a.length; b++) {
      var d = a[b], e = d.callback;
      if (null !== e) {
        d.callback = null;
        d = c;
        if ("function" !== typeof e)
          throw Error(p(191, e));
        e.call(d);
      }
    }
}
var Hg = new aa.Component().refs;
function Ig(a, b, c, d) {
  b = a.memoizedState;
  c = c(d, b);
  c = null === c || void 0 === c ? b : A({}, b, c);
  a.memoizedState = c;
  0 === a.lanes && (a.updateQueue.baseState = c);
}
var Mg = { isMounted: function(a) {
  return (a = a._reactInternals) ? Ub(a) === a : false;
}, enqueueSetState: function(a, b, c) {
  a = a._reactInternals;
  var d = Jg(), e = Kg(a), f2 = zg(d, e);
  f2.payload = b;
  void 0 !== c && null !== c && (f2.callback = c);
  Ag(a, f2);
  b = Lg(a, e, d);
  null !== b && Cg(b, a, e);
}, enqueueReplaceState: function(a, b, c) {
  a = a._reactInternals;
  var d = Jg(), e = Kg(a), f2 = zg(d, e);
  f2.tag = 1;
  f2.payload = b;
  void 0 !== c && null !== c && (f2.callback = c);
  Ag(a, f2);
  b = Lg(a, e, d);
  null !== b && Cg(b, a, e);
}, enqueueForceUpdate: function(a, b) {
  a = a._reactInternals;
  var c = Jg(), d = Kg(a), e = zg(
    c,
    d
  );
  e.tag = 2;
  void 0 !== b && null !== b && (e.callback = b);
  Ag(a, e);
  b = Lg(a, d, c);
  null !== b && Cg(b, a, d);
} };
function Ng(a, b, c, d, e, f2, g) {
  a = a.stateNode;
  return "function" === typeof a.shouldComponentUpdate ? a.shouldComponentUpdate(d, f2, g) : b.prototype && b.prototype.isPureReactComponent ? !He(c, d) || !He(e, f2) : true;
}
function Og(a, b, c) {
  var d = false, e = Uf;
  var f2 = b.contextType;
  "object" === typeof f2 && null !== f2 ? f2 = ug(f2) : (e = Yf(b) ? Wf : H.current, d = b.contextTypes, f2 = (d = null !== d && void 0 !== d) ? Xf(a, e) : Uf);
  b = new b(c, f2);
  a.memoizedState = null !== b.state && void 0 !== b.state ? b.state : null;
  b.updater = Mg;
  a.stateNode = b;
  b._reactInternals = a;
  d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f2);
  return b;
}
function Pg(a, b, c, d) {
  a = b.state;
  "function" === typeof b.componentWillReceiveProps && b.componentWillReceiveProps(c, d);
  "function" === typeof b.UNSAFE_componentWillReceiveProps && b.UNSAFE_componentWillReceiveProps(c, d);
  b.state !== a && Mg.enqueueReplaceState(b, b.state, null);
}
function Qg(a, b, c, d) {
  var e = a.stateNode;
  e.props = c;
  e.state = a.memoizedState;
  e.refs = Hg;
  xg(a);
  var f2 = b.contextType;
  "object" === typeof f2 && null !== f2 ? e.context = ug(f2) : (f2 = Yf(b) ? Wf : H.current, e.context = Xf(a, f2));
  e.state = a.memoizedState;
  f2 = b.getDerivedStateFromProps;
  "function" === typeof f2 && (Ig(a, b, f2, c), e.state = a.memoizedState);
  "function" === typeof b.getDerivedStateFromProps || "function" === typeof e.getSnapshotBeforeUpdate || "function" !== typeof e.UNSAFE_componentWillMount && "function" !== typeof e.componentWillMount || (b = e.state, "function" === typeof e.componentWillMount && e.componentWillMount(), "function" === typeof e.UNSAFE_componentWillMount && e.UNSAFE_componentWillMount(), b !== e.state && Mg.enqueueReplaceState(e, e.state, null), Eg(a, c, e, d), e.state = a.memoizedState);
  "function" === typeof e.componentDidMount && (a.flags |= 4194308);
}
var Rg = [], Sg = 0, Tg = null, Ug = 0, Vg = [], Wg = 0, Xg = null, Yg = 1, Zg = "";
function $g(a, b) {
  Rg[Sg++] = Ug;
  Rg[Sg++] = Tg;
  Tg = a;
  Ug = b;
}
function ah(a, b, c) {
  Vg[Wg++] = Yg;
  Vg[Wg++] = Zg;
  Vg[Wg++] = Xg;
  Xg = a;
  var d = Yg;
  a = Zg;
  var e = 32 - nc(d) - 1;
  d &= ~(1 << e);
  c += 1;
  var f2 = 32 - nc(b) + e;
  if (30 < f2) {
    var g = e - e % 5;
    f2 = (d & (1 << g) - 1).toString(32);
    d >>= g;
    e -= g;
    Yg = 1 << 32 - nc(b) + e | c << e | d;
    Zg = f2 + a;
  } else
    Yg = 1 << f2 | c << e | d, Zg = a;
}
function bh(a) {
  null !== a.return && ($g(a, 1), ah(a, 1, 0));
}
function ch(a) {
  for (; a === Tg; )
    Tg = Rg[--Sg], Rg[Sg] = null, Ug = Rg[--Sg], Rg[Sg] = null;
  for (; a === Xg; )
    Xg = Vg[--Wg], Vg[Wg] = null, Zg = Vg[--Wg], Vg[Wg] = null, Yg = Vg[--Wg], Vg[Wg] = null;
}
var dh = null, eh = null, I = false, fh = null;
function gh(a, b) {
  var c = hh(5, null, null, 0);
  c.elementType = "DELETED";
  c.stateNode = b;
  c.return = a;
  b = a.deletions;
  null === b ? (a.deletions = [c], a.flags |= 16) : b.push(c);
}
function ih(a, b) {
  switch (a.tag) {
    case 5:
      var c = a.type;
      b = 1 !== b.nodeType || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
      return null !== b ? (a.stateNode = b, dh = a, eh = Kf(b.firstChild), true) : false;
    case 6:
      return b = "" === a.pendingProps || 3 !== b.nodeType ? null : b, null !== b ? (a.stateNode = b, dh = a, eh = null, true) : false;
    case 13:
      return b = 8 !== b.nodeType ? null : b, null !== b ? (c = null !== Xg ? { id: Yg, overflow: Zg } : null, a.memoizedState = { dehydrated: b, treeContext: c, retryLane: 1073741824 }, c = hh(18, null, null, 0), c.stateNode = b, c.return = a, a.child = c, dh = a, eh = null, true) : false;
    default:
      return false;
  }
}
function jh(a) {
  return 0 !== (a.mode & 1) && 0 === (a.flags & 128);
}
function kh(a) {
  if (I) {
    var b = eh;
    if (b) {
      var c = b;
      if (!ih(a, b)) {
        if (jh(a))
          throw Error(p(418));
        b = Kf(c.nextSibling);
        var d = dh;
        b && ih(a, b) ? gh(d, c) : (a.flags = a.flags & -4097 | 2, I = false, dh = a);
      }
    } else {
      if (jh(a))
        throw Error(p(418));
      a.flags = a.flags & -4097 | 2;
      I = false;
      dh = a;
    }
  }
}
function lh(a) {
  for (a = a.return; null !== a && 5 !== a.tag && 3 !== a.tag && 13 !== a.tag; )
    a = a.return;
  dh = a;
}
function mh(a) {
  if (a !== dh)
    return false;
  if (!I)
    return lh(a), I = true, false;
  var b;
  (b = 3 !== a.tag) && !(b = 5 !== a.tag) && (b = a.type, b = "head" !== b && "body" !== b && !Df(a.type, a.memoizedProps));
  if (b && (b = eh)) {
    if (jh(a)) {
      for (a = eh; a; )
        a = Kf(a.nextSibling);
      throw Error(p(418));
    }
    for (; b; )
      gh(a, b), b = Kf(b.nextSibling);
  }
  lh(a);
  if (13 === a.tag) {
    a = a.memoizedState;
    a = null !== a ? a.dehydrated : null;
    if (!a)
      throw Error(p(317));
    a: {
      a = a.nextSibling;
      for (b = 0; a; ) {
        if (8 === a.nodeType) {
          var c = a.data;
          if ("/$" === c) {
            if (0 === b) {
              eh = Kf(a.nextSibling);
              break a;
            }
            b--;
          } else
            "$" !== c && "$!" !== c && "$?" !== c || b++;
        }
        a = a.nextSibling;
      }
      eh = null;
    }
  } else
    eh = dh ? Kf(a.stateNode.nextSibling) : null;
  return true;
}
function nh() {
  eh = dh = null;
  I = false;
}
function oh(a) {
  null === fh ? fh = [a] : fh.push(a);
}
function ph(a, b, c) {
  a = c.ref;
  if (null !== a && "function" !== typeof a && "object" !== typeof a) {
    if (c._owner) {
      c = c._owner;
      if (c) {
        if (1 !== c.tag)
          throw Error(p(309));
        var d = c.stateNode;
      }
      if (!d)
        throw Error(p(147, a));
      var e = d, f2 = "" + a;
      if (null !== b && null !== b.ref && "function" === typeof b.ref && b.ref._stringRef === f2)
        return b.ref;
      b = function(a2) {
        var b2 = e.refs;
        b2 === Hg && (b2 = e.refs = {});
        null === a2 ? delete b2[f2] : b2[f2] = a2;
      };
      b._stringRef = f2;
      return b;
    }
    if ("string" !== typeof a)
      throw Error(p(284));
    if (!c._owner)
      throw Error(p(290, a));
  }
  return a;
}
function qh(a, b) {
  a = Object.prototype.toString.call(b);
  throw Error(p(31, "[object Object]" === a ? "object with keys {" + Object.keys(b).join(", ") + "}" : a));
}
function rh(a) {
  var b = a._init;
  return b(a._payload);
}
function sh(a) {
  function b(b2, c2) {
    if (a) {
      var d2 = b2.deletions;
      null === d2 ? (b2.deletions = [c2], b2.flags |= 16) : d2.push(c2);
    }
  }
  function c(c2, d2) {
    if (!a)
      return null;
    for (; null !== d2; )
      b(c2, d2), d2 = d2.sibling;
    return null;
  }
  function d(a2, b2) {
    for (a2 = /* @__PURE__ */ new Map(); null !== b2; )
      null !== b2.key ? a2.set(b2.key, b2) : a2.set(b2.index, b2), b2 = b2.sibling;
    return a2;
  }
  function e(a2, b2) {
    a2 = th(a2, b2);
    a2.index = 0;
    a2.sibling = null;
    return a2;
  }
  function f2(b2, c2, d2) {
    b2.index = d2;
    if (!a)
      return b2.flags |= 1048576, c2;
    d2 = b2.alternate;
    if (null !== d2)
      return d2 = d2.index, d2 < c2 ? (b2.flags |= 2, c2) : d2;
    b2.flags |= 2;
    return c2;
  }
  function g(b2) {
    a && null === b2.alternate && (b2.flags |= 2);
    return b2;
  }
  function h(a2, b2, c2, d2) {
    if (null === b2 || 6 !== b2.tag)
      return b2 = uh(c2, a2.mode, d2), b2.return = a2, b2;
    b2 = e(b2, c2);
    b2.return = a2;
    return b2;
  }
  function k2(a2, b2, c2, d2) {
    var f3 = c2.type;
    if (f3 === wa)
      return n2(a2, b2, c2.props.children, d2, c2.key);
    if (null !== b2 && (b2.elementType === f3 || "object" === typeof f3 && null !== f3 && f3.$$typeof === Ga && rh(f3) === b2.type))
      return d2 = e(b2, c2.props), d2.ref = ph(a2, b2, c2), d2.return = a2, d2;
    d2 = vh(c2.type, c2.key, c2.props, null, a2.mode, d2);
    d2.ref = ph(a2, b2, c2);
    d2.return = a2;
    return d2;
  }
  function l2(a2, b2, c2, d2) {
    if (null === b2 || 4 !== b2.tag || b2.stateNode.containerInfo !== c2.containerInfo || b2.stateNode.implementation !== c2.implementation)
      return b2 = wh(c2, a2.mode, d2), b2.return = a2, b2;
    b2 = e(b2, c2.children || []);
    b2.return = a2;
    return b2;
  }
  function n2(a2, b2, c2, d2, f3) {
    if (null === b2 || 7 !== b2.tag)
      return b2 = xh(c2, a2.mode, d2, f3), b2.return = a2, b2;
    b2 = e(b2, c2);
    b2.return = a2;
    return b2;
  }
  function u2(a2, b2, c2) {
    if ("string" === typeof b2 && "" !== b2 || "number" === typeof b2)
      return b2 = uh("" + b2, a2.mode, c2), b2.return = a2, b2;
    if ("object" === typeof b2 && null !== b2) {
      switch (b2.$$typeof) {
        case ua:
          return c2 = vh(b2.type, b2.key, b2.props, null, a2.mode, c2), c2.ref = ph(a2, null, b2), c2.return = a2, c2;
        case va:
          return b2 = wh(b2, a2.mode, c2), b2.return = a2, b2;
        case Ga:
          var d2 = b2._init;
          return u2(a2, d2(b2._payload), c2);
      }
      if (db(b2) || Ja(b2))
        return b2 = xh(b2, a2.mode, c2, null), b2.return = a2, b2;
      qh(a2, b2);
    }
    return null;
  }
  function q2(a2, b2, c2, d2) {
    var e2 = null !== b2 ? b2.key : null;
    if ("string" === typeof c2 && "" !== c2 || "number" === typeof c2)
      return null !== e2 ? null : h(a2, b2, "" + c2, d2);
    if ("object" === typeof c2 && null !== c2) {
      switch (c2.$$typeof) {
        case ua:
          return c2.key === e2 ? k2(a2, b2, c2, d2) : null;
        case va:
          return c2.key === e2 ? l2(a2, b2, c2, d2) : null;
        case Ga:
          return e2 = c2._init, q2(
            a2,
            b2,
            e2(c2._payload),
            d2
          );
      }
      if (db(c2) || Ja(c2))
        return null !== e2 ? null : n2(a2, b2, c2, d2, null);
      qh(a2, c2);
    }
    return null;
  }
  function y2(a2, b2, c2, d2, e2) {
    if ("string" === typeof d2 && "" !== d2 || "number" === typeof d2)
      return a2 = a2.get(c2) || null, h(b2, a2, "" + d2, e2);
    if ("object" === typeof d2 && null !== d2) {
      switch (d2.$$typeof) {
        case ua:
          return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, k2(b2, a2, d2, e2);
        case va:
          return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, l2(b2, a2, d2, e2);
        case Ga:
          var f3 = d2._init;
          return y2(a2, b2, c2, f3(d2._payload), e2);
      }
      if (db(d2) || Ja(d2))
        return a2 = a2.get(c2) || null, n2(b2, a2, d2, e2, null);
      qh(b2, d2);
    }
    return null;
  }
  function m2(e2, g2, h2, k3) {
    for (var l3 = null, n3 = null, r2 = g2, m3 = g2 = 0, x2 = null; null !== r2 && m3 < h2.length; m3++) {
      r2.index > m3 ? (x2 = r2, r2 = null) : x2 = r2.sibling;
      var v2 = q2(e2, r2, h2[m3], k3);
      if (null === v2) {
        null === r2 && (r2 = x2);
        break;
      }
      a && r2 && null === v2.alternate && b(e2, r2);
      g2 = f2(v2, g2, m3);
      null === n3 ? l3 = v2 : n3.sibling = v2;
      n3 = v2;
      r2 = x2;
    }
    if (m3 === h2.length)
      return c(e2, r2), I && $g(e2, m3), l3;
    if (null === r2) {
      for (; m3 < h2.length; m3++)
        r2 = u2(e2, h2[m3], k3), null !== r2 && (g2 = f2(r2, g2, m3), null === n3 ? l3 = r2 : n3.sibling = r2, n3 = r2);
      I && $g(e2, m3);
      return l3;
    }
    for (r2 = d(e2, r2); m3 < h2.length; m3++)
      x2 = y2(r2, e2, m3, h2[m3], k3), null !== x2 && (a && null !== x2.alternate && r2.delete(null === x2.key ? m3 : x2.key), g2 = f2(x2, g2, m3), null === n3 ? l3 = x2 : n3.sibling = x2, n3 = x2);
    a && r2.forEach(function(a2) {
      return b(e2, a2);
    });
    I && $g(e2, m3);
    return l3;
  }
  function w2(e2, g2, h2, k3) {
    var l3 = Ja(h2);
    if ("function" !== typeof l3)
      throw Error(p(150));
    h2 = l3.call(h2);
    if (null == h2)
      throw Error(p(151));
    for (var n3 = l3 = null, m3 = g2, r2 = g2 = 0, x2 = null, v2 = h2.next(); null !== m3 && !v2.done; r2++, v2 = h2.next()) {
      m3.index > r2 ? (x2 = m3, m3 = null) : x2 = m3.sibling;
      var w3 = q2(e2, m3, v2.value, k3);
      if (null === w3) {
        null === m3 && (m3 = x2);
        break;
      }
      a && m3 && null === w3.alternate && b(e2, m3);
      g2 = f2(w3, g2, r2);
      null === n3 ? l3 = w3 : n3.sibling = w3;
      n3 = w3;
      m3 = x2;
    }
    if (v2.done)
      return c(
        e2,
        m3
      ), I && $g(e2, r2), l3;
    if (null === m3) {
      for (; !v2.done; r2++, v2 = h2.next())
        v2 = u2(e2, v2.value, k3), null !== v2 && (g2 = f2(v2, g2, r2), null === n3 ? l3 = v2 : n3.sibling = v2, n3 = v2);
      I && $g(e2, r2);
      return l3;
    }
    for (m3 = d(e2, m3); !v2.done; r2++, v2 = h2.next())
      v2 = y2(m3, e2, r2, v2.value, k3), null !== v2 && (a && null !== v2.alternate && m3.delete(null === v2.key ? r2 : v2.key), g2 = f2(v2, g2, r2), null === n3 ? l3 = v2 : n3.sibling = v2, n3 = v2);
    a && m3.forEach(function(a2) {
      return b(e2, a2);
    });
    I && $g(e2, r2);
    return l3;
  }
  function J2(a2, d2, f3, h2) {
    "object" === typeof f3 && null !== f3 && f3.type === wa && null === f3.key && (f3 = f3.props.children);
    if ("object" === typeof f3 && null !== f3) {
      switch (f3.$$typeof) {
        case ua:
          a: {
            for (var k3 = f3.key, l3 = d2; null !== l3; ) {
              if (l3.key === k3) {
                k3 = f3.type;
                if (k3 === wa) {
                  if (7 === l3.tag) {
                    c(a2, l3.sibling);
                    d2 = e(l3, f3.props.children);
                    d2.return = a2;
                    a2 = d2;
                    break a;
                  }
                } else if (l3.elementType === k3 || "object" === typeof k3 && null !== k3 && k3.$$typeof === Ga && rh(k3) === l3.type) {
                  c(a2, l3.sibling);
                  d2 = e(l3, f3.props);
                  d2.ref = ph(a2, l3, f3);
                  d2.return = a2;
                  a2 = d2;
                  break a;
                }
                c(a2, l3);
                break;
              } else
                b(a2, l3);
              l3 = l3.sibling;
            }
            f3.type === wa ? (d2 = xh(f3.props.children, a2.mode, h2, f3.key), d2.return = a2, a2 = d2) : (h2 = vh(f3.type, f3.key, f3.props, null, a2.mode, h2), h2.ref = ph(a2, d2, f3), h2.return = a2, a2 = h2);
          }
          return g(a2);
        case va:
          a: {
            for (l3 = f3.key; null !== d2; ) {
              if (d2.key === l3)
                if (4 === d2.tag && d2.stateNode.containerInfo === f3.containerInfo && d2.stateNode.implementation === f3.implementation) {
                  c(a2, d2.sibling);
                  d2 = e(d2, f3.children || []);
                  d2.return = a2;
                  a2 = d2;
                  break a;
                } else {
                  c(a2, d2);
                  break;
                }
              else
                b(a2, d2);
              d2 = d2.sibling;
            }
            d2 = wh(f3, a2.mode, h2);
            d2.return = a2;
            a2 = d2;
          }
          return g(a2);
        case Ga:
          return l3 = f3._init, J2(a2, d2, l3(f3._payload), h2);
      }
      if (db(f3))
        return m2(a2, d2, f3, h2);
      if (Ja(f3))
        return w2(a2, d2, f3, h2);
      qh(a2, f3);
    }
    return "string" === typeof f3 && "" !== f3 || "number" === typeof f3 ? (f3 = "" + f3, null !== d2 && 6 === d2.tag ? (c(a2, d2.sibling), d2 = e(d2, f3), d2.return = a2, a2 = d2) : (c(a2, d2), d2 = uh(f3, a2.mode, h2), d2.return = a2, a2 = d2), g(a2)) : c(a2, d2);
  }
  return J2;
}
var yh = sh(true), zh = sh(false), Ah = {}, Bh = Tf(Ah), Ch = Tf(Ah), Dh = Tf(Ah);
function Eh(a) {
  if (a === Ah)
    throw Error(p(174));
  return a;
}
function Fh(a, b) {
  G(Dh, b);
  G(Ch, a);
  G(Bh, Ah);
  a = b.nodeType;
  switch (a) {
    case 9:
    case 11:
      b = (b = b.documentElement) ? b.namespaceURI : kb(null, "");
      break;
    default:
      a = 8 === a ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = kb(b, a);
  }
  E(Bh);
  G(Bh, b);
}
function Gh() {
  E(Bh);
  E(Ch);
  E(Dh);
}
function Hh(a) {
  Eh(Dh.current);
  var b = Eh(Bh.current);
  var c = kb(b, a.type);
  b !== c && (G(Ch, a), G(Bh, c));
}
function Ih(a) {
  Ch.current === a && (E(Bh), E(Ch));
}
var K = Tf(0);
function Jh(a) {
  for (var b = a; null !== b; ) {
    if (13 === b.tag) {
      var c = b.memoizedState;
      if (null !== c && (c = c.dehydrated, null === c || "$?" === c.data || "$!" === c.data))
        return b;
    } else if (19 === b.tag && void 0 !== b.memoizedProps.revealOrder) {
      if (0 !== (b.flags & 128))
        return b;
    } else if (null !== b.child) {
      b.child.return = b;
      b = b.child;
      continue;
    }
    if (b === a)
      break;
    for (; null === b.sibling; ) {
      if (null === b.return || b.return === a)
        return null;
      b = b.return;
    }
    b.sibling.return = b.return;
    b = b.sibling;
  }
  return null;
}
var Kh = [];
function Lh() {
  for (var a = 0; a < Kh.length; a++)
    Kh[a]._workInProgressVersionPrimary = null;
  Kh.length = 0;
}
var Mh = ta.ReactCurrentDispatcher, Nh = ta.ReactCurrentBatchConfig, Oh = 0, L = null, M = null, N = null, Ph = false, Qh = false, Rh = 0, Sh = 0;
function O() {
  throw Error(p(321));
}
function Th(a, b) {
  if (null === b)
    return false;
  for (var c = 0; c < b.length && c < a.length; c++)
    if (!Ge(a[c], b[c]))
      return false;
  return true;
}
function Uh(a, b, c, d, e, f2) {
  Oh = f2;
  L = b;
  b.memoizedState = null;
  b.updateQueue = null;
  b.lanes = 0;
  Mh.current = null === a || null === a.memoizedState ? Vh : Wh;
  a = c(d, e);
  if (Qh) {
    f2 = 0;
    do {
      Qh = false;
      Rh = 0;
      if (25 <= f2)
        throw Error(p(301));
      f2 += 1;
      N = M = null;
      b.updateQueue = null;
      Mh.current = Xh;
      a = c(d, e);
    } while (Qh);
  }
  Mh.current = Yh;
  b = null !== M && null !== M.next;
  Oh = 0;
  N = M = L = null;
  Ph = false;
  if (b)
    throw Error(p(300));
  return a;
}
function Zh() {
  var a = 0 !== Rh;
  Rh = 0;
  return a;
}
function $h() {
  var a = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
  null === N ? L.memoizedState = N = a : N = N.next = a;
  return N;
}
function ai() {
  if (null === M) {
    var a = L.alternate;
    a = null !== a ? a.memoizedState : null;
  } else
    a = M.next;
  var b = null === N ? L.memoizedState : N.next;
  if (null !== b)
    N = b, M = a;
  else {
    if (null === a)
      throw Error(p(310));
    M = a;
    a = { memoizedState: M.memoizedState, baseState: M.baseState, baseQueue: M.baseQueue, queue: M.queue, next: null };
    null === N ? L.memoizedState = N = a : N = N.next = a;
  }
  return N;
}
function bi(a, b) {
  return "function" === typeof b ? b(a) : b;
}
function ci(a) {
  var b = ai(), c = b.queue;
  if (null === c)
    throw Error(p(311));
  c.lastRenderedReducer = a;
  var d = M, e = d.baseQueue, f2 = c.pending;
  if (null !== f2) {
    if (null !== e) {
      var g = e.next;
      e.next = f2.next;
      f2.next = g;
    }
    d.baseQueue = e = f2;
    c.pending = null;
  }
  if (null !== e) {
    f2 = e.next;
    d = d.baseState;
    var h = g = null, k2 = null, l2 = f2;
    do {
      var n2 = l2.lane;
      if ((Oh & n2) === n2)
        null !== k2 && (k2 = k2.next = { lane: 0, action: l2.action, hasEagerState: l2.hasEagerState, eagerState: l2.eagerState, next: null }), d = l2.hasEagerState ? l2.eagerState : a(d, l2.action);
      else {
        var u2 = {
          lane: n2,
          action: l2.action,
          hasEagerState: l2.hasEagerState,
          eagerState: l2.eagerState,
          next: null
        };
        null === k2 ? (h = k2 = u2, g = d) : k2 = k2.next = u2;
        L.lanes |= n2;
        Fg |= n2;
      }
      l2 = l2.next;
    } while (null !== l2 && l2 !== f2);
    null === k2 ? g = d : k2.next = h;
    Ge(d, b.memoizedState) || (tg = true);
    b.memoizedState = d;
    b.baseState = g;
    b.baseQueue = k2;
    c.lastRenderedState = d;
  }
  a = c.interleaved;
  if (null !== a) {
    e = a;
    do
      f2 = e.lane, L.lanes |= f2, Fg |= f2, e = e.next;
    while (e !== a);
  } else
    null === e && (c.lanes = 0);
  return [b.memoizedState, c.dispatch];
}
function di(a) {
  var b = ai(), c = b.queue;
  if (null === c)
    throw Error(p(311));
  c.lastRenderedReducer = a;
  var d = c.dispatch, e = c.pending, f2 = b.memoizedState;
  if (null !== e) {
    c.pending = null;
    var g = e = e.next;
    do
      f2 = a(f2, g.action), g = g.next;
    while (g !== e);
    Ge(f2, b.memoizedState) || (tg = true);
    b.memoizedState = f2;
    null === b.baseQueue && (b.baseState = f2);
    c.lastRenderedState = f2;
  }
  return [f2, d];
}
function ei() {
}
function fi(a, b) {
  var c = L, d = ai(), e = b(), f2 = !Ge(d.memoizedState, e);
  f2 && (d.memoizedState = e, tg = true);
  d = d.queue;
  gi(hi.bind(null, c, d, a), [a]);
  if (d.getSnapshot !== b || f2 || null !== N && N.memoizedState.tag & 1) {
    c.flags |= 2048;
    ii$1(9, ji.bind(null, c, d, e, b), void 0, null);
    if (null === P)
      throw Error(p(349));
    0 !== (Oh & 30) || ki(c, b, e);
  }
  return e;
}
function ki(a, b, c) {
  a.flags |= 16384;
  a = { getSnapshot: b, value: c };
  b = L.updateQueue;
  null === b ? (b = { lastEffect: null, stores: null }, L.updateQueue = b, b.stores = [a]) : (c = b.stores, null === c ? b.stores = [a] : c.push(a));
}
function ji(a, b, c, d) {
  b.value = c;
  b.getSnapshot = d;
  li(b) && Lg(a, 1, -1);
}
function hi(a, b, c) {
  return c(function() {
    li(b) && Lg(a, 1, -1);
  });
}
function li(a) {
  var b = a.getSnapshot;
  a = a.value;
  try {
    var c = b();
    return !Ge(a, c);
  } catch (d) {
    return true;
  }
}
function mi(a) {
  var b = $h();
  "function" === typeof a && (a = a());
  b.memoizedState = b.baseState = a;
  a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: bi, lastRenderedState: a };
  b.queue = a;
  a = a.dispatch = ni$1.bind(null, L, a);
  return [b.memoizedState, a];
}
function ii$1(a, b, c, d) {
  a = { tag: a, create: b, destroy: c, deps: d, next: null };
  b = L.updateQueue;
  null === b ? (b = { lastEffect: null, stores: null }, L.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, null === c ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
  return a;
}
function oi() {
  return ai().memoizedState;
}
function pi$1(a, b, c, d) {
  var e = $h();
  L.flags |= a;
  e.memoizedState = ii$1(1 | b, c, void 0, void 0 === d ? null : d);
}
function qi(a, b, c, d) {
  var e = ai();
  d = void 0 === d ? null : d;
  var f2 = void 0;
  if (null !== M) {
    var g = M.memoizedState;
    f2 = g.destroy;
    if (null !== d && Th(d, g.deps)) {
      e.memoizedState = ii$1(b, c, f2, d);
      return;
    }
  }
  L.flags |= a;
  e.memoizedState = ii$1(1 | b, c, f2, d);
}
function ri(a, b) {
  return pi$1(8390656, 8, a, b);
}
function gi(a, b) {
  return qi(2048, 8, a, b);
}
function si(a, b) {
  return qi(4, 2, a, b);
}
function ti(a, b) {
  return qi(4, 4, a, b);
}
function ui(a, b) {
  if ("function" === typeof b)
    return a = a(), b(a), function() {
      b(null);
    };
  if (null !== b && void 0 !== b)
    return a = a(), b.current = a, function() {
      b.current = null;
    };
}
function vi(a, b, c) {
  c = null !== c && void 0 !== c ? c.concat([a]) : null;
  return qi(4, 4, ui.bind(null, b, a), c);
}
function wi() {
}
function xi$1(a, b) {
  var c = ai();
  b = void 0 === b ? null : b;
  var d = c.memoizedState;
  if (null !== d && null !== b && Th(b, d[1]))
    return d[0];
  c.memoizedState = [a, b];
  return a;
}
function yi(a, b) {
  var c = ai();
  b = void 0 === b ? null : b;
  var d = c.memoizedState;
  if (null !== d && null !== b && Th(b, d[1]))
    return d[0];
  a = a();
  c.memoizedState = [a, b];
  return a;
}
function zi(a, b, c) {
  if (0 === (Oh & 21))
    return a.baseState && (a.baseState = false, tg = true), a.memoizedState = c;
  Ge(c, b) || (c = xc(), L.lanes |= c, Fg |= c, a.baseState = true);
  return b;
}
function Ai(a, b) {
  var c = C;
  C = 0 !== c && 4 > c ? c : 4;
  a(true);
  var d = Nh.transition;
  Nh.transition = {};
  try {
    a(false), b();
  } finally {
    C = c, Nh.transition = d;
  }
}
function Bi() {
  return ai().memoizedState;
}
function Ci(a, b, c) {
  var d = Kg(a);
  c = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
  Di(a) ? Ei(b, c) : (Fi(a, b, c), c = Jg(), a = Lg(a, d, c), null !== a && Gi(a, b, d));
}
function ni$1(a, b, c) {
  var d = Kg(a), e = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
  if (Di(a))
    Ei(b, e);
  else {
    Fi(a, b, e);
    var f2 = a.alternate;
    if (0 === a.lanes && (null === f2 || 0 === f2.lanes) && (f2 = b.lastRenderedReducer, null !== f2))
      try {
        var g = b.lastRenderedState, h = f2(g, c);
        e.hasEagerState = true;
        e.eagerState = h;
        if (Ge(h, g))
          return;
      } catch (k2) {
      } finally {
      }
    c = Jg();
    a = Lg(a, d, c);
    null !== a && Gi(a, b, d);
  }
}
function Di(a) {
  var b = a.alternate;
  return a === L || null !== b && b === L;
}
function Ei(a, b) {
  Qh = Ph = true;
  var c = a.pending;
  null === c ? b.next = b : (b.next = c.next, c.next = b);
  a.pending = b;
}
function Fi(a, b, c) {
  Bg(a) ? (a = b.interleaved, null === a ? (c.next = c, null === vg ? vg = [b] : vg.push(b)) : (c.next = a.next, a.next = c), b.interleaved = c) : (a = b.pending, null === a ? c.next = c : (c.next = a.next, a.next = c), b.pending = c);
}
function Gi(a, b, c) {
  if (0 !== (c & 4194240)) {
    var d = b.lanes;
    d &= a.pendingLanes;
    c |= d;
    b.lanes = c;
    Bc(a, c);
  }
}
var Yh = { readContext: ug, useCallback: O, useContext: O, useEffect: O, useImperativeHandle: O, useInsertionEffect: O, useLayoutEffect: O, useMemo: O, useReducer: O, useRef: O, useState: O, useDebugValue: O, useDeferredValue: O, useTransition: O, useMutableSource: O, useSyncExternalStore: O, useId: O, unstable_isNewReconciler: false }, Vh = { readContext: ug, useCallback: function(a, b) {
  $h().memoizedState = [a, void 0 === b ? null : b];
  return a;
}, useContext: ug, useEffect: ri, useImperativeHandle: function(a, b, c) {
  c = null !== c && void 0 !== c ? c.concat([a]) : null;
  return pi$1(
    4194308,
    4,
    ui.bind(null, b, a),
    c
  );
}, useLayoutEffect: function(a, b) {
  return pi$1(4194308, 4, a, b);
}, useInsertionEffect: function(a, b) {
  return pi$1(4, 2, a, b);
}, useMemo: function(a, b) {
  var c = $h();
  b = void 0 === b ? null : b;
  a = a();
  c.memoizedState = [a, b];
  return a;
}, useReducer: function(a, b, c) {
  var d = $h();
  b = void 0 !== c ? c(b) : b;
  d.memoizedState = d.baseState = b;
  a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: a, lastRenderedState: b };
  d.queue = a;
  a = a.dispatch = Ci.bind(null, L, a);
  return [d.memoizedState, a];
}, useRef: function(a) {
  var b = $h();
  a = { current: a };
  return b.memoizedState = a;
}, useState: mi, useDebugValue: wi, useDeferredValue: function(a) {
  return $h().memoizedState = a;
}, useTransition: function() {
  var a = mi(false), b = a[0];
  a = Ai.bind(null, a[1]);
  $h().memoizedState = a;
  return [b, a];
}, useMutableSource: function() {
}, useSyncExternalStore: function(a, b, c) {
  var d = L, e = $h();
  if (I) {
    if (void 0 === c)
      throw Error(p(407));
    c = c();
  } else {
    c = b();
    if (null === P)
      throw Error(p(349));
    0 !== (Oh & 30) || ki(d, b, c);
  }
  e.memoizedState = c;
  var f2 = { value: c, getSnapshot: b };
  e.queue = f2;
  ri(hi.bind(
    null,
    d,
    f2,
    a
  ), [a]);
  d.flags |= 2048;
  ii$1(9, ji.bind(null, d, f2, c, b), void 0, null);
  return c;
}, useId: function() {
  var a = $h(), b = P.identifierPrefix;
  if (I) {
    var c = Zg;
    var d = Yg;
    c = (d & ~(1 << 32 - nc(d) - 1)).toString(32) + c;
    b = ":" + b + "R" + c;
    c = Rh++;
    0 < c && (b += "H" + c.toString(32));
    b += ":";
  } else
    c = Sh++, b = ":" + b + "r" + c.toString(32) + ":";
  return a.memoizedState = b;
}, unstable_isNewReconciler: false }, Wh = {
  readContext: ug,
  useCallback: xi$1,
  useContext: ug,
  useEffect: gi,
  useImperativeHandle: vi,
  useInsertionEffect: si,
  useLayoutEffect: ti,
  useMemo: yi,
  useReducer: ci,
  useRef: oi,
  useState: function() {
    return ci(bi);
  },
  useDebugValue: wi,
  useDeferredValue: function(a) {
    var b = ai();
    return zi(b, M.memoizedState, a);
  },
  useTransition: function() {
    var a = ci(bi)[0], b = ai().memoizedState;
    return [a, b];
  },
  useMutableSource: ei,
  useSyncExternalStore: fi,
  useId: Bi,
  unstable_isNewReconciler: false
}, Xh = { readContext: ug, useCallback: xi$1, useContext: ug, useEffect: gi, useImperativeHandle: vi, useInsertionEffect: si, useLayoutEffect: ti, useMemo: yi, useReducer: di, useRef: oi, useState: function() {
  return di(bi);
}, useDebugValue: wi, useDeferredValue: function(a) {
  var b = ai();
  return null === M ? b.memoizedState = a : zi(b, M.memoizedState, a);
}, useTransition: function() {
  var a = di(bi)[0], b = ai().memoizedState;
  return [a, b];
}, useMutableSource: ei, useSyncExternalStore: fi, useId: Bi, unstable_isNewReconciler: false };
function Hi(a, b) {
  try {
    var c = "", d = b;
    do
      c += Oa(d), d = d.return;
    while (d);
    var e = c;
  } catch (f2) {
    e = "\nError generating stack: " + f2.message + "\n" + f2.stack;
  }
  return { value: a, source: b, stack: e };
}
function Ii(a, b) {
  try {
    console.error(b.value);
  } catch (c) {
    setTimeout(function() {
      throw c;
    });
  }
}
var Ji = "function" === typeof WeakMap ? WeakMap : Map;
function Ki(a, b, c) {
  c = zg(-1, c);
  c.tag = 3;
  c.payload = { element: null };
  var d = b.value;
  c.callback = function() {
    Li || (Li = true, Mi = d);
    Ii(a, b);
  };
  return c;
}
function Ni(a, b, c) {
  c = zg(-1, c);
  c.tag = 3;
  var d = a.type.getDerivedStateFromError;
  if ("function" === typeof d) {
    var e = b.value;
    c.payload = function() {
      return d(e);
    };
    c.callback = function() {
      Ii(a, b);
    };
  }
  var f2 = a.stateNode;
  null !== f2 && "function" === typeof f2.componentDidCatch && (c.callback = function() {
    Ii(a, b);
    "function" !== typeof d && (null === Oi ? Oi = /* @__PURE__ */ new Set([this]) : Oi.add(this));
    var c2 = b.stack;
    this.componentDidCatch(b.value, { componentStack: null !== c2 ? c2 : "" });
  });
  return c;
}
function Pi$1(a, b, c) {
  var d = a.pingCache;
  if (null === d) {
    d = a.pingCache = new Ji();
    var e = /* @__PURE__ */ new Set();
    d.set(b, e);
  } else
    e = d.get(b), void 0 === e && (e = /* @__PURE__ */ new Set(), d.set(b, e));
  e.has(c) || (e.add(c), a = Qi.bind(null, a, b, c), b.then(a, a));
}
function Ri(a) {
  do {
    var b;
    if (b = 13 === a.tag)
      b = a.memoizedState, b = null !== b ? null !== b.dehydrated ? true : false : true;
    if (b)
      return a;
    a = a.return;
  } while (null !== a);
  return null;
}
function Si(a, b, c, d, e) {
  if (0 === (a.mode & 1))
    return a === b ? a.flags |= 65536 : (a.flags |= 128, c.flags |= 131072, c.flags &= -52805, 1 === c.tag && (null === c.alternate ? c.tag = 17 : (b = zg(-1, 1), b.tag = 2, Ag(c, b))), c.lanes |= 1), a;
  a.flags |= 65536;
  a.lanes = e;
  return a;
}
var Ti, Ui, Vi, Wi;
Ti = function(a, b) {
  for (var c = b.child; null !== c; ) {
    if (5 === c.tag || 6 === c.tag)
      a.appendChild(c.stateNode);
    else if (4 !== c.tag && null !== c.child) {
      c.child.return = c;
      c = c.child;
      continue;
    }
    if (c === b)
      break;
    for (; null === c.sibling; ) {
      if (null === c.return || c.return === b)
        return;
      c = c.return;
    }
    c.sibling.return = c.return;
    c = c.sibling;
  }
};
Ui = function() {
};
Vi = function(a, b, c, d) {
  var e = a.memoizedProps;
  if (e !== d) {
    a = b.stateNode;
    Eh(Bh.current);
    var f2 = null;
    switch (c) {
      case "input":
        e = Xa(a, e);
        d = Xa(a, d);
        f2 = [];
        break;
      case "select":
        e = A({}, e, { value: void 0 });
        d = A({}, d, { value: void 0 });
        f2 = [];
        break;
      case "textarea":
        e = fb(a, e);
        d = fb(a, d);
        f2 = [];
        break;
      default:
        "function" !== typeof e.onClick && "function" === typeof d.onClick && (a.onclick = Af);
    }
    tb(c, d);
    var g;
    c = null;
    for (l2 in e)
      if (!d.hasOwnProperty(l2) && e.hasOwnProperty(l2) && null != e[l2])
        if ("style" === l2) {
          var h = e[l2];
          for (g in h)
            h.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
        } else
          "dangerouslySetInnerHTML" !== l2 && "children" !== l2 && "suppressContentEditableWarning" !== l2 && "suppressHydrationWarning" !== l2 && "autoFocus" !== l2 && (ea.hasOwnProperty(l2) ? f2 || (f2 = []) : (f2 = f2 || []).push(l2, null));
    for (l2 in d) {
      var k2 = d[l2];
      h = null != e ? e[l2] : void 0;
      if (d.hasOwnProperty(l2) && k2 !== h && (null != k2 || null != h))
        if ("style" === l2)
          if (h) {
            for (g in h)
              !h.hasOwnProperty(g) || k2 && k2.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
            for (g in k2)
              k2.hasOwnProperty(g) && h[g] !== k2[g] && (c || (c = {}), c[g] = k2[g]);
          } else
            c || (f2 || (f2 = []), f2.push(
              l2,
              c
            )), c = k2;
        else
          "dangerouslySetInnerHTML" === l2 ? (k2 = k2 ? k2.__html : void 0, h = h ? h.__html : void 0, null != k2 && h !== k2 && (f2 = f2 || []).push(l2, k2)) : "children" === l2 ? "string" !== typeof k2 && "number" !== typeof k2 || (f2 = f2 || []).push(l2, "" + k2) : "suppressContentEditableWarning" !== l2 && "suppressHydrationWarning" !== l2 && (ea.hasOwnProperty(l2) ? (null != k2 && "onScroll" === l2 && D("scroll", a), f2 || h === k2 || (f2 = [])) : (f2 = f2 || []).push(l2, k2));
    }
    c && (f2 = f2 || []).push("style", c);
    var l2 = f2;
    if (b.updateQueue = l2)
      b.flags |= 4;
  }
};
Wi = function(a, b, c, d) {
  c !== d && (b.flags |= 4);
};
function Xi$1(a, b) {
  if (!I)
    switch (a.tailMode) {
      case "hidden":
        b = a.tail;
        for (var c = null; null !== b; )
          null !== b.alternate && (c = b), b = b.sibling;
        null === c ? a.tail = null : c.sibling = null;
        break;
      case "collapsed":
        c = a.tail;
        for (var d = null; null !== c; )
          null !== c.alternate && (d = c), c = c.sibling;
        null === d ? b || null === a.tail ? a.tail = null : a.tail.sibling = null : d.sibling = null;
    }
}
function Q(a) {
  var b = null !== a.alternate && a.alternate.child === a.child, c = 0, d = 0;
  if (b)
    for (var e = a.child; null !== e; )
      c |= e.lanes | e.childLanes, d |= e.subtreeFlags & 14680064, d |= e.flags & 14680064, e.return = a, e = e.sibling;
  else
    for (e = a.child; null !== e; )
      c |= e.lanes | e.childLanes, d |= e.subtreeFlags, d |= e.flags, e.return = a, e = e.sibling;
  a.subtreeFlags |= d;
  a.childLanes = c;
  return b;
}
function Yi(a, b, c) {
  var d = b.pendingProps;
  ch(b);
  switch (b.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return Q(b), null;
    case 1:
      return Yf(b.type) && Zf(), Q(b), null;
    case 3:
      d = b.stateNode;
      Gh();
      E(Vf);
      E(H);
      Lh();
      d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
      if (null === a || null === a.child)
        mh(b) ? b.flags |= 4 : null === a || a.memoizedState.isDehydrated && 0 === (b.flags & 256) || (b.flags |= 1024, null !== fh && (Zi(fh), fh = null));
      Ui(a, b);
      Q(b);
      return null;
    case 5:
      Ih(b);
      var e = Eh(Dh.current);
      c = b.type;
      if (null !== a && null != b.stateNode)
        Vi(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 512, b.flags |= 2097152);
      else {
        if (!d) {
          if (null === b.stateNode)
            throw Error(p(166));
          Q(b);
          return null;
        }
        a = Eh(Bh.current);
        if (mh(b)) {
          d = b.stateNode;
          c = b.type;
          var f2 = b.memoizedProps;
          d[Nf] = b;
          d[Of] = f2;
          a = 0 !== (b.mode & 1);
          switch (c) {
            case "dialog":
              D("cancel", d);
              D("close", d);
              break;
            case "iframe":
            case "object":
            case "embed":
              D("load", d);
              break;
            case "video":
            case "audio":
              for (e = 0; e < kf.length; e++)
                D(kf[e], d);
              break;
            case "source":
              D("error", d);
              break;
            case "img":
            case "image":
            case "link":
              D(
                "error",
                d
              );
              D("load", d);
              break;
            case "details":
              D("toggle", d);
              break;
            case "input":
              Ya(d, f2);
              D("invalid", d);
              break;
            case "select":
              d._wrapperState = { wasMultiple: !!f2.multiple };
              D("invalid", d);
              break;
            case "textarea":
              gb(d, f2), D("invalid", d);
          }
          tb(c, f2);
          e = null;
          for (var g in f2)
            if (f2.hasOwnProperty(g)) {
              var h = f2[g];
              "children" === g ? "string" === typeof h ? d.textContent !== h && (true !== f2.suppressHydrationWarning && zf(d.textContent, h, a), e = ["children", h]) : "number" === typeof h && d.textContent !== "" + h && (true !== f2.suppressHydrationWarning && zf(
                d.textContent,
                h,
                a
              ), e = ["children", "" + h]) : ea.hasOwnProperty(g) && null != h && "onScroll" === g && D("scroll", d);
            }
          switch (c) {
            case "input":
              Ua(d);
              cb(d, f2, true);
              break;
            case "textarea":
              Ua(d);
              ib(d);
              break;
            case "select":
            case "option":
              break;
            default:
              "function" === typeof f2.onClick && (d.onclick = Af);
          }
          d = e;
          b.updateQueue = d;
          null !== d && (b.flags |= 4);
        } else {
          g = 9 === e.nodeType ? e : e.ownerDocument;
          "http://www.w3.org/1999/xhtml" === a && (a = jb(c));
          "http://www.w3.org/1999/xhtml" === a ? "script" === c ? (a = g.createElement("div"), a.innerHTML = "<script><\/script>", a = a.removeChild(a.firstChild)) : "string" === typeof d.is ? a = g.createElement(c, { is: d.is }) : (a = g.createElement(c), "select" === c && (g = a, d.multiple ? g.multiple = true : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
          a[Nf] = b;
          a[Of] = d;
          Ti(a, b, false, false);
          b.stateNode = a;
          a: {
            g = ub(c, d);
            switch (c) {
              case "dialog":
                D("cancel", a);
                D("close", a);
                e = d;
                break;
              case "iframe":
              case "object":
              case "embed":
                D("load", a);
                e = d;
                break;
              case "video":
              case "audio":
                for (e = 0; e < kf.length; e++)
                  D(kf[e], a);
                e = d;
                break;
              case "source":
                D("error", a);
                e = d;
                break;
              case "img":
              case "image":
              case "link":
                D(
                  "error",
                  a
                );
                D("load", a);
                e = d;
                break;
              case "details":
                D("toggle", a);
                e = d;
                break;
              case "input":
                Ya(a, d);
                e = Xa(a, d);
                D("invalid", a);
                break;
              case "option":
                e = d;
                break;
              case "select":
                a._wrapperState = { wasMultiple: !!d.multiple };
                e = A({}, d, { value: void 0 });
                D("invalid", a);
                break;
              case "textarea":
                gb(a, d);
                e = fb(a, d);
                D("invalid", a);
                break;
              default:
                e = d;
            }
            tb(c, e);
            h = e;
            for (f2 in h)
              if (h.hasOwnProperty(f2)) {
                var k2 = h[f2];
                "style" === f2 ? rb(a, k2) : "dangerouslySetInnerHTML" === f2 ? (k2 = k2 ? k2.__html : void 0, null != k2 && mb(a, k2)) : "children" === f2 ? "string" === typeof k2 ? ("textarea" !== c || "" !== k2) && nb(a, k2) : "number" === typeof k2 && nb(a, "" + k2) : "suppressContentEditableWarning" !== f2 && "suppressHydrationWarning" !== f2 && "autoFocus" !== f2 && (ea.hasOwnProperty(f2) ? null != k2 && "onScroll" === f2 && D("scroll", a) : null != k2 && sa(a, f2, k2, g));
              }
            switch (c) {
              case "input":
                Ua(a);
                cb(a, d, false);
                break;
              case "textarea":
                Ua(a);
                ib(a);
                break;
              case "option":
                null != d.value && a.setAttribute("value", "" + Ra(d.value));
                break;
              case "select":
                a.multiple = !!d.multiple;
                f2 = d.value;
                null != f2 ? eb(a, !!d.multiple, f2, false) : null != d.defaultValue && eb(
                  a,
                  !!d.multiple,
                  d.defaultValue,
                  true
                );
                break;
              default:
                "function" === typeof e.onClick && (a.onclick = Af);
            }
            switch (c) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                d = !!d.autoFocus;
                break a;
              case "img":
                d = true;
                break a;
              default:
                d = false;
            }
          }
          d && (b.flags |= 4);
        }
        null !== b.ref && (b.flags |= 512, b.flags |= 2097152);
      }
      Q(b);
      return null;
    case 6:
      if (a && null != b.stateNode)
        Wi(a, b, a.memoizedProps, d);
      else {
        if ("string" !== typeof d && null === b.stateNode)
          throw Error(p(166));
        c = Eh(Dh.current);
        Eh(Bh.current);
        if (mh(b)) {
          d = b.stateNode;
          c = b.memoizedProps;
          d[Nf] = b;
          if (f2 = d.nodeValue !== c) {
            if (a = dh, null !== a)
              switch (a.tag) {
                case 3:
                  zf(d.nodeValue, c, 0 !== (a.mode & 1));
                  break;
                case 5:
                  true !== a.memoizedProps.suppressHydrationWarning && zf(d.nodeValue, c, 0 !== (a.mode & 1));
              }
          }
          f2 && (b.flags |= 4);
        } else
          d = (9 === c.nodeType ? c : c.ownerDocument).createTextNode(d), d[Nf] = b, b.stateNode = d;
      }
      Q(b);
      return null;
    case 13:
      E(K);
      d = b.memoizedState;
      if (I && null !== eh && 0 !== (b.mode & 1) && 0 === (b.flags & 128)) {
        for (d = eh; d; )
          d = Kf(d.nextSibling);
        nh();
        b.flags |= 98560;
        return b;
      }
      if (null !== d && null !== d.dehydrated) {
        d = mh(b);
        if (null === a) {
          if (!d)
            throw Error(p(318));
          d = b.memoizedState;
          d = null !== d ? d.dehydrated : null;
          if (!d)
            throw Error(p(317));
          d[Nf] = b;
        } else
          nh(), 0 === (b.flags & 128) && (b.memoizedState = null), b.flags |= 4;
        Q(b);
        return null;
      }
      null !== fh && (Zi(fh), fh = null);
      if (0 !== (b.flags & 128))
        return b.lanes = c, b;
      d = null !== d;
      c = false;
      null === a ? mh(b) : c = null !== a.memoizedState;
      d !== c && d && (b.child.flags |= 8192, 0 !== (b.mode & 1) && (null === a || 0 !== (K.current & 1) ? 0 === R && (R = 3) : $i()));
      null !== b.updateQueue && (b.flags |= 4);
      Q(b);
      return null;
    case 4:
      return Gh(), Ui(a, b), null === a && rf(b.stateNode.containerInfo), Q(b), null;
    case 10:
      return qg(b.type._context), Q(b), null;
    case 17:
      return Yf(b.type) && Zf(), Q(b), null;
    case 19:
      E(K);
      f2 = b.memoizedState;
      if (null === f2)
        return Q(b), null;
      d = 0 !== (b.flags & 128);
      g = f2.rendering;
      if (null === g)
        if (d)
          Xi$1(f2, false);
        else {
          if (0 !== R || null !== a && 0 !== (a.flags & 128))
            for (a = b.child; null !== a; ) {
              g = Jh(a);
              if (null !== g) {
                b.flags |= 128;
                Xi$1(f2, false);
                d = g.updateQueue;
                null !== d && (b.updateQueue = d, b.flags |= 4);
                b.subtreeFlags = 0;
                d = c;
                for (c = b.child; null !== c; )
                  f2 = c, a = d, f2.flags &= 14680066, g = f2.alternate, null === g ? (f2.childLanes = 0, f2.lanes = a, f2.child = null, f2.subtreeFlags = 0, f2.memoizedProps = null, f2.memoizedState = null, f2.updateQueue = null, f2.dependencies = null, f2.stateNode = null) : (f2.childLanes = g.childLanes, f2.lanes = g.lanes, f2.child = g.child, f2.subtreeFlags = 0, f2.deletions = null, f2.memoizedProps = g.memoizedProps, f2.memoizedState = g.memoizedState, f2.updateQueue = g.updateQueue, f2.type = g.type, a = g.dependencies, f2.dependencies = null === a ? null : { lanes: a.lanes, firstContext: a.firstContext }), c = c.sibling;
                G(K, K.current & 1 | 2);
                return b.child;
              }
              a = a.sibling;
            }
          null !== f2.tail && B() > aj && (b.flags |= 128, d = true, Xi$1(f2, false), b.lanes = 4194304);
        }
      else {
        if (!d)
          if (a = Jh(g), null !== a) {
            if (b.flags |= 128, d = true, c = a.updateQueue, null !== c && (b.updateQueue = c, b.flags |= 4), Xi$1(f2, true), null === f2.tail && "hidden" === f2.tailMode && !g.alternate && !I)
              return Q(b), null;
          } else
            2 * B() - f2.renderingStartTime > aj && 1073741824 !== c && (b.flags |= 128, d = true, Xi$1(f2, false), b.lanes = 4194304);
        f2.isBackwards ? (g.sibling = b.child, b.child = g) : (c = f2.last, null !== c ? c.sibling = g : b.child = g, f2.last = g);
      }
      if (null !== f2.tail)
        return b = f2.tail, f2.rendering = b, f2.tail = b.sibling, f2.renderingStartTime = B(), b.sibling = null, c = K.current, G(K, d ? c & 1 | 2 : c & 1), b;
      Q(b);
      return null;
    case 22:
    case 23:
      return bj(), d = null !== b.memoizedState, null !== a && null !== a.memoizedState !== d && (b.flags |= 8192), d && 0 !== (b.mode & 1) ? 0 !== (cj & 1073741824) && (Q(b), b.subtreeFlags & 6 && (b.flags |= 8192)) : Q(b), null;
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(p(156, b.tag));
}
var dj = ta.ReactCurrentOwner, tg = false;
function ej(a, b, c, d) {
  b.child = null === a ? zh(b, null, c, d) : yh(b, a.child, c, d);
}
function fj(a, b, c, d, e) {
  c = c.render;
  var f2 = b.ref;
  sg(b, e);
  d = Uh(a, b, c, d, f2, e);
  c = Zh();
  if (null !== a && !tg)
    return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, gj(a, b, e);
  I && c && bh(b);
  b.flags |= 1;
  ej(a, b, d, e);
  return b.child;
}
function hj(a, b, c, d, e) {
  if (null === a) {
    var f2 = c.type;
    if ("function" === typeof f2 && !ij(f2) && void 0 === f2.defaultProps && null === c.compare && void 0 === c.defaultProps)
      return b.tag = 15, b.type = f2, jj(a, b, f2, d, e);
    a = vh(c.type, null, d, b, b.mode, e);
    a.ref = b.ref;
    a.return = b;
    return b.child = a;
  }
  f2 = a.child;
  if (0 === (a.lanes & e)) {
    var g = f2.memoizedProps;
    c = c.compare;
    c = null !== c ? c : He;
    if (c(g, d) && a.ref === b.ref)
      return gj(a, b, e);
  }
  b.flags |= 1;
  a = th(f2, d);
  a.ref = b.ref;
  a.return = b;
  return b.child = a;
}
function jj(a, b, c, d, e) {
  if (null !== a) {
    var f2 = a.memoizedProps;
    if (He(f2, d) && a.ref === b.ref)
      if (tg = false, b.pendingProps = d = f2, 0 !== (a.lanes & e))
        0 !== (a.flags & 131072) && (tg = true);
      else
        return b.lanes = a.lanes, gj(a, b, e);
  }
  return kj(a, b, c, d, e);
}
function lj(a, b, c) {
  var d = b.pendingProps, e = d.children, f2 = null !== a ? a.memoizedState : null;
  if ("hidden" === d.mode)
    if (0 === (b.mode & 1))
      b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, G(mj, cj), cj |= c;
    else if (0 !== (c & 1073741824))
      b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, d = null !== f2 ? f2.baseLanes : c, G(mj, cj), cj |= d;
    else
      return a = null !== f2 ? f2.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = { baseLanes: a, cachePool: null, transitions: null }, b.updateQueue = null, G(mj, cj), cj |= a, null;
  else
    null !== f2 ? (d = f2.baseLanes | c, b.memoizedState = null) : d = c, G(mj, cj), cj |= d;
  ej(a, b, e, c);
  return b.child;
}
function nj(a, b) {
  var c = b.ref;
  if (null === a && null !== c || null !== a && a.ref !== c)
    b.flags |= 512, b.flags |= 2097152;
}
function kj(a, b, c, d, e) {
  var f2 = Yf(c) ? Wf : H.current;
  f2 = Xf(b, f2);
  sg(b, e);
  c = Uh(a, b, c, d, f2, e);
  d = Zh();
  if (null !== a && !tg)
    return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, gj(a, b, e);
  I && d && bh(b);
  b.flags |= 1;
  ej(a, b, c, e);
  return b.child;
}
function oj(a, b, c, d, e) {
  if (Yf(c)) {
    var f2 = true;
    bg(b);
  } else
    f2 = false;
  sg(b, e);
  if (null === b.stateNode)
    null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2), Og(b, c, d), Qg(b, c, d, e), d = true;
  else if (null === a) {
    var g = b.stateNode, h = b.memoizedProps;
    g.props = h;
    var k2 = g.context, l2 = c.contextType;
    "object" === typeof l2 && null !== l2 ? l2 = ug(l2) : (l2 = Yf(c) ? Wf : H.current, l2 = Xf(b, l2));
    var n2 = c.getDerivedStateFromProps, u2 = "function" === typeof n2 || "function" === typeof g.getSnapshotBeforeUpdate;
    u2 || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== d || k2 !== l2) && Pg(b, g, d, l2);
    wg = false;
    var q2 = b.memoizedState;
    g.state = q2;
    Eg(b, d, g, e);
    k2 = b.memoizedState;
    h !== d || q2 !== k2 || Vf.current || wg ? ("function" === typeof n2 && (Ig(b, c, n2, d), k2 = b.memoizedState), (h = wg || Ng(b, c, h, d, q2, k2, l2)) ? (u2 || "function" !== typeof g.UNSAFE_componentWillMount && "function" !== typeof g.componentWillMount || ("function" === typeof g.componentWillMount && g.componentWillMount(), "function" === typeof g.UNSAFE_componentWillMount && g.UNSAFE_componentWillMount()), "function" === typeof g.componentDidMount && (b.flags |= 4194308)) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), b.memoizedProps = d, b.memoizedState = k2), g.props = d, g.state = k2, g.context = l2, d = h) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), d = false);
  } else {
    g = b.stateNode;
    yg(a, b);
    h = b.memoizedProps;
    l2 = b.type === b.elementType ? h : kg(b.type, h);
    g.props = l2;
    u2 = b.pendingProps;
    q2 = g.context;
    k2 = c.contextType;
    "object" === typeof k2 && null !== k2 ? k2 = ug(k2) : (k2 = Yf(c) ? Wf : H.current, k2 = Xf(b, k2));
    var y2 = c.getDerivedStateFromProps;
    (n2 = "function" === typeof y2 || "function" === typeof g.getSnapshotBeforeUpdate) || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== u2 || q2 !== k2) && Pg(b, g, d, k2);
    wg = false;
    q2 = b.memoizedState;
    g.state = q2;
    Eg(b, d, g, e);
    var m2 = b.memoizedState;
    h !== u2 || q2 !== m2 || Vf.current || wg ? ("function" === typeof y2 && (Ig(b, c, y2, d), m2 = b.memoizedState), (l2 = wg || Ng(b, c, l2, d, q2, m2, k2) || false) ? (n2 || "function" !== typeof g.UNSAFE_componentWillUpdate && "function" !== typeof g.componentWillUpdate || ("function" === typeof g.componentWillUpdate && g.componentWillUpdate(d, m2, k2), "function" === typeof g.UNSAFE_componentWillUpdate && g.UNSAFE_componentWillUpdate(d, m2, k2)), "function" === typeof g.componentDidUpdate && (b.flags |= 4), "function" === typeof g.getSnapshotBeforeUpdate && (b.flags |= 1024)) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && q2 === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && q2 === a.memoizedState || (b.flags |= 1024), b.memoizedProps = d, b.memoizedState = m2), g.props = d, g.state = m2, g.context = k2, d = l2) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && q2 === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && q2 === a.memoizedState || (b.flags |= 1024), d = false);
  }
  return pj(a, b, c, d, f2, e);
}
function pj(a, b, c, d, e, f2) {
  nj(a, b);
  var g = 0 !== (b.flags & 128);
  if (!d && !g)
    return e && cg(b, c, false), gj(a, b, f2);
  d = b.stateNode;
  dj.current = b;
  var h = g && "function" !== typeof c.getDerivedStateFromError ? null : d.render();
  b.flags |= 1;
  null !== a && g ? (b.child = yh(b, a.child, null, f2), b.child = yh(b, null, h, f2)) : ej(a, b, h, f2);
  b.memoizedState = d.state;
  e && cg(b, c, true);
  return b.child;
}
function qj(a) {
  var b = a.stateNode;
  b.pendingContext ? $f(a, b.pendingContext, b.pendingContext !== b.context) : b.context && $f(a, b.context, false);
  Fh(a, b.containerInfo);
}
function rj(a, b, c, d, e) {
  nh();
  oh(e);
  b.flags |= 256;
  ej(a, b, c, d);
  return b.child;
}
var sj = { dehydrated: null, treeContext: null, retryLane: 0 };
function tj(a) {
  return { baseLanes: a, cachePool: null, transitions: null };
}
function uj(a, b) {
  return { baseLanes: a.baseLanes | b, cachePool: null, transitions: a.transitions };
}
function vj(a, b, c) {
  var d = b.pendingProps, e = K.current, f2 = false, g = 0 !== (b.flags & 128), h;
  (h = g) || (h = null !== a && null === a.memoizedState ? false : 0 !== (e & 2));
  if (h)
    f2 = true, b.flags &= -129;
  else if (null === a || null !== a.memoizedState)
    e |= 1;
  G(K, e & 1);
  if (null === a) {
    kh(b);
    a = b.memoizedState;
    if (null !== a && (a = a.dehydrated, null !== a))
      return 0 === (b.mode & 1) ? b.lanes = 1 : "$!" === a.data ? b.lanes = 8 : b.lanes = 1073741824, null;
    e = d.children;
    a = d.fallback;
    return f2 ? (d = b.mode, f2 = b.child, e = { mode: "hidden", children: e }, 0 === (d & 1) && null !== f2 ? (f2.childLanes = 0, f2.pendingProps = e) : f2 = wj(e, d, 0, null), a = xh(a, d, c, null), f2.return = b, a.return = b, f2.sibling = a, b.child = f2, b.child.memoizedState = tj(c), b.memoizedState = sj, a) : xj(b, e);
  }
  e = a.memoizedState;
  if (null !== e) {
    h = e.dehydrated;
    if (null !== h) {
      if (g) {
        if (b.flags & 256)
          return b.flags &= -257, yj(a, b, c, Error(p(422)));
        if (null !== b.memoizedState)
          return b.child = a.child, b.flags |= 128, null;
        f2 = d.fallback;
        e = b.mode;
        d = wj({ mode: "visible", children: d.children }, e, 0, null);
        f2 = xh(f2, e, c, null);
        f2.flags |= 2;
        d.return = b;
        f2.return = b;
        d.sibling = f2;
        b.child = d;
        0 !== (b.mode & 1) && yh(
          b,
          a.child,
          null,
          c
        );
        b.child.memoizedState = tj(c);
        b.memoizedState = sj;
        return f2;
      }
      if (0 === (b.mode & 1))
        b = yj(a, b, c, null);
      else if ("$!" === h.data)
        b = yj(a, b, c, Error(p(419)));
      else if (d = 0 !== (c & a.childLanes), tg || d) {
        d = P;
        if (null !== d) {
          switch (c & -c) {
            case 4:
              f2 = 2;
              break;
            case 16:
              f2 = 8;
              break;
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
              f2 = 32;
              break;
            case 536870912:
              f2 = 268435456;
              break;
            default:
              f2 = 0;
          }
          d = 0 !== (f2 & (d.suspendedLanes | c)) ? 0 : f2;
          0 !== d && d !== e.retryLane && (e.retryLane = d, Lg(a, d, -1));
        }
        $i();
        b = yj(a, b, c, Error(p(421)));
      } else
        "$?" === h.data ? (b.flags |= 128, b.child = a.child, b = zj.bind(null, a), h._reactRetry = b, b = null) : (c = e.treeContext, eh = Kf(h.nextSibling), dh = b, I = true, fh = null, null !== c && (Vg[Wg++] = Yg, Vg[Wg++] = Zg, Vg[Wg++] = Xg, Yg = c.id, Zg = c.overflow, Xg = b), b = xj(b, b.pendingProps.children), b.flags |= 4096);
      return b;
    }
    if (f2)
      return d = Aj(a, b, d.children, d.fallback, c), f2 = b.child, e = a.child.memoizedState, f2.memoizedState = null === e ? tj(c) : uj(e, c), f2.childLanes = a.childLanes & ~c, b.memoizedState = sj, d;
    c = Bj(a, b, d.children, c);
    b.memoizedState = null;
    return c;
  }
  if (f2)
    return d = Aj(a, b, d.children, d.fallback, c), f2 = b.child, e = a.child.memoizedState, f2.memoizedState = null === e ? tj(c) : uj(e, c), f2.childLanes = a.childLanes & ~c, b.memoizedState = sj, d;
  c = Bj(a, b, d.children, c);
  b.memoizedState = null;
  return c;
}
function xj(a, b) {
  b = wj({ mode: "visible", children: b }, a.mode, 0, null);
  b.return = a;
  return a.child = b;
}
function Bj(a, b, c, d) {
  var e = a.child;
  a = e.sibling;
  c = th(e, { mode: "visible", children: c });
  0 === (b.mode & 1) && (c.lanes = d);
  c.return = b;
  c.sibling = null;
  null !== a && (d = b.deletions, null === d ? (b.deletions = [a], b.flags |= 16) : d.push(a));
  return b.child = c;
}
function Aj(a, b, c, d, e) {
  var f2 = b.mode;
  a = a.child;
  var g = a.sibling, h = { mode: "hidden", children: c };
  0 === (f2 & 1) && b.child !== a ? (c = b.child, c.childLanes = 0, c.pendingProps = h, b.deletions = null) : (c = th(a, h), c.subtreeFlags = a.subtreeFlags & 14680064);
  null !== g ? d = th(g, d) : (d = xh(d, f2, e, null), d.flags |= 2);
  d.return = b;
  c.return = b;
  c.sibling = d;
  b.child = c;
  return d;
}
function yj(a, b, c, d) {
  null !== d && oh(d);
  yh(b, a.child, null, c);
  a = xj(b, b.pendingProps.children);
  a.flags |= 2;
  b.memoizedState = null;
  return a;
}
function Cj(a, b, c) {
  a.lanes |= b;
  var d = a.alternate;
  null !== d && (d.lanes |= b);
  rg(a.return, b, c);
}
function Dj(a, b, c, d, e) {
  var f2 = a.memoizedState;
  null === f2 ? a.memoizedState = { isBackwards: b, rendering: null, renderingStartTime: 0, last: d, tail: c, tailMode: e } : (f2.isBackwards = b, f2.rendering = null, f2.renderingStartTime = 0, f2.last = d, f2.tail = c, f2.tailMode = e);
}
function Ej(a, b, c) {
  var d = b.pendingProps, e = d.revealOrder, f2 = d.tail;
  ej(a, b, d.children, c);
  d = K.current;
  if (0 !== (d & 2))
    d = d & 1 | 2, b.flags |= 128;
  else {
    if (null !== a && 0 !== (a.flags & 128))
      a:
        for (a = b.child; null !== a; ) {
          if (13 === a.tag)
            null !== a.memoizedState && Cj(a, c, b);
          else if (19 === a.tag)
            Cj(a, c, b);
          else if (null !== a.child) {
            a.child.return = a;
            a = a.child;
            continue;
          }
          if (a === b)
            break a;
          for (; null === a.sibling; ) {
            if (null === a.return || a.return === b)
              break a;
            a = a.return;
          }
          a.sibling.return = a.return;
          a = a.sibling;
        }
    d &= 1;
  }
  G(K, d);
  if (0 === (b.mode & 1))
    b.memoizedState = null;
  else
    switch (e) {
      case "forwards":
        c = b.child;
        for (e = null; null !== c; )
          a = c.alternate, null !== a && null === Jh(a) && (e = c), c = c.sibling;
        c = e;
        null === c ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
        Dj(b, false, e, c, f2);
        break;
      case "backwards":
        c = null;
        e = b.child;
        for (b.child = null; null !== e; ) {
          a = e.alternate;
          if (null !== a && null === Jh(a)) {
            b.child = e;
            break;
          }
          a = e.sibling;
          e.sibling = c;
          c = e;
          e = a;
        }
        Dj(b, true, c, null, f2);
        break;
      case "together":
        Dj(b, false, null, null, void 0);
        break;
      default:
        b.memoizedState = null;
    }
  return b.child;
}
function gj(a, b, c) {
  null !== a && (b.dependencies = a.dependencies);
  Fg |= b.lanes;
  if (0 === (c & b.childLanes))
    return null;
  if (null !== a && b.child !== a.child)
    throw Error(p(153));
  if (null !== b.child) {
    a = b.child;
    c = th(a, a.pendingProps);
    b.child = c;
    for (c.return = b; null !== a.sibling; )
      a = a.sibling, c = c.sibling = th(a, a.pendingProps), c.return = b;
    c.sibling = null;
  }
  return b.child;
}
function Fj(a, b, c) {
  switch (b.tag) {
    case 3:
      qj(b);
      nh();
      break;
    case 5:
      Hh(b);
      break;
    case 1:
      Yf(b.type) && bg(b);
      break;
    case 4:
      Fh(b, b.stateNode.containerInfo);
      break;
    case 10:
      var d = b.type._context, e = b.memoizedProps.value;
      G(lg$1, d._currentValue);
      d._currentValue = e;
      break;
    case 13:
      d = b.memoizedState;
      if (null !== d) {
        if (null !== d.dehydrated)
          return G(K, K.current & 1), b.flags |= 128, null;
        if (0 !== (c & b.child.childLanes))
          return vj(a, b, c);
        G(K, K.current & 1);
        a = gj(a, b, c);
        return null !== a ? a.sibling : null;
      }
      G(K, K.current & 1);
      break;
    case 19:
      d = 0 !== (c & b.childLanes);
      if (0 !== (a.flags & 128)) {
        if (d)
          return Ej(a, b, c);
        b.flags |= 128;
      }
      e = b.memoizedState;
      null !== e && (e.rendering = null, e.tail = null, e.lastEffect = null);
      G(K, K.current);
      if (d)
        break;
      else
        return null;
    case 22:
    case 23:
      return b.lanes = 0, lj(a, b, c);
  }
  return gj(a, b, c);
}
function Gj(a, b) {
  ch(b);
  switch (b.tag) {
    case 1:
      return Yf(b.type) && Zf(), a = b.flags, a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
    case 3:
      return Gh(), E(Vf), E(H), Lh(), a = b.flags, 0 !== (a & 65536) && 0 === (a & 128) ? (b.flags = a & -65537 | 128, b) : null;
    case 5:
      return Ih(b), null;
    case 13:
      E(K);
      a = b.memoizedState;
      if (null !== a && null !== a.dehydrated) {
        if (null === b.alternate)
          throw Error(p(340));
        nh();
      }
      a = b.flags;
      return a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
    case 19:
      return E(K), null;
    case 4:
      return Gh(), null;
    case 10:
      return qg(b.type._context), null;
    case 22:
    case 23:
      return bj(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
var Hj = false, S = false, Ij = "function" === typeof WeakSet ? WeakSet : Set, T = null;
function Jj(a, b) {
  var c = a.ref;
  if (null !== c)
    if ("function" === typeof c)
      try {
        c(null);
      } catch (d) {
        U(a, b, d);
      }
    else
      c.current = null;
}
function Kj(a, b, c) {
  try {
    c();
  } catch (d) {
    U(a, b, d);
  }
}
var Lj = false;
function Mj(a, b) {
  Bf = cd;
  a = Le();
  if (Me(a)) {
    if ("selectionStart" in a)
      var c = { start: a.selectionStart, end: a.selectionEnd };
    else
      a: {
        c = (c = a.ownerDocument) && c.defaultView || window;
        var d = c.getSelection && c.getSelection();
        if (d && 0 !== d.rangeCount) {
          c = d.anchorNode;
          var e = d.anchorOffset, f2 = d.focusNode;
          d = d.focusOffset;
          try {
            c.nodeType, f2.nodeType;
          } catch (Z) {
            c = null;
            break a;
          }
          var g = 0, h = -1, k2 = -1, l2 = 0, n2 = 0, u2 = a, q2 = null;
          b:
            for (; ; ) {
              for (var y2; ; ) {
                u2 !== c || 0 !== e && 3 !== u2.nodeType || (h = g + e);
                u2 !== f2 || 0 !== d && 3 !== u2.nodeType || (k2 = g + d);
                3 === u2.nodeType && (g += u2.nodeValue.length);
                if (null === (y2 = u2.firstChild))
                  break;
                q2 = u2;
                u2 = y2;
              }
              for (; ; ) {
                if (u2 === a)
                  break b;
                q2 === c && ++l2 === e && (h = g);
                q2 === f2 && ++n2 === d && (k2 = g);
                if (null !== (y2 = u2.nextSibling))
                  break;
                u2 = q2;
                q2 = u2.parentNode;
              }
              u2 = y2;
            }
          c = -1 === h || -1 === k2 ? null : { start: h, end: k2 };
        } else
          c = null;
      }
    c = c || { start: 0, end: 0 };
  } else
    c = null;
  Cf = { focusedElem: a, selectionRange: c };
  cd = false;
  for (T = b; null !== T; )
    if (b = T, a = b.child, 0 !== (b.subtreeFlags & 1028) && null !== a)
      a.return = b, T = a;
    else
      for (; null !== T; ) {
        b = T;
        try {
          var m2 = b.alternate;
          if (0 !== (b.flags & 1024))
            switch (b.tag) {
              case 0:
              case 11:
              case 15:
                break;
              case 1:
                if (null !== m2) {
                  var w2 = m2.memoizedProps, J2 = m2.memoizedState, v2 = b.stateNode, x2 = v2.getSnapshotBeforeUpdate(b.elementType === b.type ? w2 : kg(b.type, w2), J2);
                  v2.__reactInternalSnapshotBeforeUpdate = x2;
                }
                break;
              case 3:
                var r2 = b.stateNode.containerInfo;
                if (1 === r2.nodeType)
                  r2.textContent = "";
                else if (9 === r2.nodeType) {
                  var F2 = r2.body;
                  null != F2 && (F2.textContent = "");
                }
                break;
              case 5:
              case 6:
              case 4:
              case 17:
                break;
              default:
                throw Error(p(163));
            }
        } catch (Z) {
          U(b, b.return, Z);
        }
        a = b.sibling;
        if (null !== a) {
          a.return = b.return;
          T = a;
          break;
        }
        T = b.return;
      }
  m2 = Lj;
  Lj = false;
  return m2;
}
function Nj(a, b, c) {
  var d = b.updateQueue;
  d = null !== d ? d.lastEffect : null;
  if (null !== d) {
    var e = d = d.next;
    do {
      if ((e.tag & a) === a) {
        var f2 = e.destroy;
        e.destroy = void 0;
        void 0 !== f2 && Kj(b, c, f2);
      }
      e = e.next;
    } while (e !== d);
  }
}
function Oj(a, b) {
  b = b.updateQueue;
  b = null !== b ? b.lastEffect : null;
  if (null !== b) {
    var c = b = b.next;
    do {
      if ((c.tag & a) === a) {
        var d = c.create;
        c.destroy = d();
      }
      c = c.next;
    } while (c !== b);
  }
}
function Pj(a) {
  var b = a.ref;
  if (null !== b) {
    var c = a.stateNode;
    switch (a.tag) {
      case 5:
        a = c;
        break;
      default:
        a = c;
    }
    "function" === typeof b ? b(a) : b.current = a;
  }
}
function Qj(a) {
  var b = a.alternate;
  null !== b && (a.alternate = null, Qj(b));
  a.child = null;
  a.deletions = null;
  a.sibling = null;
  5 === a.tag && (b = a.stateNode, null !== b && (delete b[Nf], delete b[Of], delete b[nf], delete b[Pf], delete b[Qf]));
  a.stateNode = null;
  a.return = null;
  a.dependencies = null;
  a.memoizedProps = null;
  a.memoizedState = null;
  a.pendingProps = null;
  a.stateNode = null;
  a.updateQueue = null;
}
function Rj(a) {
  return 5 === a.tag || 3 === a.tag || 4 === a.tag;
}
function Sj(a) {
  a:
    for (; ; ) {
      for (; null === a.sibling; ) {
        if (null === a.return || Rj(a.return))
          return null;
        a = a.return;
      }
      a.sibling.return = a.return;
      for (a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag; ) {
        if (a.flags & 2)
          continue a;
        if (null === a.child || 4 === a.tag)
          continue a;
        else
          a.child.return = a, a = a.child;
      }
      if (!(a.flags & 2))
        return a.stateNode;
    }
}
function Tj(a, b, c) {
  var d = a.tag;
  if (5 === d || 6 === d)
    a = a.stateNode, b ? 8 === c.nodeType ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (8 === c.nodeType ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, null !== c && void 0 !== c || null !== b.onclick || (b.onclick = Af));
  else if (4 !== d && (a = a.child, null !== a))
    for (Tj(a, b, c), a = a.sibling; null !== a; )
      Tj(a, b, c), a = a.sibling;
}
function Uj(a, b, c) {
  var d = a.tag;
  if (5 === d || 6 === d)
    a = a.stateNode, b ? c.insertBefore(a, b) : c.appendChild(a);
  else if (4 !== d && (a = a.child, null !== a))
    for (Uj(a, b, c), a = a.sibling; null !== a; )
      Uj(a, b, c), a = a.sibling;
}
var V = null, Vj = false;
function Wj(a, b, c) {
  for (c = c.child; null !== c; )
    Xj(a, b, c), c = c.sibling;
}
function Xj(a, b, c) {
  if (kc && "function" === typeof kc.onCommitFiberUnmount)
    try {
      kc.onCommitFiberUnmount(jc, c);
    } catch (h) {
    }
  switch (c.tag) {
    case 5:
      S || Jj(c, b);
    case 6:
      var d = V, e = Vj;
      V = null;
      Wj(a, b, c);
      V = d;
      Vj = e;
      null !== V && (Vj ? (a = V, c = c.stateNode, 8 === a.nodeType ? a.parentNode.removeChild(c) : a.removeChild(c)) : V.removeChild(c.stateNode));
      break;
    case 18:
      null !== V && (Vj ? (a = V, c = c.stateNode, 8 === a.nodeType ? Jf(a.parentNode, c) : 1 === a.nodeType && Jf(a, c), ad(a)) : Jf(V, c.stateNode));
      break;
    case 4:
      d = V;
      e = Vj;
      V = c.stateNode.containerInfo;
      Vj = true;
      Wj(a, b, c);
      V = d;
      Vj = e;
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (!S && (d = c.updateQueue, null !== d && (d = d.lastEffect, null !== d))) {
        e = d = d.next;
        do {
          var f2 = e, g = f2.destroy;
          f2 = f2.tag;
          void 0 !== g && (0 !== (f2 & 2) ? Kj(c, b, g) : 0 !== (f2 & 4) && Kj(c, b, g));
          e = e.next;
        } while (e !== d);
      }
      Wj(a, b, c);
      break;
    case 1:
      if (!S && (Jj(c, b), d = c.stateNode, "function" === typeof d.componentWillUnmount))
        try {
          d.props = c.memoizedProps, d.state = c.memoizedState, d.componentWillUnmount();
        } catch (h) {
          U(c, b, h);
        }
      Wj(a, b, c);
      break;
    case 21:
      Wj(a, b, c);
      break;
    case 22:
      c.mode & 1 ? (S = (d = S) || null !== c.memoizedState, Wj(a, b, c), S = d) : Wj(a, b, c);
      break;
    default:
      Wj(a, b, c);
  }
}
function Yj(a) {
  var b = a.updateQueue;
  if (null !== b) {
    a.updateQueue = null;
    var c = a.stateNode;
    null === c && (c = a.stateNode = new Ij());
    b.forEach(function(b2) {
      var d = Zj.bind(null, a, b2);
      c.has(b2) || (c.add(b2), b2.then(d, d));
    });
  }
}
function ak(a, b) {
  var c = b.deletions;
  if (null !== c)
    for (var d = 0; d < c.length; d++) {
      var e = c[d];
      try {
        var f2 = a, g = b, h = g;
        a:
          for (; null !== h; ) {
            switch (h.tag) {
              case 5:
                V = h.stateNode;
                Vj = false;
                break a;
              case 3:
                V = h.stateNode.containerInfo;
                Vj = true;
                break a;
              case 4:
                V = h.stateNode.containerInfo;
                Vj = true;
                break a;
            }
            h = h.return;
          }
        if (null === V)
          throw Error(p(160));
        Xj(f2, g, e);
        V = null;
        Vj = false;
        var k2 = e.alternate;
        null !== k2 && (k2.return = null);
        e.return = null;
      } catch (l2) {
        U(e, b, l2);
      }
    }
  if (b.subtreeFlags & 12854)
    for (b = b.child; null !== b; )
      bk(b, a), b = b.sibling;
}
function bk(a, b) {
  var c = a.alternate, d = a.flags;
  switch (a.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      ak(b, a);
      ck(a);
      if (d & 4) {
        try {
          Nj(3, a, a.return), Oj(3, a);
        } catch (m2) {
          U(a, a.return, m2);
        }
        try {
          Nj(5, a, a.return);
        } catch (m2) {
          U(a, a.return, m2);
        }
      }
      break;
    case 1:
      ak(b, a);
      ck(a);
      d & 512 && null !== c && Jj(c, c.return);
      break;
    case 5:
      ak(b, a);
      ck(a);
      d & 512 && null !== c && Jj(c, c.return);
      if (a.flags & 32) {
        var e = a.stateNode;
        try {
          nb(e, "");
        } catch (m2) {
          U(a, a.return, m2);
        }
      }
      if (d & 4 && (e = a.stateNode, null != e)) {
        var f2 = a.memoizedProps, g = null !== c ? c.memoizedProps : f2, h = a.type, k2 = a.updateQueue;
        a.updateQueue = null;
        if (null !== k2)
          try {
            "input" === h && "radio" === f2.type && null != f2.name && Za(e, f2);
            ub(h, g);
            var l2 = ub(h, f2);
            for (g = 0; g < k2.length; g += 2) {
              var n2 = k2[g], u2 = k2[g + 1];
              "style" === n2 ? rb(e, u2) : "dangerouslySetInnerHTML" === n2 ? mb(e, u2) : "children" === n2 ? nb(e, u2) : sa(e, n2, u2, l2);
            }
            switch (h) {
              case "input":
                $a(e, f2);
                break;
              case "textarea":
                hb(e, f2);
                break;
              case "select":
                var q2 = e._wrapperState.wasMultiple;
                e._wrapperState.wasMultiple = !!f2.multiple;
                var y2 = f2.value;
                null != y2 ? eb(e, !!f2.multiple, y2, false) : q2 !== !!f2.multiple && (null != f2.defaultValue ? eb(
                  e,
                  !!f2.multiple,
                  f2.defaultValue,
                  true
                ) : eb(e, !!f2.multiple, f2.multiple ? [] : "", false));
            }
            e[Of] = f2;
          } catch (m2) {
            U(a, a.return, m2);
          }
      }
      break;
    case 6:
      ak(b, a);
      ck(a);
      if (d & 4) {
        if (null === a.stateNode)
          throw Error(p(162));
        l2 = a.stateNode;
        n2 = a.memoizedProps;
        try {
          l2.nodeValue = n2;
        } catch (m2) {
          U(a, a.return, m2);
        }
      }
      break;
    case 3:
      ak(b, a);
      ck(a);
      if (d & 4 && null !== c && c.memoizedState.isDehydrated)
        try {
          ad(b.containerInfo);
        } catch (m2) {
          U(a, a.return, m2);
        }
      break;
    case 4:
      ak(b, a);
      ck(a);
      break;
    case 13:
      ak(b, a);
      ck(a);
      l2 = a.child;
      l2.flags & 8192 && null !== l2.memoizedState && (null === l2.alternate || null === l2.alternate.memoizedState) && (dk = B());
      d & 4 && Yj(a);
      break;
    case 22:
      l2 = null !== c && null !== c.memoizedState;
      a.mode & 1 ? (S = (n2 = S) || l2, ak(b, a), S = n2) : ak(b, a);
      ck(a);
      if (d & 8192) {
        n2 = null !== a.memoizedState;
        a:
          for (u2 = null, q2 = a; ; ) {
            if (5 === q2.tag) {
              if (null === u2) {
                u2 = q2;
                try {
                  e = q2.stateNode, n2 ? (f2 = e.style, "function" === typeof f2.setProperty ? f2.setProperty("display", "none", "important") : f2.display = "none") : (h = q2.stateNode, k2 = q2.memoizedProps.style, g = void 0 !== k2 && null !== k2 && k2.hasOwnProperty("display") ? k2.display : null, h.style.display = qb("display", g));
                } catch (m2) {
                  U(a, a.return, m2);
                }
              }
            } else if (6 === q2.tag) {
              if (null === u2)
                try {
                  q2.stateNode.nodeValue = n2 ? "" : q2.memoizedProps;
                } catch (m2) {
                  U(a, a.return, m2);
                }
            } else if ((22 !== q2.tag && 23 !== q2.tag || null === q2.memoizedState || q2 === a) && null !== q2.child) {
              q2.child.return = q2;
              q2 = q2.child;
              continue;
            }
            if (q2 === a)
              break a;
            for (; null === q2.sibling; ) {
              if (null === q2.return || q2.return === a)
                break a;
              u2 === q2 && (u2 = null);
              q2 = q2.return;
            }
            u2 === q2 && (u2 = null);
            q2.sibling.return = q2.return;
            q2 = q2.sibling;
          }
        if (n2 && !l2 && 0 !== (a.mode & 1))
          for (T = a, a = a.child; null !== a; ) {
            for (l2 = T = a; null !== T; ) {
              n2 = T;
              u2 = n2.child;
              switch (n2.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                  Nj(
                    4,
                    n2,
                    n2.return
                  );
                  break;
                case 1:
                  Jj(n2, n2.return);
                  f2 = n2.stateNode;
                  if ("function" === typeof f2.componentWillUnmount) {
                    q2 = n2;
                    y2 = n2.return;
                    try {
                      e = q2, f2.props = e.memoizedProps, f2.state = e.memoizedState, f2.componentWillUnmount();
                    } catch (m2) {
                      U(q2, y2, m2);
                    }
                  }
                  break;
                case 5:
                  Jj(n2, n2.return);
                  break;
                case 22:
                  if (null !== n2.memoizedState) {
                    ek(l2);
                    continue;
                  }
              }
              null !== u2 ? (u2.return = n2, T = u2) : ek(l2);
            }
            a = a.sibling;
          }
      }
      break;
    case 19:
      ak(b, a);
      ck(a);
      d & 4 && Yj(a);
      break;
    case 21:
      break;
    default:
      ak(b, a), ck(a);
  }
}
function ck(a) {
  var b = a.flags;
  if (b & 2) {
    try {
      a: {
        for (var c = a.return; null !== c; ) {
          if (Rj(c)) {
            var d = c;
            break a;
          }
          c = c.return;
        }
        throw Error(p(160));
      }
      switch (d.tag) {
        case 5:
          var e = d.stateNode;
          d.flags & 32 && (nb(e, ""), d.flags &= -33);
          var f2 = Sj(a);
          Uj(a, f2, e);
          break;
        case 3:
        case 4:
          var g = d.stateNode.containerInfo, h = Sj(a);
          Tj(a, h, g);
          break;
        default:
          throw Error(p(161));
      }
    } catch (k2) {
      U(a, a.return, k2);
    }
    a.flags &= -3;
  }
  b & 4096 && (a.flags &= -4097);
}
function fk(a, b, c) {
  T = a;
  gk(a);
}
function gk(a, b, c) {
  for (var d = 0 !== (a.mode & 1); null !== T; ) {
    var e = T, f2 = e.child;
    if (22 === e.tag && d) {
      var g = null !== e.memoizedState || Hj;
      if (!g) {
        var h = e.alternate, k2 = null !== h && null !== h.memoizedState || S;
        h = Hj;
        var l2 = S;
        Hj = g;
        if ((S = k2) && !l2)
          for (T = e; null !== T; )
            g = T, k2 = g.child, 22 === g.tag && null !== g.memoizedState ? hk(e) : null !== k2 ? (k2.return = g, T = k2) : hk(e);
        for (; null !== f2; )
          T = f2, gk(f2), f2 = f2.sibling;
        T = e;
        Hj = h;
        S = l2;
      }
      ik(a);
    } else
      0 !== (e.subtreeFlags & 8772) && null !== f2 ? (f2.return = e, T = f2) : ik(a);
  }
}
function ik(a) {
  for (; null !== T; ) {
    var b = T;
    if (0 !== (b.flags & 8772)) {
      var c = b.alternate;
      try {
        if (0 !== (b.flags & 8772))
          switch (b.tag) {
            case 0:
            case 11:
            case 15:
              S || Oj(5, b);
              break;
            case 1:
              var d = b.stateNode;
              if (b.flags & 4 && !S)
                if (null === c)
                  d.componentDidMount();
                else {
                  var e = b.elementType === b.type ? c.memoizedProps : kg(b.type, c.memoizedProps);
                  d.componentDidUpdate(e, c.memoizedState, d.__reactInternalSnapshotBeforeUpdate);
                }
              var f2 = b.updateQueue;
              null !== f2 && Gg$1(b, f2, d);
              break;
            case 3:
              var g = b.updateQueue;
              if (null !== g) {
                c = null;
                if (null !== b.child)
                  switch (b.child.tag) {
                    case 5:
                      c = b.child.stateNode;
                      break;
                    case 1:
                      c = b.child.stateNode;
                  }
                Gg$1(b, g, c);
              }
              break;
            case 5:
              var h = b.stateNode;
              if (null === c && b.flags & 4) {
                c = h;
                var k2 = b.memoizedProps;
                switch (b.type) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    k2.autoFocus && c.focus();
                    break;
                  case "img":
                    k2.src && (c.src = k2.src);
                }
              }
              break;
            case 6:
              break;
            case 4:
              break;
            case 12:
              break;
            case 13:
              if (null === b.memoizedState) {
                var l2 = b.alternate;
                if (null !== l2) {
                  var n2 = l2.memoizedState;
                  if (null !== n2) {
                    var u2 = n2.dehydrated;
                    null !== u2 && ad(u2);
                  }
                }
              }
              break;
            case 19:
            case 17:
            case 21:
            case 22:
            case 23:
              break;
            default:
              throw Error(p(163));
          }
        S || b.flags & 512 && Pj(b);
      } catch (q2) {
        U(b, b.return, q2);
      }
    }
    if (b === a) {
      T = null;
      break;
    }
    c = b.sibling;
    if (null !== c) {
      c.return = b.return;
      T = c;
      break;
    }
    T = b.return;
  }
}
function ek(a) {
  for (; null !== T; ) {
    var b = T;
    if (b === a) {
      T = null;
      break;
    }
    var c = b.sibling;
    if (null !== c) {
      c.return = b.return;
      T = c;
      break;
    }
    T = b.return;
  }
}
function hk(a) {
  for (; null !== T; ) {
    var b = T;
    try {
      switch (b.tag) {
        case 0:
        case 11:
        case 15:
          var c = b.return;
          try {
            Oj(4, b);
          } catch (k2) {
            U(b, c, k2);
          }
          break;
        case 1:
          var d = b.stateNode;
          if ("function" === typeof d.componentDidMount) {
            var e = b.return;
            try {
              d.componentDidMount();
            } catch (k2) {
              U(b, e, k2);
            }
          }
          var f2 = b.return;
          try {
            Pj(b);
          } catch (k2) {
            U(b, f2, k2);
          }
          break;
        case 5:
          var g = b.return;
          try {
            Pj(b);
          } catch (k2) {
            U(b, g, k2);
          }
      }
    } catch (k2) {
      U(b, b.return, k2);
    }
    if (b === a) {
      T = null;
      break;
    }
    var h = b.sibling;
    if (null !== h) {
      h.return = b.return;
      T = h;
      break;
    }
    T = b.return;
  }
}
var jk = Math.ceil, kk = ta.ReactCurrentDispatcher, lk = ta.ReactCurrentOwner, mk = ta.ReactCurrentBatchConfig, W = 0, P = null, X = null, Y = 0, cj = 0, mj = Tf(0), R = 0, nk = null, Fg = 0, ok = 0, pk = 0, qk = null, rk = null, dk = 0, aj = Infinity, sk = null, Li = false, Mi = null, Oi = null, tk = false, uk = null, vk = 0, wk = 0, xk = null, yk = -1, zk = 0;
function Jg() {
  return 0 !== (W & 6) ? B() : -1 !== yk ? yk : yk = B();
}
function Kg(a) {
  if (0 === (a.mode & 1))
    return 1;
  if (0 !== (W & 2) && 0 !== Y)
    return Y & -Y;
  if (null !== jg.transition)
    return 0 === zk && (zk = xc()), zk;
  a = C;
  if (0 !== a)
    return a;
  a = window.event;
  a = void 0 === a ? 16 : id(a.type);
  return a;
}
function Lg(a, b, c) {
  if (50 < wk)
    throw wk = 0, xk = null, Error(p(185));
  var d = Ak(a, b);
  if (null === d)
    return null;
  zc(d, b, c);
  if (0 === (W & 2) || d !== P)
    d === P && (0 === (W & 2) && (ok |= b), 4 === R && Bk(d, Y)), Ck(d, c), 1 === b && 0 === W && 0 === (a.mode & 1) && (aj = B() + 500, eg$1 && ig());
  return d;
}
function Ak(a, b) {
  a.lanes |= b;
  var c = a.alternate;
  null !== c && (c.lanes |= b);
  c = a;
  for (a = a.return; null !== a; )
    a.childLanes |= b, c = a.alternate, null !== c && (c.childLanes |= b), c = a, a = a.return;
  return 3 === c.tag ? c.stateNode : null;
}
function Bg(a) {
  return (null !== P || null !== vg) && 0 !== (a.mode & 1) && 0 === (W & 2);
}
function Ck(a, b) {
  var c = a.callbackNode;
  vc(a, b);
  var d = tc(a, a === P ? Y : 0);
  if (0 === d)
    null !== c && ac$1(c), a.callbackNode = null, a.callbackPriority = 0;
  else if (b = d & -d, a.callbackPriority !== b) {
    null != c && ac$1(c);
    if (1 === b)
      0 === a.tag ? hg(Dk.bind(null, a)) : gg$1(Dk.bind(null, a)), If(function() {
        0 === W && ig();
      }), c = null;
    else {
      switch (Cc(d)) {
        case 1:
          c = ec;
          break;
        case 4:
          c = fc;
          break;
        case 16:
          c = gc;
          break;
        case 536870912:
          c = ic$1;
          break;
        default:
          c = gc;
      }
      c = Ek(c, Fk.bind(null, a));
    }
    a.callbackPriority = b;
    a.callbackNode = c;
  }
}
function Fk(a, b) {
  yk = -1;
  zk = 0;
  if (0 !== (W & 6))
    throw Error(p(327));
  var c = a.callbackNode;
  if (Gk() && a.callbackNode !== c)
    return null;
  var d = tc(a, a === P ? Y : 0);
  if (0 === d)
    return null;
  if (0 !== (d & 30) || 0 !== (d & a.expiredLanes) || b)
    b = Hk(a, d);
  else {
    b = d;
    var e = W;
    W |= 2;
    var f2 = Ik();
    if (P !== a || Y !== b)
      sk = null, aj = B() + 500, Jk(a, b);
    do
      try {
        Kk();
        break;
      } catch (h) {
        Lk(a, h);
      }
    while (1);
    pg();
    kk.current = f2;
    W = e;
    null !== X ? b = 0 : (P = null, Y = 0, b = R);
  }
  if (0 !== b) {
    2 === b && (e = wc(a), 0 !== e && (d = e, b = Mk(a, e)));
    if (1 === b)
      throw c = nk, Jk(a, 0), Bk(a, d), Ck(a, B()), c;
    if (6 === b)
      Bk(a, d);
    else {
      e = a.current.alternate;
      if (0 === (d & 30) && !Nk(e) && (b = Hk(a, d), 2 === b && (f2 = wc(a), 0 !== f2 && (d = f2, b = Mk(a, f2))), 1 === b))
        throw c = nk, Jk(a, 0), Bk(a, d), Ck(a, B()), c;
      a.finishedWork = e;
      a.finishedLanes = d;
      switch (b) {
        case 0:
        case 1:
          throw Error(p(345));
        case 2:
          Ok(a, rk, sk);
          break;
        case 3:
          Bk(a, d);
          if ((d & 130023424) === d && (b = dk + 500 - B(), 10 < b)) {
            if (0 !== tc(a, 0))
              break;
            e = a.suspendedLanes;
            if ((e & d) !== d) {
              Jg();
              a.pingedLanes |= a.suspendedLanes & e;
              break;
            }
            a.timeoutHandle = Ef(Ok.bind(null, a, rk, sk), b);
            break;
          }
          Ok(a, rk, sk);
          break;
        case 4:
          Bk(a, d);
          if ((d & 4194240) === d)
            break;
          b = a.eventTimes;
          for (e = -1; 0 < d; ) {
            var g = 31 - nc(d);
            f2 = 1 << g;
            g = b[g];
            g > e && (e = g);
            d &= ~f2;
          }
          d = e;
          d = B() - d;
          d = (120 > d ? 120 : 480 > d ? 480 : 1080 > d ? 1080 : 1920 > d ? 1920 : 3e3 > d ? 3e3 : 4320 > d ? 4320 : 1960 * jk(d / 1960)) - d;
          if (10 < d) {
            a.timeoutHandle = Ef(Ok.bind(null, a, rk, sk), d);
            break;
          }
          Ok(a, rk, sk);
          break;
        case 5:
          Ok(a, rk, sk);
          break;
        default:
          throw Error(p(329));
      }
    }
  }
  Ck(a, B());
  return a.callbackNode === c ? Fk.bind(null, a) : null;
}
function Mk(a, b) {
  var c = qk;
  a.current.memoizedState.isDehydrated && (Jk(a, b).flags |= 256);
  a = Hk(a, b);
  2 !== a && (b = rk, rk = c, null !== b && Zi(b));
  return a;
}
function Zi(a) {
  null === rk ? rk = a : rk.push.apply(rk, a);
}
function Nk(a) {
  for (var b = a; ; ) {
    if (b.flags & 16384) {
      var c = b.updateQueue;
      if (null !== c && (c = c.stores, null !== c))
        for (var d = 0; d < c.length; d++) {
          var e = c[d], f2 = e.getSnapshot;
          e = e.value;
          try {
            if (!Ge(f2(), e))
              return false;
          } catch (g) {
            return false;
          }
        }
    }
    c = b.child;
    if (b.subtreeFlags & 16384 && null !== c)
      c.return = b, b = c;
    else {
      if (b === a)
        break;
      for (; null === b.sibling; ) {
        if (null === b.return || b.return === a)
          return true;
        b = b.return;
      }
      b.sibling.return = b.return;
      b = b.sibling;
    }
  }
  return true;
}
function Bk(a, b) {
  b &= ~pk;
  b &= ~ok;
  a.suspendedLanes |= b;
  a.pingedLanes &= ~b;
  for (a = a.expirationTimes; 0 < b; ) {
    var c = 31 - nc(b), d = 1 << c;
    a[c] = -1;
    b &= ~d;
  }
}
function Dk(a) {
  if (0 !== (W & 6))
    throw Error(p(327));
  Gk();
  var b = tc(a, 0);
  if (0 === (b & 1))
    return Ck(a, B()), null;
  var c = Hk(a, b);
  if (0 !== a.tag && 2 === c) {
    var d = wc(a);
    0 !== d && (b = d, c = Mk(a, d));
  }
  if (1 === c)
    throw c = nk, Jk(a, 0), Bk(a, b), Ck(a, B()), c;
  if (6 === c)
    throw Error(p(345));
  a.finishedWork = a.current.alternate;
  a.finishedLanes = b;
  Ok(a, rk, sk);
  Ck(a, B());
  return null;
}
function Pk(a, b) {
  var c = W;
  W |= 1;
  try {
    return a(b);
  } finally {
    W = c, 0 === W && (aj = B() + 500, eg$1 && ig());
  }
}
function Qk(a) {
  null !== uk && 0 === uk.tag && 0 === (W & 6) && Gk();
  var b = W;
  W |= 1;
  var c = mk.transition, d = C;
  try {
    if (mk.transition = null, C = 1, a)
      return a();
  } finally {
    C = d, mk.transition = c, W = b, 0 === (W & 6) && ig();
  }
}
function bj() {
  cj = mj.current;
  E(mj);
}
function Jk(a, b) {
  a.finishedWork = null;
  a.finishedLanes = 0;
  var c = a.timeoutHandle;
  -1 !== c && (a.timeoutHandle = -1, Ff(c));
  if (null !== X)
    for (c = X.return; null !== c; ) {
      var d = c;
      ch(d);
      switch (d.tag) {
        case 1:
          d = d.type.childContextTypes;
          null !== d && void 0 !== d && Zf();
          break;
        case 3:
          Gh();
          E(Vf);
          E(H);
          Lh();
          break;
        case 5:
          Ih(d);
          break;
        case 4:
          Gh();
          break;
        case 13:
          E(K);
          break;
        case 19:
          E(K);
          break;
        case 10:
          qg(d.type._context);
          break;
        case 22:
        case 23:
          bj();
      }
      c = c.return;
    }
  P = a;
  X = a = th(a.current, null);
  Y = cj = b;
  R = 0;
  nk = null;
  pk = ok = Fg = 0;
  rk = qk = null;
  if (null !== vg) {
    for (b = 0; b < vg.length; b++)
      if (c = vg[b], d = c.interleaved, null !== d) {
        c.interleaved = null;
        var e = d.next, f2 = c.pending;
        if (null !== f2) {
          var g = f2.next;
          f2.next = e;
          d.next = g;
        }
        c.pending = d;
      }
    vg = null;
  }
  return a;
}
function Lk(a, b) {
  do {
    var c = X;
    try {
      pg();
      Mh.current = Yh;
      if (Ph) {
        for (var d = L.memoizedState; null !== d; ) {
          var e = d.queue;
          null !== e && (e.pending = null);
          d = d.next;
        }
        Ph = false;
      }
      Oh = 0;
      N = M = L = null;
      Qh = false;
      Rh = 0;
      lk.current = null;
      if (null === c || null === c.return) {
        R = 1;
        nk = b;
        X = null;
        break;
      }
      a: {
        var f2 = a, g = c.return, h = c, k2 = b;
        b = Y;
        h.flags |= 32768;
        if (null !== k2 && "object" === typeof k2 && "function" === typeof k2.then) {
          var l2 = k2, n2 = h, u2 = n2.tag;
          if (0 === (n2.mode & 1) && (0 === u2 || 11 === u2 || 15 === u2)) {
            var q2 = n2.alternate;
            q2 ? (n2.updateQueue = q2.updateQueue, n2.memoizedState = q2.memoizedState, n2.lanes = q2.lanes) : (n2.updateQueue = null, n2.memoizedState = null);
          }
          var y2 = Ri(g);
          if (null !== y2) {
            y2.flags &= -257;
            Si(y2, g, h, f2, b);
            y2.mode & 1 && Pi$1(f2, l2, b);
            b = y2;
            k2 = l2;
            var m2 = b.updateQueue;
            if (null === m2) {
              var w2 = /* @__PURE__ */ new Set();
              w2.add(k2);
              b.updateQueue = w2;
            } else
              m2.add(k2);
            break a;
          } else {
            if (0 === (b & 1)) {
              Pi$1(f2, l2, b);
              $i();
              break a;
            }
            k2 = Error(p(426));
          }
        } else if (I && h.mode & 1) {
          var J2 = Ri(g);
          if (null !== J2) {
            0 === (J2.flags & 65536) && (J2.flags |= 256);
            Si(J2, g, h, f2, b);
            oh(k2);
            break a;
          }
        }
        f2 = k2;
        4 !== R && (R = 2);
        null === qk ? qk = [f2] : qk.push(f2);
        k2 = Hi(k2, h);
        h = g;
        do {
          switch (h.tag) {
            case 3:
              h.flags |= 65536;
              b &= -b;
              h.lanes |= b;
              var v2 = Ki(h, k2, b);
              Dg(h, v2);
              break a;
            case 1:
              f2 = k2;
              var x2 = h.type, r2 = h.stateNode;
              if (0 === (h.flags & 128) && ("function" === typeof x2.getDerivedStateFromError || null !== r2 && "function" === typeof r2.componentDidCatch && (null === Oi || !Oi.has(r2)))) {
                h.flags |= 65536;
                b &= -b;
                h.lanes |= b;
                var F2 = Ni(h, f2, b);
                Dg(h, F2);
                break a;
              }
          }
          h = h.return;
        } while (null !== h);
      }
      Rk(c);
    } catch (Z) {
      b = Z;
      X === c && null !== c && (X = c = c.return);
      continue;
    }
    break;
  } while (1);
}
function Ik() {
  var a = kk.current;
  kk.current = Yh;
  return null === a ? Yh : a;
}
function $i() {
  if (0 === R || 3 === R || 2 === R)
    R = 4;
  null === P || 0 === (Fg & 268435455) && 0 === (ok & 268435455) || Bk(P, Y);
}
function Hk(a, b) {
  var c = W;
  W |= 2;
  var d = Ik();
  if (P !== a || Y !== b)
    sk = null, Jk(a, b);
  do
    try {
      Sk();
      break;
    } catch (e) {
      Lk(a, e);
    }
  while (1);
  pg();
  W = c;
  kk.current = d;
  if (null !== X)
    throw Error(p(261));
  P = null;
  Y = 0;
  return R;
}
function Sk() {
  for (; null !== X; )
    Tk(X);
}
function Kk() {
  for (; null !== X && !bc(); )
    Tk(X);
}
function Tk(a) {
  var b = Uk(a.alternate, a, cj);
  a.memoizedProps = a.pendingProps;
  null === b ? Rk(a) : X = b;
  lk.current = null;
}
function Rk(a) {
  var b = a;
  do {
    var c = b.alternate;
    a = b.return;
    if (0 === (b.flags & 32768)) {
      if (c = Yi(c, b, cj), null !== c) {
        X = c;
        return;
      }
    } else {
      c = Gj(c, b);
      if (null !== c) {
        c.flags &= 32767;
        X = c;
        return;
      }
      if (null !== a)
        a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
      else {
        R = 6;
        X = null;
        return;
      }
    }
    b = b.sibling;
    if (null !== b) {
      X = b;
      return;
    }
    X = b = a;
  } while (null !== b);
  0 === R && (R = 5);
}
function Ok(a, b, c) {
  var d = C, e = mk.transition;
  try {
    mk.transition = null, C = 1, Vk(a, b, c, d);
  } finally {
    mk.transition = e, C = d;
  }
  return null;
}
function Vk(a, b, c, d) {
  do
    Gk();
  while (null !== uk);
  if (0 !== (W & 6))
    throw Error(p(327));
  c = a.finishedWork;
  var e = a.finishedLanes;
  if (null === c)
    return null;
  a.finishedWork = null;
  a.finishedLanes = 0;
  if (c === a.current)
    throw Error(p(177));
  a.callbackNode = null;
  a.callbackPriority = 0;
  var f2 = c.lanes | c.childLanes;
  Ac(a, f2);
  a === P && (X = P = null, Y = 0);
  0 === (c.subtreeFlags & 2064) && 0 === (c.flags & 2064) || tk || (tk = true, Ek(gc, function() {
    Gk();
    return null;
  }));
  f2 = 0 !== (c.flags & 15990);
  if (0 !== (c.subtreeFlags & 15990) || f2) {
    f2 = mk.transition;
    mk.transition = null;
    var g = C;
    C = 1;
    var h = W;
    W |= 4;
    lk.current = null;
    Mj(a, c);
    bk(c, a);
    Ne(Cf);
    cd = !!Bf;
    Cf = Bf = null;
    a.current = c;
    fk(c);
    cc();
    W = h;
    C = g;
    mk.transition = f2;
  } else
    a.current = c;
  tk && (tk = false, uk = a, vk = e);
  f2 = a.pendingLanes;
  0 === f2 && (Oi = null);
  lc(c.stateNode);
  Ck(a, B());
  if (null !== b)
    for (d = a.onRecoverableError, c = 0; c < b.length; c++)
      d(b[c]);
  if (Li)
    throw Li = false, a = Mi, Mi = null, a;
  0 !== (vk & 1) && 0 !== a.tag && Gk();
  f2 = a.pendingLanes;
  0 !== (f2 & 1) ? a === xk ? wk++ : (wk = 0, xk = a) : wk = 0;
  ig();
  return null;
}
function Gk() {
  if (null !== uk) {
    var a = Cc(vk), b = mk.transition, c = C;
    try {
      mk.transition = null;
      C = 16 > a ? 16 : a;
      if (null === uk)
        var d = false;
      else {
        a = uk;
        uk = null;
        vk = 0;
        if (0 !== (W & 6))
          throw Error(p(331));
        var e = W;
        W |= 4;
        for (T = a.current; null !== T; ) {
          var f2 = T, g = f2.child;
          if (0 !== (T.flags & 16)) {
            var h = f2.deletions;
            if (null !== h) {
              for (var k2 = 0; k2 < h.length; k2++) {
                var l2 = h[k2];
                for (T = l2; null !== T; ) {
                  var n2 = T;
                  switch (n2.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Nj(8, n2, f2);
                  }
                  var u2 = n2.child;
                  if (null !== u2)
                    u2.return = n2, T = u2;
                  else
                    for (; null !== T; ) {
                      n2 = T;
                      var q2 = n2.sibling, y2 = n2.return;
                      Qj(n2);
                      if (n2 === l2) {
                        T = null;
                        break;
                      }
                      if (null !== q2) {
                        q2.return = y2;
                        T = q2;
                        break;
                      }
                      T = y2;
                    }
                }
              }
              var m2 = f2.alternate;
              if (null !== m2) {
                var w2 = m2.child;
                if (null !== w2) {
                  m2.child = null;
                  do {
                    var J2 = w2.sibling;
                    w2.sibling = null;
                    w2 = J2;
                  } while (null !== w2);
                }
              }
              T = f2;
            }
          }
          if (0 !== (f2.subtreeFlags & 2064) && null !== g)
            g.return = f2, T = g;
          else
            b:
              for (; null !== T; ) {
                f2 = T;
                if (0 !== (f2.flags & 2048))
                  switch (f2.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Nj(9, f2, f2.return);
                  }
                var v2 = f2.sibling;
                if (null !== v2) {
                  v2.return = f2.return;
                  T = v2;
                  break b;
                }
                T = f2.return;
              }
        }
        var x2 = a.current;
        for (T = x2; null !== T; ) {
          g = T;
          var r2 = g.child;
          if (0 !== (g.subtreeFlags & 2064) && null !== r2)
            r2.return = g, T = r2;
          else
            b:
              for (g = x2; null !== T; ) {
                h = T;
                if (0 !== (h.flags & 2048))
                  try {
                    switch (h.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Oj(9, h);
                    }
                  } catch (Z) {
                    U(h, h.return, Z);
                  }
                if (h === g) {
                  T = null;
                  break b;
                }
                var F2 = h.sibling;
                if (null !== F2) {
                  F2.return = h.return;
                  T = F2;
                  break b;
                }
                T = h.return;
              }
        }
        W = e;
        ig();
        if (kc && "function" === typeof kc.onPostCommitFiberRoot)
          try {
            kc.onPostCommitFiberRoot(jc, a);
          } catch (Z) {
          }
        d = true;
      }
      return d;
    } finally {
      C = c, mk.transition = b;
    }
  }
  return false;
}
function Wk(a, b, c) {
  b = Hi(c, b);
  b = Ki(a, b, 1);
  Ag(a, b);
  b = Jg();
  a = Ak(a, 1);
  null !== a && (zc(a, 1, b), Ck(a, b));
}
function U(a, b, c) {
  if (3 === a.tag)
    Wk(a, a, c);
  else
    for (; null !== b; ) {
      if (3 === b.tag) {
        Wk(b, a, c);
        break;
      } else if (1 === b.tag) {
        var d = b.stateNode;
        if ("function" === typeof b.type.getDerivedStateFromError || "function" === typeof d.componentDidCatch && (null === Oi || !Oi.has(d))) {
          a = Hi(c, a);
          a = Ni(b, a, 1);
          Ag(b, a);
          a = Jg();
          b = Ak(b, 1);
          null !== b && (zc(b, 1, a), Ck(b, a));
          break;
        }
      }
      b = b.return;
    }
}
function Qi(a, b, c) {
  var d = a.pingCache;
  null !== d && d.delete(b);
  b = Jg();
  a.pingedLanes |= a.suspendedLanes & c;
  P === a && (Y & c) === c && (4 === R || 3 === R && (Y & 130023424) === Y && 500 > B() - dk ? Jk(a, 0) : pk |= c);
  Ck(a, b);
}
function Xk(a, b) {
  0 === b && (0 === (a.mode & 1) ? b = 1 : (b = rc, rc <<= 1, 0 === (rc & 130023424) && (rc = 4194304)));
  var c = Jg();
  a = Ak(a, b);
  null !== a && (zc(a, b, c), Ck(a, c));
}
function zj(a) {
  var b = a.memoizedState, c = 0;
  null !== b && (c = b.retryLane);
  Xk(a, c);
}
function Zj(a, b) {
  var c = 0;
  switch (a.tag) {
    case 13:
      var d = a.stateNode;
      var e = a.memoizedState;
      null !== e && (c = e.retryLane);
      break;
    case 19:
      d = a.stateNode;
      break;
    default:
      throw Error(p(314));
  }
  null !== d && d.delete(b);
  Xk(a, c);
}
var Uk;
Uk = function(a, b, c) {
  if (null !== a)
    if (a.memoizedProps !== b.pendingProps || Vf.current)
      tg = true;
    else {
      if (0 === (a.lanes & c) && 0 === (b.flags & 128))
        return tg = false, Fj(a, b, c);
      tg = 0 !== (a.flags & 131072) ? true : false;
    }
  else
    tg = false, I && 0 !== (b.flags & 1048576) && ah(b, Ug, b.index);
  b.lanes = 0;
  switch (b.tag) {
    case 2:
      var d = b.type;
      null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2);
      a = b.pendingProps;
      var e = Xf(b, H.current);
      sg(b, c);
      e = Uh(null, b, d, a, e, c);
      var f2 = Zh();
      b.flags |= 1;
      "object" === typeof e && null !== e && "function" === typeof e.render && void 0 === e.$$typeof ? (b.tag = 1, b.memoizedState = null, b.updateQueue = null, Yf(d) ? (f2 = true, bg(b)) : f2 = false, b.memoizedState = null !== e.state && void 0 !== e.state ? e.state : null, xg(b), e.updater = Mg, b.stateNode = e, e._reactInternals = b, Qg(b, d, a, c), b = pj(null, b, d, true, f2, c)) : (b.tag = 0, I && f2 && bh(b), ej(null, b, e, c), b = b.child);
      return b;
    case 16:
      d = b.elementType;
      a: {
        null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2);
        a = b.pendingProps;
        e = d._init;
        d = e(d._payload);
        b.type = d;
        e = b.tag = Yk(d);
        a = kg(d, a);
        switch (e) {
          case 0:
            b = kj(null, b, d, a, c);
            break a;
          case 1:
            b = oj(
              null,
              b,
              d,
              a,
              c
            );
            break a;
          case 11:
            b = fj(null, b, d, a, c);
            break a;
          case 14:
            b = hj(null, b, d, kg(d.type, a), c);
            break a;
        }
        throw Error(p(306, d, ""));
      }
      return b;
    case 0:
      return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : kg(d, e), kj(a, b, d, e, c);
    case 1:
      return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : kg(d, e), oj(a, b, d, e, c);
    case 3:
      a: {
        qj(b);
        if (null === a)
          throw Error(p(387));
        d = b.pendingProps;
        f2 = b.memoizedState;
        e = f2.element;
        yg(a, b);
        Eg(b, d, null, c);
        var g = b.memoizedState;
        d = g.element;
        if (f2.isDehydrated)
          if (f2 = {
            element: d,
            isDehydrated: false,
            cache: g.cache,
            pendingSuspenseBoundaries: g.pendingSuspenseBoundaries,
            transitions: g.transitions
          }, b.updateQueue.baseState = f2, b.memoizedState = f2, b.flags & 256) {
            e = Error(p(423));
            b = rj(a, b, d, c, e);
            break a;
          } else if (d !== e) {
            e = Error(p(424));
            b = rj(a, b, d, c, e);
            break a;
          } else
            for (eh = Kf(b.stateNode.containerInfo.firstChild), dh = b, I = true, fh = null, c = zh(b, null, d, c), b.child = c; c; )
              c.flags = c.flags & -3 | 4096, c = c.sibling;
        else {
          nh();
          if (d === e) {
            b = gj(a, b, c);
            break a;
          }
          ej(a, b, d, c);
        }
        b = b.child;
      }
      return b;
    case 5:
      return Hh(b), null === a && kh(b), d = b.type, e = b.pendingProps, f2 = null !== a ? a.memoizedProps : null, g = e.children, Df(d, e) ? g = null : null !== f2 && Df(d, f2) && (b.flags |= 32), nj(a, b), ej(a, b, g, c), b.child;
    case 6:
      return null === a && kh(b), null;
    case 13:
      return vj(a, b, c);
    case 4:
      return Fh(b, b.stateNode.containerInfo), d = b.pendingProps, null === a ? b.child = yh(b, null, d, c) : ej(a, b, d, c), b.child;
    case 11:
      return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : kg(d, e), fj(a, b, d, e, c);
    case 7:
      return ej(a, b, b.pendingProps, c), b.child;
    case 8:
      return ej(a, b, b.pendingProps.children, c), b.child;
    case 12:
      return ej(
        a,
        b,
        b.pendingProps.children,
        c
      ), b.child;
    case 10:
      a: {
        d = b.type._context;
        e = b.pendingProps;
        f2 = b.memoizedProps;
        g = e.value;
        G(lg$1, d._currentValue);
        d._currentValue = g;
        if (null !== f2)
          if (Ge(f2.value, g)) {
            if (f2.children === e.children && !Vf.current) {
              b = gj(a, b, c);
              break a;
            }
          } else
            for (f2 = b.child, null !== f2 && (f2.return = b); null !== f2; ) {
              var h = f2.dependencies;
              if (null !== h) {
                g = f2.child;
                for (var k2 = h.firstContext; null !== k2; ) {
                  if (k2.context === d) {
                    if (1 === f2.tag) {
                      k2 = zg(-1, c & -c);
                      k2.tag = 2;
                      var l2 = f2.updateQueue;
                      if (null !== l2) {
                        l2 = l2.shared;
                        var n2 = l2.pending;
                        null === n2 ? k2.next = k2 : (k2.next = n2.next, n2.next = k2);
                        l2.pending = k2;
                      }
                    }
                    f2.lanes |= c;
                    k2 = f2.alternate;
                    null !== k2 && (k2.lanes |= c);
                    rg(f2.return, c, b);
                    h.lanes |= c;
                    break;
                  }
                  k2 = k2.next;
                }
              } else if (10 === f2.tag)
                g = f2.type === b.type ? null : f2.child;
              else if (18 === f2.tag) {
                g = f2.return;
                if (null === g)
                  throw Error(p(341));
                g.lanes |= c;
                h = g.alternate;
                null !== h && (h.lanes |= c);
                rg(g, c, b);
                g = f2.sibling;
              } else
                g = f2.child;
              if (null !== g)
                g.return = f2;
              else
                for (g = f2; null !== g; ) {
                  if (g === b) {
                    g = null;
                    break;
                  }
                  f2 = g.sibling;
                  if (null !== f2) {
                    f2.return = g.return;
                    g = f2;
                    break;
                  }
                  g = g.return;
                }
              f2 = g;
            }
        ej(a, b, e.children, c);
        b = b.child;
      }
      return b;
    case 9:
      return e = b.type, d = b.pendingProps.children, sg(b, c), e = ug(e), d = d(e), b.flags |= 1, ej(a, b, d, c), b.child;
    case 14:
      return d = b.type, e = kg(d, b.pendingProps), e = kg(d.type, e), hj(a, b, d, e, c);
    case 15:
      return jj(a, b, b.type, b.pendingProps, c);
    case 17:
      return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : kg(d, e), null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2), b.tag = 1, Yf(d) ? (a = true, bg(b)) : a = false, sg(b, c), Og(b, d, e), Qg(b, d, e, c), pj(null, b, d, true, a, c);
    case 19:
      return Ej(a, b, c);
    case 22:
      return lj(a, b, c);
  }
  throw Error(p(
    156,
    b.tag
  ));
};
function Ek(a, b) {
  return $b(a, b);
}
function Zk(a, b, c, d) {
  this.tag = a;
  this.key = c;
  this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
  this.index = 0;
  this.ref = null;
  this.pendingProps = b;
  this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
  this.mode = d;
  this.subtreeFlags = this.flags = 0;
  this.deletions = null;
  this.childLanes = this.lanes = 0;
  this.alternate = null;
}
function hh(a, b, c, d) {
  return new Zk(a, b, c, d);
}
function ij(a) {
  a = a.prototype;
  return !(!a || !a.isReactComponent);
}
function Yk(a) {
  if ("function" === typeof a)
    return ij(a) ? 1 : 0;
  if (void 0 !== a && null !== a) {
    a = a.$$typeof;
    if (a === Ca)
      return 11;
    if (a === Fa)
      return 14;
  }
  return 2;
}
function th(a, b) {
  var c = a.alternate;
  null === c ? (c = hh(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.subtreeFlags = 0, c.deletions = null);
  c.flags = a.flags & 14680064;
  c.childLanes = a.childLanes;
  c.lanes = a.lanes;
  c.child = a.child;
  c.memoizedProps = a.memoizedProps;
  c.memoizedState = a.memoizedState;
  c.updateQueue = a.updateQueue;
  b = a.dependencies;
  c.dependencies = null === b ? null : { lanes: b.lanes, firstContext: b.firstContext };
  c.sibling = a.sibling;
  c.index = a.index;
  c.ref = a.ref;
  return c;
}
function vh(a, b, c, d, e, f2) {
  var g = 2;
  d = a;
  if ("function" === typeof a)
    ij(a) && (g = 1);
  else if ("string" === typeof a)
    g = 5;
  else
    a:
      switch (a) {
        case wa:
          return xh(c.children, e, f2, b);
        case xa:
          g = 8;
          e |= 8;
          break;
        case za:
          return a = hh(12, c, b, e | 2), a.elementType = za, a.lanes = f2, a;
        case Da:
          return a = hh(13, c, b, e), a.elementType = Da, a.lanes = f2, a;
        case Ea:
          return a = hh(19, c, b, e), a.elementType = Ea, a.lanes = f2, a;
        case Ha:
          return wj(c, e, f2, b);
        default:
          if ("object" === typeof a && null !== a)
            switch (a.$$typeof) {
              case Aa:
                g = 10;
                break a;
              case Ba:
                g = 9;
                break a;
              case Ca:
                g = 11;
                break a;
              case Fa:
                g = 14;
                break a;
              case Ga:
                g = 16;
                d = null;
                break a;
            }
          throw Error(p(130, null == a ? a : typeof a, ""));
      }
  b = hh(g, c, b, e);
  b.elementType = a;
  b.type = d;
  b.lanes = f2;
  return b;
}
function xh(a, b, c, d) {
  a = hh(7, a, d, b);
  a.lanes = c;
  return a;
}
function wj(a, b, c, d) {
  a = hh(22, a, d, b);
  a.elementType = Ha;
  a.lanes = c;
  a.stateNode = {};
  return a;
}
function uh(a, b, c) {
  a = hh(6, a, null, b);
  a.lanes = c;
  return a;
}
function wh(a, b, c) {
  b = hh(4, null !== a.children ? a.children : [], a.key, b);
  b.lanes = c;
  b.stateNode = { containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation };
  return b;
}
function $k(a, b, c, d, e) {
  this.tag = b;
  this.containerInfo = a;
  this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
  this.timeoutHandle = -1;
  this.callbackNode = this.pendingContext = this.context = null;
  this.callbackPriority = 0;
  this.eventTimes = yc(0);
  this.expirationTimes = yc(-1);
  this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
  this.entanglements = yc(0);
  this.identifierPrefix = d;
  this.onRecoverableError = e;
  this.mutableSourceEagerHydrationData = null;
}
function al(a, b, c, d, e, f2, g, h, k2) {
  a = new $k(a, b, c, h, k2);
  1 === b ? (b = 1, true === f2 && (b |= 8)) : b = 0;
  f2 = hh(3, null, null, b);
  a.current = f2;
  f2.stateNode = a;
  f2.memoizedState = { element: d, isDehydrated: c, cache: null, transitions: null, pendingSuspenseBoundaries: null };
  xg(f2);
  return a;
}
function bl(a, b, c) {
  var d = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
  return { $$typeof: va, key: null == d ? null : "" + d, children: a, containerInfo: b, implementation: c };
}
function cl(a) {
  if (!a)
    return Uf;
  a = a._reactInternals;
  a: {
    if (Ub(a) !== a || 1 !== a.tag)
      throw Error(p(170));
    var b = a;
    do {
      switch (b.tag) {
        case 3:
          b = b.stateNode.context;
          break a;
        case 1:
          if (Yf(b.type)) {
            b = b.stateNode.__reactInternalMemoizedMergedChildContext;
            break a;
          }
      }
      b = b.return;
    } while (null !== b);
    throw Error(p(171));
  }
  if (1 === a.tag) {
    var c = a.type;
    if (Yf(c))
      return ag(a, c, b);
  }
  return b;
}
function dl(a, b, c, d, e, f2, g, h, k2) {
  a = al(c, d, true, a, e, f2, g, h, k2);
  a.context = cl(null);
  c = a.current;
  d = Jg();
  e = Kg(c);
  f2 = zg(d, e);
  f2.callback = void 0 !== b && null !== b ? b : null;
  Ag(c, f2);
  a.current.lanes = e;
  zc(a, e, d);
  Ck(a, d);
  return a;
}
function el$1(a, b, c, d) {
  var e = b.current, f2 = Jg(), g = Kg(e);
  c = cl(c);
  null === b.context ? b.context = c : b.pendingContext = c;
  b = zg(f2, g);
  b.payload = { element: a };
  d = void 0 === d ? null : d;
  null !== d && (b.callback = d);
  Ag(e, b);
  a = Lg(e, g, f2);
  null !== a && Cg(a, e, g);
  return g;
}
function fl(a) {
  a = a.current;
  if (!a.child)
    return null;
  switch (a.child.tag) {
    case 5:
      return a.child.stateNode;
    default:
      return a.child.stateNode;
  }
}
function gl$1(a, b) {
  a = a.memoizedState;
  if (null !== a && null !== a.dehydrated) {
    var c = a.retryLane;
    a.retryLane = 0 !== c && c < b ? c : b;
  }
}
function hl(a, b) {
  gl$1(a, b);
  (a = a.alternate) && gl$1(a, b);
}
function il() {
  return null;
}
var jl = "function" === typeof reportError ? reportError : function(a) {
  console.error(a);
};
function kl(a) {
  this._internalRoot = a;
}
ll$1.prototype.render = kl.prototype.render = function(a) {
  var b = this._internalRoot;
  if (null === b)
    throw Error(p(409));
  el$1(a, b, null, null);
};
ll$1.prototype.unmount = kl.prototype.unmount = function() {
  var a = this._internalRoot;
  if (null !== a) {
    this._internalRoot = null;
    var b = a.containerInfo;
    Qk(function() {
      el$1(null, a, null, null);
    });
    b[tf] = null;
  }
};
function ll$1(a) {
  this._internalRoot = a;
}
ll$1.prototype.unstable_scheduleHydration = function(a) {
  if (a) {
    var b = Gc();
    a = { blockedOn: null, target: a, priority: b };
    for (var c = 0; c < Pc.length && 0 !== b && b < Pc[c].priority; c++)
      ;
    Pc.splice(c, 0, a);
    0 === c && Uc(a);
  }
};
function ml(a) {
  return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType);
}
function nl(a) {
  return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType && (8 !== a.nodeType || " react-mount-point-unstable " !== a.nodeValue));
}
function ol() {
}
function pl(a, b, c, d, e) {
  if (e) {
    if ("function" === typeof d) {
      var f2 = d;
      d = function() {
        var a2 = fl(g);
        f2.call(a2);
      };
    }
    var g = dl(b, d, a, 0, null, false, false, "", ol);
    a._reactRootContainer = g;
    a[tf] = g.current;
    rf(8 === a.nodeType ? a.parentNode : a);
    Qk();
    return g;
  }
  for (; e = a.lastChild; )
    a.removeChild(e);
  if ("function" === typeof d) {
    var h = d;
    d = function() {
      var a2 = fl(k2);
      h.call(a2);
    };
  }
  var k2 = al(a, 0, false, null, null, false, false, "", ol);
  a._reactRootContainer = k2;
  a[tf] = k2.current;
  rf(8 === a.nodeType ? a.parentNode : a);
  Qk(function() {
    el$1(b, k2, c, d);
  });
  return k2;
}
function ql(a, b, c, d, e) {
  var f2 = c._reactRootContainer;
  if (f2) {
    var g = f2;
    if ("function" === typeof e) {
      var h = e;
      e = function() {
        var a2 = fl(g);
        h.call(a2);
      };
    }
    el$1(b, g, a, e);
  } else
    g = pl(c, b, a, e, d);
  return fl(g);
}
Dc = function(a) {
  switch (a.tag) {
    case 3:
      var b = a.stateNode;
      if (b.current.memoizedState.isDehydrated) {
        var c = sc$1(b.pendingLanes);
        0 !== c && (Bc(b, c | 1), Ck(b, B()), 0 === (W & 6) && (aj = B() + 500, ig()));
      }
      break;
    case 13:
      var d = Jg();
      Qk(function() {
        return Lg(a, 1, d);
      });
      hl(a, 1);
  }
};
Ec = function(a) {
  if (13 === a.tag) {
    var b = Jg();
    Lg(a, 134217728, b);
    hl(a, 134217728);
  }
};
Fc = function(a) {
  if (13 === a.tag) {
    var b = Jg(), c = Kg(a);
    Lg(a, c, b);
    hl(a, c);
  }
};
Gc = function() {
  return C;
};
Hc = function(a, b) {
  var c = C;
  try {
    return C = a, b();
  } finally {
    C = c;
  }
};
xb = function(a, b, c) {
  switch (b) {
    case "input":
      $a(a, c);
      b = c.name;
      if ("radio" === c.type && null != b) {
        for (c = a; c.parentNode; )
          c = c.parentNode;
        c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + '][type="radio"]');
        for (b = 0; b < c.length; b++) {
          var d = c[b];
          if (d !== a && d.form === a.form) {
            var e = Cb(d);
            if (!e)
              throw Error(p(90));
            Va(d);
            $a(d, e);
          }
        }
      }
      break;
    case "textarea":
      hb(a, c);
      break;
    case "select":
      b = c.value, null != b && eb(a, !!c.multiple, b, false);
  }
};
Fb = Pk;
Gb = Qk;
var rl = { usingClientEntryPoint: false, Events: [Bb, te, Cb, Db, Eb, Pk] }, sl = { findFiberByHostInstance: Vc, bundleType: 0, version: "18.1.0", rendererPackageName: "react-dom" };
var tl = { bundleType: sl.bundleType, version: sl.version, rendererPackageName: sl.rendererPackageName, rendererConfig: sl.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ta.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
  a = Yb(a);
  return null === a ? null : a.stateNode;
}, findFiberByHostInstance: sl.findFiberByHostInstance || il, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.1.0-next-22edb9f77-20220426" };
if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
  var ul = __REACT_DEVTOOLS_GLOBAL_HOOK__;
  if (!ul.isDisabled && ul.supportsFiber)
    try {
      jc = ul.inject(tl), kc = ul;
    } catch (a) {
    }
}
reactDom_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = rl;
reactDom_production_min.createPortal = function(a, b) {
  var c = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
  if (!ml(b))
    throw Error(p(200));
  return bl(a, b, null, c);
};
reactDom_production_min.createRoot = function(a, b) {
  if (!ml(a))
    throw Error(p(299));
  var c = false, d = "", e = jl;
  null !== b && void 0 !== b && (true === b.unstable_strictMode && (c = true), void 0 !== b.identifierPrefix && (d = b.identifierPrefix), void 0 !== b.onRecoverableError && (e = b.onRecoverableError));
  b = al(a, 1, false, null, null, c, false, d, e);
  a[tf] = b.current;
  rf(8 === a.nodeType ? a.parentNode : a);
  return new kl(b);
};
reactDom_production_min.findDOMNode = function(a) {
  if (null == a)
    return null;
  if (1 === a.nodeType)
    return a;
  var b = a._reactInternals;
  if (void 0 === b) {
    if ("function" === typeof a.render)
      throw Error(p(188));
    a = Object.keys(a).join(",");
    throw Error(p(268, a));
  }
  a = Yb(b);
  a = null === a ? null : a.stateNode;
  return a;
};
reactDom_production_min.flushSync = function(a) {
  return Qk(a);
};
reactDom_production_min.hydrate = function(a, b, c) {
  if (!nl(b))
    throw Error(p(200));
  return ql(null, a, b, true, c);
};
reactDom_production_min.hydrateRoot = function(a, b, c) {
  if (!ml(a))
    throw Error(p(405));
  var d = null != c && c.hydratedSources || null, e = false, f2 = "", g = jl;
  null !== c && void 0 !== c && (true === c.unstable_strictMode && (e = true), void 0 !== c.identifierPrefix && (f2 = c.identifierPrefix), void 0 !== c.onRecoverableError && (g = c.onRecoverableError));
  b = dl(b, null, a, 1, null != c ? c : null, e, false, f2, g);
  a[tf] = b.current;
  rf(a);
  if (d)
    for (a = 0; a < d.length; a++)
      c = d[a], e = c._getVersion, e = e(c._source), null == b.mutableSourceEagerHydrationData ? b.mutableSourceEagerHydrationData = [c, e] : b.mutableSourceEagerHydrationData.push(
        c,
        e
      );
  return new ll$1(b);
};
reactDom_production_min.render = function(a, b, c) {
  if (!nl(b))
    throw Error(p(200));
  return ql(null, a, b, false, c);
};
reactDom_production_min.unmountComponentAtNode = function(a) {
  if (!nl(a))
    throw Error(p(40));
  return a._reactRootContainer ? (Qk(function() {
    ql(null, null, a, false, function() {
      a._reactRootContainer = null;
      a[tf] = null;
    });
  }), true) : false;
};
reactDom_production_min.unstable_batchedUpdates = Pk;
reactDom_production_min.unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
  if (!nl(c))
    throw Error(p(200));
  if (null == a || void 0 === a._reactInternals)
    throw Error(p(38));
  return ql(a, b, c, false, d);
};
reactDom_production_min.version = "18.1.0-next-22edb9f77-20220426";
function checkDCE() {
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
    return;
  }
  try {
    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
  } catch (err) {
    console.error(err);
  }
}
{
  checkDCE();
  reactDom.exports = reactDom_production_min;
}
var reactDomExports = reactDom.exports;
const toolbarButton = "";
const ToolbarButton = ({
  children,
  title = "",
  icon,
  disabled = false,
  toggled = false,
  onClick = () => {
  },
  style
}) => {
  let className = `toolbar-button ${icon}`;
  if (toggled)
    className += " toggled";
  return /* @__PURE__ */ jsxs(
    "button",
    {
      className,
      onMouseDown: preventDefault,
      onClick,
      onDoubleClick: preventDefault,
      title,
      disabled: !!disabled,
      style,
      children: [
        icon && /* @__PURE__ */ jsx("span", { className: `codicon codicon-${icon}`, style: children ? { marginRight: 5 } : {} }),
        children
      ]
    }
  );
};
const preventDefault = (e) => {
  e.stopPropagation();
  e.preventDefault();
};
const contextSymbol = Symbol("context");
const nextInContextSymbol = Symbol("next");
const prevInListSymbol = Symbol("prev");
const eventsSymbol = Symbol("events");
const resourcesSymbol = Symbol("resources");
class MultiTraceModel {
  constructor(contexts) {
    __publicField(this, "startTime");
    __publicField(this, "endTime");
    __publicField(this, "browserName");
    __publicField(this, "platform");
    __publicField(this, "wallTime");
    __publicField(this, "title");
    __publicField(this, "options");
    __publicField(this, "pages");
    __publicField(this, "actions");
    __publicField(this, "events");
    __publicField(this, "hasSource");
    __publicField(this, "sdkLanguage");
    __publicField(this, "testIdAttributeName");
    __publicField(this, "sources");
    var _a, _b, _c, _d, _e, _f;
    contexts.forEach((contextEntry) => indexModel(contextEntry));
    this.browserName = ((_a = contexts[0]) == null ? void 0 : _a.browserName) || "";
    this.sdkLanguage = (_b = contexts[0]) == null ? void 0 : _b.sdkLanguage;
    this.testIdAttributeName = (_c = contexts[0]) == null ? void 0 : _c.testIdAttributeName;
    this.platform = ((_d = contexts[0]) == null ? void 0 : _d.platform) || "";
    this.title = ((_e = contexts[0]) == null ? void 0 : _e.title) || "";
    this.options = ((_f = contexts[0]) == null ? void 0 : _f.options) || {};
    this.wallTime = contexts.map((c) => c.wallTime).reduce((prev, cur) => Math.min(prev || Number.MAX_VALUE, cur), Number.MAX_VALUE);
    this.startTime = contexts.map((c) => c.startTime).reduce((prev, cur) => Math.min(prev, cur), Number.MAX_VALUE);
    this.endTime = contexts.map((c) => c.endTime).reduce((prev, cur) => Math.max(prev, cur), Number.MIN_VALUE);
    this.pages = [].concat(...contexts.map((c) => c.pages));
    this.actions = mergeActions(contexts);
    this.events = [].concat(...contexts.map((c) => c.events));
    this.hasSource = contexts.some((c) => c.hasSource);
    this.events.sort((a1, a2) => a1.time - a2.time);
    this.sources = collectSources(this.actions);
  }
}
function indexModel(context2) {
  for (const page of context2.pages)
    page[contextSymbol] = context2;
  for (let i = 0; i < context2.actions.length; ++i) {
    const action = context2.actions[i];
    action[contextSymbol] = context2;
  }
  let lastNonRouteAction = void 0;
  for (let i = context2.actions.length - 1; i >= 0; i--) {
    const action = context2.actions[i];
    action[nextInContextSymbol] = lastNonRouteAction;
    if (!action.apiName.includes("route."))
      lastNonRouteAction = action;
  }
  for (const event of context2.events)
    event[contextSymbol] = context2;
}
function mergeActions(contexts) {
  const map2 = /* @__PURE__ */ new Map();
  let offset = 0;
  const primaryContexts = contexts.filter((context2) => context2.isPrimary);
  const nonPrimaryContexts = contexts.filter((context2) => !context2.isPrimary);
  for (const context2 of primaryContexts) {
    for (const action of context2.actions)
      map2.set(`${action.apiName}@${action.wallTime}`, { ...action, context: context2 });
    if (!offset && context2.actions.length)
      offset = context2.actions[0].startTime - context2.actions[0].wallTime;
  }
  const nonPrimaryIdToPrimaryId = /* @__PURE__ */ new Map();
  for (const context2 of nonPrimaryContexts) {
    for (const action of context2.actions) {
      if (offset) {
        const duration = action.endTime - action.startTime;
        if (action.startTime)
          action.startTime = action.wallTime + offset;
        if (action.endTime)
          action.endTime = action.startTime + duration;
      }
      const key = `${action.apiName}@${action.wallTime}`;
      const existing = map2.get(key);
      if (existing && existing.apiName === action.apiName) {
        nonPrimaryIdToPrimaryId.set(action.callId, existing.callId);
        if (action.error)
          existing.error = action.error;
        if (action.attachments)
          existing.attachments = action.attachments;
        if (action.parentId)
          existing.parentId = nonPrimaryIdToPrimaryId.get(action.parentId) ?? action.parentId;
        continue;
      }
      if (action.parentId)
        action.parentId = nonPrimaryIdToPrimaryId.get(action.parentId) ?? action.parentId;
      map2.set(key, { ...action, context: context2 });
    }
  }
  const result = [...map2.values()];
  result.sort((a1, a2) => {
    if (a2.parentId === a1.callId)
      return -1;
    if (a1.parentId === a2.callId)
      return 1;
    return a1.wallTime - a2.wallTime || a1.startTime - a2.startTime;
  });
  for (let i = 1; i < result.length; ++i)
    result[i][prevInListSymbol] = result[i - 1];
  return result;
}
function buildActionTree(actions) {
  const itemMap = /* @__PURE__ */ new Map();
  for (const action of actions) {
    itemMap.set(action.callId, {
      id: action.callId,
      parent: void 0,
      children: [],
      action
    });
  }
  const rootItem = { id: "", parent: void 0, children: [] };
  for (const item of itemMap.values()) {
    const parent = item.action.parentId ? itemMap.get(item.action.parentId) || rootItem : rootItem;
    parent.children.push(item);
    item.parent = parent;
  }
  return { rootItem, itemMap };
}
function idForAction(action) {
  return `${action.pageId || "none"}:${action.callId}`;
}
function context(action) {
  return action[contextSymbol];
}
function nextInContext(action) {
  return action[nextInContextSymbol];
}
function prevInList(action) {
  return action[prevInListSymbol];
}
function stats(action) {
  var _a;
  let errors = 0;
  let warnings = 0;
  const c = context(action);
  for (const event of eventsForAction(action)) {
    if (event.method === "console") {
      const { guid } = event.params.message;
      const type = (_a = c.initializers[guid]) == null ? void 0 : _a.type;
      if (type === "warning")
        ++warnings;
      else if (type === "error")
        ++errors;
    }
    if (event.method === "pageError")
      ++errors;
  }
  return { errors, warnings };
}
function eventsForAction(action) {
  let result = action[eventsSymbol];
  if (result)
    return result;
  const nextAction = nextInContext(action);
  result = context(action).events.filter((event) => {
    return event.time >= action.startTime && (!nextAction || event.time < nextAction.startTime);
  });
  action[eventsSymbol] = result;
  return result;
}
function resourcesForAction(action) {
  let result = action[resourcesSymbol];
  if (result)
    return result;
  const nextAction = nextInContext(action);
  result = context(action).resources.filter((resource) => {
    return typeof resource._monotonicTime === "number" && resource._monotonicTime > action.startTime && (!nextAction || resource._monotonicTime < nextAction.startTime);
  });
  action[resourcesSymbol] = result;
  return result;
}
function collectSources(actions) {
  var _a, _b;
  const result = /* @__PURE__ */ new Map();
  for (const action of actions) {
    for (const frame of action.stack || []) {
      let source = result.get(frame.file);
      if (!source) {
        source = { errors: [], content: void 0 };
        result.set(frame.file, source);
      }
    }
    if (action.error && ((_a = action.stack) == null ? void 0 : _a[0]))
      result.get(action.stack[0].file).errors.push({ line: ((_b = action.stack) == null ? void 0 : _b[0].line) || 0, message: action.error.message });
  }
  return result;
}
const workbench = "";
const splitView = "";
const kMinSize = 50;
const SplitView = ({
  sidebarSize,
  sidebarHidden = false,
  sidebarIsFirst = false,
  orientation = "vertical",
  children
}) => {
  const [size, setSize] = reactExports.useState(Math.max(kMinSize, sidebarSize));
  const [resizing, setResizing] = reactExports.useState(null);
  const childrenArray = reactExports.Children.toArray(children);
  document.body.style.userSelect = resizing ? "none" : "inherit";
  let resizerStyle = {};
  if (orientation === "vertical") {
    if (sidebarIsFirst)
      resizerStyle = { top: resizing ? 0 : size - 4, bottom: resizing ? 0 : void 0, height: resizing ? "initial" : 8 };
    else
      resizerStyle = { bottom: resizing ? 0 : size - 4, top: resizing ? 0 : void 0, height: resizing ? "initial" : 8 };
  } else {
    if (sidebarIsFirst)
      resizerStyle = { left: resizing ? 0 : size - 4, right: resizing ? 0 : void 0, width: resizing ? "initial" : 8 };
    else
      resizerStyle = { right: resizing ? 0 : size - 4, left: resizing ? 0 : void 0, width: resizing ? "initial" : 8 };
  }
  return /* @__PURE__ */ jsxs("div", { className: "split-view " + orientation + (sidebarIsFirst ? " sidebar-first" : ""), children: [
    /* @__PURE__ */ jsx("div", { className: "split-view-main", children: childrenArray[0] }),
    !sidebarHidden && /* @__PURE__ */ jsx("div", { style: { flexBasis: size }, className: "split-view-sidebar", children: childrenArray[1] }),
    !sidebarHidden && /* @__PURE__ */ jsx(
      "div",
      {
        style: resizerStyle,
        className: "split-view-resizer",
        onMouseDown: (event) => setResizing({ offset: orientation === "vertical" ? event.clientY : event.clientX, size }),
        onMouseUp: () => setResizing(null),
        onMouseMove: (event) => {
          if (!event.buttons) {
            setResizing(null);
          } else if (resizing) {
            const offset = orientation === "vertical" ? event.clientY : event.clientX;
            const delta2 = offset - resizing.offset;
            const newSize = sidebarIsFirst ? resizing.size + delta2 : resizing.size - delta2;
            const splitView2 = event.target.parentElement;
            const rect2 = splitView2.getBoundingClientRect();
            const size2 = Math.min(Math.max(kMinSize, newSize), (orientation === "vertical" ? rect2.height : rect2.width) - kMinSize);
            setSize(size2);
          }
        }
      }
    )
  ] });
};
const actionList = "";
function escapeWithQuotes(text, char = "'") {
  const stringified = JSON.stringify(text);
  const escapedText = stringified.substring(1, stringified.length - 1).replace(/\\"/g, '"');
  if (char === "'")
    return char + escapedText.replace(/[']/g, "\\'") + char;
  if (char === '"')
    return char + escapedText.replace(/["]/g, '\\"') + char;
  if (char === "`")
    return char + escapedText.replace(/[`]/g, "`") + char;
  throw new Error("Invalid escape char");
}
function isString(obj) {
  return typeof obj === "string" || obj instanceof String;
}
function toTitleCase(name) {
  return name.charAt(0).toUpperCase() + name.substring(1);
}
function toSnakeCase(name) {
  return name.replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/([A-Z])([A-Z][a-z])/g, "$1_$2").toLowerCase();
}
function cssEscape(s) {
  let result = "";
  for (let i = 0; i < s.length; i++)
    result += cssEscapeOne(s, i);
  return result;
}
function cssEscapeOne(s, i) {
  const c = s.charCodeAt(i);
  if (c === 0)
    return "�";
  if (c >= 1 && c <= 31 || c >= 48 && c <= 57 && (i === 0 || i === 1 && s.charCodeAt(0) === 45))
    return "\\" + c.toString(16) + " ";
  if (i === 0 && c === 45 && s.length === 1)
    return "\\" + s.charAt(i);
  if (c >= 128 || c === 45 || c === 95 || c >= 48 && c <= 57 || c >= 65 && c <= 90 || c >= 97 && c <= 122)
    return s.charAt(i);
  return "\\" + s.charAt(i);
}
function normalizeWhiteSpace(text) {
  return text.replace(/\u200b/g, "").trim().replace(/\s+/g, " ");
}
function escapeForTextSelector(text, exact) {
  if (typeof text !== "string")
    return String(text).replace(/>>/g, "\\>\\>");
  return `${JSON.stringify(text)}${exact ? "s" : "i"}`;
}
function escapeForAttributeSelector(value, exact) {
  if (typeof value !== "string")
    return String(value).replace(/>>/g, "\\>\\>");
  return `"${value.replace(/\\/g, "\\\\").replace(/["]/g, '\\"')}"${exact ? "s" : "i"}`;
}
const between$1 = function(num2, first, last) {
  return num2 >= first && num2 <= last;
};
function digit(code) {
  return between$1(code, 48, 57);
}
function hexdigit(code) {
  return digit(code) || between$1(code, 65, 70) || between$1(code, 97, 102);
}
function uppercaseletter(code) {
  return between$1(code, 65, 90);
}
function lowercaseletter(code) {
  return between$1(code, 97, 122);
}
function letter(code) {
  return uppercaseletter(code) || lowercaseletter(code);
}
function nonascii(code) {
  return code >= 128;
}
function namestartchar(code) {
  return letter(code) || nonascii(code) || code === 95;
}
function namechar(code) {
  return namestartchar(code) || digit(code) || code === 45;
}
function nonprintable(code) {
  return between$1(code, 0, 8) || code === 11 || between$1(code, 14, 31) || code === 127;
}
function newline(code) {
  return code === 10;
}
function whitespace(code) {
  return newline(code) || code === 9 || code === 32;
}
const maximumallowedcodepoint = 1114111;
class InvalidCharacterError extends Error {
  constructor(message) {
    super(message);
    this.name = "InvalidCharacterError";
  }
}
function preprocess(str) {
  const codepoints = [];
  for (let i = 0; i < str.length; i++) {
    let code = str.charCodeAt(i);
    if (code === 13 && str.charCodeAt(i + 1) === 10) {
      code = 10;
      i++;
    }
    if (code === 13 || code === 12)
      code = 10;
    if (code === 0)
      code = 65533;
    if (between$1(code, 55296, 56319) && between$1(str.charCodeAt(i + 1), 56320, 57343)) {
      const lead = code - 55296;
      const trail = str.charCodeAt(i + 1) - 56320;
      code = Math.pow(2, 16) + lead * Math.pow(2, 10) + trail;
      i++;
    }
    codepoints.push(code);
  }
  return codepoints;
}
function stringFromCode(code) {
  if (code <= 65535)
    return String.fromCharCode(code);
  code -= Math.pow(2, 16);
  const lead = Math.floor(code / Math.pow(2, 10)) + 55296;
  const trail = code % Math.pow(2, 10) + 56320;
  return String.fromCharCode(lead) + String.fromCharCode(trail);
}
function tokenize$1(str1) {
  const str = preprocess(str1);
  let i = -1;
  const tokens = [];
  let code;
  const codepoint = function(i2) {
    if (i2 >= str.length)
      return -1;
    return str[i2];
  };
  const next = function(num2) {
    if (num2 === void 0)
      num2 = 1;
    if (num2 > 3)
      throw "Spec Error: no more than three codepoints of lookahead.";
    return codepoint(i + num2);
  };
  const consume = function(num2) {
    if (num2 === void 0)
      num2 = 1;
    i += num2;
    code = codepoint(i);
    return true;
  };
  const reconsume = function() {
    i -= 1;
    return true;
  };
  const eof = function(codepoint2) {
    if (codepoint2 === void 0)
      codepoint2 = code;
    return codepoint2 === -1;
  };
  const consumeAToken = function() {
    consumeComments();
    consume();
    if (whitespace(code)) {
      while (whitespace(next()))
        consume();
      return new WhitespaceToken();
    } else if (code === 34) {
      return consumeAStringToken();
    } else if (code === 35) {
      if (namechar(next()) || areAValidEscape(next(1), next(2))) {
        const token = new HashToken("");
        if (wouldStartAnIdentifier(next(1), next(2), next(3)))
          token.type = "id";
        token.value = consumeAName();
        return token;
      } else {
        return new DelimToken(code);
      }
    } else if (code === 36) {
      if (next() === 61) {
        consume();
        return new SuffixMatchToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 39) {
      return consumeAStringToken();
    } else if (code === 40) {
      return new OpenParenToken();
    } else if (code === 41) {
      return new CloseParenToken();
    } else if (code === 42) {
      if (next() === 61) {
        consume();
        return new SubstringMatchToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 43) {
      if (startsWithANumber()) {
        reconsume();
        return consumeANumericToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 44) {
      return new CommaToken();
    } else if (code === 45) {
      if (startsWithANumber()) {
        reconsume();
        return consumeANumericToken();
      } else if (next(1) === 45 && next(2) === 62) {
        consume(2);
        return new CDCToken();
      } else if (startsWithAnIdentifier()) {
        reconsume();
        return consumeAnIdentlikeToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 46) {
      if (startsWithANumber()) {
        reconsume();
        return consumeANumericToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 58) {
      return new ColonToken();
    } else if (code === 59) {
      return new SemicolonToken();
    } else if (code === 60) {
      if (next(1) === 33 && next(2) === 45 && next(3) === 45) {
        consume(3);
        return new CDOToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 64) {
      if (wouldStartAnIdentifier(next(1), next(2), next(3)))
        return new AtKeywordToken(consumeAName());
      else
        return new DelimToken(code);
    } else if (code === 91) {
      return new OpenSquareToken();
    } else if (code === 92) {
      if (startsWithAValidEscape()) {
        reconsume();
        return consumeAnIdentlikeToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 93) {
      return new CloseSquareToken();
    } else if (code === 94) {
      if (next() === 61) {
        consume();
        return new PrefixMatchToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 123) {
      return new OpenCurlyToken();
    } else if (code === 124) {
      if (next() === 61) {
        consume();
        return new DashMatchToken();
      } else if (next() === 124) {
        consume();
        return new ColumnToken();
      } else {
        return new DelimToken(code);
      }
    } else if (code === 125) {
      return new CloseCurlyToken();
    } else if (code === 126) {
      if (next() === 61) {
        consume();
        return new IncludeMatchToken();
      } else {
        return new DelimToken(code);
      }
    } else if (digit(code)) {
      reconsume();
      return consumeANumericToken();
    } else if (namestartchar(code)) {
      reconsume();
      return consumeAnIdentlikeToken();
    } else if (eof()) {
      return new EOFToken();
    } else {
      return new DelimToken(code);
    }
  };
  const consumeComments = function() {
    while (next(1) === 47 && next(2) === 42) {
      consume(2);
      while (true) {
        consume();
        if (code === 42 && next() === 47) {
          consume();
          break;
        } else if (eof()) {
          return;
        }
      }
    }
  };
  const consumeANumericToken = function() {
    const num2 = consumeANumber();
    if (wouldStartAnIdentifier(next(1), next(2), next(3))) {
      const token = new DimensionToken();
      token.value = num2.value;
      token.repr = num2.repr;
      token.type = num2.type;
      token.unit = consumeAName();
      return token;
    } else if (next() === 37) {
      consume();
      const token = new PercentageToken();
      token.value = num2.value;
      token.repr = num2.repr;
      return token;
    } else {
      const token = new NumberToken();
      token.value = num2.value;
      token.repr = num2.repr;
      token.type = num2.type;
      return token;
    }
  };
  const consumeAnIdentlikeToken = function() {
    const str2 = consumeAName();
    if (str2.toLowerCase() === "url" && next() === 40) {
      consume();
      while (whitespace(next(1)) && whitespace(next(2)))
        consume();
      if (next() === 34 || next() === 39)
        return new FunctionToken(str2);
      else if (whitespace(next()) && (next(2) === 34 || next(2) === 39))
        return new FunctionToken(str2);
      else
        return consumeAURLToken();
    } else if (next() === 40) {
      consume();
      return new FunctionToken(str2);
    } else {
      return new IdentToken(str2);
    }
  };
  const consumeAStringToken = function(endingCodePoint) {
    if (endingCodePoint === void 0)
      endingCodePoint = code;
    let string = "";
    while (consume()) {
      if (code === endingCodePoint || eof()) {
        return new StringToken(string);
      } else if (newline(code)) {
        reconsume();
        return new BadStringToken();
      } else if (code === 92) {
        if (eof(next()))
          ;
        else if (newline(next()))
          consume();
        else
          string += stringFromCode(consumeEscape());
      } else {
        string += stringFromCode(code);
      }
    }
    throw new Error("Internal error");
  };
  const consumeAURLToken = function() {
    const token = new URLToken("");
    while (whitespace(next()))
      consume();
    if (eof(next()))
      return token;
    while (consume()) {
      if (code === 41 || eof()) {
        return token;
      } else if (whitespace(code)) {
        while (whitespace(next()))
          consume();
        if (next() === 41 || eof(next())) {
          consume();
          return token;
        } else {
          consumeTheRemnantsOfABadURL();
          return new BadURLToken();
        }
      } else if (code === 34 || code === 39 || code === 40 || nonprintable(code)) {
        consumeTheRemnantsOfABadURL();
        return new BadURLToken();
      } else if (code === 92) {
        if (startsWithAValidEscape()) {
          token.value += stringFromCode(consumeEscape());
        } else {
          consumeTheRemnantsOfABadURL();
          return new BadURLToken();
        }
      } else {
        token.value += stringFromCode(code);
      }
    }
    throw new Error("Internal error");
  };
  const consumeEscape = function() {
    consume();
    if (hexdigit(code)) {
      const digits = [code];
      for (let total = 0; total < 5; total++) {
        if (hexdigit(next())) {
          consume();
          digits.push(code);
        } else {
          break;
        }
      }
      if (whitespace(next()))
        consume();
      let value = parseInt(digits.map(function(x2) {
        return String.fromCharCode(x2);
      }).join(""), 16);
      if (value > maximumallowedcodepoint)
        value = 65533;
      return value;
    } else if (eof()) {
      return 65533;
    } else {
      return code;
    }
  };
  const areAValidEscape = function(c1, c2) {
    if (c1 !== 92)
      return false;
    if (newline(c2))
      return false;
    return true;
  };
  const startsWithAValidEscape = function() {
    return areAValidEscape(code, next());
  };
  const wouldStartAnIdentifier = function(c1, c2, c3) {
    if (c1 === 45)
      return namestartchar(c2) || c2 === 45 || areAValidEscape(c2, c3);
    else if (namestartchar(c1))
      return true;
    else if (c1 === 92)
      return areAValidEscape(c1, c2);
    else
      return false;
  };
  const startsWithAnIdentifier = function() {
    return wouldStartAnIdentifier(code, next(1), next(2));
  };
  const wouldStartANumber = function(c1, c2, c3) {
    if (c1 === 43 || c1 === 45) {
      if (digit(c2))
        return true;
      if (c2 === 46 && digit(c3))
        return true;
      return false;
    } else if (c1 === 46) {
      if (digit(c2))
        return true;
      return false;
    } else if (digit(c1)) {
      return true;
    } else {
      return false;
    }
  };
  const startsWithANumber = function() {
    return wouldStartANumber(code, next(1), next(2));
  };
  const consumeAName = function() {
    let result = "";
    while (consume()) {
      if (namechar(code)) {
        result += stringFromCode(code);
      } else if (startsWithAValidEscape()) {
        result += stringFromCode(consumeEscape());
      } else {
        reconsume();
        return result;
      }
    }
    throw new Error("Internal parse error");
  };
  const consumeANumber = function() {
    let repr = "";
    let type = "integer";
    if (next() === 43 || next() === 45) {
      consume();
      repr += stringFromCode(code);
    }
    while (digit(next())) {
      consume();
      repr += stringFromCode(code);
    }
    if (next(1) === 46 && digit(next(2))) {
      consume();
      repr += stringFromCode(code);
      consume();
      repr += stringFromCode(code);
      type = "number";
      while (digit(next())) {
        consume();
        repr += stringFromCode(code);
      }
    }
    const c1 = next(1), c2 = next(2), c3 = next(3);
    if ((c1 === 69 || c1 === 101) && digit(c2)) {
      consume();
      repr += stringFromCode(code);
      consume();
      repr += stringFromCode(code);
      type = "number";
      while (digit(next())) {
        consume();
        repr += stringFromCode(code);
      }
    } else if ((c1 === 69 || c1 === 101) && (c2 === 43 || c2 === 45) && digit(c3)) {
      consume();
      repr += stringFromCode(code);
      consume();
      repr += stringFromCode(code);
      consume();
      repr += stringFromCode(code);
      type = "number";
      while (digit(next())) {
        consume();
        repr += stringFromCode(code);
      }
    }
    const value = convertAStringToANumber(repr);
    return { type, value, repr };
  };
  const convertAStringToANumber = function(string) {
    return +string;
  };
  const consumeTheRemnantsOfABadURL = function() {
    while (consume()) {
      if (code === 41 || eof()) {
        return;
      } else if (startsWithAValidEscape()) {
        consumeEscape();
      } else
        ;
    }
  };
  let iterationCount = 0;
  while (!eof(next())) {
    tokens.push(consumeAToken());
    iterationCount++;
    if (iterationCount > str.length * 2)
      throw new Error("I'm infinite-looping!");
  }
  return tokens;
}
class CSSParserToken {
  constructor() {
    this.tokenType = "";
  }
  toJSON() {
    return { token: this.tokenType };
  }
  toString() {
    return this.tokenType;
  }
  toSource() {
    return "" + this;
  }
}
class BadStringToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "BADSTRING";
  }
}
class BadURLToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "BADURL";
  }
}
class WhitespaceToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "WHITESPACE";
  }
  toString() {
    return "WS";
  }
  toSource() {
    return " ";
  }
}
class CDOToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "CDO";
  }
  toSource() {
    return "<!--";
  }
}
class CDCToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "CDC";
  }
  toSource() {
    return "-->";
  }
}
class ColonToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = ":";
  }
}
class SemicolonToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = ";";
  }
}
class CommaToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = ",";
  }
}
class GroupingToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.value = "";
    this.mirror = "";
  }
}
class OpenCurlyToken extends GroupingToken {
  constructor() {
    super();
    this.tokenType = "{";
    this.value = "{";
    this.mirror = "}";
  }
}
class CloseCurlyToken extends GroupingToken {
  constructor() {
    super();
    this.tokenType = "}";
    this.value = "}";
    this.mirror = "{";
  }
}
class OpenSquareToken extends GroupingToken {
  constructor() {
    super();
    this.tokenType = "[";
    this.value = "[";
    this.mirror = "]";
  }
}
class CloseSquareToken extends GroupingToken {
  constructor() {
    super();
    this.tokenType = "]";
    this.value = "]";
    this.mirror = "[";
  }
}
class OpenParenToken extends GroupingToken {
  constructor() {
    super();
    this.tokenType = "(";
    this.value = "(";
    this.mirror = ")";
  }
}
class CloseParenToken extends GroupingToken {
  constructor() {
    super();
    this.tokenType = ")";
    this.value = ")";
    this.mirror = "(";
  }
}
class IncludeMatchToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "~=";
  }
}
class DashMatchToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "|=";
  }
}
class PrefixMatchToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "^=";
  }
}
class SuffixMatchToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "$=";
  }
}
class SubstringMatchToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "*=";
  }
}
class ColumnToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "||";
  }
}
class EOFToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.tokenType = "EOF";
  }
  toSource() {
    return "";
  }
}
class DelimToken extends CSSParserToken {
  constructor(code) {
    super();
    this.tokenType = "DELIM";
    this.value = "";
    this.value = stringFromCode(code);
  }
  toString() {
    return "DELIM(" + this.value + ")";
  }
  toJSON() {
    const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
    json.value = this.value;
    return json;
  }
  toSource() {
    if (this.value === "\\")
      return "\\\n";
    else
      return this.value;
  }
}
class StringValuedToken extends CSSParserToken {
  constructor() {
    super(...arguments);
    this.value = "";
  }
  ASCIIMatch(str) {
    return this.value.toLowerCase() === str.toLowerCase();
  }
  toJSON() {
    const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
    json.value = this.value;
    return json;
  }
}
class IdentToken extends StringValuedToken {
  constructor(val) {
    super();
    this.tokenType = "IDENT";
    this.value = val;
  }
  toString() {
    return "IDENT(" + this.value + ")";
  }
  toSource() {
    return escapeIdent(this.value);
  }
}
class FunctionToken extends StringValuedToken {
  constructor(val) {
    super();
    this.tokenType = "FUNCTION";
    this.value = val;
    this.mirror = ")";
  }
  toString() {
    return "FUNCTION(" + this.value + ")";
  }
  toSource() {
    return escapeIdent(this.value) + "(";
  }
}
class AtKeywordToken extends StringValuedToken {
  constructor(val) {
    super();
    this.tokenType = "AT-KEYWORD";
    this.value = val;
  }
  toString() {
    return "AT(" + this.value + ")";
  }
  toSource() {
    return "@" + escapeIdent(this.value);
  }
}
class HashToken extends StringValuedToken {
  constructor(val) {
    super();
    this.tokenType = "HASH";
    this.value = val;
    this.type = "unrestricted";
  }
  toString() {
    return "HASH(" + this.value + ")";
  }
  toJSON() {
    const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
    json.value = this.value;
    json.type = this.type;
    return json;
  }
  toSource() {
    if (this.type === "id")
      return "#" + escapeIdent(this.value);
    else
      return "#" + escapeHash(this.value);
  }
}
class StringToken extends StringValuedToken {
  constructor(val) {
    super();
    this.tokenType = "STRING";
    this.value = val;
  }
  toString() {
    return '"' + escapeString(this.value) + '"';
  }
}
class URLToken extends StringValuedToken {
  constructor(val) {
    super();
    this.tokenType = "URL";
    this.value = val;
  }
  toString() {
    return "URL(" + this.value + ")";
  }
  toSource() {
    return 'url("' + escapeString(this.value) + '")';
  }
}
class NumberToken extends CSSParserToken {
  constructor() {
    super();
    this.tokenType = "NUMBER";
    this.type = "integer";
    this.repr = "";
  }
  toString() {
    if (this.type === "integer")
      return "INT(" + this.value + ")";
    return "NUMBER(" + this.value + ")";
  }
  toJSON() {
    const json = super.toJSON();
    json.value = this.value;
    json.type = this.type;
    json.repr = this.repr;
    return json;
  }
  toSource() {
    return this.repr;
  }
}
class PercentageToken extends CSSParserToken {
  constructor() {
    super();
    this.tokenType = "PERCENTAGE";
    this.repr = "";
  }
  toString() {
    return "PERCENTAGE(" + this.value + ")";
  }
  toJSON() {
    const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
    json.value = this.value;
    json.repr = this.repr;
    return json;
  }
  toSource() {
    return this.repr + "%";
  }
}
class DimensionToken extends CSSParserToken {
  constructor() {
    super();
    this.tokenType = "DIMENSION";
    this.type = "integer";
    this.repr = "";
    this.unit = "";
  }
  toString() {
    return "DIM(" + this.value + "," + this.unit + ")";
  }
  toJSON() {
    const json = this.constructor.prototype.constructor.prototype.toJSON.call(this);
    json.value = this.value;
    json.type = this.type;
    json.repr = this.repr;
    json.unit = this.unit;
    return json;
  }
  toSource() {
    const source = this.repr;
    let unit = escapeIdent(this.unit);
    if (unit[0].toLowerCase() === "e" && (unit[1] === "-" || between$1(unit.charCodeAt(1), 48, 57))) {
      unit = "\\65 " + unit.slice(1, unit.length);
    }
    return source + unit;
  }
}
function escapeIdent(string) {
  string = "" + string;
  let result = "";
  const firstcode = string.charCodeAt(0);
  for (let i = 0; i < string.length; i++) {
    const code = string.charCodeAt(i);
    if (code === 0)
      throw new InvalidCharacterError("Invalid character: the input contains U+0000.");
    if (between$1(code, 1, 31) || code === 127 || i === 0 && between$1(code, 48, 57) || i === 1 && between$1(code, 48, 57) && firstcode === 45)
      result += "\\" + code.toString(16) + " ";
    else if (code >= 128 || code === 45 || code === 95 || between$1(code, 48, 57) || between$1(code, 65, 90) || between$1(code, 97, 122))
      result += string[i];
    else
      result += "\\" + string[i];
  }
  return result;
}
function escapeHash(string) {
  string = "" + string;
  let result = "";
  for (let i = 0; i < string.length; i++) {
    const code = string.charCodeAt(i);
    if (code === 0)
      throw new InvalidCharacterError("Invalid character: the input contains U+0000.");
    if (code >= 128 || code === 45 || code === 95 || between$1(code, 48, 57) || between$1(code, 65, 90) || between$1(code, 97, 122))
      result += string[i];
    else
      result += "\\" + code.toString(16) + " ";
  }
  return result;
}
function escapeString(string) {
  string = "" + string;
  let result = "";
  for (let i = 0; i < string.length; i++) {
    const code = string.charCodeAt(i);
    if (code === 0)
      throw new InvalidCharacterError("Invalid character: the input contains U+0000.");
    if (between$1(code, 1, 31) || code === 127)
      result += "\\" + code.toString(16) + " ";
    else if (code === 34 || code === 92)
      result += "\\" + string[i];
    else
      result += string[i];
  }
  return result;
}
class InvalidSelectorError extends Error {
}
function parseCSS(selector, customNames) {
  let tokens;
  try {
    tokens = tokenize$1(selector);
    if (!(tokens[tokens.length - 1] instanceof EOFToken))
      tokens.push(new EOFToken());
  } catch (e) {
    const newMessage = e.message + ` while parsing selector "${selector}"`;
    const index = (e.stack || "").indexOf(e.message);
    if (index !== -1)
      e.stack = e.stack.substring(0, index) + newMessage + e.stack.substring(index + e.message.length);
    e.message = newMessage;
    throw e;
  }
  const unsupportedToken = tokens.find((token) => {
    return token instanceof AtKeywordToken || token instanceof BadStringToken || token instanceof BadURLToken || token instanceof ColumnToken || token instanceof CDOToken || token instanceof CDCToken || token instanceof SemicolonToken || // TODO: Consider using these for something, e.g. to escape complex strings.
    // For example :xpath{ (//div/bar[@attr="foo"])[2]/baz }
    // Or this way :xpath( {complex-xpath-goes-here("hello")} )
    token instanceof OpenCurlyToken || token instanceof CloseCurlyToken || // TODO: Consider treating these as strings?
    token instanceof URLToken || token instanceof PercentageToken;
  });
  if (unsupportedToken)
    throw new InvalidSelectorError(`Unsupported token "${unsupportedToken.toSource()}" while parsing selector "${selector}"`);
  let pos = 0;
  const names = /* @__PURE__ */ new Set();
  function unexpected() {
    return new InvalidSelectorError(`Unexpected token "${tokens[pos].toSource()}" while parsing selector "${selector}"`);
  }
  function skipWhitespace() {
    while (tokens[pos] instanceof WhitespaceToken)
      pos++;
  }
  function isIdent(p2 = pos) {
    return tokens[p2] instanceof IdentToken;
  }
  function isString2(p2 = pos) {
    return tokens[p2] instanceof StringToken;
  }
  function isNumber(p2 = pos) {
    return tokens[p2] instanceof NumberToken;
  }
  function isComma(p2 = pos) {
    return tokens[p2] instanceof CommaToken;
  }
  function isCloseParen(p2 = pos) {
    return tokens[p2] instanceof CloseParenToken;
  }
  function isStar(p2 = pos) {
    return tokens[p2] instanceof DelimToken && tokens[p2].value === "*";
  }
  function isEOF(p2 = pos) {
    return tokens[p2] instanceof EOFToken;
  }
  function isClauseCombinator(p2 = pos) {
    return tokens[p2] instanceof DelimToken && [">", "+", "~"].includes(tokens[p2].value);
  }
  function isSelectorClauseEnd(p2 = pos) {
    return isComma(p2) || isCloseParen(p2) || isEOF(p2) || isClauseCombinator(p2) || tokens[p2] instanceof WhitespaceToken;
  }
  function consumeFunctionArguments() {
    const result2 = [consumeArgument()];
    while (true) {
      skipWhitespace();
      if (!isComma())
        break;
      pos++;
      result2.push(consumeArgument());
    }
    return result2;
  }
  function consumeArgument() {
    skipWhitespace();
    if (isNumber())
      return tokens[pos++].value;
    if (isString2())
      return tokens[pos++].value;
    return consumeComplexSelector();
  }
  function consumeComplexSelector() {
    const result2 = { simples: [] };
    skipWhitespace();
    if (isClauseCombinator()) {
      result2.simples.push({ selector: { functions: [{ name: "scope", args: [] }] }, combinator: "" });
    } else {
      result2.simples.push({ selector: consumeSimpleSelector(), combinator: "" });
    }
    while (true) {
      skipWhitespace();
      if (isClauseCombinator()) {
        result2.simples[result2.simples.length - 1].combinator = tokens[pos++].value;
        skipWhitespace();
      } else if (isSelectorClauseEnd()) {
        break;
      }
      result2.simples.push({ combinator: "", selector: consumeSimpleSelector() });
    }
    return result2;
  }
  function consumeSimpleSelector() {
    let rawCSSString = "";
    const functions = [];
    while (!isSelectorClauseEnd()) {
      if (isIdent() || isStar()) {
        rawCSSString += tokens[pos++].toSource();
      } else if (tokens[pos] instanceof HashToken) {
        rawCSSString += tokens[pos++].toSource();
      } else if (tokens[pos] instanceof DelimToken && tokens[pos].value === ".") {
        pos++;
        if (isIdent())
          rawCSSString += "." + tokens[pos++].toSource();
        else
          throw unexpected();
      } else if (tokens[pos] instanceof ColonToken) {
        pos++;
        if (isIdent()) {
          if (!customNames.has(tokens[pos].value.toLowerCase())) {
            rawCSSString += ":" + tokens[pos++].toSource();
          } else {
            const name = tokens[pos++].value.toLowerCase();
            functions.push({ name, args: [] });
            names.add(name);
          }
        } else if (tokens[pos] instanceof FunctionToken) {
          const name = tokens[pos++].value.toLowerCase();
          if (!customNames.has(name)) {
            rawCSSString += `:${name}(${consumeBuiltinFunctionArguments()})`;
          } else {
            functions.push({ name, args: consumeFunctionArguments() });
            names.add(name);
          }
          skipWhitespace();
          if (!isCloseParen())
            throw unexpected();
          pos++;
        } else {
          throw unexpected();
        }
      } else if (tokens[pos] instanceof OpenSquareToken) {
        rawCSSString += "[";
        pos++;
        while (!(tokens[pos] instanceof CloseSquareToken) && !isEOF())
          rawCSSString += tokens[pos++].toSource();
        if (!(tokens[pos] instanceof CloseSquareToken))
          throw unexpected();
        rawCSSString += "]";
        pos++;
      } else {
        throw unexpected();
      }
    }
    if (!rawCSSString && !functions.length)
      throw unexpected();
    return { css: rawCSSString || void 0, functions };
  }
  function consumeBuiltinFunctionArguments() {
    let s = "";
    while (!isCloseParen() && !isEOF())
      s += tokens[pos++].toSource();
    return s;
  }
  const result = consumeFunctionArguments();
  if (!isEOF())
    throw new InvalidSelectorError(`Error while parsing selector "${selector}"`);
  if (result.some((arg) => typeof arg !== "object" || !("simples" in arg)))
    throw new InvalidSelectorError(`Error while parsing selector "${selector}"`);
  return { selector: result, names: Array.from(names) };
}
const kNestedSelectorNames = /* @__PURE__ */ new Set(["internal:has", "internal:has-not", "internal:and", "internal:or", "left-of", "right-of", "above", "below", "near"]);
const kNestedSelectorNamesWithDistance = /* @__PURE__ */ new Set(["left-of", "right-of", "above", "below", "near"]);
const customCSSNames = /* @__PURE__ */ new Set(["not", "is", "where", "has", "scope", "light", "visible", "text", "text-matches", "text-is", "has-text", "above", "below", "right-of", "left-of", "near", "nth-match"]);
function parseSelector(selector) {
  const parsedStrings = parseSelectorString(selector);
  const parts = [];
  for (const part2 of parsedStrings.parts) {
    if (part2.name === "css" || part2.name === "css:light") {
      if (part2.name === "css:light")
        part2.body = ":light(" + part2.body + ")";
      const parsedCSS = parseCSS(part2.body, customCSSNames);
      parts.push({
        name: "css",
        body: parsedCSS.selector,
        source: part2.body
      });
      continue;
    }
    if (kNestedSelectorNames.has(part2.name)) {
      let innerSelector;
      let distance;
      try {
        const unescaped = JSON.parse("[" + part2.body + "]");
        if (!Array.isArray(unescaped) || unescaped.length < 1 || unescaped.length > 2 || typeof unescaped[0] !== "string")
          throw new InvalidSelectorError(`Malformed selector: ${part2.name}=` + part2.body);
        innerSelector = unescaped[0];
        if (unescaped.length === 2) {
          if (typeof unescaped[1] !== "number" || !kNestedSelectorNamesWithDistance.has(part2.name))
            throw new InvalidSelectorError(`Malformed selector: ${part2.name}=` + part2.body);
          distance = unescaped[1];
        }
      } catch (e) {
        throw new InvalidSelectorError(`Malformed selector: ${part2.name}=` + part2.body);
      }
      const nested = { name: part2.name, source: part2.body, body: { parsed: parseSelector(innerSelector), distance } };
      const lastFrame = [...nested.body.parsed.parts].reverse().find((part22) => part22.name === "internal:control" && part22.body === "enter-frame");
      const lastFrameIndex = lastFrame ? nested.body.parsed.parts.indexOf(lastFrame) : -1;
      if (lastFrameIndex !== -1 && selectorPartsEqual(nested.body.parsed.parts.slice(0, lastFrameIndex + 1), parts.slice(0, lastFrameIndex + 1)))
        nested.body.parsed.parts.splice(0, lastFrameIndex + 1);
      parts.push(nested);
      continue;
    }
    parts.push({ ...part2, source: part2.body });
  }
  if (kNestedSelectorNames.has(parts[0].name))
    throw new InvalidSelectorError(`"${parts[0].name}" selector cannot be first`);
  return {
    capture: parsedStrings.capture,
    parts
  };
}
function selectorPartsEqual(list1, list2) {
  return stringifySelector({ parts: list1 }) === stringifySelector({ parts: list2 });
}
function stringifySelector(selector) {
  if (typeof selector === "string")
    return selector;
  return selector.parts.map((p2, i) => {
    const prefix = p2.name === "css" ? "" : p2.name + "=";
    return `${i === selector.capture ? "*" : ""}${prefix}${p2.source}`;
  }).join(" >> ");
}
function visitAllSelectorParts(selector, visitor) {
  const visit = (selector2, nested) => {
    for (const part2 of selector2.parts) {
      visitor(part2, nested);
      if (kNestedSelectorNames.has(part2.name))
        visit(part2.body.parsed, true);
    }
  };
  visit(selector, false);
}
function parseSelectorString(selector) {
  let index = 0;
  let quote;
  let start = 0;
  const result = { parts: [] };
  const append = () => {
    const part2 = selector.substring(start, index).trim();
    const eqIndex = part2.indexOf("=");
    let name;
    let body;
    if (eqIndex !== -1 && part2.substring(0, eqIndex).trim().match(/^[a-zA-Z_0-9-+:*]+$/)) {
      name = part2.substring(0, eqIndex).trim();
      body = part2.substring(eqIndex + 1);
    } else if (part2.length > 1 && part2[0] === '"' && part2[part2.length - 1] === '"') {
      name = "text";
      body = part2;
    } else if (part2.length > 1 && part2[0] === "'" && part2[part2.length - 1] === "'") {
      name = "text";
      body = part2;
    } else if (/^\(*\/\//.test(part2) || part2.startsWith("..")) {
      name = "xpath";
      body = part2;
    } else {
      name = "css";
      body = part2;
    }
    let capture = false;
    if (name[0] === "*") {
      capture = true;
      name = name.substring(1);
    }
    result.parts.push({ name, body });
    if (capture) {
      if (result.capture !== void 0)
        throw new InvalidSelectorError(`Only one of the selectors can capture using * modifier`);
      result.capture = result.parts.length - 1;
    }
  };
  if (!selector.includes(">>")) {
    index = selector.length;
    append();
    return result;
  }
  const shouldIgnoreTextSelectorQuote = () => {
    const prefix = selector.substring(start, index);
    const match = prefix.match(/^\s*text\s*=(.*)$/);
    return !!match && !!match[1];
  };
  while (index < selector.length) {
    const c = selector[index];
    if (c === "\\" && index + 1 < selector.length) {
      index += 2;
    } else if (c === quote) {
      quote = void 0;
      index++;
    } else if (!quote && (c === '"' || c === "'" || c === "`") && !shouldIgnoreTextSelectorQuote()) {
      quote = c;
      index++;
    } else if (!quote && c === ">" && selector[index + 1] === ">") {
      append();
      index += 2;
      start = index;
    } else {
      index++;
    }
  }
  append();
  return result;
}
function parseAttributeSelector(selector, allowUnquotedStrings) {
  let wp2 = 0;
  let EOL = selector.length === 0;
  const next = () => selector[wp2] || "";
  const eat1 = () => {
    const result2 = next();
    ++wp2;
    EOL = wp2 >= selector.length;
    return result2;
  };
  const syntaxError = (stage) => {
    if (EOL)
      throw new InvalidSelectorError(`Unexpected end of selector while parsing selector \`${selector}\``);
    throw new InvalidSelectorError(`Error while parsing selector \`${selector}\` - unexpected symbol "${next()}" at position ${wp2}` + (stage ? " during " + stage : ""));
  };
  function skipSpaces() {
    while (!EOL && /\s/.test(next()))
      eat1();
  }
  function isCSSNameChar(char) {
    return char >= "" || char >= "0" && char <= "9" || char >= "A" && char <= "Z" || char >= "a" && char <= "z" || char >= "0" && char <= "9" || char === "_" || char === "-";
  }
  function readIdentifier() {
    let result2 = "";
    skipSpaces();
    while (!EOL && isCSSNameChar(next()))
      result2 += eat1();
    return result2;
  }
  function readQuotedString(quote) {
    let result2 = eat1();
    if (result2 !== quote)
      syntaxError("parsing quoted string");
    while (!EOL && next() !== quote) {
      if (next() === "\\")
        eat1();
      result2 += eat1();
    }
    if (next() !== quote)
      syntaxError("parsing quoted string");
    result2 += eat1();
    return result2;
  }
  function readRegularExpression() {
    if (eat1() !== "/")
      syntaxError("parsing regular expression");
    let source = "";
    let inClass = false;
    while (!EOL) {
      if (next() === "\\") {
        source += eat1();
        if (EOL)
          syntaxError("parsing regular expressiion");
      } else if (inClass && next() === "]") {
        inClass = false;
      } else if (!inClass && next() === "[") {
        inClass = true;
      } else if (!inClass && next() === "/") {
        break;
      }
      source += eat1();
    }
    if (eat1() !== "/")
      syntaxError("parsing regular expression");
    let flags = "";
    while (!EOL && next().match(/[dgimsuy]/))
      flags += eat1();
    try {
      return new RegExp(source, flags);
    } catch (e) {
      throw new InvalidSelectorError(`Error while parsing selector \`${selector}\`: ${e.message}`);
    }
  }
  function readAttributeToken() {
    let token = "";
    skipSpaces();
    if (next() === `'` || next() === `"`)
      token = readQuotedString(next()).slice(1, -1);
    else
      token = readIdentifier();
    if (!token)
      syntaxError("parsing property path");
    return token;
  }
  function readOperator() {
    skipSpaces();
    let op = "";
    if (!EOL)
      op += eat1();
    if (!EOL && op !== "=")
      op += eat1();
    if (!["=", "*=", "^=", "$=", "|=", "~="].includes(op))
      syntaxError("parsing operator");
    return op;
  }
  function readAttribute() {
    eat1();
    const jsonPath = [];
    jsonPath.push(readAttributeToken());
    skipSpaces();
    while (next() === ".") {
      eat1();
      jsonPath.push(readAttributeToken());
      skipSpaces();
    }
    if (next() === "]") {
      eat1();
      return { name: jsonPath.join("."), jsonPath, op: "<truthy>", value: null, caseSensitive: false };
    }
    const operator = readOperator();
    let value = void 0;
    let caseSensitive = true;
    skipSpaces();
    if (next() === "/") {
      if (operator !== "=")
        throw new InvalidSelectorError(`Error while parsing selector \`${selector}\` - cannot use ${operator} in attribute with regular expression`);
      value = readRegularExpression();
    } else if (next() === `'` || next() === `"`) {
      value = readQuotedString(next()).slice(1, -1);
      skipSpaces();
      if (next() === "i" || next() === "I") {
        caseSensitive = false;
        eat1();
      } else if (next() === "s" || next() === "S") {
        caseSensitive = true;
        eat1();
      }
    } else {
      value = "";
      while (!EOL && (isCSSNameChar(next()) || next() === "+" || next() === "."))
        value += eat1();
      if (value === "true") {
        value = true;
      } else if (value === "false") {
        value = false;
      } else {
        if (!allowUnquotedStrings) {
          value = +value;
          if (Number.isNaN(value))
            syntaxError("parsing attribute value");
        }
      }
    }
    skipSpaces();
    if (next() !== "]")
      syntaxError("parsing attribute value");
    eat1();
    if (operator !== "=" && typeof value !== "string")
      throw new InvalidSelectorError(`Error while parsing selector \`${selector}\` - cannot use ${operator} in attribute with non-string matching value - ${value}`);
    return { name: jsonPath.join("."), jsonPath, op: operator, value, caseSensitive };
  }
  const result = {
    name: "",
    attributes: []
  };
  result.name = readIdentifier();
  skipSpaces();
  while (next() === "[") {
    result.attributes.push(readAttribute());
    skipSpaces();
  }
  if (!EOL)
    syntaxError(void 0);
  if (!result.name && !result.attributes.length)
    throw new InvalidSelectorError(`Error while parsing selector \`${selector}\` - selector cannot be empty`);
  return result;
}
function asLocator(lang2, selector, isFrameLocator = false, playSafe = false) {
  return asLocators(lang2, selector, isFrameLocator, playSafe)[0];
}
function asLocators(lang2, selector, isFrameLocator = false, playSafe = false, maxOutputSize = 20) {
  if (playSafe) {
    try {
      return innerAsLocators(generators[lang2], parseSelector(selector), isFrameLocator, maxOutputSize);
    } catch (e) {
      return [selector];
    }
  } else {
    return innerAsLocators(generators[lang2], parseSelector(selector), isFrameLocator, maxOutputSize);
  }
}
function innerAsLocators(factory, parsed, isFrameLocator = false, maxOutputSize = 20) {
  const parts = [...parsed.parts];
  for (let index = 0; index < parts.length - 1; index++) {
    if (parts[index].name === "nth" && parts[index + 1].name === "internal:control" && parts[index + 1].body === "enter-frame") {
      const [nth] = parts.splice(index, 1);
      parts.splice(index + 1, 0, nth);
    }
  }
  const tokens = [];
  let nextBase = isFrameLocator ? "frame-locator" : "page";
  for (let index = 0; index < parts.length; index++) {
    const part2 = parts[index];
    const base = nextBase;
    nextBase = "locator";
    if (part2.name === "nth") {
      if (part2.body === "0")
        tokens.push([factory.generateLocator(base, "first", ""), factory.generateLocator(base, "nth", "0")]);
      else if (part2.body === "-1")
        tokens.push([factory.generateLocator(base, "last", ""), factory.generateLocator(base, "nth", "-1")]);
      else
        tokens.push([factory.generateLocator(base, "nth", part2.body)]);
      continue;
    }
    if (part2.name === "internal:text") {
      const { exact, text } = detectExact(part2.body);
      tokens.push([factory.generateLocator(base, "text", text, { exact })]);
      continue;
    }
    if (part2.name === "internal:has-text") {
      const { exact, text } = detectExact(part2.body);
      if (!exact) {
        tokens.push([factory.generateLocator(base, "has-text", text, { exact })]);
        continue;
      }
    }
    if (part2.name === "internal:has-not-text") {
      const { exact, text } = detectExact(part2.body);
      if (!exact) {
        tokens.push([factory.generateLocator(base, "has-not-text", text, { exact })]);
        continue;
      }
    }
    if (part2.name === "internal:has") {
      const inners = innerAsLocators(factory, part2.body.parsed, false, maxOutputSize);
      tokens.push(inners.map((inner) => factory.generateLocator(base, "has", inner)));
      continue;
    }
    if (part2.name === "internal:has-not") {
      const inners = innerAsLocators(factory, part2.body.parsed, false, maxOutputSize);
      tokens.push(inners.map((inner) => factory.generateLocator(base, "hasNot", inner)));
      continue;
    }
    if (part2.name === "internal:and") {
      const inners = innerAsLocators(factory, part2.body.parsed, false, maxOutputSize);
      tokens.push(inners.map((inner) => factory.generateLocator(base, "and", inner)));
      continue;
    }
    if (part2.name === "internal:or") {
      const inners = innerAsLocators(factory, part2.body.parsed, false, maxOutputSize);
      tokens.push(inners.map((inner) => factory.generateLocator(base, "or", inner)));
      continue;
    }
    if (part2.name === "internal:label") {
      const { exact, text } = detectExact(part2.body);
      tokens.push([factory.generateLocator(base, "label", text, { exact })]);
      continue;
    }
    if (part2.name === "internal:role") {
      const attrSelector = parseAttributeSelector(part2.body, true);
      const options = { attrs: [] };
      for (const attr of attrSelector.attributes) {
        if (attr.name === "name") {
          options.exact = attr.caseSensitive;
          options.name = attr.value;
        } else {
          if (attr.name === "level" && typeof attr.value === "string")
            attr.value = +attr.value;
          options.attrs.push({ name: attr.name === "include-hidden" ? "includeHidden" : attr.name, value: attr.value });
        }
      }
      tokens.push([factory.generateLocator(base, "role", attrSelector.name, options)]);
      continue;
    }
    if (part2.name === "internal:testid") {
      const attrSelector = parseAttributeSelector(part2.body, true);
      const { value } = attrSelector.attributes[0];
      tokens.push([factory.generateLocator(base, "test-id", value)]);
      continue;
    }
    if (part2.name === "internal:attr") {
      const attrSelector = parseAttributeSelector(part2.body, true);
      const { name, value, caseSensitive } = attrSelector.attributes[0];
      const text = value;
      const exact = !!caseSensitive;
      if (name === "placeholder") {
        tokens.push([factory.generateLocator(base, "placeholder", text, { exact })]);
        continue;
      }
      if (name === "alt") {
        tokens.push([factory.generateLocator(base, "alt", text, { exact })]);
        continue;
      }
      if (name === "title") {
        tokens.push([factory.generateLocator(base, "title", text, { exact })]);
        continue;
      }
    }
    let locatorType = "default";
    const nextPart = parts[index + 1];
    if (nextPart && nextPart.name === "internal:control" && nextPart.body === "enter-frame") {
      locatorType = "frame";
      nextBase = "frame-locator";
      index++;
    }
    const selectorPart = stringifySelector({ parts: [part2] });
    const locatorPart = factory.generateLocator(base, locatorType, selectorPart);
    if (locatorType === "default" && nextPart && ["internal:has-text", "internal:has-not-text"].includes(nextPart.name)) {
      const { exact, text } = detectExact(nextPart.body);
      if (!exact) {
        const nextLocatorPart = factory.generateLocator("locator", nextPart.name === "internal:has-text" ? "has-text" : "has-not-text", text, { exact });
        const options = {};
        if (nextPart.name === "internal:has-text")
          options.hasText = text;
        else
          options.hasNotText = text;
        const combinedPart = factory.generateLocator(base, "default", selectorPart, options);
        tokens.push([factory.chainLocators([locatorPart, nextLocatorPart]), combinedPart]);
        index++;
        continue;
      }
    }
    tokens.push([locatorPart]);
  }
  return combineTokens(factory, tokens, maxOutputSize);
}
function combineTokens(factory, tokens, maxOutputSize) {
  const currentTokens = tokens.map(() => "");
  const result = [];
  const visit = (index) => {
    if (index === tokens.length) {
      result.push(factory.chainLocators(currentTokens));
      return currentTokens.length < maxOutputSize;
    }
    for (const taken of tokens[index]) {
      currentTokens[index] = taken;
      if (!visit(index + 1))
        return false;
    }
    return true;
  };
  visit(0);
  return result;
}
function detectExact(text) {
  let exact = false;
  const match = text.match(/^\/(.*)\/([igm]*)$/);
  if (match)
    return { text: new RegExp(match[1], match[2]) };
  if (text.endsWith('"')) {
    text = JSON.parse(text);
    exact = true;
  } else if (text.endsWith('"s')) {
    text = JSON.parse(text.substring(0, text.length - 1));
    exact = true;
  } else if (text.endsWith('"i')) {
    text = JSON.parse(text.substring(0, text.length - 1));
    exact = false;
  }
  return { exact, text };
}
class JavaScriptLocatorFactory {
  generateLocator(base, kind, body, options = {}) {
    switch (kind) {
      case "default":
        if (options.hasText !== void 0)
          return `locator(${this.quote(body)}, { hasText: ${this.toHasText(options.hasText)} })`;
        if (options.hasNotText !== void 0)
          return `locator(${this.quote(body)}, { hasNotText: ${this.toHasText(options.hasNotText)} })`;
        return `locator(${this.quote(body)})`;
      case "frame":
        return `frameLocator(${this.quote(body)})`;
      case "nth":
        return `nth(${body})`;
      case "first":
        return `first()`;
      case "last":
        return `last()`;
      case "role":
        const attrs = [];
        if (isRegExp(options.name)) {
          attrs.push(`name: ${options.name}`);
        } else if (typeof options.name === "string") {
          attrs.push(`name: ${this.quote(options.name)}`);
          if (options.exact)
            attrs.push(`exact: true`);
        }
        for (const { name, value } of options.attrs)
          attrs.push(`${name}: ${typeof value === "string" ? this.quote(value) : value}`);
        const attrString = attrs.length ? `, { ${attrs.join(", ")} }` : "";
        return `getByRole(${this.quote(body)}${attrString})`;
      case "has-text":
        return `filter({ hasText: ${this.toHasText(body)} })`;
      case "has-not-text":
        return `filter({ hasNotText: ${this.toHasText(body)} })`;
      case "has":
        return `filter({ has: ${body} })`;
      case "hasNot":
        return `filter({ hasNot: ${body} })`;
      case "and":
        return `and(${body})`;
      case "or":
        return `or(${body})`;
      case "test-id":
        return `getByTestId(${this.toTestIdValue(body)})`;
      case "text":
        return this.toCallWithExact("getByText", body, !!options.exact);
      case "alt":
        return this.toCallWithExact("getByAltText", body, !!options.exact);
      case "placeholder":
        return this.toCallWithExact("getByPlaceholder", body, !!options.exact);
      case "label":
        return this.toCallWithExact("getByLabel", body, !!options.exact);
      case "title":
        return this.toCallWithExact("getByTitle", body, !!options.exact);
      default:
        throw new Error("Unknown selector kind " + kind);
    }
  }
  chainLocators(locators) {
    return locators.join(".");
  }
  toCallWithExact(method, body, exact) {
    if (isRegExp(body))
      return `${method}(${body})`;
    return exact ? `${method}(${this.quote(body)}, { exact: true })` : `${method}(${this.quote(body)})`;
  }
  toHasText(body) {
    if (isRegExp(body))
      return String(body);
    return this.quote(body);
  }
  toTestIdValue(value) {
    if (isRegExp(value))
      return String(value);
    return this.quote(value);
  }
  quote(text) {
    return escapeWithQuotes(text, "'");
  }
}
class PythonLocatorFactory {
  generateLocator(base, kind, body, options = {}) {
    switch (kind) {
      case "default":
        if (options.hasText !== void 0)
          return `locator(${this.quote(body)}, has_text=${this.toHasText(options.hasText)})`;
        if (options.hasNotText !== void 0)
          return `locator(${this.quote(body)}, has_not_text=${this.toHasText(options.hasNotText)})`;
        return `locator(${this.quote(body)})`;
      case "frame":
        return `frame_locator(${this.quote(body)})`;
      case "nth":
        return `nth(${body})`;
      case "first":
        return `first`;
      case "last":
        return `last`;
      case "role":
        const attrs = [];
        if (isRegExp(options.name)) {
          attrs.push(`name=${this.regexToString(options.name)}`);
        } else if (typeof options.name === "string") {
          attrs.push(`name=${this.quote(options.name)}`);
          if (options.exact)
            attrs.push(`exact=True`);
        }
        for (const { name, value } of options.attrs) {
          let valueString = typeof value === "string" ? this.quote(value) : value;
          if (typeof value === "boolean")
            valueString = value ? "True" : "False";
          attrs.push(`${toSnakeCase(name)}=${valueString}`);
        }
        const attrString = attrs.length ? `, ${attrs.join(", ")}` : "";
        return `get_by_role(${this.quote(body)}${attrString})`;
      case "has-text":
        return `filter(has_text=${this.toHasText(body)})`;
      case "has-not-text":
        return `filter(has_not_text=${this.toHasText(body)})`;
      case "has":
        return `filter(has=${body})`;
      case "hasNot":
        return `filter(has_not=${body})`;
      case "and":
        return `and_(${body})`;
      case "or":
        return `or_(${body})`;
      case "test-id":
        return `get_by_test_id(${this.toTestIdValue(body)})`;
      case "text":
        return this.toCallWithExact("get_by_text", body, !!options.exact);
      case "alt":
        return this.toCallWithExact("get_by_alt_text", body, !!options.exact);
      case "placeholder":
        return this.toCallWithExact("get_by_placeholder", body, !!options.exact);
      case "label":
        return this.toCallWithExact("get_by_label", body, !!options.exact);
      case "title":
        return this.toCallWithExact("get_by_title", body, !!options.exact);
      default:
        throw new Error("Unknown selector kind " + kind);
    }
  }
  chainLocators(locators) {
    return locators.join(".");
  }
  regexToString(body) {
    const suffix = body.flags.includes("i") ? ", re.IGNORECASE" : "";
    return `re.compile(r"${body.source.replace(/\\\//, "/").replace(/"/g, '\\"')}"${suffix})`;
  }
  toCallWithExact(method, body, exact) {
    if (isRegExp(body))
      return `${method}(${this.regexToString(body)})`;
    if (exact)
      return `${method}(${this.quote(body)}, exact=True)`;
    return `${method}(${this.quote(body)})`;
  }
  toHasText(body) {
    if (isRegExp(body))
      return this.regexToString(body);
    return `${this.quote(body)}`;
  }
  toTestIdValue(value) {
    if (isRegExp(value))
      return this.regexToString(value);
    return this.quote(value);
  }
  quote(text) {
    return escapeWithQuotes(text, '"');
  }
}
class JavaLocatorFactory {
  generateLocator(base, kind, body, options = {}) {
    let clazz;
    switch (base) {
      case "page":
        clazz = "Page";
        break;
      case "frame-locator":
        clazz = "FrameLocator";
        break;
      case "locator":
        clazz = "Locator";
        break;
    }
    switch (kind) {
      case "default":
        if (options.hasText !== void 0)
          return `locator(${this.quote(body)}, new ${clazz}.LocatorOptions().setHasText(${this.toHasText(options.hasText)}))`;
        if (options.hasNotText !== void 0)
          return `locator(${this.quote(body)}, new ${clazz}.LocatorOptions().setHasNotText(${this.toHasText(options.hasNotText)}))`;
        return `locator(${this.quote(body)})`;
      case "frame":
        return `frameLocator(${this.quote(body)})`;
      case "nth":
        return `nth(${body})`;
      case "first":
        return `first()`;
      case "last":
        return `last()`;
      case "role":
        const attrs = [];
        if (isRegExp(options.name)) {
          attrs.push(`.setName(${this.regexToString(options.name)})`);
        } else if (typeof options.name === "string") {
          attrs.push(`.setName(${this.quote(options.name)})`);
          if (options.exact)
            attrs.push(`.setExact(true)`);
        }
        for (const { name, value } of options.attrs)
          attrs.push(`.set${toTitleCase(name)}(${typeof value === "string" ? this.quote(value) : value})`);
        const attrString = attrs.length ? `, new ${clazz}.GetByRoleOptions()${attrs.join("")}` : "";
        return `getByRole(AriaRole.${toSnakeCase(body).toUpperCase()}${attrString})`;
      case "has-text":
        return `filter(new ${clazz}.FilterOptions().setHasText(${this.toHasText(body)}))`;
      case "has-not-text":
        return `filter(new ${clazz}.FilterOptions().setHasNotText(${this.toHasText(body)}))`;
      case "has":
        return `filter(new ${clazz}.FilterOptions().setHas(${body}))`;
      case "hasNot":
        return `filter(new ${clazz}.FilterOptions().setHasNot(${body}))`;
      case "and":
        return `and(${body})`;
      case "or":
        return `or(${body})`;
      case "test-id":
        return `getByTestId(${this.toTestIdValue(body)})`;
      case "text":
        return this.toCallWithExact(clazz, "getByText", body, !!options.exact);
      case "alt":
        return this.toCallWithExact(clazz, "getByAltText", body, !!options.exact);
      case "placeholder":
        return this.toCallWithExact(clazz, "getByPlaceholder", body, !!options.exact);
      case "label":
        return this.toCallWithExact(clazz, "getByLabel", body, !!options.exact);
      case "title":
        return this.toCallWithExact(clazz, "getByTitle", body, !!options.exact);
      default:
        throw new Error("Unknown selector kind " + kind);
    }
  }
  chainLocators(locators) {
    return locators.join(".");
  }
  regexToString(body) {
    const suffix = body.flags.includes("i") ? ", Pattern.CASE_INSENSITIVE" : "";
    return `Pattern.compile(${this.quote(body.source)}${suffix})`;
  }
  toCallWithExact(clazz, method, body, exact) {
    if (isRegExp(body))
      return `${method}(${this.regexToString(body)})`;
    if (exact)
      return `${method}(${this.quote(body)}, new ${clazz}.${toTitleCase(method)}Options().setExact(true))`;
    return `${method}(${this.quote(body)})`;
  }
  toHasText(body) {
    if (isRegExp(body))
      return this.regexToString(body);
    return this.quote(body);
  }
  toTestIdValue(value) {
    if (isRegExp(value))
      return this.regexToString(value);
    return this.quote(value);
  }
  quote(text) {
    return escapeWithQuotes(text, '"');
  }
}
class CSharpLocatorFactory {
  generateLocator(base, kind, body, options = {}) {
    switch (kind) {
      case "default":
        if (options.hasText !== void 0)
          return `Locator(${this.quote(body)}, new() { ${this.toHasText(options.hasText)} })`;
        if (options.hasNotText !== void 0)
          return `Locator(${this.quote(body)}, new() { ${this.toHasNotText(options.hasNotText)} })`;
        return `Locator(${this.quote(body)})`;
      case "frame":
        return `FrameLocator(${this.quote(body)})`;
      case "nth":
        return `Nth(${body})`;
      case "first":
        return `First`;
      case "last":
        return `Last`;
      case "role":
        const attrs = [];
        if (isRegExp(options.name)) {
          attrs.push(`NameRegex = ${this.regexToString(options.name)}`);
        } else if (typeof options.name === "string") {
          attrs.push(`Name = ${this.quote(options.name)}`);
          if (options.exact)
            attrs.push(`Exact = true`);
        }
        for (const { name, value } of options.attrs)
          attrs.push(`${toTitleCase(name)} = ${typeof value === "string" ? this.quote(value) : value}`);
        const attrString = attrs.length ? `, new() { ${attrs.join(", ")} }` : "";
        return `GetByRole(AriaRole.${toTitleCase(body)}${attrString})`;
      case "has-text":
        return `Filter(new() { ${this.toHasText(body)} })`;
      case "has-not-text":
        return `Filter(new() { ${this.toHasNotText(body)} })`;
      case "has":
        return `Filter(new() { Has = ${body} })`;
      case "hasNot":
        return `Filter(new() { HasNot = ${body} })`;
      case "and":
        return `And(${body})`;
      case "or":
        return `Or(${body})`;
      case "test-id":
        return `GetByTestId(${this.toTestIdValue(body)})`;
      case "text":
        return this.toCallWithExact("GetByText", body, !!options.exact);
      case "alt":
        return this.toCallWithExact("GetByAltText", body, !!options.exact);
      case "placeholder":
        return this.toCallWithExact("GetByPlaceholder", body, !!options.exact);
      case "label":
        return this.toCallWithExact("GetByLabel", body, !!options.exact);
      case "title":
        return this.toCallWithExact("GetByTitle", body, !!options.exact);
      default:
        throw new Error("Unknown selector kind " + kind);
    }
  }
  chainLocators(locators) {
    return locators.join(".");
  }
  regexToString(body) {
    const suffix = body.flags.includes("i") ? ", RegexOptions.IgnoreCase" : "";
    return `new Regex(${this.quote(body.source)}${suffix})`;
  }
  toCallWithExact(method, body, exact) {
    if (isRegExp(body))
      return `${method}(${this.regexToString(body)})`;
    if (exact)
      return `${method}(${this.quote(body)}, new() { Exact = true })`;
    return `${method}(${this.quote(body)})`;
  }
  toHasText(body) {
    if (isRegExp(body))
      return `HasTextRegex = ${this.regexToString(body)}`;
    return `HasText = ${this.quote(body)}`;
  }
  toTestIdValue(value) {
    if (isRegExp(value))
      return this.regexToString(value);
    return this.quote(value);
  }
  toHasNotText(body) {
    if (isRegExp(body))
      return `HasNotTextRegex = ${this.regexToString(body)}`;
    return `HasNotText = ${this.quote(body)}`;
  }
  quote(text) {
    return escapeWithQuotes(text, '"');
  }
}
class JsonlLocatorFactory {
  generateLocator(base, kind, body, options = {}) {
    return JSON.stringify({
      kind,
      body,
      options
    });
  }
  chainLocators(locators) {
    const objects = locators.map((l2) => JSON.parse(l2));
    for (let i = 0; i < objects.length - 1; ++i)
      objects[i].next = objects[i + 1];
    return JSON.stringify(objects[0]);
  }
}
const generators = {
  javascript: new JavaScriptLocatorFactory(),
  python: new PythonLocatorFactory(),
  java: new JavaLocatorFactory(),
  csharp: new CSharpLocatorFactory(),
  jsonl: new JsonlLocatorFactory()
};
function isRegExp(obj) {
  return obj instanceof RegExp;
}
const listView = "";
function ListView({
  items = [],
  id: id2,
  render,
  icon,
  isError,
  indent,
  selectedItem,
  onAccepted,
  onSelected,
  onLeftArrow,
  onRightArrow,
  onHighlighted,
  onIconClicked,
  noItemsMessage,
  dataTestId
}) {
  const itemListRef = reactExports.useRef(null);
  const [highlightedItem, setHighlightedItem] = reactExports.useState();
  reactExports.useEffect(() => {
    onHighlighted == null ? void 0 : onHighlighted(highlightedItem);
  }, [onHighlighted, highlightedItem]);
  return /* @__PURE__ */ jsx("div", { className: "list-view vbox", role: "list", "data-testid": dataTestId, children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: "list-view-content",
      tabIndex: 0,
      onDoubleClick: () => selectedItem && (onAccepted == null ? void 0 : onAccepted(selectedItem)),
      onKeyDown: (event) => {
        var _a;
        if (selectedItem && event.key === "Enter") {
          onAccepted == null ? void 0 : onAccepted(selectedItem);
          return;
        }
        if (event.key !== "ArrowDown" && event.key !== "ArrowUp" && event.key !== "ArrowLeft" && event.key !== "ArrowRight")
          return;
        event.stopPropagation();
        event.preventDefault();
        if (selectedItem && event.key === "ArrowLeft") {
          onLeftArrow == null ? void 0 : onLeftArrow(selectedItem);
          return;
        }
        if (selectedItem && event.key === "ArrowRight") {
          onRightArrow == null ? void 0 : onRightArrow(selectedItem);
          return;
        }
        const index = selectedItem ? items.indexOf(selectedItem) : -1;
        let newIndex = index;
        if (event.key === "ArrowDown") {
          if (index === -1)
            newIndex = 0;
          else
            newIndex = Math.min(index + 1, items.length - 1);
        }
        if (event.key === "ArrowUp") {
          if (index === -1)
            newIndex = items.length - 1;
          else
            newIndex = Math.max(index - 1, 0);
        }
        const element = (_a = itemListRef.current) == null ? void 0 : _a.children.item(newIndex);
        scrollIntoViewIfNeeded(element || void 0);
        onHighlighted == null ? void 0 : onHighlighted(void 0);
        onSelected == null ? void 0 : onSelected(items[newIndex]);
      },
      ref: itemListRef,
      children: [
        noItemsMessage && items.length === 0 && /* @__PURE__ */ jsx("div", { className: "list-view-empty", children: noItemsMessage }),
        items.map((item, index) => {
          const selectedSuffix = selectedItem === item ? " selected" : "";
          const highlightedSuffix = highlightedItem === item ? " highlighted" : "";
          const errorSuffix = (isError == null ? void 0 : isError(item)) ? " error" : "";
          const indentation = (indent == null ? void 0 : indent(item)) || 0;
          const rendered = render(item);
          return /* @__PURE__ */ jsxs(
            "div",
            {
              role: "listitem",
              className: "list-view-entry" + selectedSuffix + highlightedSuffix + errorSuffix,
              onClick: () => onSelected == null ? void 0 : onSelected(item),
              onMouseEnter: () => setHighlightedItem(item),
              onMouseLeave: () => setHighlightedItem(void 0),
              children: [
                indentation ? new Array(indentation).fill(0).map(() => /* @__PURE__ */ jsx("div", { className: "list-view-indent" })) : void 0,
                icon && /* @__PURE__ */ jsx(
                  "div",
                  {
                    className: "codicon " + (icon(item) || "codicon-blank"),
                    style: { minWidth: 16, marginRight: 4 },
                    onDoubleClick: (e) => {
                      e.preventDefault();
                      e.stopPropagation();
                    },
                    onClick: (e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      onIconClicked == null ? void 0 : onIconClicked(item);
                    }
                  }
                ),
                typeof rendered === "string" ? /* @__PURE__ */ jsx("div", { style: { textOverflow: "ellipsis", overflow: "hidden" }, children: rendered }) : rendered
              ]
            },
            (id2 == null ? void 0 : id2(item)) || index
          );
        })
      ]
    }
  ) });
}
function scrollIntoViewIfNeeded(element) {
  if (!element)
    return;
  if (element == null ? void 0 : element.scrollIntoViewIfNeeded)
    element.scrollIntoViewIfNeeded(false);
  else
    element == null ? void 0 : element.scrollIntoView();
}
const TreeListView = ListView;
function TreeView({
  rootItem,
  render,
  icon,
  isError,
  selectedItem,
  onAccepted,
  onSelected,
  onHighlighted,
  treeState,
  setTreeState,
  noItemsMessage,
  dataTestId,
  autoExpandDepth
}) {
  const treeItems = reactExports.useMemo(() => {
    for (let item = selectedItem == null ? void 0 : selectedItem.parent; item; item = item.parent)
      treeState.expandedItems.set(item.id, true);
    return flattenTree(rootItem, treeState.expandedItems, autoExpandDepth || 0);
  }, [rootItem, selectedItem, treeState, autoExpandDepth]);
  return /* @__PURE__ */ jsx(
    TreeListView,
    {
      items: [...treeItems.keys()],
      id: (item) => item.id,
      dataTestId,
      render: (item) => {
        const rendered = render(item);
        return /* @__PURE__ */ jsxs(Fragment, { children: [
          icon && /* @__PURE__ */ jsx("div", { className: "codicon " + (icon(item) || "blank"), style: { minWidth: 16, marginRight: 4 } }),
          typeof rendered === "string" ? /* @__PURE__ */ jsx("div", { style: { textOverflow: "ellipsis", overflow: "hidden" }, children: rendered }) : rendered
        ] });
      },
      icon: (item) => {
        const expanded = treeItems.get(item).expanded;
        if (typeof expanded === "boolean")
          return expanded ? "codicon-chevron-down" : "codicon-chevron-right";
      },
      isError: (item) => (isError == null ? void 0 : isError(item)) || false,
      indent: (item) => treeItems.get(item).depth,
      selectedItem,
      onAccepted: (item) => onAccepted == null ? void 0 : onAccepted(item),
      onSelected: (item) => onSelected == null ? void 0 : onSelected(item),
      onHighlighted: (item) => onHighlighted == null ? void 0 : onHighlighted(item),
      onLeftArrow: (item) => {
        const { expanded, parent } = treeItems.get(item);
        if (expanded) {
          treeState.expandedItems.set(item.id, false);
          setTreeState({ ...treeState });
        } else if (parent) {
          onSelected == null ? void 0 : onSelected(parent);
        }
      },
      onRightArrow: (item) => {
        if (item.children.length) {
          treeState.expandedItems.set(item.id, true);
          setTreeState({ ...treeState });
        }
      },
      onIconClicked: (item) => {
        const { expanded } = treeItems.get(item);
        if (expanded) {
          for (let i = selectedItem; i; i = i.parent) {
            if (i === item) {
              onSelected == null ? void 0 : onSelected(item);
              break;
            }
          }
          treeState.expandedItems.set(item.id, false);
        } else {
          treeState.expandedItems.set(item.id, true);
        }
        setTreeState({ ...treeState });
      },
      noItemsMessage
    }
  );
}
function flattenTree(rootItem, expandedItems, autoExpandDepth) {
  const result = /* @__PURE__ */ new Map();
  const appendChildren = (parent, depth) => {
    for (const item of parent.children) {
      const expandState = expandedItems.get(item.id);
      const autoExpandMatches = autoExpandDepth > depth && result.size < 25 && expandState !== false;
      const expanded = item.children.length ? expandState || autoExpandMatches : void 0;
      result.set(item, { depth, expanded, parent: rootItem === parent ? null : parent });
      if (expanded)
        appendChildren(item, depth + 1);
    }
  };
  appendChildren(rootItem, 0);
  return result;
}
const ActionTreeView = TreeView;
const ActionList = ({
  actions,
  selectedAction,
  sdkLanguage,
  onSelected,
  onHighlighted,
  revealConsole,
  isLive
}) => {
  const [treeState, setTreeState] = reactExports.useState({ expandedItems: /* @__PURE__ */ new Map() });
  const { rootItem, itemMap } = reactExports.useMemo(() => buildActionTree(actions), [actions]);
  const { selectedItem } = reactExports.useMemo(() => {
    const selectedItem2 = selectedAction ? itemMap.get(selectedAction.callId) : void 0;
    return { selectedItem: selectedItem2 };
  }, [itemMap, selectedAction]);
  return /* @__PURE__ */ jsx(
    ActionTreeView,
    {
      dataTestId: "action-list",
      rootItem,
      treeState,
      setTreeState,
      selectedItem,
      onSelected: (item) => onSelected(item.action),
      onHighlighted: (item) => onHighlighted(item == null ? void 0 : item.action),
      isError: (item) => {
        var _a, _b;
        return !!((_b = (_a = item.action) == null ? void 0 : _a.error) == null ? void 0 : _b.message);
      },
      render: (item) => renderAction(item.action, sdkLanguage, revealConsole, isLive || false)
    }
  );
};
const renderAction = (action, sdkLanguage, revealConsole, isLive) => {
  const { errors, warnings } = stats(action);
  const locator = action.params.selector ? asLocator(
    sdkLanguage || "javascript",
    action.params.selector,
    false,
    true
    /* playSafe */
  ) : void 0;
  let time = "";
  if (action.endTime)
    time = msToString(action.endTime - action.startTime);
  else if (action.error)
    time = "Timed out";
  else if (!isLive)
    time = "-";
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "action-title", children: [
      /* @__PURE__ */ jsx("span", { children: action.apiName }),
      locator && /* @__PURE__ */ jsx("div", { className: "action-selector", title: locator, children: locator }),
      action.method === "goto" && action.params.url && /* @__PURE__ */ jsx("div", { className: "action-url", title: action.params.url, children: action.params.url })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "action-duration", style: { flex: "none" }, children: time || /* @__PURE__ */ jsx("span", { className: "codicon codicon-loading" }) }),
    /* @__PURE__ */ jsxs("div", { className: "action-icons", onClick: () => revealConsole(), children: [
      !!errors && /* @__PURE__ */ jsxs("div", { className: "action-icon", children: [
        /* @__PURE__ */ jsx("span", { className: "codicon codicon-error" }),
        /* @__PURE__ */ jsx("span", { className: "action-icon-value", children: errors })
      ] }),
      !!warnings && /* @__PURE__ */ jsxs("div", { className: "action-icon", children: [
        /* @__PURE__ */ jsx("span", { className: "codicon codicon-warning" }),
        /* @__PURE__ */ jsx("span", { className: "action-icon-value", children: warnings })
      ] })
    ] })
  ] });
};
const callTab = "";
const CopyToClipboard = ({ value }) => {
  const [iconClassName, setIconClassName] = reactExports.useState("codicon-clippy");
  const handleCopy = reactExports.useCallback(() => {
    navigator.clipboard.writeText(value).then(() => {
      setIconClassName("codicon-check");
      setTimeout(() => {
        setIconClassName("codicon-clippy");
      }, 3e3);
    }, () => {
      setIconClassName("codicon-close");
    });
  }, [value]);
  return /* @__PURE__ */ jsx("span", { className: `copy-icon codicon ${iconClassName}`, onClick: handleCopy });
};
var lib = {};
var decode = {};
const Aacute$1 = "Á";
const aacute$1 = "á";
const Abreve = "Ă";
const abreve = "ă";
const ac = "∾";
const acd = "∿";
const acE = "∾̳";
const Acirc$1 = "Â";
const acirc$1 = "â";
const acute$1 = "´";
const Acy = "А";
const acy = "а";
const AElig$1 = "Æ";
const aelig$1 = "æ";
const af = "⁡";
const Afr = "𝔄";
const afr = "𝔞";
const Agrave$1 = "À";
const agrave$1 = "à";
const alefsym = "ℵ";
const aleph = "ℵ";
const Alpha = "Α";
const alpha = "α";
const Amacr = "Ā";
const amacr = "ā";
const amalg = "⨿";
const amp$2 = "&";
const AMP$1 = "&";
const andand = "⩕";
const And = "⩓";
const and = "∧";
const andd = "⩜";
const andslope = "⩘";
const andv = "⩚";
const ang = "∠";
const ange = "⦤";
const angle = "∠";
const angmsdaa = "⦨";
const angmsdab = "⦩";
const angmsdac = "⦪";
const angmsdad = "⦫";
const angmsdae = "⦬";
const angmsdaf = "⦭";
const angmsdag = "⦮";
const angmsdah = "⦯";
const angmsd = "∡";
const angrt = "∟";
const angrtvb = "⊾";
const angrtvbd = "⦝";
const angsph = "∢";
const angst = "Å";
const angzarr = "⍼";
const Aogon = "Ą";
const aogon = "ą";
const Aopf = "𝔸";
const aopf = "𝕒";
const apacir = "⩯";
const ap = "≈";
const apE = "⩰";
const ape = "≊";
const apid = "≋";
const apos$1 = "'";
const ApplyFunction = "⁡";
const approx = "≈";
const approxeq = "≊";
const Aring$1 = "Å";
const aring$1 = "å";
const Ascr = "𝒜";
const ascr = "𝒶";
const Assign = "≔";
const ast = "*";
const asymp = "≈";
const asympeq = "≍";
const Atilde$1 = "Ã";
const atilde$1 = "ã";
const Auml$1 = "Ä";
const auml$1 = "ä";
const awconint = "∳";
const awint = "⨑";
const backcong = "≌";
const backepsilon = "϶";
const backprime = "‵";
const backsim = "∽";
const backsimeq = "⋍";
const Backslash = "∖";
const Barv = "⫧";
const barvee = "⊽";
const barwed = "⌅";
const Barwed = "⌆";
const barwedge = "⌅";
const bbrk = "⎵";
const bbrktbrk = "⎶";
const bcong = "≌";
const Bcy = "Б";
const bcy = "б";
const bdquo = "„";
const becaus = "∵";
const because = "∵";
const Because = "∵";
const bemptyv = "⦰";
const bepsi = "϶";
const bernou = "ℬ";
const Bernoullis = "ℬ";
const Beta = "Β";
const beta = "β";
const beth = "ℶ";
const between = "≬";
const Bfr = "𝔅";
const bfr = "𝔟";
const bigcap = "⋂";
const bigcirc = "◯";
const bigcup = "⋃";
const bigodot = "⨀";
const bigoplus = "⨁";
const bigotimes = "⨂";
const bigsqcup = "⨆";
const bigstar = "★";
const bigtriangledown = "▽";
const bigtriangleup = "△";
const biguplus = "⨄";
const bigvee = "⋁";
const bigwedge = "⋀";
const bkarow = "⤍";
const blacklozenge = "⧫";
const blacksquare = "▪";
const blacktriangle = "▴";
const blacktriangledown = "▾";
const blacktriangleleft = "◂";
const blacktriangleright = "▸";
const blank = "␣";
const blk12 = "▒";
const blk14 = "░";
const blk34 = "▓";
const block = "█";
const bne = "=⃥";
const bnequiv = "≡⃥";
const bNot = "⫭";
const bnot = "⌐";
const Bopf = "𝔹";
const bopf = "𝕓";
const bot = "⊥";
const bottom = "⊥";
const bowtie = "⋈";
const boxbox = "⧉";
const boxdl = "┐";
const boxdL = "╕";
const boxDl = "╖";
const boxDL = "╗";
const boxdr = "┌";
const boxdR = "╒";
const boxDr = "╓";
const boxDR = "╔";
const boxh = "─";
const boxH = "═";
const boxhd = "┬";
const boxHd = "╤";
const boxhD = "╥";
const boxHD = "╦";
const boxhu = "┴";
const boxHu = "╧";
const boxhU = "╨";
const boxHU = "╩";
const boxminus = "⊟";
const boxplus = "⊞";
const boxtimes = "⊠";
const boxul = "┘";
const boxuL = "╛";
const boxUl = "╜";
const boxUL = "╝";
const boxur = "└";
const boxuR = "╘";
const boxUr = "╙";
const boxUR = "╚";
const boxv = "│";
const boxV = "║";
const boxvh = "┼";
const boxvH = "╪";
const boxVh = "╫";
const boxVH = "╬";
const boxvl = "┤";
const boxvL = "╡";
const boxVl = "╢";
const boxVL = "╣";
const boxvr = "├";
const boxvR = "╞";
const boxVr = "╟";
const boxVR = "╠";
const bprime = "‵";
const breve = "˘";
const Breve = "˘";
const brvbar$1 = "¦";
const bscr = "𝒷";
const Bscr = "ℬ";
const bsemi = "⁏";
const bsim = "∽";
const bsime = "⋍";
const bsolb = "⧅";
const bsol = "\\";
const bsolhsub = "⟈";
const bull = "•";
const bullet = "•";
const bump = "≎";
const bumpE = "⪮";
const bumpe = "≏";
const Bumpeq = "≎";
const bumpeq = "≏";
const Cacute = "Ć";
const cacute = "ć";
const capand = "⩄";
const capbrcup = "⩉";
const capcap = "⩋";
const cap = "∩";
const Cap = "⋒";
const capcup = "⩇";
const capdot = "⩀";
const CapitalDifferentialD = "ⅅ";
const caps = "∩︀";
const caret = "⁁";
const caron = "ˇ";
const Cayleys = "ℭ";
const ccaps = "⩍";
const Ccaron = "Č";
const ccaron = "č";
const Ccedil$1 = "Ç";
const ccedil$1 = "ç";
const Ccirc = "Ĉ";
const ccirc = "ĉ";
const Cconint = "∰";
const ccups = "⩌";
const ccupssm = "⩐";
const Cdot = "Ċ";
const cdot = "ċ";
const cedil$1 = "¸";
const Cedilla = "¸";
const cemptyv = "⦲";
const cent$1 = "¢";
const centerdot = "·";
const CenterDot = "·";
const cfr = "𝔠";
const Cfr = "ℭ";
const CHcy = "Ч";
const chcy = "ч";
const check = "✓";
const checkmark = "✓";
const Chi = "Χ";
const chi = "χ";
const circ = "ˆ";
const circeq = "≗";
const circlearrowleft = "↺";
const circlearrowright = "↻";
const circledast = "⊛";
const circledcirc = "⊚";
const circleddash = "⊝";
const CircleDot = "⊙";
const circledR = "®";
const circledS = "Ⓢ";
const CircleMinus = "⊖";
const CirclePlus = "⊕";
const CircleTimes = "⊗";
const cir = "○";
const cirE = "⧃";
const cire = "≗";
const cirfnint = "⨐";
const cirmid = "⫯";
const cirscir = "⧂";
const ClockwiseContourIntegral = "∲";
const CloseCurlyDoubleQuote = "”";
const CloseCurlyQuote = "’";
const clubs = "♣";
const clubsuit = "♣";
const colon = ":";
const Colon = "∷";
const Colone = "⩴";
const colone = "≔";
const coloneq = "≔";
const comma = ",";
const commat = "@";
const comp = "∁";
const compfn = "∘";
const complement = "∁";
const complexes = "ℂ";
const cong = "≅";
const congdot = "⩭";
const Congruent = "≡";
const conint = "∮";
const Conint = "∯";
const ContourIntegral = "∮";
const copf = "𝕔";
const Copf = "ℂ";
const coprod = "∐";
const Coproduct = "∐";
const copy$1 = "©";
const COPY$1 = "©";
const copysr = "℗";
const CounterClockwiseContourIntegral = "∳";
const crarr = "↵";
const cross = "✗";
const Cross = "⨯";
const Cscr = "𝒞";
const cscr = "𝒸";
const csub = "⫏";
const csube = "⫑";
const csup = "⫐";
const csupe = "⫒";
const ctdot = "⋯";
const cudarrl = "⤸";
const cudarrr = "⤵";
const cuepr = "⋞";
const cuesc = "⋟";
const cularr = "↶";
const cularrp = "⤽";
const cupbrcap = "⩈";
const cupcap = "⩆";
const CupCap = "≍";
const cup = "∪";
const Cup = "⋓";
const cupcup = "⩊";
const cupdot = "⊍";
const cupor = "⩅";
const cups = "∪︀";
const curarr = "↷";
const curarrm = "⤼";
const curlyeqprec = "⋞";
const curlyeqsucc = "⋟";
const curlyvee = "⋎";
const curlywedge = "⋏";
const curren$1 = "¤";
const curvearrowleft = "↶";
const curvearrowright = "↷";
const cuvee = "⋎";
const cuwed = "⋏";
const cwconint = "∲";
const cwint = "∱";
const cylcty = "⌭";
const dagger = "†";
const Dagger = "‡";
const daleth = "ℸ";
const darr = "↓";
const Darr = "↡";
const dArr = "⇓";
const dash = "‐";
const Dashv = "⫤";
const dashv = "⊣";
const dbkarow = "⤏";
const dblac = "˝";
const Dcaron = "Ď";
const dcaron = "ď";
const Dcy = "Д";
const dcy = "д";
const ddagger = "‡";
const ddarr = "⇊";
const DD = "ⅅ";
const dd = "ⅆ";
const DDotrahd = "⤑";
const ddotseq = "⩷";
const deg$1 = "°";
const Del = "∇";
const Delta = "Δ";
const delta = "δ";
const demptyv = "⦱";
const dfisht = "⥿";
const Dfr = "𝔇";
const dfr = "𝔡";
const dHar = "⥥";
const dharl = "⇃";
const dharr = "⇂";
const DiacriticalAcute = "´";
const DiacriticalDot = "˙";
const DiacriticalDoubleAcute = "˝";
const DiacriticalGrave = "`";
const DiacriticalTilde = "˜";
const diam = "⋄";
const diamond = "⋄";
const Diamond = "⋄";
const diamondsuit = "♦";
const diams = "♦";
const die = "¨";
const DifferentialD = "ⅆ";
const digamma = "ϝ";
const disin = "⋲";
const div = "÷";
const divide$1 = "÷";
const divideontimes = "⋇";
const divonx = "⋇";
const DJcy = "Ђ";
const djcy = "ђ";
const dlcorn = "⌞";
const dlcrop = "⌍";
const dollar = "$";
const Dopf = "𝔻";
const dopf = "𝕕";
const Dot = "¨";
const dot = "˙";
const DotDot = "⃜";
const doteq = "≐";
const doteqdot = "≑";
const DotEqual = "≐";
const dotminus = "∸";
const dotplus = "∔";
const dotsquare = "⊡";
const doublebarwedge = "⌆";
const DoubleContourIntegral = "∯";
const DoubleDot = "¨";
const DoubleDownArrow = "⇓";
const DoubleLeftArrow = "⇐";
const DoubleLeftRightArrow = "⇔";
const DoubleLeftTee = "⫤";
const DoubleLongLeftArrow = "⟸";
const DoubleLongLeftRightArrow = "⟺";
const DoubleLongRightArrow = "⟹";
const DoubleRightArrow = "⇒";
const DoubleRightTee = "⊨";
const DoubleUpArrow = "⇑";
const DoubleUpDownArrow = "⇕";
const DoubleVerticalBar = "∥";
const DownArrowBar = "⤓";
const downarrow = "↓";
const DownArrow = "↓";
const Downarrow = "⇓";
const DownArrowUpArrow = "⇵";
const DownBreve = "̑";
const downdownarrows = "⇊";
const downharpoonleft = "⇃";
const downharpoonright = "⇂";
const DownLeftRightVector = "⥐";
const DownLeftTeeVector = "⥞";
const DownLeftVectorBar = "⥖";
const DownLeftVector = "↽";
const DownRightTeeVector = "⥟";
const DownRightVectorBar = "⥗";
const DownRightVector = "⇁";
const DownTeeArrow = "↧";
const DownTee = "⊤";
const drbkarow = "⤐";
const drcorn = "⌟";
const drcrop = "⌌";
const Dscr = "𝒟";
const dscr = "𝒹";
const DScy = "Ѕ";
const dscy = "ѕ";
const dsol = "⧶";
const Dstrok = "Đ";
const dstrok = "đ";
const dtdot = "⋱";
const dtri = "▿";
const dtrif = "▾";
const duarr = "⇵";
const duhar = "⥯";
const dwangle = "⦦";
const DZcy = "Џ";
const dzcy = "џ";
const dzigrarr = "⟿";
const Eacute$1 = "É";
const eacute$1 = "é";
const easter = "⩮";
const Ecaron = "Ě";
const ecaron = "ě";
const Ecirc$1 = "Ê";
const ecirc$1 = "ê";
const ecir = "≖";
const ecolon = "≕";
const Ecy = "Э";
const ecy = "э";
const eDDot = "⩷";
const Edot = "Ė";
const edot = "ė";
const eDot = "≑";
const ee = "ⅇ";
const efDot = "≒";
const Efr = "𝔈";
const efr = "𝔢";
const eg = "⪚";
const Egrave$1 = "È";
const egrave$1 = "è";
const egs = "⪖";
const egsdot = "⪘";
const el = "⪙";
const Element$1 = "∈";
const elinters = "⏧";
const ell = "ℓ";
const els = "⪕";
const elsdot = "⪗";
const Emacr = "Ē";
const emacr = "ē";
const empty = "∅";
const emptyset = "∅";
const EmptySmallSquare = "◻";
const emptyv = "∅";
const EmptyVerySmallSquare = "▫";
const emsp13 = " ";
const emsp14 = " ";
const emsp = " ";
const ENG = "Ŋ";
const eng = "ŋ";
const ensp = " ";
const Eogon = "Ę";
const eogon = "ę";
const Eopf = "𝔼";
const eopf = "𝕖";
const epar = "⋕";
const eparsl = "⧣";
const eplus = "⩱";
const epsi = "ε";
const Epsilon = "Ε";
const epsilon = "ε";
const epsiv = "ϵ";
const eqcirc = "≖";
const eqcolon = "≕";
const eqsim = "≂";
const eqslantgtr = "⪖";
const eqslantless = "⪕";
const Equal = "⩵";
const equals = "=";
const EqualTilde = "≂";
const equest = "≟";
const Equilibrium = "⇌";
const equiv = "≡";
const equivDD = "⩸";
const eqvparsl = "⧥";
const erarr = "⥱";
const erDot = "≓";
const escr = "ℯ";
const Escr = "ℰ";
const esdot = "≐";
const Esim = "⩳";
const esim = "≂";
const Eta = "Η";
const eta = "η";
const ETH$1 = "Ð";
const eth$1 = "ð";
const Euml$1 = "Ë";
const euml$1 = "ë";
const euro = "€";
const excl = "!";
const exist = "∃";
const Exists = "∃";
const expectation = "ℰ";
const exponentiale = "ⅇ";
const ExponentialE = "ⅇ";
const fallingdotseq = "≒";
const Fcy = "Ф";
const fcy = "ф";
const female = "♀";
const ffilig = "ﬃ";
const fflig = "ﬀ";
const ffllig = "ﬄ";
const Ffr = "𝔉";
const ffr = "𝔣";
const filig = "ﬁ";
const FilledSmallSquare = "◼";
const FilledVerySmallSquare = "▪";
const fjlig = "fj";
const flat = "♭";
const fllig = "ﬂ";
const fltns = "▱";
const fnof = "ƒ";
const Fopf = "𝔽";
const fopf = "𝕗";
const forall = "∀";
const ForAll = "∀";
const fork = "⋔";
const forkv = "⫙";
const Fouriertrf = "ℱ";
const fpartint = "⨍";
const frac12$1 = "½";
const frac13 = "⅓";
const frac14$1 = "¼";
const frac15 = "⅕";
const frac16 = "⅙";
const frac18 = "⅛";
const frac23 = "⅔";
const frac25 = "⅖";
const frac34$1 = "¾";
const frac35 = "⅗";
const frac38 = "⅜";
const frac45 = "⅘";
const frac56 = "⅚";
const frac58 = "⅝";
const frac78 = "⅞";
const frasl = "⁄";
const frown = "⌢";
const fscr = "𝒻";
const Fscr = "ℱ";
const gacute = "ǵ";
const Gamma = "Γ";
const gamma = "γ";
const Gammad = "Ϝ";
const gammad = "ϝ";
const gap = "⪆";
const Gbreve = "Ğ";
const gbreve = "ğ";
const Gcedil = "Ģ";
const Gcirc = "Ĝ";
const gcirc = "ĝ";
const Gcy = "Г";
const gcy = "г";
const Gdot = "Ġ";
const gdot = "ġ";
const ge = "≥";
const gE = "≧";
const gEl = "⪌";
const gel = "⋛";
const geq = "≥";
const geqq = "≧";
const geqslant = "⩾";
const gescc = "⪩";
const ges = "⩾";
const gesdot = "⪀";
const gesdoto = "⪂";
const gesdotol = "⪄";
const gesl = "⋛︀";
const gesles = "⪔";
const Gfr = "𝔊";
const gfr = "𝔤";
const gg = "≫";
const Gg = "⋙";
const ggg = "⋙";
const gimel = "ℷ";
const GJcy = "Ѓ";
const gjcy = "ѓ";
const gla = "⪥";
const gl = "≷";
const glE = "⪒";
const glj = "⪤";
const gnap = "⪊";
const gnapprox = "⪊";
const gne = "⪈";
const gnE = "≩";
const gneq = "⪈";
const gneqq = "≩";
const gnsim = "⋧";
const Gopf = "𝔾";
const gopf = "𝕘";
const grave = "`";
const GreaterEqual = "≥";
const GreaterEqualLess = "⋛";
const GreaterFullEqual = "≧";
const GreaterGreater = "⪢";
const GreaterLess = "≷";
const GreaterSlantEqual = "⩾";
const GreaterTilde = "≳";
const Gscr = "𝒢";
const gscr = "ℊ";
const gsim = "≳";
const gsime = "⪎";
const gsiml = "⪐";
const gtcc = "⪧";
const gtcir = "⩺";
const gt$2 = ">";
const GT$1 = ">";
const Gt = "≫";
const gtdot = "⋗";
const gtlPar = "⦕";
const gtquest = "⩼";
const gtrapprox = "⪆";
const gtrarr = "⥸";
const gtrdot = "⋗";
const gtreqless = "⋛";
const gtreqqless = "⪌";
const gtrless = "≷";
const gtrsim = "≳";
const gvertneqq = "≩︀";
const gvnE = "≩︀";
const Hacek = "ˇ";
const hairsp = " ";
const half = "½";
const hamilt = "ℋ";
const HARDcy = "Ъ";
const hardcy = "ъ";
const harrcir = "⥈";
const harr = "↔";
const hArr = "⇔";
const harrw = "↭";
const Hat = "^";
const hbar = "ℏ";
const Hcirc = "Ĥ";
const hcirc = "ĥ";
const hearts = "♥";
const heartsuit = "♥";
const hellip = "…";
const hercon = "⊹";
const hfr = "𝔥";
const Hfr = "ℌ";
const HilbertSpace = "ℋ";
const hksearow = "⤥";
const hkswarow = "⤦";
const hoarr = "⇿";
const homtht = "∻";
const hookleftarrow = "↩";
const hookrightarrow = "↪";
const hopf = "𝕙";
const Hopf = "ℍ";
const horbar = "―";
const HorizontalLine = "─";
const hscr = "𝒽";
const Hscr = "ℋ";
const hslash = "ℏ";
const Hstrok = "Ħ";
const hstrok = "ħ";
const HumpDownHump = "≎";
const HumpEqual = "≏";
const hybull = "⁃";
const hyphen = "‐";
const Iacute$1 = "Í";
const iacute$1 = "í";
const ic = "⁣";
const Icirc$1 = "Î";
const icirc$1 = "î";
const Icy = "И";
const icy = "и";
const Idot = "İ";
const IEcy = "Е";
const iecy = "е";
const iexcl$1 = "¡";
const iff = "⇔";
const ifr = "𝔦";
const Ifr = "ℑ";
const Igrave$1 = "Ì";
const igrave$1 = "ì";
const ii = "ⅈ";
const iiiint = "⨌";
const iiint = "∭";
const iinfin = "⧜";
const iiota = "℩";
const IJlig = "Ĳ";
const ijlig = "ĳ";
const Imacr = "Ī";
const imacr = "ī";
const image = "ℑ";
const ImaginaryI = "ⅈ";
const imagline = "ℐ";
const imagpart = "ℑ";
const imath = "ı";
const Im = "ℑ";
const imof = "⊷";
const imped = "Ƶ";
const Implies = "⇒";
const incare = "℅";
const infin = "∞";
const infintie = "⧝";
const inodot = "ı";
const intcal = "⊺";
const int = "∫";
const Int = "∬";
const integers = "ℤ";
const Integral = "∫";
const intercal = "⊺";
const Intersection = "⋂";
const intlarhk = "⨗";
const intprod = "⨼";
const InvisibleComma = "⁣";
const InvisibleTimes = "⁢";
const IOcy = "Ё";
const iocy = "ё";
const Iogon = "Į";
const iogon = "į";
const Iopf = "𝕀";
const iopf = "𝕚";
const Iota = "Ι";
const iota = "ι";
const iprod = "⨼";
const iquest$1 = "¿";
const iscr = "𝒾";
const Iscr = "ℐ";
const isin = "∈";
const isindot = "⋵";
const isinE = "⋹";
const isins = "⋴";
const isinsv = "⋳";
const isinv = "∈";
const it = "⁢";
const Itilde = "Ĩ";
const itilde = "ĩ";
const Iukcy = "І";
const iukcy = "і";
const Iuml$1 = "Ï";
const iuml$1 = "ï";
const Jcirc = "Ĵ";
const jcirc = "ĵ";
const Jcy = "Й";
const jcy = "й";
const Jfr = "𝔍";
const jfr = "𝔧";
const jmath = "ȷ";
const Jopf = "𝕁";
const jopf = "𝕛";
const Jscr = "𝒥";
const jscr = "𝒿";
const Jsercy = "Ј";
const jsercy = "ј";
const Jukcy = "Є";
const jukcy = "є";
const Kappa = "Κ";
const kappa = "κ";
const kappav = "ϰ";
const Kcedil = "Ķ";
const kcedil = "ķ";
const Kcy = "К";
const kcy = "к";
const Kfr = "𝔎";
const kfr = "𝔨";
const kgreen = "ĸ";
const KHcy = "Х";
const khcy = "х";
const KJcy = "Ќ";
const kjcy = "ќ";
const Kopf = "𝕂";
const kopf = "𝕜";
const Kscr = "𝒦";
const kscr = "𝓀";
const lAarr = "⇚";
const Lacute = "Ĺ";
const lacute = "ĺ";
const laemptyv = "⦴";
const lagran = "ℒ";
const Lambda = "Λ";
const lambda = "λ";
const lang = "⟨";
const Lang = "⟪";
const langd = "⦑";
const langle = "⟨";
const lap = "⪅";
const Laplacetrf = "ℒ";
const laquo$1 = "«";
const larrb = "⇤";
const larrbfs = "⤟";
const larr = "←";
const Larr = "↞";
const lArr = "⇐";
const larrfs = "⤝";
const larrhk = "↩";
const larrlp = "↫";
const larrpl = "⤹";
const larrsim = "⥳";
const larrtl = "↢";
const latail = "⤙";
const lAtail = "⤛";
const lat = "⪫";
const late = "⪭";
const lates = "⪭︀";
const lbarr = "⤌";
const lBarr = "⤎";
const lbbrk = "❲";
const lbrace = "{";
const lbrack = "[";
const lbrke = "⦋";
const lbrksld = "⦏";
const lbrkslu = "⦍";
const Lcaron = "Ľ";
const lcaron = "ľ";
const Lcedil = "Ļ";
const lcedil = "ļ";
const lceil = "⌈";
const lcub = "{";
const Lcy = "Л";
const lcy = "л";
const ldca = "⤶";
const ldquo = "“";
const ldquor = "„";
const ldrdhar = "⥧";
const ldrushar = "⥋";
const ldsh = "↲";
const le = "≤";
const lE = "≦";
const LeftAngleBracket = "⟨";
const LeftArrowBar = "⇤";
const leftarrow = "←";
const LeftArrow = "←";
const Leftarrow = "⇐";
const LeftArrowRightArrow = "⇆";
const leftarrowtail = "↢";
const LeftCeiling = "⌈";
const LeftDoubleBracket = "⟦";
const LeftDownTeeVector = "⥡";
const LeftDownVectorBar = "⥙";
const LeftDownVector = "⇃";
const LeftFloor = "⌊";
const leftharpoondown = "↽";
const leftharpoonup = "↼";
const leftleftarrows = "⇇";
const leftrightarrow = "↔";
const LeftRightArrow = "↔";
const Leftrightarrow = "⇔";
const leftrightarrows = "⇆";
const leftrightharpoons = "⇋";
const leftrightsquigarrow = "↭";
const LeftRightVector = "⥎";
const LeftTeeArrow = "↤";
const LeftTee = "⊣";
const LeftTeeVector = "⥚";
const leftthreetimes = "⋋";
const LeftTriangleBar = "⧏";
const LeftTriangle = "⊲";
const LeftTriangleEqual = "⊴";
const LeftUpDownVector = "⥑";
const LeftUpTeeVector = "⥠";
const LeftUpVectorBar = "⥘";
const LeftUpVector = "↿";
const LeftVectorBar = "⥒";
const LeftVector = "↼";
const lEg = "⪋";
const leg = "⋚";
const leq = "≤";
const leqq = "≦";
const leqslant = "⩽";
const lescc = "⪨";
const les = "⩽";
const lesdot = "⩿";
const lesdoto = "⪁";
const lesdotor = "⪃";
const lesg = "⋚︀";
const lesges = "⪓";
const lessapprox = "⪅";
const lessdot = "⋖";
const lesseqgtr = "⋚";
const lesseqqgtr = "⪋";
const LessEqualGreater = "⋚";
const LessFullEqual = "≦";
const LessGreater = "≶";
const lessgtr = "≶";
const LessLess = "⪡";
const lesssim = "≲";
const LessSlantEqual = "⩽";
const LessTilde = "≲";
const lfisht = "⥼";
const lfloor = "⌊";
const Lfr = "𝔏";
const lfr = "𝔩";
const lg = "≶";
const lgE = "⪑";
const lHar = "⥢";
const lhard = "↽";
const lharu = "↼";
const lharul = "⥪";
const lhblk = "▄";
const LJcy = "Љ";
const ljcy = "љ";
const llarr = "⇇";
const ll = "≪";
const Ll = "⋘";
const llcorner = "⌞";
const Lleftarrow = "⇚";
const llhard = "⥫";
const lltri = "◺";
const Lmidot = "Ŀ";
const lmidot = "ŀ";
const lmoustache = "⎰";
const lmoust = "⎰";
const lnap = "⪉";
const lnapprox = "⪉";
const lne = "⪇";
const lnE = "≨";
const lneq = "⪇";
const lneqq = "≨";
const lnsim = "⋦";
const loang = "⟬";
const loarr = "⇽";
const lobrk = "⟦";
const longleftarrow = "⟵";
const LongLeftArrow = "⟵";
const Longleftarrow = "⟸";
const longleftrightarrow = "⟷";
const LongLeftRightArrow = "⟷";
const Longleftrightarrow = "⟺";
const longmapsto = "⟼";
const longrightarrow = "⟶";
const LongRightArrow = "⟶";
const Longrightarrow = "⟹";
const looparrowleft = "↫";
const looparrowright = "↬";
const lopar = "⦅";
const Lopf = "𝕃";
const lopf = "𝕝";
const loplus = "⨭";
const lotimes = "⨴";
const lowast = "∗";
const lowbar = "_";
const LowerLeftArrow = "↙";
const LowerRightArrow = "↘";
const loz = "◊";
const lozenge = "◊";
const lozf = "⧫";
const lpar = "(";
const lparlt = "⦓";
const lrarr = "⇆";
const lrcorner = "⌟";
const lrhar = "⇋";
const lrhard = "⥭";
const lrm = "‎";
const lrtri = "⊿";
const lsaquo = "‹";
const lscr = "𝓁";
const Lscr = "ℒ";
const lsh = "↰";
const Lsh = "↰";
const lsim = "≲";
const lsime = "⪍";
const lsimg = "⪏";
const lsqb = "[";
const lsquo = "‘";
const lsquor = "‚";
const Lstrok = "Ł";
const lstrok = "ł";
const ltcc = "⪦";
const ltcir = "⩹";
const lt$2 = "<";
const LT$1 = "<";
const Lt = "≪";
const ltdot = "⋖";
const lthree = "⋋";
const ltimes = "⋉";
const ltlarr = "⥶";
const ltquest = "⩻";
const ltri = "◃";
const ltrie = "⊴";
const ltrif = "◂";
const ltrPar = "⦖";
const lurdshar = "⥊";
const luruhar = "⥦";
const lvertneqq = "≨︀";
const lvnE = "≨︀";
const macr$1 = "¯";
const male = "♂";
const malt = "✠";
const maltese = "✠";
const map = "↦";
const mapsto = "↦";
const mapstodown = "↧";
const mapstoleft = "↤";
const mapstoup = "↥";
const marker = "▮";
const mcomma = "⨩";
const Mcy = "М";
const mcy = "м";
const mdash = "—";
const mDDot = "∺";
const measuredangle = "∡";
const MediumSpace = " ";
const Mellintrf = "ℳ";
const Mfr = "𝔐";
const mfr = "𝔪";
const mho = "℧";
const micro$1 = "µ";
const midast = "*";
const midcir = "⫰";
const mid = "∣";
const middot$1 = "·";
const minusb = "⊟";
const minus = "−";
const minusd = "∸";
const minusdu = "⨪";
const MinusPlus = "∓";
const mlcp = "⫛";
const mldr = "…";
const mnplus = "∓";
const models = "⊧";
const Mopf = "𝕄";
const mopf = "𝕞";
const mp = "∓";
const mscr = "𝓂";
const Mscr = "ℳ";
const mstpos = "∾";
const Mu = "Μ";
const mu = "μ";
const multimap = "⊸";
const mumap = "⊸";
const nabla = "∇";
const Nacute = "Ń";
const nacute = "ń";
const nang = "∠⃒";
const nap = "≉";
const napE = "⩰̸";
const napid = "≋̸";
const napos = "ŉ";
const napprox = "≉";
const natural = "♮";
const naturals = "ℕ";
const natur = "♮";
const nbsp$1 = " ";
const nbump = "≎̸";
const nbumpe = "≏̸";
const ncap = "⩃";
const Ncaron = "Ň";
const ncaron = "ň";
const Ncedil = "Ņ";
const ncedil = "ņ";
const ncong = "≇";
const ncongdot = "⩭̸";
const ncup = "⩂";
const Ncy = "Н";
const ncy = "н";
const ndash = "–";
const nearhk = "⤤";
const nearr = "↗";
const neArr = "⇗";
const nearrow = "↗";
const ne = "≠";
const nedot = "≐̸";
const NegativeMediumSpace = "​";
const NegativeThickSpace = "​";
const NegativeThinSpace = "​";
const NegativeVeryThinSpace = "​";
const nequiv = "≢";
const nesear = "⤨";
const nesim = "≂̸";
const NestedGreaterGreater = "≫";
const NestedLessLess = "≪";
const NewLine = "\n";
const nexist = "∄";
const nexists = "∄";
const Nfr = "𝔑";
const nfr = "𝔫";
const ngE = "≧̸";
const nge = "≱";
const ngeq = "≱";
const ngeqq = "≧̸";
const ngeqslant = "⩾̸";
const nges = "⩾̸";
const nGg = "⋙̸";
const ngsim = "≵";
const nGt = "≫⃒";
const ngt = "≯";
const ngtr = "≯";
const nGtv = "≫̸";
const nharr = "↮";
const nhArr = "⇎";
const nhpar = "⫲";
const ni = "∋";
const nis = "⋼";
const nisd = "⋺";
const niv = "∋";
const NJcy = "Њ";
const njcy = "њ";
const nlarr = "↚";
const nlArr = "⇍";
const nldr = "‥";
const nlE = "≦̸";
const nle = "≰";
const nleftarrow = "↚";
const nLeftarrow = "⇍";
const nleftrightarrow = "↮";
const nLeftrightarrow = "⇎";
const nleq = "≰";
const nleqq = "≦̸";
const nleqslant = "⩽̸";
const nles = "⩽̸";
const nless = "≮";
const nLl = "⋘̸";
const nlsim = "≴";
const nLt = "≪⃒";
const nlt = "≮";
const nltri = "⋪";
const nltrie = "⋬";
const nLtv = "≪̸";
const nmid = "∤";
const NoBreak = "⁠";
const NonBreakingSpace = " ";
const nopf = "𝕟";
const Nopf = "ℕ";
const Not = "⫬";
const not$1 = "¬";
const NotCongruent = "≢";
const NotCupCap = "≭";
const NotDoubleVerticalBar = "∦";
const NotElement = "∉";
const NotEqual = "≠";
const NotEqualTilde = "≂̸";
const NotExists = "∄";
const NotGreater = "≯";
const NotGreaterEqual = "≱";
const NotGreaterFullEqual = "≧̸";
const NotGreaterGreater = "≫̸";
const NotGreaterLess = "≹";
const NotGreaterSlantEqual = "⩾̸";
const NotGreaterTilde = "≵";
const NotHumpDownHump = "≎̸";
const NotHumpEqual = "≏̸";
const notin = "∉";
const notindot = "⋵̸";
const notinE = "⋹̸";
const notinva = "∉";
const notinvb = "⋷";
const notinvc = "⋶";
const NotLeftTriangleBar = "⧏̸";
const NotLeftTriangle = "⋪";
const NotLeftTriangleEqual = "⋬";
const NotLess = "≮";
const NotLessEqual = "≰";
const NotLessGreater = "≸";
const NotLessLess = "≪̸";
const NotLessSlantEqual = "⩽̸";
const NotLessTilde = "≴";
const NotNestedGreaterGreater = "⪢̸";
const NotNestedLessLess = "⪡̸";
const notni = "∌";
const notniva = "∌";
const notnivb = "⋾";
const notnivc = "⋽";
const NotPrecedes = "⊀";
const NotPrecedesEqual = "⪯̸";
const NotPrecedesSlantEqual = "⋠";
const NotReverseElement = "∌";
const NotRightTriangleBar = "⧐̸";
const NotRightTriangle = "⋫";
const NotRightTriangleEqual = "⋭";
const NotSquareSubset = "⊏̸";
const NotSquareSubsetEqual = "⋢";
const NotSquareSuperset = "⊐̸";
const NotSquareSupersetEqual = "⋣";
const NotSubset = "⊂⃒";
const NotSubsetEqual = "⊈";
const NotSucceeds = "⊁";
const NotSucceedsEqual = "⪰̸";
const NotSucceedsSlantEqual = "⋡";
const NotSucceedsTilde = "≿̸";
const NotSuperset = "⊃⃒";
const NotSupersetEqual = "⊉";
const NotTilde = "≁";
const NotTildeEqual = "≄";
const NotTildeFullEqual = "≇";
const NotTildeTilde = "≉";
const NotVerticalBar = "∤";
const nparallel = "∦";
const npar = "∦";
const nparsl = "⫽⃥";
const npart = "∂̸";
const npolint = "⨔";
const npr = "⊀";
const nprcue = "⋠";
const nprec = "⊀";
const npreceq = "⪯̸";
const npre = "⪯̸";
const nrarrc = "⤳̸";
const nrarr = "↛";
const nrArr = "⇏";
const nrarrw = "↝̸";
const nrightarrow = "↛";
const nRightarrow = "⇏";
const nrtri = "⋫";
const nrtrie = "⋭";
const nsc = "⊁";
const nsccue = "⋡";
const nsce = "⪰̸";
const Nscr = "𝒩";
const nscr = "𝓃";
const nshortmid = "∤";
const nshortparallel = "∦";
const nsim = "≁";
const nsime = "≄";
const nsimeq = "≄";
const nsmid = "∤";
const nspar = "∦";
const nsqsube = "⋢";
const nsqsupe = "⋣";
const nsub = "⊄";
const nsubE = "⫅̸";
const nsube = "⊈";
const nsubset = "⊂⃒";
const nsubseteq = "⊈";
const nsubseteqq = "⫅̸";
const nsucc = "⊁";
const nsucceq = "⪰̸";
const nsup = "⊅";
const nsupE = "⫆̸";
const nsupe = "⊉";
const nsupset = "⊃⃒";
const nsupseteq = "⊉";
const nsupseteqq = "⫆̸";
const ntgl = "≹";
const Ntilde$1 = "Ñ";
const ntilde$1 = "ñ";
const ntlg = "≸";
const ntriangleleft = "⋪";
const ntrianglelefteq = "⋬";
const ntriangleright = "⋫";
const ntrianglerighteq = "⋭";
const Nu = "Ν";
const nu = "ν";
const num = "#";
const numero = "№";
const numsp = " ";
const nvap = "≍⃒";
const nvdash = "⊬";
const nvDash = "⊭";
const nVdash = "⊮";
const nVDash = "⊯";
const nvge = "≥⃒";
const nvgt = ">⃒";
const nvHarr = "⤄";
const nvinfin = "⧞";
const nvlArr = "⤂";
const nvle = "≤⃒";
const nvlt = "<⃒";
const nvltrie = "⊴⃒";
const nvrArr = "⤃";
const nvrtrie = "⊵⃒";
const nvsim = "∼⃒";
const nwarhk = "⤣";
const nwarr = "↖";
const nwArr = "⇖";
const nwarrow = "↖";
const nwnear = "⤧";
const Oacute$1 = "Ó";
const oacute$1 = "ó";
const oast = "⊛";
const Ocirc$1 = "Ô";
const ocirc$1 = "ô";
const ocir = "⊚";
const Ocy = "О";
const ocy = "о";
const odash = "⊝";
const Odblac = "Ő";
const odblac = "ő";
const odiv = "⨸";
const odot = "⊙";
const odsold = "⦼";
const OElig = "Œ";
const oelig = "œ";
const ofcir = "⦿";
const Ofr = "𝔒";
const ofr = "𝔬";
const ogon = "˛";
const Ograve$1 = "Ò";
const ograve$1 = "ò";
const ogt = "⧁";
const ohbar = "⦵";
const ohm = "Ω";
const oint = "∮";
const olarr = "↺";
const olcir = "⦾";
const olcross = "⦻";
const oline = "‾";
const olt = "⧀";
const Omacr = "Ō";
const omacr = "ō";
const Omega = "Ω";
const omega = "ω";
const Omicron = "Ο";
const omicron = "ο";
const omid = "⦶";
const ominus = "⊖";
const Oopf = "𝕆";
const oopf = "𝕠";
const opar = "⦷";
const OpenCurlyDoubleQuote = "“";
const OpenCurlyQuote = "‘";
const operp = "⦹";
const oplus = "⊕";
const orarr = "↻";
const Or = "⩔";
const or = "∨";
const ord = "⩝";
const order = "ℴ";
const orderof = "ℴ";
const ordf$1 = "ª";
const ordm$1 = "º";
const origof = "⊶";
const oror = "⩖";
const orslope = "⩗";
const orv = "⩛";
const oS = "Ⓢ";
const Oscr = "𝒪";
const oscr = "ℴ";
const Oslash$1 = "Ø";
const oslash$1 = "ø";
const osol = "⊘";
const Otilde$1 = "Õ";
const otilde$1 = "õ";
const otimesas = "⨶";
const Otimes = "⨷";
const otimes = "⊗";
const Ouml$1 = "Ö";
const ouml$1 = "ö";
const ovbar = "⌽";
const OverBar = "‾";
const OverBrace = "⏞";
const OverBracket = "⎴";
const OverParenthesis = "⏜";
const para$1 = "¶";
const parallel = "∥";
const par = "∥";
const parsim = "⫳";
const parsl = "⫽";
const part = "∂";
const PartialD = "∂";
const Pcy = "П";
const pcy = "п";
const percnt = "%";
const period = ".";
const permil = "‰";
const perp = "⊥";
const pertenk = "‱";
const Pfr = "𝔓";
const pfr = "𝔭";
const Phi = "Φ";
const phi = "φ";
const phiv = "ϕ";
const phmmat = "ℳ";
const phone = "☎";
const Pi = "Π";
const pi = "π";
const pitchfork = "⋔";
const piv = "ϖ";
const planck = "ℏ";
const planckh = "ℎ";
const plankv = "ℏ";
const plusacir = "⨣";
const plusb = "⊞";
const pluscir = "⨢";
const plus = "+";
const plusdo = "∔";
const plusdu = "⨥";
const pluse = "⩲";
const PlusMinus = "±";
const plusmn$1 = "±";
const plussim = "⨦";
const plustwo = "⨧";
const pm = "±";
const Poincareplane = "ℌ";
const pointint = "⨕";
const popf = "𝕡";
const Popf = "ℙ";
const pound$1 = "£";
const prap = "⪷";
const Pr = "⪻";
const pr = "≺";
const prcue = "≼";
const precapprox = "⪷";
const prec = "≺";
const preccurlyeq = "≼";
const Precedes = "≺";
const PrecedesEqual = "⪯";
const PrecedesSlantEqual = "≼";
const PrecedesTilde = "≾";
const preceq = "⪯";
const precnapprox = "⪹";
const precneqq = "⪵";
const precnsim = "⋨";
const pre = "⪯";
const prE = "⪳";
const precsim = "≾";
const prime = "′";
const Prime = "″";
const primes = "ℙ";
const prnap = "⪹";
const prnE = "⪵";
const prnsim = "⋨";
const prod = "∏";
const Product = "∏";
const profalar = "⌮";
const profline = "⌒";
const profsurf = "⌓";
const prop = "∝";
const Proportional = "∝";
const Proportion = "∷";
const propto = "∝";
const prsim = "≾";
const prurel = "⊰";
const Pscr = "𝒫";
const pscr = "𝓅";
const Psi = "Ψ";
const psi = "ψ";
const puncsp = " ";
const Qfr = "𝔔";
const qfr = "𝔮";
const qint = "⨌";
const qopf = "𝕢";
const Qopf = "ℚ";
const qprime = "⁗";
const Qscr = "𝒬";
const qscr = "𝓆";
const quaternions = "ℍ";
const quatint = "⨖";
const quest = "?";
const questeq = "≟";
const quot$2 = '"';
const QUOT$1 = '"';
const rAarr = "⇛";
const race = "∽̱";
const Racute = "Ŕ";
const racute = "ŕ";
const radic = "√";
const raemptyv = "⦳";
const rang = "⟩";
const Rang = "⟫";
const rangd = "⦒";
const range$1 = "⦥";
const rangle = "⟩";
const raquo$1 = "»";
const rarrap = "⥵";
const rarrb = "⇥";
const rarrbfs = "⤠";
const rarrc = "⤳";
const rarr = "→";
const Rarr = "↠";
const rArr = "⇒";
const rarrfs = "⤞";
const rarrhk = "↪";
const rarrlp = "↬";
const rarrpl = "⥅";
const rarrsim = "⥴";
const Rarrtl = "⤖";
const rarrtl = "↣";
const rarrw = "↝";
const ratail = "⤚";
const rAtail = "⤜";
const ratio = "∶";
const rationals = "ℚ";
const rbarr = "⤍";
const rBarr = "⤏";
const RBarr = "⤐";
const rbbrk = "❳";
const rbrace = "}";
const rbrack = "]";
const rbrke = "⦌";
const rbrksld = "⦎";
const rbrkslu = "⦐";
const Rcaron = "Ř";
const rcaron = "ř";
const Rcedil = "Ŗ";
const rcedil = "ŗ";
const rceil = "⌉";
const rcub = "}";
const Rcy = "Р";
const rcy = "р";
const rdca = "⤷";
const rdldhar = "⥩";
const rdquo = "”";
const rdquor = "”";
const rdsh = "↳";
const real = "ℜ";
const realine = "ℛ";
const realpart = "ℜ";
const reals = "ℝ";
const Re = "ℜ";
const rect = "▭";
const reg$1 = "®";
const REG$1 = "®";
const ReverseElement = "∋";
const ReverseEquilibrium = "⇋";
const ReverseUpEquilibrium = "⥯";
const rfisht = "⥽";
const rfloor = "⌋";
const rfr = "𝔯";
const Rfr = "ℜ";
const rHar = "⥤";
const rhard = "⇁";
const rharu = "⇀";
const rharul = "⥬";
const Rho = "Ρ";
const rho = "ρ";
const rhov = "ϱ";
const RightAngleBracket = "⟩";
const RightArrowBar = "⇥";
const rightarrow = "→";
const RightArrow = "→";
const Rightarrow = "⇒";
const RightArrowLeftArrow = "⇄";
const rightarrowtail = "↣";
const RightCeiling = "⌉";
const RightDoubleBracket = "⟧";
const RightDownTeeVector = "⥝";
const RightDownVectorBar = "⥕";
const RightDownVector = "⇂";
const RightFloor = "⌋";
const rightharpoondown = "⇁";
const rightharpoonup = "⇀";
const rightleftarrows = "⇄";
const rightleftharpoons = "⇌";
const rightrightarrows = "⇉";
const rightsquigarrow = "↝";
const RightTeeArrow = "↦";
const RightTee = "⊢";
const RightTeeVector = "⥛";
const rightthreetimes = "⋌";
const RightTriangleBar = "⧐";
const RightTriangle = "⊳";
const RightTriangleEqual = "⊵";
const RightUpDownVector = "⥏";
const RightUpTeeVector = "⥜";
const RightUpVectorBar = "⥔";
const RightUpVector = "↾";
const RightVectorBar = "⥓";
const RightVector = "⇀";
const ring = "˚";
const risingdotseq = "≓";
const rlarr = "⇄";
const rlhar = "⇌";
const rlm = "‏";
const rmoustache = "⎱";
const rmoust = "⎱";
const rnmid = "⫮";
const roang = "⟭";
const roarr = "⇾";
const robrk = "⟧";
const ropar = "⦆";
const ropf = "𝕣";
const Ropf = "ℝ";
const roplus = "⨮";
const rotimes = "⨵";
const RoundImplies = "⥰";
const rpar = ")";
const rpargt = "⦔";
const rppolint = "⨒";
const rrarr = "⇉";
const Rrightarrow = "⇛";
const rsaquo = "›";
const rscr = "𝓇";
const Rscr = "ℛ";
const rsh = "↱";
const Rsh = "↱";
const rsqb = "]";
const rsquo = "’";
const rsquor = "’";
const rthree = "⋌";
const rtimes = "⋊";
const rtri = "▹";
const rtrie = "⊵";
const rtrif = "▸";
const rtriltri = "⧎";
const RuleDelayed = "⧴";
const ruluhar = "⥨";
const rx = "℞";
const Sacute = "Ś";
const sacute = "ś";
const sbquo = "‚";
const scap = "⪸";
const Scaron = "Š";
const scaron = "š";
const Sc = "⪼";
const sc = "≻";
const sccue = "≽";
const sce = "⪰";
const scE = "⪴";
const Scedil = "Ş";
const scedil = "ş";
const Scirc = "Ŝ";
const scirc = "ŝ";
const scnap = "⪺";
const scnE = "⪶";
const scnsim = "⋩";
const scpolint = "⨓";
const scsim = "≿";
const Scy = "С";
const scy = "с";
const sdotb = "⊡";
const sdot = "⋅";
const sdote = "⩦";
const searhk = "⤥";
const searr = "↘";
const seArr = "⇘";
const searrow = "↘";
const sect$1 = "§";
const semi = ";";
const seswar = "⤩";
const setminus = "∖";
const setmn = "∖";
const sext = "✶";
const Sfr = "𝔖";
const sfr = "𝔰";
const sfrown = "⌢";
const sharp = "♯";
const SHCHcy = "Щ";
const shchcy = "щ";
const SHcy = "Ш";
const shcy = "ш";
const ShortDownArrow = "↓";
const ShortLeftArrow = "←";
const shortmid = "∣";
const shortparallel = "∥";
const ShortRightArrow = "→";
const ShortUpArrow = "↑";
const shy$1 = "­";
const Sigma = "Σ";
const sigma = "σ";
const sigmaf = "ς";
const sigmav = "ς";
const sim = "∼";
const simdot = "⩪";
const sime = "≃";
const simeq = "≃";
const simg = "⪞";
const simgE = "⪠";
const siml = "⪝";
const simlE = "⪟";
const simne = "≆";
const simplus = "⨤";
const simrarr = "⥲";
const slarr = "←";
const SmallCircle = "∘";
const smallsetminus = "∖";
const smashp = "⨳";
const smeparsl = "⧤";
const smid = "∣";
const smile = "⌣";
const smt = "⪪";
const smte = "⪬";
const smtes = "⪬︀";
const SOFTcy = "Ь";
const softcy = "ь";
const solbar = "⌿";
const solb = "⧄";
const sol = "/";
const Sopf = "𝕊";
const sopf = "𝕤";
const spades = "♠";
const spadesuit = "♠";
const spar = "∥";
const sqcap = "⊓";
const sqcaps = "⊓︀";
const sqcup = "⊔";
const sqcups = "⊔︀";
const Sqrt = "√";
const sqsub = "⊏";
const sqsube = "⊑";
const sqsubset = "⊏";
const sqsubseteq = "⊑";
const sqsup = "⊐";
const sqsupe = "⊒";
const sqsupset = "⊐";
const sqsupseteq = "⊒";
const square = "□";
const Square = "□";
const SquareIntersection = "⊓";
const SquareSubset = "⊏";
const SquareSubsetEqual = "⊑";
const SquareSuperset = "⊐";
const SquareSupersetEqual = "⊒";
const SquareUnion = "⊔";
const squarf = "▪";
const squ = "□";
const squf = "▪";
const srarr = "→";
const Sscr = "𝒮";
const sscr = "𝓈";
const ssetmn = "∖";
const ssmile = "⌣";
const sstarf = "⋆";
const Star = "⋆";
const star = "☆";
const starf = "★";
const straightepsilon = "ϵ";
const straightphi = "ϕ";
const strns = "¯";
const sub = "⊂";
const Sub = "⋐";
const subdot = "⪽";
const subE = "⫅";
const sube = "⊆";
const subedot = "⫃";
const submult = "⫁";
const subnE = "⫋";
const subne = "⊊";
const subplus = "⪿";
const subrarr = "⥹";
const subset = "⊂";
const Subset = "⋐";
const subseteq = "⊆";
const subseteqq = "⫅";
const SubsetEqual = "⊆";
const subsetneq = "⊊";
const subsetneqq = "⫋";
const subsim = "⫇";
const subsub = "⫕";
const subsup = "⫓";
const succapprox = "⪸";
const succ = "≻";
const succcurlyeq = "≽";
const Succeeds = "≻";
const SucceedsEqual = "⪰";
const SucceedsSlantEqual = "≽";
const SucceedsTilde = "≿";
const succeq = "⪰";
const succnapprox = "⪺";
const succneqq = "⪶";
const succnsim = "⋩";
const succsim = "≿";
const SuchThat = "∋";
const sum = "∑";
const Sum = "∑";
const sung = "♪";
const sup1$1 = "¹";
const sup2$1 = "²";
const sup3$1 = "³";
const sup = "⊃";
const Sup = "⋑";
const supdot = "⪾";
const supdsub = "⫘";
const supE = "⫆";
const supe = "⊇";
const supedot = "⫄";
const Superset = "⊃";
const SupersetEqual = "⊇";
const suphsol = "⟉";
const suphsub = "⫗";
const suplarr = "⥻";
const supmult = "⫂";
const supnE = "⫌";
const supne = "⊋";
const supplus = "⫀";
const supset = "⊃";
const Supset = "⋑";
const supseteq = "⊇";
const supseteqq = "⫆";
const supsetneq = "⊋";
const supsetneqq = "⫌";
const supsim = "⫈";
const supsub = "⫔";
const supsup = "⫖";
const swarhk = "⤦";
const swarr = "↙";
const swArr = "⇙";
const swarrow = "↙";
const swnwar = "⤪";
const szlig$1 = "ß";
const Tab = "	";
const target = "⌖";
const Tau = "Τ";
const tau = "τ";
const tbrk = "⎴";
const Tcaron = "Ť";
const tcaron = "ť";
const Tcedil = "Ţ";
const tcedil = "ţ";
const Tcy = "Т";
const tcy = "т";
const tdot = "⃛";
const telrec = "⌕";
const Tfr = "𝔗";
const tfr = "𝔱";
const there4 = "∴";
const therefore = "∴";
const Therefore = "∴";
const Theta = "Θ";
const theta = "θ";
const thetasym = "ϑ";
const thetav = "ϑ";
const thickapprox = "≈";
const thicksim = "∼";
const ThickSpace = "  ";
const ThinSpace = " ";
const thinsp = " ";
const thkap = "≈";
const thksim = "∼";
const THORN$1 = "Þ";
const thorn$1 = "þ";
const tilde = "˜";
const Tilde = "∼";
const TildeEqual = "≃";
const TildeFullEqual = "≅";
const TildeTilde = "≈";
const timesbar = "⨱";
const timesb = "⊠";
const times$1 = "×";
const timesd = "⨰";
const tint = "∭";
const toea = "⤨";
const topbot = "⌶";
const topcir = "⫱";
const top = "⊤";
const Topf = "𝕋";
const topf = "𝕥";
const topfork = "⫚";
const tosa = "⤩";
const tprime = "‴";
const trade = "™";
const TRADE = "™";
const triangle = "▵";
const triangledown = "▿";
const triangleleft = "◃";
const trianglelefteq = "⊴";
const triangleq = "≜";
const triangleright = "▹";
const trianglerighteq = "⊵";
const tridot = "◬";
const trie = "≜";
const triminus = "⨺";
const TripleDot = "⃛";
const triplus = "⨹";
const trisb = "⧍";
const tritime = "⨻";
const trpezium = "⏢";
const Tscr = "𝒯";
const tscr = "𝓉";
const TScy = "Ц";
const tscy = "ц";
const TSHcy = "Ћ";
const tshcy = "ћ";
const Tstrok = "Ŧ";
const tstrok = "ŧ";
const twixt = "≬";
const twoheadleftarrow = "↞";
const twoheadrightarrow = "↠";
const Uacute$1 = "Ú";
const uacute$1 = "ú";
const uarr = "↑";
const Uarr = "↟";
const uArr = "⇑";
const Uarrocir = "⥉";
const Ubrcy = "Ў";
const ubrcy = "ў";
const Ubreve = "Ŭ";
const ubreve = "ŭ";
const Ucirc$1 = "Û";
const ucirc$1 = "û";
const Ucy = "У";
const ucy = "у";
const udarr = "⇅";
const Udblac = "Ű";
const udblac = "ű";
const udhar = "⥮";
const ufisht = "⥾";
const Ufr = "𝔘";
const ufr = "𝔲";
const Ugrave$1 = "Ù";
const ugrave$1 = "ù";
const uHar = "⥣";
const uharl = "↿";
const uharr = "↾";
const uhblk = "▀";
const ulcorn = "⌜";
const ulcorner = "⌜";
const ulcrop = "⌏";
const ultri = "◸";
const Umacr = "Ū";
const umacr = "ū";
const uml$1 = "¨";
const UnderBar = "_";
const UnderBrace = "⏟";
const UnderBracket = "⎵";
const UnderParenthesis = "⏝";
const Union = "⋃";
const UnionPlus = "⊎";
const Uogon = "Ų";
const uogon = "ų";
const Uopf = "𝕌";
const uopf = "𝕦";
const UpArrowBar = "⤒";
const uparrow = "↑";
const UpArrow = "↑";
const Uparrow = "⇑";
const UpArrowDownArrow = "⇅";
const updownarrow = "↕";
const UpDownArrow = "↕";
const Updownarrow = "⇕";
const UpEquilibrium = "⥮";
const upharpoonleft = "↿";
const upharpoonright = "↾";
const uplus = "⊎";
const UpperLeftArrow = "↖";
const UpperRightArrow = "↗";
const upsi = "υ";
const Upsi = "ϒ";
const upsih = "ϒ";
const Upsilon = "Υ";
const upsilon = "υ";
const UpTeeArrow = "↥";
const UpTee = "⊥";
const upuparrows = "⇈";
const urcorn = "⌝";
const urcorner = "⌝";
const urcrop = "⌎";
const Uring = "Ů";
const uring = "ů";
const urtri = "◹";
const Uscr = "𝒰";
const uscr = "𝓊";
const utdot = "⋰";
const Utilde = "Ũ";
const utilde = "ũ";
const utri = "▵";
const utrif = "▴";
const uuarr = "⇈";
const Uuml$1 = "Ü";
const uuml$1 = "ü";
const uwangle = "⦧";
const vangrt = "⦜";
const varepsilon = "ϵ";
const varkappa = "ϰ";
const varnothing = "∅";
const varphi = "ϕ";
const varpi = "ϖ";
const varpropto = "∝";
const varr = "↕";
const vArr = "⇕";
const varrho = "ϱ";
const varsigma = "ς";
const varsubsetneq = "⊊︀";
const varsubsetneqq = "⫋︀";
const varsupsetneq = "⊋︀";
const varsupsetneqq = "⫌︀";
const vartheta = "ϑ";
const vartriangleleft = "⊲";
const vartriangleright = "⊳";
const vBar = "⫨";
const Vbar = "⫫";
const vBarv = "⫩";
const Vcy = "В";
const vcy = "в";
const vdash = "⊢";
const vDash = "⊨";
const Vdash = "⊩";
const VDash = "⊫";
const Vdashl = "⫦";
const veebar = "⊻";
const vee = "∨";
const Vee = "⋁";
const veeeq = "≚";
const vellip = "⋮";
const verbar = "|";
const Verbar = "‖";
const vert = "|";
const Vert = "‖";
const VerticalBar = "∣";
const VerticalLine = "|";
const VerticalSeparator = "❘";
const VerticalTilde = "≀";
const VeryThinSpace = " ";
const Vfr = "𝔙";
const vfr = "𝔳";
const vltri = "⊲";
const vnsub = "⊂⃒";
const vnsup = "⊃⃒";
const Vopf = "𝕍";
const vopf = "𝕧";
const vprop = "∝";
const vrtri = "⊳";
const Vscr = "𝒱";
const vscr = "𝓋";
const vsubnE = "⫋︀";
const vsubne = "⊊︀";
const vsupnE = "⫌︀";
const vsupne = "⊋︀";
const Vvdash = "⊪";
const vzigzag = "⦚";
const Wcirc = "Ŵ";
const wcirc = "ŵ";
const wedbar = "⩟";
const wedge = "∧";
const Wedge = "⋀";
const wedgeq = "≙";
const weierp = "℘";
const Wfr = "𝔚";
const wfr = "𝔴";
const Wopf = "𝕎";
const wopf = "𝕨";
const wp = "℘";
const wr = "≀";
const wreath = "≀";
const Wscr = "𝒲";
const wscr = "𝓌";
const xcap = "⋂";
const xcirc = "◯";
const xcup = "⋃";
const xdtri = "▽";
const Xfr = "𝔛";
const xfr = "𝔵";
const xharr = "⟷";
const xhArr = "⟺";
const Xi = "Ξ";
const xi = "ξ";
const xlarr = "⟵";
const xlArr = "⟸";
const xmap = "⟼";
const xnis = "⋻";
const xodot = "⨀";
const Xopf = "𝕏";
const xopf = "𝕩";
const xoplus = "⨁";
const xotime = "⨂";
const xrarr = "⟶";
const xrArr = "⟹";
const Xscr = "𝒳";
const xscr = "𝓍";
const xsqcup = "⨆";
const xuplus = "⨄";
const xutri = "△";
const xvee = "⋁";
const xwedge = "⋀";
const Yacute$1 = "Ý";
const yacute$1 = "ý";
const YAcy = "Я";
const yacy = "я";
const Ycirc = "Ŷ";
const ycirc = "ŷ";
const Ycy = "Ы";
const ycy = "ы";
const yen$1 = "¥";
const Yfr = "𝔜";
const yfr = "𝔶";
const YIcy = "Ї";
const yicy = "ї";
const Yopf = "𝕐";
const yopf = "𝕪";
const Yscr = "𝒴";
const yscr = "𝓎";
const YUcy = "Ю";
const yucy = "ю";
const yuml$1 = "ÿ";
const Yuml = "Ÿ";
const Zacute = "Ź";
const zacute = "ź";
const Zcaron = "Ž";
const zcaron = "ž";
const Zcy = "З";
const zcy = "з";
const Zdot = "Ż";
const zdot = "ż";
const zeetrf = "ℨ";
const ZeroWidthSpace = "​";
const Zeta = "Ζ";
const zeta = "ζ";
const zfr = "𝔷";
const Zfr = "ℨ";
const ZHcy = "Ж";
const zhcy = "ж";
const zigrarr = "⇝";
const zopf = "𝕫";
const Zopf = "ℤ";
const Zscr = "𝒵";
const zscr = "𝓏";
const zwj = "‍";
const zwnj = "‌";
const require$$1$1 = {
  Aacute: Aacute$1,
  aacute: aacute$1,
  Abreve,
  abreve,
  ac,
  acd,
  acE,
  Acirc: Acirc$1,
  acirc: acirc$1,
  acute: acute$1,
  Acy,
  acy,
  AElig: AElig$1,
  aelig: aelig$1,
  af,
  Afr,
  afr,
  Agrave: Agrave$1,
  agrave: agrave$1,
  alefsym,
  aleph,
  Alpha,
  alpha,
  Amacr,
  amacr,
  amalg,
  amp: amp$2,
  AMP: AMP$1,
  andand,
  And,
  and,
  andd,
  andslope,
  andv,
  ang,
  ange,
  angle,
  angmsdaa,
  angmsdab,
  angmsdac,
  angmsdad,
  angmsdae,
  angmsdaf,
  angmsdag,
  angmsdah,
  angmsd,
  angrt,
  angrtvb,
  angrtvbd,
  angsph,
  angst,
  angzarr,
  Aogon,
  aogon,
  Aopf,
  aopf,
  apacir,
  ap,
  apE,
  ape,
  apid,
  apos: apos$1,
  ApplyFunction,
  approx,
  approxeq,
  Aring: Aring$1,
  aring: aring$1,
  Ascr,
  ascr,
  Assign,
  ast,
  asymp,
  asympeq,
  Atilde: Atilde$1,
  atilde: atilde$1,
  Auml: Auml$1,
  auml: auml$1,
  awconint,
  awint,
  backcong,
  backepsilon,
  backprime,
  backsim,
  backsimeq,
  Backslash,
  Barv,
  barvee,
  barwed,
  Barwed,
  barwedge,
  bbrk,
  bbrktbrk,
  bcong,
  Bcy,
  bcy,
  bdquo,
  becaus,
  because,
  Because,
  bemptyv,
  bepsi,
  bernou,
  Bernoullis,
  Beta,
  beta,
  beth,
  between,
  Bfr,
  bfr,
  bigcap,
  bigcirc,
  bigcup,
  bigodot,
  bigoplus,
  bigotimes,
  bigsqcup,
  bigstar,
  bigtriangledown,
  bigtriangleup,
  biguplus,
  bigvee,
  bigwedge,
  bkarow,
  blacklozenge,
  blacksquare,
  blacktriangle,
  blacktriangledown,
  blacktriangleleft,
  blacktriangleright,
  blank,
  blk12,
  blk14,
  blk34,
  block,
  bne,
  bnequiv,
  bNot,
  bnot,
  Bopf,
  bopf,
  bot,
  bottom,
  bowtie,
  boxbox,
  boxdl,
  boxdL,
  boxDl,
  boxDL,
  boxdr,
  boxdR,
  boxDr,
  boxDR,
  boxh,
  boxH,
  boxhd,
  boxHd,
  boxhD,
  boxHD,
  boxhu,
  boxHu,
  boxhU,
  boxHU,
  boxminus,
  boxplus,
  boxtimes,
  boxul,
  boxuL,
  boxUl,
  boxUL,
  boxur,
  boxuR,
  boxUr,
  boxUR,
  boxv,
  boxV,
  boxvh,
  boxvH,
  boxVh,
  boxVH,
  boxvl,
  boxvL,
  boxVl,
  boxVL,
  boxvr,
  boxvR,
  boxVr,
  boxVR,
  bprime,
  breve,
  Breve,
  brvbar: brvbar$1,
  bscr,
  Bscr,
  bsemi,
  bsim,
  bsime,
  bsolb,
  bsol,
  bsolhsub,
  bull,
  bullet,
  bump,
  bumpE,
  bumpe,
  Bumpeq,
  bumpeq,
  Cacute,
  cacute,
  capand,
  capbrcup,
  capcap,
  cap,
  Cap,
  capcup,
  capdot,
  CapitalDifferentialD,
  caps,
  caret,
  caron,
  Cayleys,
  ccaps,
  Ccaron,
  ccaron,
  Ccedil: Ccedil$1,
  ccedil: ccedil$1,
  Ccirc,
  ccirc,
  Cconint,
  ccups,
  ccupssm,
  Cdot,
  cdot,
  cedil: cedil$1,
  Cedilla,
  cemptyv,
  cent: cent$1,
  centerdot,
  CenterDot,
  cfr,
  Cfr,
  CHcy,
  chcy,
  check,
  checkmark,
  Chi,
  chi,
  circ,
  circeq,
  circlearrowleft,
  circlearrowright,
  circledast,
  circledcirc,
  circleddash,
  CircleDot,
  circledR,
  circledS,
  CircleMinus,
  CirclePlus,
  CircleTimes,
  cir,
  cirE,
  cire,
  cirfnint,
  cirmid,
  cirscir,
  ClockwiseContourIntegral,
  CloseCurlyDoubleQuote,
  CloseCurlyQuote,
  clubs,
  clubsuit,
  colon,
  Colon,
  Colone,
  colone,
  coloneq,
  comma,
  commat,
  comp,
  compfn,
  complement,
  complexes,
  cong,
  congdot,
  Congruent,
  conint,
  Conint,
  ContourIntegral,
  copf,
  Copf,
  coprod,
  Coproduct,
  copy: copy$1,
  COPY: COPY$1,
  copysr,
  CounterClockwiseContourIntegral,
  crarr,
  cross,
  Cross,
  Cscr,
  cscr,
  csub,
  csube,
  csup,
  csupe,
  ctdot,
  cudarrl,
  cudarrr,
  cuepr,
  cuesc,
  cularr,
  cularrp,
  cupbrcap,
  cupcap,
  CupCap,
  cup,
  Cup,
  cupcup,
  cupdot,
  cupor,
  cups,
  curarr,
  curarrm,
  curlyeqprec,
  curlyeqsucc,
  curlyvee,
  curlywedge,
  curren: curren$1,
  curvearrowleft,
  curvearrowright,
  cuvee,
  cuwed,
  cwconint,
  cwint,
  cylcty,
  dagger,
  Dagger,
  daleth,
  darr,
  Darr,
  dArr,
  dash,
  Dashv,
  dashv,
  dbkarow,
  dblac,
  Dcaron,
  dcaron,
  Dcy,
  dcy,
  ddagger,
  ddarr,
  DD,
  dd,
  DDotrahd,
  ddotseq,
  deg: deg$1,
  Del,
  Delta,
  delta,
  demptyv,
  dfisht,
  Dfr,
  dfr,
  dHar,
  dharl,
  dharr,
  DiacriticalAcute,
  DiacriticalDot,
  DiacriticalDoubleAcute,
  DiacriticalGrave,
  DiacriticalTilde,
  diam,
  diamond,
  Diamond,
  diamondsuit,
  diams,
  die,
  DifferentialD,
  digamma,
  disin,
  div,
  divide: divide$1,
  divideontimes,
  divonx,
  DJcy,
  djcy,
  dlcorn,
  dlcrop,
  dollar,
  Dopf,
  dopf,
  Dot,
  dot,
  DotDot,
  doteq,
  doteqdot,
  DotEqual,
  dotminus,
  dotplus,
  dotsquare,
  doublebarwedge,
  DoubleContourIntegral,
  DoubleDot,
  DoubleDownArrow,
  DoubleLeftArrow,
  DoubleLeftRightArrow,
  DoubleLeftTee,
  DoubleLongLeftArrow,
  DoubleLongLeftRightArrow,
  DoubleLongRightArrow,
  DoubleRightArrow,
  DoubleRightTee,
  DoubleUpArrow,
  DoubleUpDownArrow,
  DoubleVerticalBar,
  DownArrowBar,
  downarrow,
  DownArrow,
  Downarrow,
  DownArrowUpArrow,
  DownBreve,
  downdownarrows,
  downharpoonleft,
  downharpoonright,
  DownLeftRightVector,
  DownLeftTeeVector,
  DownLeftVectorBar,
  DownLeftVector,
  DownRightTeeVector,
  DownRightVectorBar,
  DownRightVector,
  DownTeeArrow,
  DownTee,
  drbkarow,
  drcorn,
  drcrop,
  Dscr,
  dscr,
  DScy,
  dscy,
  dsol,
  Dstrok,
  dstrok,
  dtdot,
  dtri,
  dtrif,
  duarr,
  duhar,
  dwangle,
  DZcy,
  dzcy,
  dzigrarr,
  Eacute: Eacute$1,
  eacute: eacute$1,
  easter,
  Ecaron,
  ecaron,
  Ecirc: Ecirc$1,
  ecirc: ecirc$1,
  ecir,
  ecolon,
  Ecy,
  ecy,
  eDDot,
  Edot,
  edot,
  eDot,
  ee,
  efDot,
  Efr,
  efr,
  eg,
  Egrave: Egrave$1,
  egrave: egrave$1,
  egs,
  egsdot,
  el,
  Element: Element$1,
  elinters,
  ell,
  els,
  elsdot,
  Emacr,
  emacr,
  empty,
  emptyset,
  EmptySmallSquare,
  emptyv,
  EmptyVerySmallSquare,
  emsp13,
  emsp14,
  emsp,
  ENG,
  eng,
  ensp,
  Eogon,
  eogon,
  Eopf,
  eopf,
  epar,
  eparsl,
  eplus,
  epsi,
  Epsilon,
  epsilon,
  epsiv,
  eqcirc,
  eqcolon,
  eqsim,
  eqslantgtr,
  eqslantless,
  Equal,
  equals,
  EqualTilde,
  equest,
  Equilibrium,
  equiv,
  equivDD,
  eqvparsl,
  erarr,
  erDot,
  escr,
  Escr,
  esdot,
  Esim,
  esim,
  Eta,
  eta,
  ETH: ETH$1,
  eth: eth$1,
  Euml: Euml$1,
  euml: euml$1,
  euro,
  excl,
  exist,
  Exists,
  expectation,
  exponentiale,
  ExponentialE,
  fallingdotseq,
  Fcy,
  fcy,
  female,
  ffilig,
  fflig,
  ffllig,
  Ffr,
  ffr,
  filig,
  FilledSmallSquare,
  FilledVerySmallSquare,
  fjlig,
  flat,
  fllig,
  fltns,
  fnof,
  Fopf,
  fopf,
  forall,
  ForAll,
  fork,
  forkv,
  Fouriertrf,
  fpartint,
  frac12: frac12$1,
  frac13,
  frac14: frac14$1,
  frac15,
  frac16,
  frac18,
  frac23,
  frac25,
  frac34: frac34$1,
  frac35,
  frac38,
  frac45,
  frac56,
  frac58,
  frac78,
  frasl,
  frown,
  fscr,
  Fscr,
  gacute,
  Gamma,
  gamma,
  Gammad,
  gammad,
  gap,
  Gbreve,
  gbreve,
  Gcedil,
  Gcirc,
  gcirc,
  Gcy,
  gcy,
  Gdot,
  gdot,
  ge,
  gE,
  gEl,
  gel,
  geq,
  geqq,
  geqslant,
  gescc,
  ges,
  gesdot,
  gesdoto,
  gesdotol,
  gesl,
  gesles,
  Gfr,
  gfr,
  gg,
  Gg,
  ggg,
  gimel,
  GJcy,
  gjcy,
  gla,
  gl,
  glE,
  glj,
  gnap,
  gnapprox,
  gne,
  gnE,
  gneq,
  gneqq,
  gnsim,
  Gopf,
  gopf,
  grave,
  GreaterEqual,
  GreaterEqualLess,
  GreaterFullEqual,
  GreaterGreater,
  GreaterLess,
  GreaterSlantEqual,
  GreaterTilde,
  Gscr,
  gscr,
  gsim,
  gsime,
  gsiml,
  gtcc,
  gtcir,
  gt: gt$2,
  GT: GT$1,
  Gt,
  gtdot,
  gtlPar,
  gtquest,
  gtrapprox,
  gtrarr,
  gtrdot,
  gtreqless,
  gtreqqless,
  gtrless,
  gtrsim,
  gvertneqq,
  gvnE,
  Hacek,
  hairsp,
  half,
  hamilt,
  HARDcy,
  hardcy,
  harrcir,
  harr,
  hArr,
  harrw,
  Hat,
  hbar,
  Hcirc,
  hcirc,
  hearts,
  heartsuit,
  hellip,
  hercon,
  hfr,
  Hfr,
  HilbertSpace,
  hksearow,
  hkswarow,
  hoarr,
  homtht,
  hookleftarrow,
  hookrightarrow,
  hopf,
  Hopf,
  horbar,
  HorizontalLine,
  hscr,
  Hscr,
  hslash,
  Hstrok,
  hstrok,
  HumpDownHump,
  HumpEqual,
  hybull,
  hyphen,
  Iacute: Iacute$1,
  iacute: iacute$1,
  ic,
  Icirc: Icirc$1,
  icirc: icirc$1,
  Icy,
  icy,
  Idot,
  IEcy,
  iecy,
  iexcl: iexcl$1,
  iff,
  ifr,
  Ifr,
  Igrave: Igrave$1,
  igrave: igrave$1,
  ii,
  iiiint,
  iiint,
  iinfin,
  iiota,
  IJlig,
  ijlig,
  Imacr,
  imacr,
  image,
  ImaginaryI,
  imagline,
  imagpart,
  imath,
  Im,
  imof,
  imped,
  Implies,
  incare,
  "in": "∈",
  infin,
  infintie,
  inodot,
  intcal,
  int,
  Int,
  integers,
  Integral,
  intercal,
  Intersection,
  intlarhk,
  intprod,
  InvisibleComma,
  InvisibleTimes,
  IOcy,
  iocy,
  Iogon,
  iogon,
  Iopf,
  iopf,
  Iota,
  iota,
  iprod,
  iquest: iquest$1,
  iscr,
  Iscr,
  isin,
  isindot,
  isinE,
  isins,
  isinsv,
  isinv,
  it,
  Itilde,
  itilde,
  Iukcy,
  iukcy,
  Iuml: Iuml$1,
  iuml: iuml$1,
  Jcirc,
  jcirc,
  Jcy,
  jcy,
  Jfr,
  jfr,
  jmath,
  Jopf,
  jopf,
  Jscr,
  jscr,
  Jsercy,
  jsercy,
  Jukcy,
  jukcy,
  Kappa,
  kappa,
  kappav,
  Kcedil,
  kcedil,
  Kcy,
  kcy,
  Kfr,
  kfr,
  kgreen,
  KHcy,
  khcy,
  KJcy,
  kjcy,
  Kopf,
  kopf,
  Kscr,
  kscr,
  lAarr,
  Lacute,
  lacute,
  laemptyv,
  lagran,
  Lambda,
  lambda,
  lang,
  Lang,
  langd,
  langle,
  lap,
  Laplacetrf,
  laquo: laquo$1,
  larrb,
  larrbfs,
  larr,
  Larr,
  lArr,
  larrfs,
  larrhk,
  larrlp,
  larrpl,
  larrsim,
  larrtl,
  latail,
  lAtail,
  lat,
  late,
  lates,
  lbarr,
  lBarr,
  lbbrk,
  lbrace,
  lbrack,
  lbrke,
  lbrksld,
  lbrkslu,
  Lcaron,
  lcaron,
  Lcedil,
  lcedil,
  lceil,
  lcub,
  Lcy,
  lcy,
  ldca,
  ldquo,
  ldquor,
  ldrdhar,
  ldrushar,
  ldsh,
  le,
  lE,
  LeftAngleBracket,
  LeftArrowBar,
  leftarrow,
  LeftArrow,
  Leftarrow,
  LeftArrowRightArrow,
  leftarrowtail,
  LeftCeiling,
  LeftDoubleBracket,
  LeftDownTeeVector,
  LeftDownVectorBar,
  LeftDownVector,
  LeftFloor,
  leftharpoondown,
  leftharpoonup,
  leftleftarrows,
  leftrightarrow,
  LeftRightArrow,
  Leftrightarrow,
  leftrightarrows,
  leftrightharpoons,
  leftrightsquigarrow,
  LeftRightVector,
  LeftTeeArrow,
  LeftTee,
  LeftTeeVector,
  leftthreetimes,
  LeftTriangleBar,
  LeftTriangle,
  LeftTriangleEqual,
  LeftUpDownVector,
  LeftUpTeeVector,
  LeftUpVectorBar,
  LeftUpVector,
  LeftVectorBar,
  LeftVector,
  lEg,
  leg,
  leq,
  leqq,
  leqslant,
  lescc,
  les,
  lesdot,
  lesdoto,
  lesdotor,
  lesg,
  lesges,
  lessapprox,
  lessdot,
  lesseqgtr,
  lesseqqgtr,
  LessEqualGreater,
  LessFullEqual,
  LessGreater,
  lessgtr,
  LessLess,
  lesssim,
  LessSlantEqual,
  LessTilde,
  lfisht,
  lfloor,
  Lfr,
  lfr,
  lg,
  lgE,
  lHar,
  lhard,
  lharu,
  lharul,
  lhblk,
  LJcy,
  ljcy,
  llarr,
  ll,
  Ll,
  llcorner,
  Lleftarrow,
  llhard,
  lltri,
  Lmidot,
  lmidot,
  lmoustache,
  lmoust,
  lnap,
  lnapprox,
  lne,
  lnE,
  lneq,
  lneqq,
  lnsim,
  loang,
  loarr,
  lobrk,
  longleftarrow,
  LongLeftArrow,
  Longleftarrow,
  longleftrightarrow,
  LongLeftRightArrow,
  Longleftrightarrow,
  longmapsto,
  longrightarrow,
  LongRightArrow,
  Longrightarrow,
  looparrowleft,
  looparrowright,
  lopar,
  Lopf,
  lopf,
  loplus,
  lotimes,
  lowast,
  lowbar,
  LowerLeftArrow,
  LowerRightArrow,
  loz,
  lozenge,
  lozf,
  lpar,
  lparlt,
  lrarr,
  lrcorner,
  lrhar,
  lrhard,
  lrm,
  lrtri,
  lsaquo,
  lscr,
  Lscr,
  lsh,
  Lsh,
  lsim,
  lsime,
  lsimg,
  lsqb,
  lsquo,
  lsquor,
  Lstrok,
  lstrok,
  ltcc,
  ltcir,
  lt: lt$2,
  LT: LT$1,
  Lt,
  ltdot,
  lthree,
  ltimes,
  ltlarr,
  ltquest,
  ltri,
  ltrie,
  ltrif,
  ltrPar,
  lurdshar,
  luruhar,
  lvertneqq,
  lvnE,
  macr: macr$1,
  male,
  malt,
  maltese,
  "Map": "⤅",
  map,
  mapsto,
  mapstodown,
  mapstoleft,
  mapstoup,
  marker,
  mcomma,
  Mcy,
  mcy,
  mdash,
  mDDot,
  measuredangle,
  MediumSpace,
  Mellintrf,
  Mfr,
  mfr,
  mho,
  micro: micro$1,
  midast,
  midcir,
  mid,
  middot: middot$1,
  minusb,
  minus,
  minusd,
  minusdu,
  MinusPlus,
  mlcp,
  mldr,
  mnplus,
  models,
  Mopf,
  mopf,
  mp,
  mscr,
  Mscr,
  mstpos,
  Mu,
  mu,
  multimap,
  mumap,
  nabla,
  Nacute,
  nacute,
  nang,
  nap,
  napE,
  napid,
  napos,
  napprox,
  natural,
  naturals,
  natur,
  nbsp: nbsp$1,
  nbump,
  nbumpe,
  ncap,
  Ncaron,
  ncaron,
  Ncedil,
  ncedil,
  ncong,
  ncongdot,
  ncup,
  Ncy,
  ncy,
  ndash,
  nearhk,
  nearr,
  neArr,
  nearrow,
  ne,
  nedot,
  NegativeMediumSpace,
  NegativeThickSpace,
  NegativeThinSpace,
  NegativeVeryThinSpace,
  nequiv,
  nesear,
  nesim,
  NestedGreaterGreater,
  NestedLessLess,
  NewLine,
  nexist,
  nexists,
  Nfr,
  nfr,
  ngE,
  nge,
  ngeq,
  ngeqq,
  ngeqslant,
  nges,
  nGg,
  ngsim,
  nGt,
  ngt,
  ngtr,
  nGtv,
  nharr,
  nhArr,
  nhpar,
  ni,
  nis,
  nisd,
  niv,
  NJcy,
  njcy,
  nlarr,
  nlArr,
  nldr,
  nlE,
  nle,
  nleftarrow,
  nLeftarrow,
  nleftrightarrow,
  nLeftrightarrow,
  nleq,
  nleqq,
  nleqslant,
  nles,
  nless,
  nLl,
  nlsim,
  nLt,
  nlt,
  nltri,
  nltrie,
  nLtv,
  nmid,
  NoBreak,
  NonBreakingSpace,
  nopf,
  Nopf,
  Not,
  not: not$1,
  NotCongruent,
  NotCupCap,
  NotDoubleVerticalBar,
  NotElement,
  NotEqual,
  NotEqualTilde,
  NotExists,
  NotGreater,
  NotGreaterEqual,
  NotGreaterFullEqual,
  NotGreaterGreater,
  NotGreaterLess,
  NotGreaterSlantEqual,
  NotGreaterTilde,
  NotHumpDownHump,
  NotHumpEqual,
  notin,
  notindot,
  notinE,
  notinva,
  notinvb,
  notinvc,
  NotLeftTriangleBar,
  NotLeftTriangle,
  NotLeftTriangleEqual,
  NotLess,
  NotLessEqual,
  NotLessGreater,
  NotLessLess,
  NotLessSlantEqual,
  NotLessTilde,
  NotNestedGreaterGreater,
  NotNestedLessLess,
  notni,
  notniva,
  notnivb,
  notnivc,
  NotPrecedes,
  NotPrecedesEqual,
  NotPrecedesSlantEqual,
  NotReverseElement,
  NotRightTriangleBar,
  NotRightTriangle,
  NotRightTriangleEqual,
  NotSquareSubset,
  NotSquareSubsetEqual,
  NotSquareSuperset,
  NotSquareSupersetEqual,
  NotSubset,
  NotSubsetEqual,
  NotSucceeds,
  NotSucceedsEqual,
  NotSucceedsSlantEqual,
  NotSucceedsTilde,
  NotSuperset,
  NotSupersetEqual,
  NotTilde,
  NotTildeEqual,
  NotTildeFullEqual,
  NotTildeTilde,
  NotVerticalBar,
  nparallel,
  npar,
  nparsl,
  npart,
  npolint,
  npr,
  nprcue,
  nprec,
  npreceq,
  npre,
  nrarrc,
  nrarr,
  nrArr,
  nrarrw,
  nrightarrow,
  nRightarrow,
  nrtri,
  nrtrie,
  nsc,
  nsccue,
  nsce,
  Nscr,
  nscr,
  nshortmid,
  nshortparallel,
  nsim,
  nsime,
  nsimeq,
  nsmid,
  nspar,
  nsqsube,
  nsqsupe,
  nsub,
  nsubE,
  nsube,
  nsubset,
  nsubseteq,
  nsubseteqq,
  nsucc,
  nsucceq,
  nsup,
  nsupE,
  nsupe,
  nsupset,
  nsupseteq,
  nsupseteqq,
  ntgl,
  Ntilde: Ntilde$1,
  ntilde: ntilde$1,
  ntlg,
  ntriangleleft,
  ntrianglelefteq,
  ntriangleright,
  ntrianglerighteq,
  Nu,
  nu,
  num,
  numero,
  numsp,
  nvap,
  nvdash,
  nvDash,
  nVdash,
  nVDash,
  nvge,
  nvgt,
  nvHarr,
  nvinfin,
  nvlArr,
  nvle,
  nvlt,
  nvltrie,
  nvrArr,
  nvrtrie,
  nvsim,
  nwarhk,
  nwarr,
  nwArr,
  nwarrow,
  nwnear,
  Oacute: Oacute$1,
  oacute: oacute$1,
  oast,
  Ocirc: Ocirc$1,
  ocirc: ocirc$1,
  ocir,
  Ocy,
  ocy,
  odash,
  Odblac,
  odblac,
  odiv,
  odot,
  odsold,
  OElig,
  oelig,
  ofcir,
  Ofr,
  ofr,
  ogon,
  Ograve: Ograve$1,
  ograve: ograve$1,
  ogt,
  ohbar,
  ohm,
  oint,
  olarr,
  olcir,
  olcross,
  oline,
  olt,
  Omacr,
  omacr,
  Omega,
  omega,
  Omicron,
  omicron,
  omid,
  ominus,
  Oopf,
  oopf,
  opar,
  OpenCurlyDoubleQuote,
  OpenCurlyQuote,
  operp,
  oplus,
  orarr,
  Or,
  or,
  ord,
  order,
  orderof,
  ordf: ordf$1,
  ordm: ordm$1,
  origof,
  oror,
  orslope,
  orv,
  oS,
  Oscr,
  oscr,
  Oslash: Oslash$1,
  oslash: oslash$1,
  osol,
  Otilde: Otilde$1,
  otilde: otilde$1,
  otimesas,
  Otimes,
  otimes,
  Ouml: Ouml$1,
  ouml: ouml$1,
  ovbar,
  OverBar,
  OverBrace,
  OverBracket,
  OverParenthesis,
  para: para$1,
  parallel,
  par,
  parsim,
  parsl,
  part,
  PartialD,
  Pcy,
  pcy,
  percnt,
  period,
  permil,
  perp,
  pertenk,
  Pfr,
  pfr,
  Phi,
  phi,
  phiv,
  phmmat,
  phone,
  Pi,
  pi,
  pitchfork,
  piv,
  planck,
  planckh,
  plankv,
  plusacir,
  plusb,
  pluscir,
  plus,
  plusdo,
  plusdu,
  pluse,
  PlusMinus,
  plusmn: plusmn$1,
  plussim,
  plustwo,
  pm,
  Poincareplane,
  pointint,
  popf,
  Popf,
  pound: pound$1,
  prap,
  Pr,
  pr,
  prcue,
  precapprox,
  prec,
  preccurlyeq,
  Precedes,
  PrecedesEqual,
  PrecedesSlantEqual,
  PrecedesTilde,
  preceq,
  precnapprox,
  precneqq,
  precnsim,
  pre,
  prE,
  precsim,
  prime,
  Prime,
  primes,
  prnap,
  prnE,
  prnsim,
  prod,
  Product,
  profalar,
  profline,
  profsurf,
  prop,
  Proportional,
  Proportion,
  propto,
  prsim,
  prurel,
  Pscr,
  pscr,
  Psi,
  psi,
  puncsp,
  Qfr,
  qfr,
  qint,
  qopf,
  Qopf,
  qprime,
  Qscr,
  qscr,
  quaternions,
  quatint,
  quest,
  questeq,
  quot: quot$2,
  QUOT: QUOT$1,
  rAarr,
  race,
  Racute,
  racute,
  radic,
  raemptyv,
  rang,
  Rang,
  rangd,
  range: range$1,
  rangle,
  raquo: raquo$1,
  rarrap,
  rarrb,
  rarrbfs,
  rarrc,
  rarr,
  Rarr,
  rArr,
  rarrfs,
  rarrhk,
  rarrlp,
  rarrpl,
  rarrsim,
  Rarrtl,
  rarrtl,
  rarrw,
  ratail,
  rAtail,
  ratio,
  rationals,
  rbarr,
  rBarr,
  RBarr,
  rbbrk,
  rbrace,
  rbrack,
  rbrke,
  rbrksld,
  rbrkslu,
  Rcaron,
  rcaron,
  Rcedil,
  rcedil,
  rceil,
  rcub,
  Rcy,
  rcy,
  rdca,
  rdldhar,
  rdquo,
  rdquor,
  rdsh,
  real,
  realine,
  realpart,
  reals,
  Re,
  rect,
  reg: reg$1,
  REG: REG$1,
  ReverseElement,
  ReverseEquilibrium,
  ReverseUpEquilibrium,
  rfisht,
  rfloor,
  rfr,
  Rfr,
  rHar,
  rhard,
  rharu,
  rharul,
  Rho,
  rho,
  rhov,
  RightAngleBracket,
  RightArrowBar,
  rightarrow,
  RightArrow,
  Rightarrow,
  RightArrowLeftArrow,
  rightarrowtail,
  RightCeiling,
  RightDoubleBracket,
  RightDownTeeVector,
  RightDownVectorBar,
  RightDownVector,
  RightFloor,
  rightharpoondown,
  rightharpoonup,
  rightleftarrows,
  rightleftharpoons,
  rightrightarrows,
  rightsquigarrow,
  RightTeeArrow,
  RightTee,
  RightTeeVector,
  rightthreetimes,
  RightTriangleBar,
  RightTriangle,
  RightTriangleEqual,
  RightUpDownVector,
  RightUpTeeVector,
  RightUpVectorBar,
  RightUpVector,
  RightVectorBar,
  RightVector,
  ring,
  risingdotseq,
  rlarr,
  rlhar,
  rlm,
  rmoustache,
  rmoust,
  rnmid,
  roang,
  roarr,
  robrk,
  ropar,
  ropf,
  Ropf,
  roplus,
  rotimes,
  RoundImplies,
  rpar,
  rpargt,
  rppolint,
  rrarr,
  Rrightarrow,
  rsaquo,
  rscr,
  Rscr,
  rsh,
  Rsh,
  rsqb,
  rsquo,
  rsquor,
  rthree,
  rtimes,
  rtri,
  rtrie,
  rtrif,
  rtriltri,
  RuleDelayed,
  ruluhar,
  rx,
  Sacute,
  sacute,
  sbquo,
  scap,
  Scaron,
  scaron,
  Sc,
  sc,
  sccue,
  sce,
  scE,
  Scedil,
  scedil,
  Scirc,
  scirc,
  scnap,
  scnE,
  scnsim,
  scpolint,
  scsim,
  Scy,
  scy,
  sdotb,
  sdot,
  sdote,
  searhk,
  searr,
  seArr,
  searrow,
  sect: sect$1,
  semi,
  seswar,
  setminus,
  setmn,
  sext,
  Sfr,
  sfr,
  sfrown,
  sharp,
  SHCHcy,
  shchcy,
  SHcy,
  shcy,
  ShortDownArrow,
  ShortLeftArrow,
  shortmid,
  shortparallel,
  ShortRightArrow,
  ShortUpArrow,
  shy: shy$1,
  Sigma,
  sigma,
  sigmaf,
  sigmav,
  sim,
  simdot,
  sime,
  simeq,
  simg,
  simgE,
  siml,
  simlE,
  simne,
  simplus,
  simrarr,
  slarr,
  SmallCircle,
  smallsetminus,
  smashp,
  smeparsl,
  smid,
  smile,
  smt,
  smte,
  smtes,
  SOFTcy,
  softcy,
  solbar,
  solb,
  sol,
  Sopf,
  sopf,
  spades,
  spadesuit,
  spar,
  sqcap,
  sqcaps,
  sqcup,
  sqcups,
  Sqrt,
  sqsub,
  sqsube,
  sqsubset,
  sqsubseteq,
  sqsup,
  sqsupe,
  sqsupset,
  sqsupseteq,
  square,
  Square,
  SquareIntersection,
  SquareSubset,
  SquareSubsetEqual,
  SquareSuperset,
  SquareSupersetEqual,
  SquareUnion,
  squarf,
  squ,
  squf,
  srarr,
  Sscr,
  sscr,
  ssetmn,
  ssmile,
  sstarf,
  Star,
  star,
  starf,
  straightepsilon,
  straightphi,
  strns,
  sub,
  Sub,
  subdot,
  subE,
  sube,
  subedot,
  submult,
  subnE,
  subne,
  subplus,
  subrarr,
  subset,
  Subset,
  subseteq,
  subseteqq,
  SubsetEqual,
  subsetneq,
  subsetneqq,
  subsim,
  subsub,
  subsup,
  succapprox,
  succ,
  succcurlyeq,
  Succeeds,
  SucceedsEqual,
  SucceedsSlantEqual,
  SucceedsTilde,
  succeq,
  succnapprox,
  succneqq,
  succnsim,
  succsim,
  SuchThat,
  sum,
  Sum,
  sung,
  sup1: sup1$1,
  sup2: sup2$1,
  sup3: sup3$1,
  sup,
  Sup,
  supdot,
  supdsub,
  supE,
  supe,
  supedot,
  Superset,
  SupersetEqual,
  suphsol,
  suphsub,
  suplarr,
  supmult,
  supnE,
  supne,
  supplus,
  supset,
  Supset,
  supseteq,
  supseteqq,
  supsetneq,
  supsetneqq,
  supsim,
  supsub,
  supsup,
  swarhk,
  swarr,
  swArr,
  swarrow,
  swnwar,
  szlig: szlig$1,
  Tab,
  target,
  Tau,
  tau,
  tbrk,
  Tcaron,
  tcaron,
  Tcedil,
  tcedil,
  Tcy,
  tcy,
  tdot,
  telrec,
  Tfr,
  tfr,
  there4,
  therefore,
  Therefore,
  Theta,
  theta,
  thetasym,
  thetav,
  thickapprox,
  thicksim,
  ThickSpace,
  ThinSpace,
  thinsp,
  thkap,
  thksim,
  THORN: THORN$1,
  thorn: thorn$1,
  tilde,
  Tilde,
  TildeEqual,
  TildeFullEqual,
  TildeTilde,
  timesbar,
  timesb,
  times: times$1,
  timesd,
  tint,
  toea,
  topbot,
  topcir,
  top,
  Topf,
  topf,
  topfork,
  tosa,
  tprime,
  trade,
  TRADE,
  triangle,
  triangledown,
  triangleleft,
  trianglelefteq,
  triangleq,
  triangleright,
  trianglerighteq,
  tridot,
  trie,
  triminus,
  TripleDot,
  triplus,
  trisb,
  tritime,
  trpezium,
  Tscr,
  tscr,
  TScy,
  tscy,
  TSHcy,
  tshcy,
  Tstrok,
  tstrok,
  twixt,
  twoheadleftarrow,
  twoheadrightarrow,
  Uacute: Uacute$1,
  uacute: uacute$1,
  uarr,
  Uarr,
  uArr,
  Uarrocir,
  Ubrcy,
  ubrcy,
  Ubreve,
  ubreve,
  Ucirc: Ucirc$1,
  ucirc: ucirc$1,
  Ucy,
  ucy,
  udarr,
  Udblac,
  udblac,
  udhar,
  ufisht,
  Ufr,
  ufr,
  Ugrave: Ugrave$1,
  ugrave: ugrave$1,
  uHar,
  uharl,
  uharr,
  uhblk,
  ulcorn,
  ulcorner,
  ulcrop,
  ultri,
  Umacr,
  umacr,
  uml: uml$1,
  UnderBar,
  UnderBrace,
  UnderBracket,
  UnderParenthesis,
  Union,
  UnionPlus,
  Uogon,
  uogon,
  Uopf,
  uopf,
  UpArrowBar,
  uparrow,
  UpArrow,
  Uparrow,
  UpArrowDownArrow,
  updownarrow,
  UpDownArrow,
  Updownarrow,
  UpEquilibrium,
  upharpoonleft,
  upharpoonright,
  uplus,
  UpperLeftArrow,
  UpperRightArrow,
  upsi,
  Upsi,
  upsih,
  Upsilon,
  upsilon,
  UpTeeArrow,
  UpTee,
  upuparrows,
  urcorn,
  urcorner,
  urcrop,
  Uring,
  uring,
  urtri,
  Uscr,
  uscr,
  utdot,
  Utilde,
  utilde,
  utri,
  utrif,
  uuarr,
  Uuml: Uuml$1,
  uuml: uuml$1,
  uwangle,
  vangrt,
  varepsilon,
  varkappa,
  varnothing,
  varphi,
  varpi,
  varpropto,
  varr,
  vArr,
  varrho,
  varsigma,
  varsubsetneq,
  varsubsetneqq,
  varsupsetneq,
  varsupsetneqq,
  vartheta,
  vartriangleleft,
  vartriangleright,
  vBar,
  Vbar,
  vBarv,
  Vcy,
  vcy,
  vdash,
  vDash,
  Vdash,
  VDash,
  Vdashl,
  veebar,
  vee,
  Vee,
  veeeq,
  vellip,
  verbar,
  Verbar,
  vert,
  Vert,
  VerticalBar,
  VerticalLine,
  VerticalSeparator,
  VerticalTilde,
  VeryThinSpace,
  Vfr,
  vfr,
  vltri,
  vnsub,
  vnsup,
  Vopf,
  vopf,
  vprop,
  vrtri,
  Vscr,
  vscr,
  vsubnE,
  vsubne,
  vsupnE,
  vsupne,
  Vvdash,
  vzigzag,
  Wcirc,
  wcirc,
  wedbar,
  wedge,
  Wedge,
  wedgeq,
  weierp,
  Wfr,
  wfr,
  Wopf,
  wopf,
  wp,
  wr,
  wreath,
  Wscr,
  wscr,
  xcap,
  xcirc,
  xcup,
  xdtri,
  Xfr,
  xfr,
  xharr,
  xhArr,
  Xi,
  xi,
  xlarr,
  xlArr,
  xmap,
  xnis,
  xodot,
  Xopf,
  xopf,
  xoplus,
  xotime,
  xrarr,
  xrArr,
  Xscr,
  xscr,
  xsqcup,
  xuplus,
  xutri,
  xvee,
  xwedge,
  Yacute: Yacute$1,
  yacute: yacute$1,
  YAcy,
  yacy,
  Ycirc,
  ycirc,
  Ycy,
  ycy,
  yen: yen$1,
  Yfr,
  yfr,
  YIcy,
  yicy,
  Yopf,
  yopf,
  Yscr,
  yscr,
  YUcy,
  yucy,
  yuml: yuml$1,
  Yuml,
  Zacute,
  zacute,
  Zcaron,
  zcaron,
  Zcy,
  zcy,
  Zdot,
  zdot,
  zeetrf,
  ZeroWidthSpace,
  Zeta,
  zeta,
  zfr,
  Zfr,
  ZHcy,
  zhcy,
  zigrarr,
  zopf,
  Zopf,
  Zscr,
  zscr,
  zwj,
  zwnj
};
const Aacute = "Á";
const aacute = "á";
const Acirc = "Â";
const acirc = "â";
const acute = "´";
const AElig = "Æ";
const aelig = "æ";
const Agrave = "À";
const agrave = "à";
const amp$1 = "&";
const AMP = "&";
const Aring = "Å";
const aring = "å";
const Atilde = "Ã";
const atilde = "ã";
const Auml = "Ä";
const auml = "ä";
const brvbar = "¦";
const Ccedil = "Ç";
const ccedil = "ç";
const cedil = "¸";
const cent = "¢";
const copy = "©";
const COPY = "©";
const curren = "¤";
const deg = "°";
const divide = "÷";
const Eacute = "É";
const eacute = "é";
const Ecirc = "Ê";
const ecirc = "ê";
const Egrave = "È";
const egrave = "è";
const ETH = "Ð";
const eth = "ð";
const Euml = "Ë";
const euml = "ë";
const frac12 = "½";
const frac14 = "¼";
const frac34 = "¾";
const gt$1 = ">";
const GT = ">";
const Iacute = "Í";
const iacute = "í";
const Icirc = "Î";
const icirc = "î";
const iexcl = "¡";
const Igrave = "Ì";
const igrave = "ì";
const iquest = "¿";
const Iuml = "Ï";
const iuml = "ï";
const laquo = "«";
const lt$1 = "<";
const LT = "<";
const macr = "¯";
const micro = "µ";
const middot = "·";
const nbsp = " ";
const not = "¬";
const Ntilde = "Ñ";
const ntilde = "ñ";
const Oacute = "Ó";
const oacute = "ó";
const Ocirc = "Ô";
const ocirc = "ô";
const Ograve = "Ò";
const ograve = "ò";
const ordf = "ª";
const ordm = "º";
const Oslash = "Ø";
const oslash = "ø";
const Otilde = "Õ";
const otilde = "õ";
const Ouml = "Ö";
const ouml = "ö";
const para = "¶";
const plusmn = "±";
const pound = "£";
const quot$1 = '"';
const QUOT = '"';
const raquo = "»";
const reg = "®";
const REG = "®";
const sect = "§";
const shy = "­";
const sup1 = "¹";
const sup2 = "²";
const sup3 = "³";
const szlig = "ß";
const THORN = "Þ";
const thorn = "þ";
const times = "×";
const Uacute = "Ú";
const uacute = "ú";
const Ucirc = "Û";
const ucirc = "û";
const Ugrave = "Ù";
const ugrave = "ù";
const uml = "¨";
const Uuml = "Ü";
const uuml = "ü";
const Yacute = "Ý";
const yacute = "ý";
const yen = "¥";
const yuml = "ÿ";
const require$$1 = {
  Aacute,
  aacute,
  Acirc,
  acirc,
  acute,
  AElig,
  aelig,
  Agrave,
  agrave,
  amp: amp$1,
  AMP,
  Aring,
  aring,
  Atilde,
  atilde,
  Auml,
  auml,
  brvbar,
  Ccedil,
  ccedil,
  cedil,
  cent,
  copy,
  COPY,
  curren,
  deg,
  divide,
  Eacute,
  eacute,
  Ecirc,
  ecirc,
  Egrave,
  egrave,
  ETH,
  eth,
  Euml,
  euml,
  frac12,
  frac14,
  frac34,
  gt: gt$1,
  GT,
  Iacute,
  iacute,
  Icirc,
  icirc,
  iexcl,
  Igrave,
  igrave,
  iquest,
  Iuml,
  iuml,
  laquo,
  lt: lt$1,
  LT,
  macr,
  micro,
  middot,
  nbsp,
  not,
  Ntilde,
  ntilde,
  Oacute,
  oacute,
  Ocirc,
  ocirc,
  Ograve,
  ograve,
  ordf,
  ordm,
  Oslash,
  oslash,
  Otilde,
  otilde,
  Ouml,
  ouml,
  para,
  plusmn,
  pound,
  quot: quot$1,
  QUOT,
  raquo,
  reg,
  REG,
  sect,
  shy,
  sup1,
  sup2,
  sup3,
  szlig,
  THORN,
  thorn,
  times,
  Uacute,
  uacute,
  Ucirc,
  ucirc,
  Ugrave,
  ugrave,
  uml,
  Uuml,
  uuml,
  Yacute,
  yacute,
  yen,
  yuml
};
const amp = "&";
const apos = "'";
const gt = ">";
const lt = "<";
const quot = '"';
const require$$0$1 = {
  amp,
  apos,
  gt,
  lt,
  quot
};
var decode_codepoint = {};
const require$$0 = {
  "0": 65533,
  "128": 8364,
  "130": 8218,
  "131": 402,
  "132": 8222,
  "133": 8230,
  "134": 8224,
  "135": 8225,
  "136": 710,
  "137": 8240,
  "138": 352,
  "139": 8249,
  "140": 338,
  "142": 381,
  "145": 8216,
  "146": 8217,
  "147": 8220,
  "148": 8221,
  "149": 8226,
  "150": 8211,
  "151": 8212,
  "152": 732,
  "153": 8482,
  "154": 353,
  "155": 8250,
  "156": 339,
  "158": 382,
  "159": 376
};
var __importDefault$2 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(decode_codepoint, "__esModule", { value: true });
var decode_json_1 = __importDefault$2(require$$0);
var fromCodePoint = (
  // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
  String.fromCodePoint || function(codePoint) {
    var output = "";
    if (codePoint > 65535) {
      codePoint -= 65536;
      output += String.fromCharCode(codePoint >>> 10 & 1023 | 55296);
      codePoint = 56320 | codePoint & 1023;
    }
    output += String.fromCharCode(codePoint);
    return output;
  }
);
function decodeCodePoint(codePoint) {
  if (codePoint >= 55296 && codePoint <= 57343 || codePoint > 1114111) {
    return "�";
  }
  if (codePoint in decode_json_1.default) {
    codePoint = decode_json_1.default[codePoint];
  }
  return fromCodePoint(codePoint);
}
decode_codepoint.default = decodeCodePoint;
var __importDefault$1 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(decode, "__esModule", { value: true });
decode.decodeHTML = decode.decodeHTMLStrict = decode.decodeXML = void 0;
var entities_json_1$1 = __importDefault$1(require$$1$1);
var legacy_json_1 = __importDefault$1(require$$1);
var xml_json_1$1 = __importDefault$1(require$$0$1);
var decode_codepoint_1 = __importDefault$1(decode_codepoint);
var strictEntityRe = /&(?:[a-zA-Z0-9]+|#[xX][\da-fA-F]+|#\d+);/g;
decode.decodeXML = getStrictDecoder(xml_json_1$1.default);
decode.decodeHTMLStrict = getStrictDecoder(entities_json_1$1.default);
function getStrictDecoder(map2) {
  var replace = getReplacer(map2);
  return function(str) {
    return String(str).replace(strictEntityRe, replace);
  };
}
var sorter = function(a, b) {
  return a < b ? 1 : -1;
};
decode.decodeHTML = function() {
  var legacy = Object.keys(legacy_json_1.default).sort(sorter);
  var keys = Object.keys(entities_json_1$1.default).sort(sorter);
  for (var i = 0, j = 0; i < keys.length; i++) {
    if (legacy[j] === keys[i]) {
      keys[i] += ";?";
      j++;
    } else {
      keys[i] += ";";
    }
  }
  var re2 = new RegExp("&(?:" + keys.join("|") + "|#[xX][\\da-fA-F]+;?|#\\d+;?)", "g");
  var replace = getReplacer(entities_json_1$1.default);
  function replacer(str) {
    if (str.substr(-1) !== ";")
      str += ";";
    return replace(str);
  }
  return function(str) {
    return String(str).replace(re2, replacer);
  };
}();
function getReplacer(map2) {
  return function replace(str) {
    if (str.charAt(1) === "#") {
      var secondChar = str.charAt(2);
      if (secondChar === "X" || secondChar === "x") {
        return decode_codepoint_1.default(parseInt(str.substr(3), 16));
      }
      return decode_codepoint_1.default(parseInt(str.substr(2), 10));
    }
    return map2[str.slice(1, -1)] || str;
  };
}
var encode = {};
var __importDefault = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(encode, "__esModule", { value: true });
encode.escapeUTF8 = encode.escape = encode.encodeNonAsciiHTML = encode.encodeHTML = encode.encodeXML = void 0;
var xml_json_1 = __importDefault(require$$0$1);
var inverseXML = getInverseObj(xml_json_1.default);
var xmlReplacer = getInverseReplacer(inverseXML);
encode.encodeXML = getASCIIEncoder(inverseXML);
var entities_json_1 = __importDefault(require$$1$1);
var inverseHTML = getInverseObj(entities_json_1.default);
var htmlReplacer = getInverseReplacer(inverseHTML);
encode.encodeHTML = getInverse(inverseHTML, htmlReplacer);
encode.encodeNonAsciiHTML = getASCIIEncoder(inverseHTML);
function getInverseObj(obj) {
  return Object.keys(obj).sort().reduce(function(inverse, name) {
    inverse[obj[name]] = "&" + name + ";";
    return inverse;
  }, {});
}
function getInverseReplacer(inverse) {
  var single = [];
  var multiple = [];
  for (var _i = 0, _a = Object.keys(inverse); _i < _a.length; _i++) {
    var k2 = _a[_i];
    if (k2.length === 1) {
      single.push("\\" + k2);
    } else {
      multiple.push(k2);
    }
  }
  single.sort();
  for (var start = 0; start < single.length - 1; start++) {
    var end = start;
    while (end < single.length - 1 && single[end].charCodeAt(1) + 1 === single[end + 1].charCodeAt(1)) {
      end += 1;
    }
    var count = 1 + end - start;
    if (count < 3)
      continue;
    single.splice(start, count, single[start] + "-" + single[end]);
  }
  multiple.unshift("[" + single.join("") + "]");
  return new RegExp(multiple.join("|"), "g");
}
var reNonASCII = /(?:[\x80-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/g;
var getCodePoint = (
  // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
  String.prototype.codePointAt != null ? (
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    function(str) {
      return str.codePointAt(0);
    }
  ) : (
    // http://mathiasbynens.be/notes/javascript-encoding#surrogate-formulae
    function(c) {
      return (c.charCodeAt(0) - 55296) * 1024 + c.charCodeAt(1) - 56320 + 65536;
    }
  )
);
function singleCharReplacer(c) {
  return "&#x" + (c.length > 1 ? getCodePoint(c) : c.charCodeAt(0)).toString(16).toUpperCase() + ";";
}
function getInverse(inverse, re2) {
  return function(data) {
    return data.replace(re2, function(name) {
      return inverse[name];
    }).replace(reNonASCII, singleCharReplacer);
  };
}
var reEscapeChars = new RegExp(xmlReplacer.source + "|" + reNonASCII.source, "g");
function escape(data) {
  return data.replace(reEscapeChars, singleCharReplacer);
}
encode.escape = escape;
function escapeUTF8(data) {
  return data.replace(xmlReplacer, singleCharReplacer);
}
encode.escapeUTF8 = escapeUTF8;
function getASCIIEncoder(obj) {
  return function(data) {
    return data.replace(reEscapeChars, function(c) {
      return obj[c] || singleCharReplacer(c);
    });
  };
}
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.decodeXMLStrict = exports.decodeHTML5Strict = exports.decodeHTML4Strict = exports.decodeHTML5 = exports.decodeHTML4 = exports.decodeHTMLStrict = exports.decodeHTML = exports.decodeXML = exports.encodeHTML5 = exports.encodeHTML4 = exports.escapeUTF8 = exports.escape = exports.encodeNonAsciiHTML = exports.encodeHTML = exports.encodeXML = exports.encode = exports.decodeStrict = exports.decode = void 0;
  var decode_1 = decode;
  var encode_1 = encode;
  function decode$1(data, level) {
    return (!level || level <= 0 ? decode_1.decodeXML : decode_1.decodeHTML)(data);
  }
  exports.decode = decode$1;
  function decodeStrict(data, level) {
    return (!level || level <= 0 ? decode_1.decodeXML : decode_1.decodeHTMLStrict)(data);
  }
  exports.decodeStrict = decodeStrict;
  function encode$1(data, level) {
    return (!level || level <= 0 ? encode_1.encodeXML : encode_1.encodeHTML)(data);
  }
  exports.encode = encode$1;
  var encode_2 = encode;
  Object.defineProperty(exports, "encodeXML", { enumerable: true, get: function() {
    return encode_2.encodeXML;
  } });
  Object.defineProperty(exports, "encodeHTML", { enumerable: true, get: function() {
    return encode_2.encodeHTML;
  } });
  Object.defineProperty(exports, "encodeNonAsciiHTML", { enumerable: true, get: function() {
    return encode_2.encodeNonAsciiHTML;
  } });
  Object.defineProperty(exports, "escape", { enumerable: true, get: function() {
    return encode_2.escape;
  } });
  Object.defineProperty(exports, "escapeUTF8", { enumerable: true, get: function() {
    return encode_2.escapeUTF8;
  } });
  Object.defineProperty(exports, "encodeHTML4", { enumerable: true, get: function() {
    return encode_2.encodeHTML;
  } });
  Object.defineProperty(exports, "encodeHTML5", { enumerable: true, get: function() {
    return encode_2.encodeHTML;
  } });
  var decode_2 = decode;
  Object.defineProperty(exports, "decodeXML", { enumerable: true, get: function() {
    return decode_2.decodeXML;
  } });
  Object.defineProperty(exports, "decodeHTML", { enumerable: true, get: function() {
    return decode_2.decodeHTML;
  } });
  Object.defineProperty(exports, "decodeHTMLStrict", { enumerable: true, get: function() {
    return decode_2.decodeHTMLStrict;
  } });
  Object.defineProperty(exports, "decodeHTML4", { enumerable: true, get: function() {
    return decode_2.decodeHTML;
  } });
  Object.defineProperty(exports, "decodeHTML5", { enumerable: true, get: function() {
    return decode_2.decodeHTML;
  } });
  Object.defineProperty(exports, "decodeHTML4Strict", { enumerable: true, get: function() {
    return decode_2.decodeHTMLStrict;
  } });
  Object.defineProperty(exports, "decodeHTML5Strict", { enumerable: true, get: function() {
    return decode_2.decodeHTMLStrict;
  } });
  Object.defineProperty(exports, "decodeXMLStrict", { enumerable: true, get: function() {
    return decode_2.decodeXML;
  } });
})(lib);
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _defineProperties(target2, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor)
      descriptor.writable = true;
    Object.defineProperty(target2, descriptor.key, descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps)
    _defineProperties(Constructor.prototype, protoProps);
  if (staticProps)
    _defineProperties(Constructor, staticProps);
  return Constructor;
}
function _createForOfIteratorHelper(o, allowArrayLike) {
  var it2 = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
  if (!it2) {
    if (Array.isArray(o) || (it2 = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
      if (it2)
        o = it2;
      var i = 0;
      var F2 = function F3() {
      };
      return { s: F2, n: function n2() {
        if (i >= o.length)
          return { done: true };
        return { done: false, value: o[i++] };
      }, e: function e(_e) {
        throw _e;
      }, f: F2 };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  var normalCompletion = true, didErr = false, err;
  return { s: function s() {
    it2 = it2.call(o);
  }, n: function n2() {
    var step = it2.next();
    normalCompletion = step.done;
    return step;
  }, e: function e(_e2) {
    didErr = true;
    err = _e2;
  }, f: function f2() {
    try {
      if (!normalCompletion && it2["return"] != null)
        it2["return"]();
    } finally {
      if (didErr)
        throw err;
    }
  } };
}
function _unsupportedIterableToArray(o, minLen) {
  if (!o)
    return;
  if (typeof o === "string")
    return _arrayLikeToArray(o, minLen);
  var n2 = Object.prototype.toString.call(o).slice(8, -1);
  if (n2 === "Object" && o.constructor)
    n2 = o.constructor.name;
  if (n2 === "Map" || n2 === "Set")
    return Array.from(o);
  if (n2 === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n2))
    return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length)
    len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }
  return arr2;
}
var entities = lib;
var defaults = {
  fg: "#FFF",
  bg: "#000",
  newline: false,
  escapeXML: false,
  stream: false,
  colors: getDefaultColors()
};
function getDefaultColors() {
  var colors = {
    0: "#000",
    1: "#A00",
    2: "#0A0",
    3: "#A50",
    4: "#00A",
    5: "#A0A",
    6: "#0AA",
    7: "#AAA",
    8: "#555",
    9: "#F55",
    10: "#5F5",
    11: "#FF5",
    12: "#55F",
    13: "#F5F",
    14: "#5FF",
    15: "#FFF"
  };
  range(0, 5).forEach(function(red) {
    range(0, 5).forEach(function(green) {
      range(0, 5).forEach(function(blue) {
        return setStyleColor(red, green, blue, colors);
      });
    });
  });
  range(0, 23).forEach(function(gray) {
    var c = gray + 232;
    var l2 = toHexString(gray * 10 + 8);
    colors[c] = "#" + l2 + l2 + l2;
  });
  return colors;
}
function setStyleColor(red, green, blue, colors) {
  var c = 16 + red * 36 + green * 6 + blue;
  var r2 = red > 0 ? red * 40 + 55 : 0;
  var g = green > 0 ? green * 40 + 55 : 0;
  var b = blue > 0 ? blue * 40 + 55 : 0;
  colors[c] = toColorHexString([r2, g, b]);
}
function toHexString(num2) {
  var str = num2.toString(16);
  while (str.length < 2) {
    str = "0" + str;
  }
  return str;
}
function toColorHexString(ref) {
  var results = [];
  var _iterator = _createForOfIteratorHelper(ref), _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done; ) {
      var r2 = _step.value;
      results.push(toHexString(r2));
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return "#" + results.join("");
}
function generateOutput(stack, token, data, options) {
  var result;
  if (token === "text") {
    result = pushText(data, options);
  } else if (token === "display") {
    result = handleDisplay(stack, data, options);
  } else if (token === "xterm256Foreground") {
    result = pushForegroundColor(stack, options.colors[data]);
  } else if (token === "xterm256Background") {
    result = pushBackgroundColor(stack, options.colors[data]);
  } else if (token === "rgb") {
    result = handleRgb(stack, data);
  }
  return result;
}
function handleRgb(stack, data) {
  data = data.substring(2).slice(0, -1);
  var operation = +data.substr(0, 2);
  var color = data.substring(5).split(";");
  var rgb = color.map(function(value) {
    return ("0" + Number(value).toString(16)).substr(-2);
  }).join("");
  return pushStyle(stack, (operation === 38 ? "color:#" : "background-color:#") + rgb);
}
function handleDisplay(stack, code, options) {
  code = parseInt(code, 10);
  var codeMap = {
    "-1": function _() {
      return "<br/>";
    },
    0: function _() {
      return stack.length && resetStyles(stack);
    },
    1: function _() {
      return pushTag(stack, "b");
    },
    3: function _() {
      return pushTag(stack, "i");
    },
    4: function _() {
      return pushTag(stack, "u");
    },
    8: function _() {
      return pushStyle(stack, "display:none");
    },
    9: function _() {
      return pushTag(stack, "strike");
    },
    22: function _() {
      return pushStyle(stack, "font-weight:normal;text-decoration:none;font-style:normal");
    },
    23: function _() {
      return closeTag(stack, "i");
    },
    24: function _() {
      return closeTag(stack, "u");
    },
    39: function _() {
      return pushForegroundColor(stack, options.fg);
    },
    49: function _() {
      return pushBackgroundColor(stack, options.bg);
    },
    53: function _() {
      return pushStyle(stack, "text-decoration:overline");
    }
  };
  var result;
  if (codeMap[code]) {
    result = codeMap[code]();
  } else if (4 < code && code < 7) {
    result = pushTag(stack, "blink");
  } else if (29 < code && code < 38) {
    result = pushForegroundColor(stack, options.colors[code - 30]);
  } else if (39 < code && code < 48) {
    result = pushBackgroundColor(stack, options.colors[code - 40]);
  } else if (89 < code && code < 98) {
    result = pushForegroundColor(stack, options.colors[8 + (code - 90)]);
  } else if (99 < code && code < 108) {
    result = pushBackgroundColor(stack, options.colors[8 + (code - 100)]);
  }
  return result;
}
function resetStyles(stack) {
  var stackClone = stack.slice(0);
  stack.length = 0;
  return stackClone.reverse().map(function(tag) {
    return "</" + tag + ">";
  }).join("");
}
function range(low, high) {
  var results = [];
  for (var j = low; j <= high; j++) {
    results.push(j);
  }
  return results;
}
function notCategory(category) {
  return function(e) {
    return (category === null || e.category !== category) && category !== "all";
  };
}
function categoryForCode(code) {
  code = parseInt(code, 10);
  var result = null;
  if (code === 0) {
    result = "all";
  } else if (code === 1) {
    result = "bold";
  } else if (2 < code && code < 5) {
    result = "underline";
  } else if (4 < code && code < 7) {
    result = "blink";
  } else if (code === 8) {
    result = "hide";
  } else if (code === 9) {
    result = "strike";
  } else if (29 < code && code < 38 || code === 39 || 89 < code && code < 98) {
    result = "foreground-color";
  } else if (39 < code && code < 48 || code === 49 || 99 < code && code < 108) {
    result = "background-color";
  }
  return result;
}
function pushText(text, options) {
  if (options.escapeXML) {
    return entities.encodeXML(text);
  }
  return text;
}
function pushTag(stack, tag, style) {
  if (!style) {
    style = "";
  }
  stack.push(tag);
  return "<".concat(tag).concat(style ? ' style="'.concat(style, '"') : "", ">");
}
function pushStyle(stack, style) {
  return pushTag(stack, "span", style);
}
function pushForegroundColor(stack, color) {
  return pushTag(stack, "span", "color:" + color);
}
function pushBackgroundColor(stack, color) {
  return pushTag(stack, "span", "background-color:" + color);
}
function closeTag(stack, style) {
  var last;
  if (stack.slice(-1)[0] === style) {
    last = stack.pop();
  }
  if (last) {
    return "</" + style + ">";
  }
}
function tokenize(text, options, callback) {
  var ansiMatch = false;
  var ansiHandler = 3;
  function remove() {
    return "";
  }
  function removeXterm256Foreground(m2, g1) {
    callback("xterm256Foreground", g1);
    return "";
  }
  function removeXterm256Background(m2, g1) {
    callback("xterm256Background", g1);
    return "";
  }
  function newline2(m2) {
    if (options.newline) {
      callback("display", -1);
    } else {
      callback("text", m2);
    }
    return "";
  }
  function ansiMess(m2, g1) {
    ansiMatch = true;
    if (g1.trim().length === 0) {
      g1 = "0";
    }
    g1 = g1.trimRight(";").split(";");
    var _iterator2 = _createForOfIteratorHelper(g1), _step2;
    try {
      for (_iterator2.s(); !(_step2 = _iterator2.n()).done; ) {
        var g = _step2.value;
        callback("display", g);
      }
    } catch (err) {
      _iterator2.e(err);
    } finally {
      _iterator2.f();
    }
    return "";
  }
  function realText(m2) {
    callback("text", m2);
    return "";
  }
  function rgb(m2) {
    callback("rgb", m2);
    return "";
  }
  var tokens = [{
    pattern: /^\x08+/,
    sub: remove
  }, {
    pattern: /^\x1b\[[012]?K/,
    sub: remove
  }, {
    pattern: /^\x1b\[\(B/,
    sub: remove
  }, {
    pattern: /^\x1b\[[34]8;2;\d+;\d+;\d+m/,
    sub: rgb
  }, {
    pattern: /^\x1b\[38;5;(\d+)m/,
    sub: removeXterm256Foreground
  }, {
    pattern: /^\x1b\[48;5;(\d+)m/,
    sub: removeXterm256Background
  }, {
    pattern: /^\n/,
    sub: newline2
  }, {
    pattern: /^\r+\n/,
    sub: newline2
  }, {
    pattern: /^\r/,
    sub: newline2
  }, {
    pattern: /^\x1b\[((?:\d{1,3};?)+|)m/,
    sub: ansiMess
  }, {
    // CSI n J
    // ED - Erase in Display Clears part of the screen.
    // If n is 0 (or missing), clear from cursor to end of screen.
    // If n is 1, clear from cursor to beginning of the screen.
    // If n is 2, clear entire screen (and moves cursor to upper left on DOS ANSI.SYS).
    // If n is 3, clear entire screen and delete all lines saved in the scrollback buffer
    //   (this feature was added for xterm and is supported by other terminal applications).
    pattern: /^\x1b\[\d?J/,
    sub: remove
  }, {
    // CSI n ; m f
    // HVP - Horizontal Vertical Position Same as CUP
    pattern: /^\x1b\[\d{0,3};\d{0,3}f/,
    sub: remove
  }, {
    // catch-all for CSI sequences?
    pattern: /^\x1b\[?[\d;]{0,3}/,
    sub: remove
  }, {
    /**
     * extracts real text - not containing:
     * - `\x1b' - ESC - escape (Ascii 27)
     * - '\x08' - BS - backspace (Ascii 8)
     * - `\n` - Newline - linefeed (LF) (ascii 10)
     * - `\r` - Windows Carriage Return (CR)
     */
    pattern: /^(([^\x1b\x08\r\n])+)/,
    sub: realText
  }];
  function process(handler2, i2) {
    if (i2 > ansiHandler && ansiMatch) {
      return;
    }
    ansiMatch = false;
    text = text.replace(handler2.pattern, handler2.sub);
  }
  var results1 = [];
  var _text = text, length = _text.length;
  outer:
    while (length > 0) {
      for (var i = 0, o = 0, len = tokens.length; o < len; i = ++o) {
        var handler = tokens[i];
        process(handler, i);
        if (text.length !== length) {
          length = text.length;
          continue outer;
        }
      }
      if (text.length === length) {
        break;
      }
      results1.push(0);
      length = text.length;
    }
  return results1;
}
function updateStickyStack(stickyStack, token, data) {
  if (token !== "text") {
    stickyStack = stickyStack.filter(notCategory(categoryForCode(data)));
    stickyStack.push({
      token,
      data,
      category: categoryForCode(data)
    });
  }
  return stickyStack;
}
var Filter = /* @__PURE__ */ function() {
  function Filter2(options) {
    _classCallCheck(this, Filter2);
    options = options || {};
    if (options.colors) {
      options.colors = Object.assign({}, defaults.colors, options.colors);
    }
    this.options = Object.assign({}, defaults, options);
    this.stack = [];
    this.stickyStack = [];
  }
  _createClass(Filter2, [{
    key: "toHtml",
    value: function toHtml(input) {
      var _this = this;
      input = typeof input === "string" ? [input] : input;
      var stack = this.stack, options = this.options;
      var buf = [];
      this.stickyStack.forEach(function(element) {
        var output = generateOutput(stack, element.token, element.data, options);
        if (output) {
          buf.push(output);
        }
      });
      tokenize(input.join(""), options, function(token, data) {
        var output = generateOutput(stack, token, data, options);
        if (output) {
          buf.push(output);
        }
        if (options.stream) {
          _this.stickyStack = updateStickyStack(_this.stickyStack, token, data);
        }
      });
      if (stack.length) {
        buf.push(resetStyles(stack));
      }
      return buf.join("");
    }
  }]);
  return Filter2;
}();
var ansi_to_html = Filter;
const ansi2html = /* @__PURE__ */ getDefaultExportFromCjs(ansi_to_html);
const errorMessage = "";
const ErrorMessage = ({ error }) => {
  const html = reactExports.useMemo(() => ansi2htmlMarkup(error), [error]);
  return /* @__PURE__ */ jsx("div", { className: "error-message", dangerouslySetInnerHTML: { __html: html || "" } });
};
function ansi2htmlMarkup(text) {
  const config = {
    bg: "var(--vscode-panel-background)",
    fg: "var(--vscode-foreground)"
  };
  config.colors = ansiColors;
  return new ansi2html(config).toHtml(escapeHTML(text));
}
const ansiColors = {
  0: "#000",
  1: "#C00",
  2: "#0C0",
  3: "#C50",
  4: "#00C",
  5: "#C0C",
  6: "#0CC",
  7: "#CCC",
  8: "#555",
  9: "#F55",
  10: "#5F5",
  11: "#FF5",
  12: "#55F",
  13: "#F5F",
  14: "#5FF",
  15: "#FFF"
};
function escapeHTML(text) {
  return text.replace(/[&"<>]/g, (c) => ({ "&": "&amp;", '"': "&quot;", "<": "&lt;", ">": "&gt;" })[c]);
}
const CallTab = ({ action, sdkLanguage }) => {
  var _a;
  if (!action)
    return null;
  const logs = action.log;
  const error = (_a = action.error) == null ? void 0 : _a.message;
  const params = { ...action.params };
  delete params.info;
  const paramKeys = Object.keys(params);
  const wallTime = action.wallTime ? new Date(action.wallTime).toLocaleString() : null;
  const duration = action.endTime ? msToString(action.endTime - action.startTime) : "Timed Out";
  return /* @__PURE__ */ jsxs("div", { className: "call-tab", children: [
    !!error && /* @__PURE__ */ jsx(ErrorMessage, { error }),
    !!error && /* @__PURE__ */ jsx("div", { className: "call-section", children: "Call" }),
    /* @__PURE__ */ jsx("div", { className: "call-line", children: action.apiName }),
    /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("div", { className: "call-section", children: "Time" }),
      wallTime && /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
        "wall time:",
        /* @__PURE__ */ jsx("span", { className: "call-value datetime", title: wallTime, children: wallTime })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
        "duration:",
        /* @__PURE__ */ jsx("span", { className: "call-value datetime", title: duration, children: duration })
      ] })
    ] }),
    !!paramKeys.length && /* @__PURE__ */ jsx("div", { className: "call-section", children: "Parameters" }),
    !!paramKeys.length && paramKeys.map((name, index) => renderProperty(propertyToString(action, name, params[name], sdkLanguage), "param-" + index)),
    !!action.result && /* @__PURE__ */ jsx("div", { className: "call-section", children: "Return value" }),
    !!action.result && Object.keys(action.result).map(
      (name, index) => renderProperty(propertyToString(action, name, action.result[name], sdkLanguage), "result-" + index)
    ),
    /* @__PURE__ */ jsx("div", { className: "call-section", children: "Log" }),
    logs.map((logLine, index) => {
      return /* @__PURE__ */ jsx("div", { className: "call-line", children: logLine }, index);
    })
  ] });
};
function renderProperty(property, key) {
  let text = property.text.replace(/\n/g, "↵");
  if (property.type === "string")
    text = `"${text}"`;
  return /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
    property.name,
    ":",
    /* @__PURE__ */ jsx("span", { className: `call-value ${property.type}`, title: property.text, children: text }),
    ["string", "number", "object", "locator"].includes(property.type) && /* @__PURE__ */ jsx(CopyToClipboard, { value: property.text })
  ] }, key);
}
function propertyToString(event, name, value, sdkLanguage) {
  const isEval = event.method.includes("eval") || event.method === "waitForFunction";
  if (name === "files")
    return { text: "<files>", type: "string", name };
  if (name === "eventInit" || name === "expectedValue" || name === "arg" && isEval)
    value = parseSerializedValue(value.value, new Array(10).fill({ handle: "<handle>" }));
  if (name === "value" && isEval || name === "received" && event.method === "expect")
    value = parseSerializedValue(value, new Array(10).fill({ handle: "<handle>" }));
  if (name === "selector")
    return { text: asLocator(
      sdkLanguage || "javascript",
      event.params.selector,
      false,
      true
      /* playSafe */
    ), type: "locator", name: "locator" };
  const type = typeof value;
  if (type !== "object" || value === null)
    return { text: String(value), type, name };
  if (value.guid)
    return { text: "<handle>", type: "handle", name };
  return { text: JSON.stringify(value).slice(0, 1e3), type: "object", name };
}
function parseSerializedValue(value, handles) {
  if (value.n !== void 0)
    return value.n;
  if (value.s !== void 0)
    return value.s;
  if (value.b !== void 0)
    return value.b;
  if (value.v !== void 0) {
    if (value.v === "undefined")
      return void 0;
    if (value.v === "null")
      return null;
    if (value.v === "NaN")
      return NaN;
    if (value.v === "Infinity")
      return Infinity;
    if (value.v === "-Infinity")
      return -Infinity;
    if (value.v === "-0")
      return -0;
  }
  if (value.d !== void 0)
    return new Date(value.d);
  if (value.r !== void 0)
    return new RegExp(value.r.p, value.r.f);
  if (value.a !== void 0)
    return value.a.map((a) => parseSerializedValue(a, handles));
  if (value.o !== void 0) {
    const result = {};
    for (const { k: k2, v: v2 } of value.o)
      result[k2] = parseSerializedValue(v2, handles);
    return result;
  }
  if (value.h !== void 0) {
    if (handles === void 0)
      return "<object>";
    return handles[value.h];
  }
  return "<object>";
}
const consoleTab = "";
const ConsoleTab = ({ action }) => {
  const entries = reactExports.useMemo(() => {
    if (!action)
      return [];
    const entries2 = [];
    const context$1 = context(action);
    for (const event of eventsForAction(action)) {
      if (event.method !== "console" && event.method !== "pageError")
        continue;
      if (event.method === "console") {
        const { guid } = event.params.message;
        entries2.push({ message: context$1.initializers[guid] });
      }
      if (event.method === "pageError")
        entries2.push({ error: event.params.error });
    }
    return entries2;
  }, [action]);
  return /* @__PURE__ */ jsx("div", { className: "console-tab", children: entries.map((entry, index) => {
    const { message, error } = entry;
    if (message) {
      const url = message.location.url;
      const filename = url ? url.substring(url.lastIndexOf("/") + 1) : "<anonymous>";
      return /* @__PURE__ */ jsxs("div", { className: "console-line " + message.type, children: [
        /* @__PURE__ */ jsxs("span", { className: "console-location", children: [
          filename,
          ":",
          message.location.lineNumber
        ] }),
        /* @__PURE__ */ jsx("span", { className: "codicon codicon-" + iconClass(message) }),
        /* @__PURE__ */ jsx("span", { className: "console-line-message", children: message.text })
      ] }, index);
    }
    if (error) {
      const { error: errorObject, value } = error;
      if (errorObject) {
        return /* @__PURE__ */ jsxs("div", { className: "console-line error", children: [
          /* @__PURE__ */ jsx("span", { className: "codicon codicon-error" }),
          /* @__PURE__ */ jsx("span", { className: "console-line-message", children: errorObject.message }),
          /* @__PURE__ */ jsx("div", { className: "console-stack", children: errorObject.stack })
        ] }, index);
      } else {
        return /* @__PURE__ */ jsxs("div", { className: "console-line error", children: [
          /* @__PURE__ */ jsx("span", { className: "codicon codicon-error" }),
          /* @__PURE__ */ jsx("span", { className: "console-line-message", children: String(value) })
        ] }, index);
      }
    }
    return null;
  }) });
};
function iconClass(message) {
  switch (message.type) {
    case "error":
      return "error";
    case "warning":
      return "warning";
  }
  return "blank";
}
const expandable = "";
const Expandable = ({ title, children, setExpanded, expanded }) => {
  return /* @__PURE__ */ jsxs("div", { className: "expandable" + (expanded ? " expanded" : ""), children: [
    /* @__PURE__ */ jsxs("div", { className: "expandable-title", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "codicon codicon-" + (expanded ? "chevron-down" : "chevron-right"),
          style: { cursor: "pointer", color: "var(--vscode-foreground)", marginLeft: "5px" },
          onClick: () => setExpanded(!expanded)
        }
      ),
      title
    ] }),
    expanded && /* @__PURE__ */ jsx("div", { style: { marginLeft: 25 }, children })
  ] });
};
const networkResourceDetails = "";
const NetworkResourceDetails = ({ resource, index, selected, setSelected }) => {
  const [expanded, setExpanded] = reactExports.useState(false);
  const [requestBody, setRequestBody] = reactExports.useState(null);
  const [responseBody, setResponseBody] = reactExports.useState(null);
  reactExports.useEffect(() => {
    setExpanded(false);
    setSelected(-1);
  }, [resource, setSelected]);
  reactExports.useEffect(() => {
    const readResources = async () => {
      if (resource.request.postData) {
        if (resource.request.postData._sha1) {
          const response = await fetch(`sha1/${resource.request.postData._sha1}`);
          const requestResource = await response.text();
          setRequestBody(requestResource);
        } else {
          setRequestBody(resource.request.postData.text);
        }
      }
      if (resource.response.content._sha1) {
        const useBase64 = resource.response.content.mimeType.includes("image");
        const response = await fetch(`sha1/${resource.response.content._sha1}`);
        if (useBase64) {
          const blob = await response.blob();
          const reader = new FileReader();
          const eventPromise = new Promise((f2) => reader.onload = f2);
          reader.readAsDataURL(blob);
          setResponseBody({ dataUrl: (await eventPromise).target.result });
        } else {
          setResponseBody({ text: await response.text() });
        }
      }
    };
    readResources();
  }, [expanded, resource]);
  const { routeStatus, requestContentType, resourceName, contentType } = reactExports.useMemo(() => {
    const routeStatus2 = formatRouteStatus(resource);
    const requestContentTypeHeader = resource.request.headers.find((q2) => q2.name === "Content-Type");
    const requestContentType2 = requestContentTypeHeader ? requestContentTypeHeader.value : "";
    const resourceName2 = resource.request.url.substring(resource.request.url.lastIndexOf("/"));
    let contentType2 = resource.response.content.mimeType;
    const charset = contentType2.match(/^(.*);\s*charset=.*$/);
    if (charset)
      contentType2 = charset[1];
    return { routeStatus: routeStatus2, requestContentType: requestContentType2, resourceName: resourceName2, contentType: contentType2 };
  }, [resource]);
  const renderTitle2 = reactExports.useCallback(() => {
    return /* @__PURE__ */ jsxs("div", { className: "network-request-title", children: [
      routeStatus && /* @__PURE__ */ jsx("div", { className: `network-request-title-status status-route ${routeStatus}`, children: routeStatus }),
      resource.response._failureText && /* @__PURE__ */ jsx("div", { className: "network-request-title-status status-failure", children: resource.response._failureText }),
      !resource.response._failureText && /* @__PURE__ */ jsx("div", { className: "network-request-title-status " + formatStatus(resource.response.status), children: resource.response.status }),
      /* @__PURE__ */ jsx("div", { className: "network-request-title-status", children: resource.request.method }),
      /* @__PURE__ */ jsx("div", { className: "network-request-title-url", children: resourceName }),
      /* @__PURE__ */ jsx("div", { className: "network-request-title-content-type", children: contentType })
    ] });
  }, [contentType, resource, resourceName, routeStatus]);
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: "network-request " + (selected ? "selected" : ""),
      onClick: () => setSelected(index),
      children: /* @__PURE__ */ jsx(Expandable, { expanded, setExpanded, title: renderTitle2(), children: /* @__PURE__ */ jsxs("div", { className: "network-request-details", children: [
        /* @__PURE__ */ jsxs("div", { className: "network-request-details-time", children: [
          resource.time,
          "ms"
        ] }),
        /* @__PURE__ */ jsx("div", { className: "network-request-details-header", children: "URL" }),
        /* @__PURE__ */ jsx("div", { className: "network-request-details-url", children: resource.request.url }),
        /* @__PURE__ */ jsx("div", { className: "network-request-details-header", children: "Request Headers" }),
        /* @__PURE__ */ jsx("div", { className: "network-request-headers", children: resource.request.headers.map((pair) => `${pair.name}: ${pair.value}`).join("\n") }),
        /* @__PURE__ */ jsx("div", { className: "network-request-details-header", children: "Response Headers" }),
        /* @__PURE__ */ jsx("div", { className: "network-request-headers", children: resource.response.headers.map((pair) => `${pair.name}: ${pair.value}`).join("\n") }),
        resource.request.postData ? /* @__PURE__ */ jsx("div", { className: "network-request-details-header", children: "Request Body" }) : "",
        resource.request.postData ? /* @__PURE__ */ jsx("div", { className: "network-request-body", children: formatBody(requestBody, requestContentType) }) : "",
        /* @__PURE__ */ jsx("div", { className: "network-request-details-header", children: "Response Body" }),
        !resource.response.content._sha1 ? /* @__PURE__ */ jsx("div", { className: "network-request-response-body", children: "Response body is not available for this request." }) : "",
        responseBody !== null && responseBody.dataUrl ? /* @__PURE__ */ jsx("img", { draggable: "false", src: responseBody.dataUrl }) : "",
        responseBody !== null && responseBody.text ? /* @__PURE__ */ jsx("div", { className: "network-request-response-body", children: formatBody(responseBody.text, resource.response.content.mimeType) }) : ""
      ] }) })
    }
  );
};
function formatStatus(status) {
  if (status >= 200 && status < 400)
    return "status-success";
  if (status >= 400)
    return "status-failure";
  return "";
}
function formatBody(body, contentType) {
  if (body === null)
    return "Loading...";
  const bodyStr = body;
  if (bodyStr === "")
    return "<Empty>";
  if (contentType.includes("application/json")) {
    try {
      return JSON.stringify(JSON.parse(bodyStr), null, 2);
    } catch (err) {
      return bodyStr;
    }
  }
  if (contentType.includes("application/x-www-form-urlencoded"))
    return decodeURIComponent(bodyStr);
  return bodyStr;
}
function formatRouteStatus(request) {
  if (request._wasAborted)
    return "aborted";
  if (request._wasContinued)
    return "continued";
  if (request._wasFulfilled)
    return "fulfilled";
  if (request._apiRequest)
    return "api";
  return "";
}
const networkTab = "";
const NetworkTab = ({ action }) => {
  const [selected, setSelected] = reactExports.useState(0);
  const resources = action ? resourcesForAction(action) : [];
  return /* @__PURE__ */ jsx("div", { className: "network-tab", children: resources.map((resource, index) => {
    return /* @__PURE__ */ jsx(NetworkResourceDetails, { resource, index, selected: selected === index, setSelected }, index);
  }) });
};
const snapshotTab = "";
const scriptRel = "modulepreload";
const assetsURL = function(dep, importerUrl) {
  return new URL(dep, importerUrl).href;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  if (!deps || deps.length === 0) {
    return baseModule();
  }
  const links = document.getElementsByTagName("link");
  return Promise.all(deps.map((dep) => {
    dep = assetsURL(dep, importerUrl);
    if (dep in seen)
      return;
    seen[dep] = true;
    const isCss = dep.endsWith(".css");
    const cssSelector = isCss ? '[rel="stylesheet"]' : "";
    const isBaseRelative = !!importerUrl;
    if (isBaseRelative) {
      for (let i = links.length - 1; i >= 0; i--) {
        const link2 = links[i];
        if (link2.href === dep && (!isCss || link2.rel === "stylesheet")) {
          return;
        }
      }
    } else if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
      return;
    }
    const link = document.createElement("link");
    link.rel = isCss ? "stylesheet" : scriptRel;
    if (!isCss) {
      link.as = "script";
      link.crossOrigin = "";
    }
    link.href = dep;
    document.head.appendChild(link);
    if (isCss) {
      return new Promise((res, rej) => {
        link.addEventListener("load", res);
        link.addEventListener("error", () => rej(new Error(`Unable to preload CSS for ${dep}`)));
      });
    }
  })).then(() => baseModule());
};
const codeMirrorWrapper = "";
const CodeMirrorWrapper = ({
  text,
  language,
  readOnly,
  highlight,
  revealLine,
  lineNumbers,
  focusOnChange,
  wrapLines,
  onChange
}) => {
  const [measure, codemirrorElement] = useMeasure();
  const [modulePromise] = reactExports.useState(__vitePreload(() => import("./codeMirrorModule-bbff145f.js"), true ? ["./codeMirrorModule-bbff145f.js","../codeMirrorModule.eb494ea9.css"] : void 0, import.meta.url).then((m2) => m2.default));
  const codemirrorRef = reactExports.useRef(null);
  const [codemirror, setCodemirror] = reactExports.useState();
  reactExports.useEffect(() => {
    (async () => {
      var _a, _b;
      const CodeMirror = await modulePromise;
      const element = codemirrorElement.current;
      if (!element)
        return;
      let mode = "javascript";
      if (language === "python")
        mode = "python";
      if (language === "java")
        mode = "text/x-java";
      if (language === "csharp")
        mode = "text/x-csharp";
      if (codemirrorRef.current && mode === codemirrorRef.current.cm.getOption("mode") && !!readOnly === codemirrorRef.current.cm.getOption("readOnly") && lineNumbers === codemirrorRef.current.cm.getOption("lineNumbers") && wrapLines === codemirrorRef.current.cm.getOption("lineWrapping")) {
        return;
      }
      (_b = (_a = codemirrorRef.current) == null ? void 0 : _a.cm) == null ? void 0 : _b.getWrapperElement().remove();
      const cm = CodeMirror(element, {
        value: "",
        mode,
        readOnly: !!readOnly,
        lineNumbers,
        lineWrapping: wrapLines
      });
      codemirrorRef.current = { cm };
      setCodemirror(cm);
      return cm;
    })();
  }, [modulePromise, codemirror, codemirrorElement, language, lineNumbers, wrapLines, readOnly]);
  reactExports.useEffect(() => {
    if (codemirrorRef.current)
      codemirrorRef.current.cm.setSize(measure.width, measure.height);
  }, [measure]);
  reactExports.useLayoutEffect(() => {
    var _a;
    if (!codemirror)
      return;
    let valueChanged = false;
    if (codemirror.getValue() !== text) {
      codemirror.setValue(text);
      valueChanged = true;
      if (focusOnChange) {
        codemirror.execCommand("selectAll");
        codemirror.focus();
      }
    }
    if (valueChanged || JSON.stringify(highlight) !== JSON.stringify(codemirrorRef.current.highlight)) {
      for (const h of codemirrorRef.current.highlight || [])
        codemirror.removeLineClass(h.line - 1, "wrap");
      for (const h of highlight || [])
        codemirror.addLineClass(h.line - 1, "wrap", `source-line-${h.type}`);
      for (const w2 of codemirrorRef.current.widgets || [])
        codemirror.removeLineWidget(w2);
      const widgets = [];
      for (const h of highlight || []) {
        if (h.type !== "error")
          continue;
        const line = (_a = codemirrorRef.current) == null ? void 0 : _a.cm.getLine(h.line - 1);
        if (line) {
          const underlineWidgetElement = document.createElement("div");
          underlineWidgetElement.className = "source-line-error-underline";
          underlineWidgetElement.innerHTML = "&nbsp;".repeat(line.length || 1);
          widgets.push(codemirror.addLineWidget(h.line, underlineWidgetElement, { above: true, coverGutter: false }));
        }
        const errorWidgetElement = document.createElement("div");
        errorWidgetElement.innerHTML = ansi2htmlMarkup(h.message || "");
        errorWidgetElement.className = "source-line-error-widget";
        widgets.push(codemirror.addLineWidget(h.line, errorWidgetElement, { above: true, coverGutter: false }));
      }
      codemirrorRef.current.highlight = highlight;
      codemirrorRef.current.widgets = widgets;
    }
    if (typeof revealLine === "number" && codemirrorRef.current.cm.lineCount() >= revealLine)
      codemirror.scrollIntoView({ line: Math.max(0, revealLine - 1), ch: 0 }, 50);
    let changeListener;
    if (onChange) {
      changeListener = () => onChange(codemirror.getValue());
      codemirror.on("change", changeListener);
    }
    return () => {
      if (changeListener)
        codemirror.off("change", changeListener);
    };
  }, [codemirror, text, highlight, revealLine, focusOnChange, onChange]);
  return /* @__PURE__ */ jsx("div", { className: "cm-wrapper", ref: codemirrorElement });
};
const toolbar = "";
const Toolbar = ({
  noShadow,
  children,
  noMinHeight
}) => {
  return /* @__PURE__ */ jsx("div", { className: "toolbar" + (noShadow ? " no-shadow" : "") + (noMinHeight ? " no-min-height" : ""), children });
};
const XPathEngine = {
  queryAll(root, selector) {
    if (selector.startsWith("/"))
      selector = "." + selector;
    const result = [];
    const document2 = root.ownerDocument || root;
    if (!document2)
      return result;
    const it2 = document2.evaluate(selector, root, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE);
    for (let node = it2.iterateNext(); node; node = it2.iterateNext()) {
      if (node.nodeType === Node.ELEMENT_NODE)
        result.push(node);
    }
    return result;
  }
};
function isInsideScope(scope, element) {
  while (element) {
    if (scope.contains(element))
      return true;
    element = enclosingShadowHost(element);
  }
  return false;
}
function parentElementOrShadowHost(element) {
  if (element.parentElement)
    return element.parentElement;
  if (!element.parentNode)
    return;
  if (element.parentNode.nodeType === 11 && element.parentNode.host)
    return element.parentNode.host;
}
function enclosingShadowRootOrDocument(element) {
  let node = element;
  while (node.parentNode)
    node = node.parentNode;
  if (node.nodeType === 11 || node.nodeType === 9)
    return node;
}
function enclosingShadowHost(element) {
  while (element.parentElement)
    element = element.parentElement;
  return parentElementOrShadowHost(element);
}
function closestCrossShadow(element, css, scope) {
  while (element) {
    const closest = element.closest(css);
    if (scope && closest !== scope && (closest == null ? void 0 : closest.contains(scope)))
      return;
    if (closest)
      return closest;
    element = enclosingShadowHost(element);
  }
}
function getElementComputedStyle(element, pseudo) {
  return element.ownerDocument && element.ownerDocument.defaultView ? element.ownerDocument.defaultView.getComputedStyle(element, pseudo) : void 0;
}
function isElementStyleVisibilityVisible(element, style) {
  style = style ?? getElementComputedStyle(element);
  if (!style)
    return true;
  if (Element.prototype.checkVisibility) {
    if (!element.checkVisibility({ checkOpacity: false, checkVisibilityCSS: false }))
      return false;
  } else {
    const detailsOrSummary = element.closest("details,summary");
    if (detailsOrSummary !== element && (detailsOrSummary == null ? void 0 : detailsOrSummary.nodeName) === "DETAILS" && !detailsOrSummary.open)
      return false;
  }
  if (style.visibility !== "visible")
    return false;
  return true;
}
function isElementVisible(element) {
  const style = getElementComputedStyle(element);
  if (!style)
    return true;
  if (style.display === "contents") {
    for (let child = element.firstChild; child; child = child.nextSibling) {
      if (child.nodeType === 1 && isElementVisible(child))
        return true;
      if (child.nodeType === 3 && isVisibleTextNode(child))
        return true;
    }
    return false;
  }
  if (!isElementStyleVisibilityVisible(element, style))
    return false;
  const rect2 = element.getBoundingClientRect();
  return rect2.width > 0 && rect2.height > 0;
}
function isVisibleTextNode(node) {
  const range2 = node.ownerDocument.createRange();
  range2.selectNode(node);
  const rect2 = range2.getBoundingClientRect();
  return rect2.width > 0 && rect2.height > 0;
}
function hasExplicitAccessibleName(e) {
  return e.hasAttribute("aria-label") || e.hasAttribute("aria-labelledby");
}
const kAncestorPreventingLandmark = "article:not([role]), aside:not([role]), main:not([role]), nav:not([role]), section:not([role]), [role=article], [role=complementary], [role=main], [role=navigation], [role=region]";
const kGlobalAriaAttributes = [
  "aria-atomic",
  "aria-busy",
  "aria-controls",
  "aria-current",
  "aria-describedby",
  "aria-details",
  "aria-disabled",
  "aria-dropeffect",
  "aria-errormessage",
  "aria-flowto",
  "aria-grabbed",
  "aria-haspopup",
  "aria-hidden",
  "aria-invalid",
  "aria-keyshortcuts",
  "aria-label",
  "aria-labelledby",
  "aria-live",
  "aria-owns",
  "aria-relevant",
  "aria-roledescription"
];
function hasGlobalAriaAttribute(e) {
  return kGlobalAriaAttributes.some((a) => e.hasAttribute(a));
}
const kImplicitRoleByTagName = {
  "A": (e) => {
    return e.hasAttribute("href") ? "link" : null;
  },
  "AREA": (e) => {
    return e.hasAttribute("href") ? "link" : null;
  },
  "ARTICLE": () => "article",
  "ASIDE": () => "complementary",
  "BLOCKQUOTE": () => "blockquote",
  "BUTTON": () => "button",
  "CAPTION": () => "caption",
  "CODE": () => "code",
  "DATALIST": () => "listbox",
  "DD": () => "definition",
  "DEL": () => "deletion",
  "DETAILS": () => "group",
  "DFN": () => "term",
  "DIALOG": () => "dialog",
  "DT": () => "term",
  "EM": () => "emphasis",
  "FIELDSET": () => "group",
  "FIGURE": () => "figure",
  "FOOTER": (e) => closestCrossShadow(e, kAncestorPreventingLandmark) ? null : "contentinfo",
  "FORM": (e) => hasExplicitAccessibleName(e) ? "form" : null,
  "H1": () => "heading",
  "H2": () => "heading",
  "H3": () => "heading",
  "H4": () => "heading",
  "H5": () => "heading",
  "H6": () => "heading",
  "HEADER": (e) => closestCrossShadow(e, kAncestorPreventingLandmark) ? null : "banner",
  "HR": () => "separator",
  "HTML": () => "document",
  "IMG": (e) => e.getAttribute("alt") === "" && !hasGlobalAriaAttribute(e) && Number.isNaN(Number(String(e.getAttribute("tabindex")))) ? "presentation" : "img",
  "INPUT": (e) => {
    const type = e.type.toLowerCase();
    if (type === "search")
      return e.hasAttribute("list") ? "combobox" : "searchbox";
    if (["email", "tel", "text", "url", ""].includes(type)) {
      const list = getIdRefs(e, e.getAttribute("list"))[0];
      return list && list.tagName === "DATALIST" ? "combobox" : "textbox";
    }
    if (type === "hidden")
      return "";
    return {
      "button": "button",
      "checkbox": "checkbox",
      "image": "button",
      "number": "spinbutton",
      "radio": "radio",
      "range": "slider",
      "reset": "button",
      "submit": "button"
    }[type] || "textbox";
  },
  "INS": () => "insertion",
  "LI": () => "listitem",
  "MAIN": () => "main",
  "MARK": () => "mark",
  "MATH": () => "math",
  "MENU": () => "list",
  "METER": () => "meter",
  "NAV": () => "navigation",
  "OL": () => "list",
  "OPTGROUP": () => "group",
  "OPTION": () => "option",
  "OUTPUT": () => "status",
  "P": () => "paragraph",
  "PROGRESS": () => "progressbar",
  "SECTION": (e) => hasExplicitAccessibleName(e) ? "region" : null,
  "SELECT": (e) => e.hasAttribute("multiple") || e.size > 1 ? "listbox" : "combobox",
  "STRONG": () => "strong",
  "SUB": () => "subscript",
  "SUP": () => "superscript",
  // For <svg> we default to Chrome behavior:
  // - Chrome reports 'img'.
  // - Firefox reports 'diagram' that is not in official ARIA spec yet.
  // - Safari reports 'no role', but still computes accessible name.
  "SVG": () => "img",
  "TABLE": () => "table",
  "TBODY": () => "rowgroup",
  "TD": (e) => {
    const table = closestCrossShadow(e, "table");
    const role = table ? getExplicitAriaRole(table) : "";
    return role === "grid" || role === "treegrid" ? "gridcell" : "cell";
  },
  "TEXTAREA": () => "textbox",
  "TFOOT": () => "rowgroup",
  "TH": (e) => {
    if (e.getAttribute("scope") === "col")
      return "columnheader";
    if (e.getAttribute("scope") === "row")
      return "rowheader";
    const table = closestCrossShadow(e, "table");
    const role = table ? getExplicitAriaRole(table) : "";
    return role === "grid" || role === "treegrid" ? "gridcell" : "cell";
  },
  "THEAD": () => "rowgroup",
  "TIME": () => "time",
  "TR": () => "row",
  "UL": () => "list"
};
const kPresentationInheritanceParents = {
  "DD": ["DL", "DIV"],
  "DIV": ["DL"],
  "DT": ["DL", "DIV"],
  "LI": ["OL", "UL"],
  "TBODY": ["TABLE"],
  "TD": ["TR"],
  "TFOOT": ["TABLE"],
  "TH": ["TR"],
  "THEAD": ["TABLE"],
  "TR": ["THEAD", "TBODY", "TFOOT", "TABLE"]
};
function getImplicitAriaRole(element) {
  var _a;
  const implicitRole = ((_a = kImplicitRoleByTagName[element.tagName.toUpperCase()]) == null ? void 0 : _a.call(kImplicitRoleByTagName, element)) || "";
  if (!implicitRole)
    return null;
  let ancestor = element;
  while (ancestor) {
    const parent = parentElementOrShadowHost(ancestor);
    const parents = kPresentationInheritanceParents[ancestor.tagName];
    if (!parents || !parent || !parents.includes(parent.tagName))
      break;
    const parentExplicitRole = getExplicitAriaRole(parent);
    if ((parentExplicitRole === "none" || parentExplicitRole === "presentation") && !hasPresentationConflictResolution(parent))
      return parentExplicitRole;
    ancestor = parent;
  }
  return implicitRole;
}
const allRoles = [
  "alert",
  "alertdialog",
  "application",
  "article",
  "banner",
  "blockquote",
  "button",
  "caption",
  "cell",
  "checkbox",
  "code",
  "columnheader",
  "combobox",
  "command",
  "complementary",
  "composite",
  "contentinfo",
  "definition",
  "deletion",
  "dialog",
  "directory",
  "document",
  "emphasis",
  "feed",
  "figure",
  "form",
  "generic",
  "grid",
  "gridcell",
  "group",
  "heading",
  "img",
  "input",
  "insertion",
  "landmark",
  "link",
  "list",
  "listbox",
  "listitem",
  "log",
  "main",
  "marquee",
  "math",
  "meter",
  "menu",
  "menubar",
  "menuitem",
  "menuitemcheckbox",
  "menuitemradio",
  "navigation",
  "none",
  "note",
  "option",
  "paragraph",
  "presentation",
  "progressbar",
  "radio",
  "radiogroup",
  "range",
  "region",
  "roletype",
  "row",
  "rowgroup",
  "rowheader",
  "scrollbar",
  "search",
  "searchbox",
  "section",
  "sectionhead",
  "select",
  "separator",
  "slider",
  "spinbutton",
  "status",
  "strong",
  "structure",
  "subscript",
  "superscript",
  "switch",
  "tab",
  "table",
  "tablist",
  "tabpanel",
  "term",
  "textbox",
  "time",
  "timer",
  "toolbar",
  "tooltip",
  "tree",
  "treegrid",
  "treeitem",
  "widget",
  "window"
];
const abstractRoles = ["command", "composite", "input", "landmark", "range", "roletype", "section", "sectionhead", "select", "structure", "widget", "window"];
const validRoles = allRoles.filter((role) => !abstractRoles.includes(role));
function getExplicitAriaRole(element) {
  const roles = (element.getAttribute("role") || "").split(" ").map((role) => role.trim());
  return roles.find((role) => validRoles.includes(role)) || null;
}
function hasPresentationConflictResolution(element) {
  return !hasGlobalAriaAttribute(element);
}
function getAriaRole(element) {
  const explicitRole = getExplicitAriaRole(element);
  if (!explicitRole)
    return getImplicitAriaRole(element);
  if ((explicitRole === "none" || explicitRole === "presentation") && hasPresentationConflictResolution(element))
    return getImplicitAriaRole(element);
  return explicitRole;
}
function getAriaBoolean(attr) {
  return attr === null ? void 0 : attr.toLowerCase() === "true";
}
function isElementHiddenForAria(element) {
  if (["STYLE", "SCRIPT", "NOSCRIPT", "TEMPLATE"].includes(element.tagName))
    return true;
  const style = getElementComputedStyle(element);
  const isSlot = element.nodeName === "SLOT";
  if ((style == null ? void 0 : style.display) === "contents" && !isSlot) {
    for (let child = element.firstChild; child; child = child.nextSibling) {
      if (child.nodeType === 1 && !isElementHiddenForAria(child))
        return false;
      if (child.nodeType === 3 && isVisibleTextNode(child))
        return false;
    }
    return true;
  }
  const isOptionInsideSelect = element.nodeName === "OPTION" && !!element.closest("select");
  if (!isOptionInsideSelect && !isSlot && !isElementStyleVisibilityVisible(element, style))
    return true;
  return belongsToDisplayNoneOrAriaHiddenOrNonSlotted(element);
}
function belongsToDisplayNoneOrAriaHiddenOrNonSlotted(element) {
  let hidden = cacheIsHidden == null ? void 0 : cacheIsHidden.get(element);
  if (hidden === void 0) {
    hidden = false;
    if (element.parentElement && element.parentElement.shadowRoot && !element.assignedSlot)
      hidden = true;
    if (!hidden) {
      const style = getElementComputedStyle(element);
      hidden = !style || style.display === "none" || getAriaBoolean(element.getAttribute("aria-hidden")) === true;
    }
    if (!hidden) {
      const parent = parentElementOrShadowHost(element);
      if (parent)
        hidden = belongsToDisplayNoneOrAriaHiddenOrNonSlotted(parent);
    }
    cacheIsHidden == null ? void 0 : cacheIsHidden.set(element, hidden);
  }
  return hidden;
}
function getIdRefs(element, ref) {
  if (!ref)
    return [];
  const root = enclosingShadowRootOrDocument(element);
  if (!root)
    return [];
  try {
    const ids = ref.split(" ").filter((id2) => !!id2);
    const set = /* @__PURE__ */ new Set();
    for (const id2 of ids) {
      const firstElement = root.querySelector("#" + CSS.escape(id2));
      if (firstElement)
        set.add(firstElement);
    }
    return [...set];
  } catch (e) {
    return [];
  }
}
function normalizeAccessbileName(s) {
  return s.replace(/\r\n/g, "\n").replace(/\u00A0/g, " ").replace(/\s\s+/g, " ").trim();
}
function queryInAriaOwned(element, selector) {
  const result = [...element.querySelectorAll(selector)];
  for (const owned of getIdRefs(element, element.getAttribute("aria-owns"))) {
    if (owned.matches(selector))
      result.push(owned);
    result.push(...owned.querySelectorAll(selector));
  }
  return result;
}
function getPseudoContent(pseudoStyle) {
  if (!pseudoStyle)
    return "";
  const content = pseudoStyle.content;
  if (content[0] === "'" && content[content.length - 1] === "'" || content[0] === '"' && content[content.length - 1] === '"') {
    const unquoted = content.substring(1, content.length - 1);
    const display = pseudoStyle.display || "inline";
    if (display !== "inline")
      return " " + unquoted + " ";
    return unquoted;
  }
  return "";
}
function getAriaLabelledByElements(element) {
  const ref = element.getAttribute("aria-labelledby");
  if (ref === null)
    return null;
  return getIdRefs(element, ref);
}
function allowsNameFromContent(role, targetDescendant) {
  const alwaysAllowsNameFromContent = ["button", "cell", "checkbox", "columnheader", "gridcell", "heading", "link", "menuitem", "menuitemcheckbox", "menuitemradio", "option", "radio", "row", "rowheader", "switch", "tab", "tooltip", "treeitem"].includes(role);
  const descendantAllowsNameFromContent = targetDescendant && ["", "caption", "code", "contentinfo", "definition", "deletion", "emphasis", "insertion", "list", "listitem", "mark", "none", "paragraph", "presentation", "region", "row", "rowgroup", "section", "strong", "subscript", "superscript", "table", "term", "time"].includes(role);
  return alwaysAllowsNameFromContent || descendantAllowsNameFromContent;
}
function getElementAccessibleName(element, includeHidden) {
  const cache = includeHidden ? cacheAccessibleNameHidden : cacheAccessibleName;
  let accessibleName = cache == null ? void 0 : cache.get(element);
  if (accessibleName === void 0) {
    accessibleName = "";
    const elementProhibitsNaming = ["caption", "code", "definition", "deletion", "emphasis", "generic", "insertion", "mark", "paragraph", "presentation", "strong", "subscript", "suggestion", "superscript", "term", "time"].includes(getAriaRole(element) || "");
    if (!elementProhibitsNaming) {
      accessibleName = normalizeAccessbileName(getElementAccessibleNameInternal(element, {
        includeHidden,
        visitedElements: /* @__PURE__ */ new Set(),
        embeddedInLabelledBy: "none",
        embeddedInLabel: "none",
        embeddedInTextAlternativeElement: false,
        embeddedInTargetElement: "self"
      }));
    }
    cache == null ? void 0 : cache.set(element, accessibleName);
  }
  return accessibleName;
}
function getElementAccessibleNameInternal(element, options) {
  if (options.visitedElements.has(element))
    return "";
  const childOptions = {
    ...options,
    embeddedInLabel: options.embeddedInLabel === "self" ? "descendant" : options.embeddedInLabel,
    embeddedInLabelledBy: options.embeddedInLabelledBy === "self" ? "descendant" : options.embeddedInLabelledBy,
    embeddedInTargetElement: options.embeddedInTargetElement === "self" ? "descendant" : options.embeddedInTargetElement
  };
  if (!options.includeHidden && options.embeddedInLabelledBy !== "self" && isElementHiddenForAria(element)) {
    options.visitedElements.add(element);
    return "";
  }
  const labelledBy = getAriaLabelledByElements(element);
  if (options.embeddedInLabelledBy === "none") {
    const accessibleName = (labelledBy || []).map((ref) => getElementAccessibleNameInternal(ref, {
      ...options,
      embeddedInLabelledBy: "self",
      embeddedInTargetElement: "none",
      embeddedInLabel: "none",
      embeddedInTextAlternativeElement: false
    })).join(" ");
    if (accessibleName)
      return accessibleName;
  }
  const role = getAriaRole(element) || "";
  if (options.embeddedInLabel !== "none" || options.embeddedInLabelledBy !== "none") {
    const isOwnLabel = [...element.labels || []].includes(element);
    const isOwnLabelledBy = (labelledBy || []).includes(element);
    if (!isOwnLabel && !isOwnLabelledBy) {
      if (role === "textbox") {
        options.visitedElements.add(element);
        if (element.tagName === "INPUT" || element.tagName === "TEXTAREA")
          return element.value;
        return element.textContent || "";
      }
      if (["combobox", "listbox"].includes(role)) {
        options.visitedElements.add(element);
        let selectedOptions;
        if (element.tagName === "SELECT") {
          selectedOptions = [...element.selectedOptions];
          if (!selectedOptions.length && element.options.length)
            selectedOptions.push(element.options[0]);
        } else {
          const listbox = role === "combobox" ? queryInAriaOwned(element, "*").find((e) => getAriaRole(e) === "listbox") : element;
          selectedOptions = listbox ? queryInAriaOwned(listbox, '[aria-selected="true"]').filter((e) => getAriaRole(e) === "option") : [];
        }
        return selectedOptions.map((option) => getElementAccessibleNameInternal(option, childOptions)).join(" ");
      }
      if (["progressbar", "scrollbar", "slider", "spinbutton", "meter"].includes(role)) {
        options.visitedElements.add(element);
        if (element.hasAttribute("aria-valuetext"))
          return element.getAttribute("aria-valuetext") || "";
        if (element.hasAttribute("aria-valuenow"))
          return element.getAttribute("aria-valuenow") || "";
        return element.getAttribute("value") || "";
      }
      if (["menu"].includes(role)) {
        options.visitedElements.add(element);
        return "";
      }
    }
  }
  const ariaLabel = element.getAttribute("aria-label") || "";
  if (ariaLabel.trim()) {
    options.visitedElements.add(element);
    return ariaLabel;
  }
  if (!["presentation", "none"].includes(role)) {
    if (element.tagName === "INPUT" && ["button", "submit", "reset"].includes(element.type)) {
      options.visitedElements.add(element);
      const value = element.value || "";
      if (value.trim())
        return value;
      if (element.type === "submit")
        return "Submit";
      if (element.type === "reset")
        return "Reset";
      const title = element.getAttribute("title") || "";
      return title;
    }
    if (element.tagName === "INPUT" && element.type === "image") {
      options.visitedElements.add(element);
      const labels = element.labels || [];
      if (labels.length && options.embeddedInLabelledBy === "none") {
        return [...labels].map((label) => getElementAccessibleNameInternal(label, {
          ...options,
          embeddedInLabel: "self",
          embeddedInTextAlternativeElement: false,
          embeddedInLabelledBy: "none",
          embeddedInTargetElement: "none"
        })).filter((accessibleName) => !!accessibleName).join(" ");
      }
      const alt = element.getAttribute("alt") || "";
      if (alt.trim())
        return alt;
      const title = element.getAttribute("title") || "";
      if (title.trim())
        return title;
      return "Submit";
    }
    if (!labelledBy && element.tagName === "BUTTON") {
      options.visitedElements.add(element);
      const labels = element.labels || [];
      if (labels.length) {
        return [...labels].map((label) => getElementAccessibleNameInternal(label, {
          ...options,
          embeddedInLabel: "self",
          embeddedInTextAlternativeElement: false,
          embeddedInLabelledBy: "none",
          embeddedInTargetElement: "none"
        })).filter((accessibleName) => !!accessibleName).join(" ");
      }
    }
    if (!labelledBy && (element.tagName === "TEXTAREA" || element.tagName === "SELECT" || element.tagName === "INPUT")) {
      options.visitedElements.add(element);
      const labels = element.labels || [];
      if (labels.length) {
        return [...labels].map((label) => getElementAccessibleNameInternal(label, {
          ...options,
          embeddedInLabel: "self",
          embeddedInTextAlternativeElement: false,
          embeddedInLabelledBy: "none",
          embeddedInTargetElement: "none"
        })).filter((accessibleName) => !!accessibleName).join(" ");
      }
      const usePlaceholder = element.tagName === "INPUT" && ["text", "password", "search", "tel", "email", "url"].includes(element.type) || element.tagName === "TEXTAREA";
      const placeholder = element.getAttribute("placeholder") || "";
      const title = element.getAttribute("title") || "";
      if (!usePlaceholder || title)
        return title;
      return placeholder;
    }
    if (!labelledBy && element.tagName === "FIELDSET") {
      options.visitedElements.add(element);
      for (let child = element.firstElementChild; child; child = child.nextElementSibling) {
        if (child.tagName === "LEGEND") {
          return getElementAccessibleNameInternal(child, {
            ...childOptions,
            embeddedInTextAlternativeElement: true
          });
        }
      }
      const title = element.getAttribute("title") || "";
      return title;
    }
    if (!labelledBy && element.tagName === "FIGURE") {
      options.visitedElements.add(element);
      for (let child = element.firstElementChild; child; child = child.nextElementSibling) {
        if (child.tagName === "FIGCAPTION") {
          return getElementAccessibleNameInternal(child, {
            ...childOptions,
            embeddedInTextAlternativeElement: true
          });
        }
      }
      const title = element.getAttribute("title") || "";
      return title;
    }
    if (element.tagName === "IMG") {
      options.visitedElements.add(element);
      const alt = element.getAttribute("alt") || "";
      if (alt.trim())
        return alt;
      const title = element.getAttribute("title") || "";
      return title;
    }
    if (element.tagName === "TABLE") {
      options.visitedElements.add(element);
      for (let child = element.firstElementChild; child; child = child.nextElementSibling) {
        if (child.tagName === "CAPTION") {
          return getElementAccessibleNameInternal(child, {
            ...childOptions,
            embeddedInTextAlternativeElement: true
          });
        }
      }
      const summary = element.getAttribute("summary") || "";
      if (summary)
        return summary;
    }
    if (element.tagName === "AREA") {
      options.visitedElements.add(element);
      const alt = element.getAttribute("alt") || "";
      if (alt.trim())
        return alt;
      const title = element.getAttribute("title") || "";
      return title;
    }
    if (element.tagName.toUpperCase() === "SVG" || element.ownerSVGElement) {
      options.visitedElements.add(element);
      for (let child = element.firstElementChild; child; child = child.nextElementSibling) {
        if (child.tagName.toUpperCase() === "TITLE" && child.ownerSVGElement) {
          return getElementAccessibleNameInternal(child, {
            ...childOptions,
            embeddedInLabelledBy: "self"
          });
        }
      }
    }
    if (element.ownerSVGElement && element.tagName.toUpperCase() === "A") {
      const title = element.getAttribute("xlink:title") || "";
      if (title.trim()) {
        options.visitedElements.add(element);
        return title;
      }
    }
  }
  if (allowsNameFromContent(role, options.embeddedInTargetElement === "descendant") || options.embeddedInLabelledBy !== "none" || options.embeddedInLabel !== "none" || options.embeddedInTextAlternativeElement) {
    options.visitedElements.add(element);
    const tokens = [];
    const visit = (node, skipSlotted) => {
      var _a;
      if (skipSlotted && node.assignedSlot)
        return;
      if (node.nodeType === 1) {
        const display = ((_a = getElementComputedStyle(node)) == null ? void 0 : _a.display) || "inline";
        let token = getElementAccessibleNameInternal(node, childOptions);
        if (display !== "inline" || node.nodeName === "BR")
          token = " " + token + " ";
        tokens.push(token);
      } else if (node.nodeType === 3) {
        tokens.push(node.textContent || "");
      }
    };
    tokens.push(getPseudoContent(getElementComputedStyle(element, "::before")));
    const assignedNodes = element.nodeName === "SLOT" ? element.assignedNodes() : [];
    if (assignedNodes.length) {
      for (const child of assignedNodes)
        visit(child, false);
    } else {
      for (let child = element.firstChild; child; child = child.nextSibling)
        visit(child, true);
      if (element.shadowRoot) {
        for (let child = element.shadowRoot.firstChild; child; child = child.nextSibling)
          visit(child, true);
      }
      for (const owned of getIdRefs(element, element.getAttribute("aria-owns")))
        visit(owned, true);
    }
    tokens.push(getPseudoContent(getElementComputedStyle(element, "::after")));
    const accessibleName = tokens.join("");
    if (accessibleName.trim())
      return accessibleName;
  }
  if (!["presentation", "none"].includes(role) || element.tagName === "IFRAME") {
    options.visitedElements.add(element);
    const title = element.getAttribute("title") || "";
    if (title.trim())
      return title;
  }
  options.visitedElements.add(element);
  return "";
}
const kAriaSelectedRoles = ["gridcell", "option", "row", "tab", "rowheader", "columnheader", "treeitem"];
function getAriaSelected(element) {
  if (element.tagName === "OPTION")
    return element.selected;
  if (kAriaSelectedRoles.includes(getAriaRole(element) || ""))
    return getAriaBoolean(element.getAttribute("aria-selected")) === true;
  return false;
}
const kAriaCheckedRoles = ["checkbox", "menuitemcheckbox", "option", "radio", "switch", "menuitemradio", "treeitem"];
function getAriaChecked(element) {
  const result = getChecked(element, true);
  return result === "error" ? false : result;
}
function getChecked(element, allowMixed) {
  if (allowMixed && element.tagName === "INPUT" && element.indeterminate)
    return "mixed";
  if (element.tagName === "INPUT" && ["checkbox", "radio"].includes(element.type))
    return element.checked;
  if (kAriaCheckedRoles.includes(getAriaRole(element) || "")) {
    const checked = element.getAttribute("aria-checked");
    if (checked === "true")
      return true;
    if (allowMixed && checked === "mixed")
      return "mixed";
    return false;
  }
  return "error";
}
const kAriaPressedRoles = ["button"];
function getAriaPressed(element) {
  if (kAriaPressedRoles.includes(getAriaRole(element) || "")) {
    const pressed = element.getAttribute("aria-pressed");
    if (pressed === "true")
      return true;
    if (pressed === "mixed")
      return "mixed";
  }
  return false;
}
const kAriaExpandedRoles = ["application", "button", "checkbox", "combobox", "gridcell", "link", "listbox", "menuitem", "row", "rowheader", "tab", "treeitem", "columnheader", "menuitemcheckbox", "menuitemradio", "rowheader", "switch"];
function getAriaExpanded(element) {
  if (element.tagName === "DETAILS")
    return element.open;
  if (kAriaExpandedRoles.includes(getAriaRole(element) || "")) {
    const expanded = element.getAttribute("aria-expanded");
    if (expanded === null)
      return "none";
    if (expanded === "true")
      return true;
    return false;
  }
  return "none";
}
const kAriaLevelRoles = ["heading", "listitem", "row", "treeitem"];
function getAriaLevel(element) {
  const native = { "H1": 1, "H2": 2, "H3": 3, "H4": 4, "H5": 5, "H6": 6 }[element.tagName];
  if (native)
    return native;
  if (kAriaLevelRoles.includes(getAriaRole(element) || "")) {
    const attr = element.getAttribute("aria-level");
    const value = attr === null ? Number.NaN : Number(attr);
    if (Number.isInteger(value) && value >= 1)
      return value;
  }
  return 0;
}
const kAriaDisabledRoles = ["application", "button", "composite", "gridcell", "group", "input", "link", "menuitem", "scrollbar", "separator", "tab", "checkbox", "columnheader", "combobox", "grid", "listbox", "menu", "menubar", "menuitemcheckbox", "menuitemradio", "option", "radio", "radiogroup", "row", "rowheader", "searchbox", "select", "slider", "spinbutton", "switch", "tablist", "textbox", "toolbar", "tree", "treegrid", "treeitem"];
function getAriaDisabled(element) {
  const isNativeFormControl = ["BUTTON", "INPUT", "SELECT", "TEXTAREA", "OPTION", "OPTGROUP"].includes(element.tagName);
  if (isNativeFormControl && (element.hasAttribute("disabled") || belongsToDisabledFieldSet(element)))
    return true;
  return hasExplicitAriaDisabled(element);
}
function belongsToDisabledFieldSet(element) {
  if (!element)
    return false;
  if (element.tagName === "FIELDSET" && element.hasAttribute("disabled"))
    return true;
  return belongsToDisabledFieldSet(element.parentElement);
}
function hasExplicitAriaDisabled(element) {
  if (!element)
    return false;
  if (kAriaDisabledRoles.includes(getAriaRole(element) || "")) {
    const attribute = (element.getAttribute("aria-disabled") || "").toLowerCase();
    if (attribute === "true")
      return true;
    if (attribute === "false")
      return false;
  }
  return hasExplicitAriaDisabled(parentElementOrShadowHost(element));
}
let cacheAccessibleName;
let cacheAccessibleNameHidden;
let cacheIsHidden;
let cachesCounter = 0;
function beginAriaCaches() {
  ++cachesCounter;
  cacheAccessibleName ?? (cacheAccessibleName = /* @__PURE__ */ new Map());
  cacheAccessibleNameHidden ?? (cacheAccessibleNameHidden = /* @__PURE__ */ new Map());
  cacheIsHidden ?? (cacheIsHidden = /* @__PURE__ */ new Map());
}
function endAriaCaches() {
  if (!--cachesCounter) {
    cacheAccessibleName = void 0;
    cacheAccessibleNameHidden = void 0;
    cacheIsHidden = void 0;
  }
}
function matchesComponentAttribute(obj, attr) {
  for (const token of attr.jsonPath) {
    if (obj !== void 0 && obj !== null)
      obj = obj[token];
  }
  return matchesAttributePart(obj, attr);
}
function matchesAttributePart(value, attr) {
  const objValue = typeof value === "string" && !attr.caseSensitive ? value.toUpperCase() : value;
  const attrValue = typeof attr.value === "string" && !attr.caseSensitive ? attr.value.toUpperCase() : attr.value;
  if (attr.op === "<truthy>")
    return !!objValue;
  if (attr.op === "=") {
    if (attrValue instanceof RegExp)
      return typeof objValue === "string" && !!objValue.match(attrValue);
    return objValue === attrValue;
  }
  if (typeof objValue !== "string" || typeof attrValue !== "string")
    return false;
  if (attr.op === "*=")
    return objValue.includes(attrValue);
  if (attr.op === "^=")
    return objValue.startsWith(attrValue);
  if (attr.op === "$=")
    return objValue.endsWith(attrValue);
  if (attr.op === "|=")
    return objValue === attrValue || objValue.startsWith(attrValue + "-");
  if (attr.op === "~=")
    return objValue.split(" ").includes(attrValue);
  return false;
}
function shouldSkipForTextMatching(element) {
  const document2 = element.ownerDocument;
  return element.nodeName === "SCRIPT" || element.nodeName === "NOSCRIPT" || element.nodeName === "STYLE" || document2.head && document2.head.contains(element);
}
function elementText(cache, root) {
  let value = cache.get(root);
  if (value === void 0) {
    value = { full: "", immediate: [] };
    if (!shouldSkipForTextMatching(root)) {
      let currentImmediate = "";
      if (root instanceof HTMLInputElement && (root.type === "submit" || root.type === "button")) {
        value = { full: root.value, immediate: [root.value] };
      } else {
        for (let child = root.firstChild; child; child = child.nextSibling) {
          if (child.nodeType === Node.TEXT_NODE) {
            value.full += child.nodeValue || "";
            currentImmediate += child.nodeValue || "";
          } else {
            if (currentImmediate)
              value.immediate.push(currentImmediate);
            currentImmediate = "";
            if (child.nodeType === Node.ELEMENT_NODE)
              value.full += elementText(cache, child).full;
          }
        }
        if (currentImmediate)
          value.immediate.push(currentImmediate);
        if (root.shadowRoot)
          value.full += elementText(cache, root.shadowRoot).full;
      }
    }
    cache.set(root, value);
  }
  return value;
}
function elementMatchesText(cache, element, matcher) {
  if (shouldSkipForTextMatching(element))
    return "none";
  if (!matcher(elementText(cache, element)))
    return "none";
  for (let child = element.firstChild; child; child = child.nextSibling) {
    if (child.nodeType === Node.ELEMENT_NODE && matcher(elementText(cache, child)))
      return "selfAndChildren";
  }
  if (element.shadowRoot && matcher(elementText(cache, element.shadowRoot)))
    return "selfAndChildren";
  return "self";
}
function getElementLabels(textCache, element) {
  const labels = getAriaLabelledByElements(element);
  if (labels)
    return labels.map((label) => elementText(textCache, label));
  const ariaLabel = element.getAttribute("aria-label");
  if (ariaLabel !== null && !!ariaLabel.trim())
    return [{ full: ariaLabel, immediate: [ariaLabel] }];
  const isNonHiddenInput = element.nodeName === "INPUT" && element.type !== "hidden";
  if (["BUTTON", "METER", "OUTPUT", "PROGRESS", "SELECT", "TEXTAREA"].includes(element.nodeName) || isNonHiddenInput) {
    const labels2 = element.labels;
    if (labels2)
      return [...labels2].map((label) => elementText(textCache, label));
  }
  return [];
}
function getFunctionComponentName(component) {
  return component.displayName || component.name || "Anonymous";
}
function getComponentName(reactElement) {
  if (reactElement.type) {
    switch (typeof reactElement.type) {
      case "function":
        return getFunctionComponentName(reactElement.type);
      case "string":
        return reactElement.type;
      case "object":
        return reactElement.type.displayName || (reactElement.type.render ? getFunctionComponentName(reactElement.type.render) : "");
    }
  }
  if (reactElement._currentElement) {
    const elementType = reactElement._currentElement.type;
    if (typeof elementType === "string")
      return elementType;
    if (typeof elementType === "function")
      return elementType.displayName || elementType.name || "Anonymous";
  }
  return "";
}
function getComponentKey(reactElement) {
  var _a;
  return reactElement.key ?? ((_a = reactElement._currentElement) == null ? void 0 : _a.key);
}
function getChildren(reactElement) {
  if (reactElement.child) {
    const children = [];
    for (let child = reactElement.child; child; child = child.sibling)
      children.push(child);
    return children;
  }
  if (!reactElement._currentElement)
    return [];
  const isKnownElement = (reactElement2) => {
    var _a;
    const elementType = (_a = reactElement2._currentElement) == null ? void 0 : _a.type;
    return typeof elementType === "function" || typeof elementType === "string";
  };
  if (reactElement._renderedComponent) {
    const child = reactElement._renderedComponent;
    return isKnownElement(child) ? [child] : [];
  }
  if (reactElement._renderedChildren)
    return [...Object.values(reactElement._renderedChildren)].filter(isKnownElement);
  return [];
}
function getProps(reactElement) {
  var _a;
  const props = (
    // React 16+
    reactElement.memoizedProps || // React 15
    ((_a = reactElement._currentElement) == null ? void 0 : _a.props)
  );
  if (!props || typeof props === "string")
    return props;
  const result = { ...props };
  delete result.children;
  return result;
}
function buildComponentsTree(reactElement) {
  var _a;
  const treeNode = {
    key: getComponentKey(reactElement),
    name: getComponentName(reactElement),
    children: getChildren(reactElement).map(buildComponentsTree),
    rootElements: [],
    props: getProps(reactElement)
  };
  const rootElement = (
    // React 16+
    // @see https://github.com/baruchvlz/resq/blob/5c15a5e04d3f7174087248f5a158c3d6dcc1ec72/src/utils.js#L29
    reactElement.stateNode || // React 15
    reactElement._hostNode || ((_a = reactElement._renderedComponent) == null ? void 0 : _a._hostNode)
  );
  if (rootElement instanceof Element) {
    treeNode.rootElements.push(rootElement);
  } else {
    for (const child of treeNode.children)
      treeNode.rootElements.push(...child.rootElements);
  }
  return treeNode;
}
function filterComponentsTree$1(treeNode, searchFn, result = []) {
  if (searchFn(treeNode))
    result.push(treeNode);
  for (const child of treeNode.children)
    filterComponentsTree$1(child, searchFn, result);
  return result;
}
function findReactRoots(root, roots = []) {
  const document2 = root.ownerDocument || root;
  const walker = document2.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  do {
    const node = walker.currentNode;
    const reactNode = node;
    const rootKey = Object.keys(reactNode).find((key) => key.startsWith("__reactContainer") && reactNode[key] !== null);
    if (rootKey) {
      roots.push(reactNode[rootKey].stateNode.current);
    } else {
      const legacyRootKey = "_reactRootContainer";
      if (reactNode.hasOwnProperty(legacyRootKey) && reactNode[legacyRootKey] !== null) {
        roots.push(reactNode[legacyRootKey]._internalRoot.current);
      }
    }
    if (node instanceof Element && node.hasAttribute("data-reactroot")) {
      for (const key of Object.keys(node)) {
        if (key.startsWith("__reactInternalInstance") || key.startsWith("__reactFiber"))
          roots.push(node[key]);
      }
    }
    const shadowRoot = node instanceof Element ? node.shadowRoot : null;
    if (shadowRoot)
      findReactRoots(shadowRoot, roots);
  } while (walker.nextNode());
  return roots;
}
const ReactEngine = {
  queryAll(scope, selector) {
    const { name, attributes } = parseAttributeSelector(selector, false);
    const reactRoots = findReactRoots(scope.ownerDocument || scope);
    const trees = reactRoots.map((reactRoot) => buildComponentsTree(reactRoot));
    const treeNodes = trees.map((tree) => filterComponentsTree$1(tree, (treeNode) => {
      const props = treeNode.props ?? {};
      if (treeNode.key !== void 0)
        props.key = treeNode.key;
      if (name && treeNode.name !== name)
        return false;
      if (treeNode.rootElements.some((domNode) => !isInsideScope(scope, domNode)))
        return false;
      for (const attr of attributes) {
        if (!matchesComponentAttribute(props, attr))
          return false;
      }
      return true;
    })).flat();
    const allRootElements = /* @__PURE__ */ new Set();
    for (const treeNode of treeNodes) {
      for (const domNode of treeNode.rootElements)
        allRootElements.add(domNode);
    }
    return [...allRootElements];
  }
};
function basename(filename, ext) {
  const normalized = filename.replace(/^[a-zA-Z]:/, "").replace(/\\/g, "/");
  let result = normalized.substring(normalized.lastIndexOf("/") + 1);
  if (ext && result.endsWith(ext))
    result = result.substring(0, result.length - ext.length);
  return result;
}
function toUpper(_, c) {
  return c ? c.toUpperCase() : "";
}
const classifyRE = /(?:^|[-_/])(\w)/g;
const classify = (str) => {
  return str && str.replace(classifyRE, toUpper);
};
function buildComponentsTreeVue3(instance) {
  function getComponentTypeName(options) {
    const name = options.name || options._componentTag || options.__playwright_guessedName;
    if (name)
      return name;
    const file = options.__file;
    if (file)
      return classify(basename(file, ".vue"));
  }
  function saveComponentName(instance2, key) {
    instance2.type.__playwright_guessedName = key;
    return key;
  }
  function getInstanceName(instance2) {
    var _a, _b, _c, _d;
    const name = getComponentTypeName(instance2.type || {});
    if (name)
      return name;
    if (instance2.root === instance2)
      return "Root";
    for (const key in (_b = (_a = instance2.parent) == null ? void 0 : _a.type) == null ? void 0 : _b.components)
      if (((_c = instance2.parent) == null ? void 0 : _c.type.components[key]) === instance2.type)
        return saveComponentName(instance2, key);
    for (const key in (_d = instance2.appContext) == null ? void 0 : _d.components)
      if (instance2.appContext.components[key] === instance2.type)
        return saveComponentName(instance2, key);
    return "Anonymous Component";
  }
  function isBeingDestroyed(instance2) {
    return instance2._isBeingDestroyed || instance2.isUnmounted;
  }
  function isFragment(instance2) {
    return instance2.subTree.type.toString() === "Symbol(Fragment)";
  }
  function getInternalInstanceChildren(subTree) {
    const list = [];
    if (subTree.component)
      list.push(subTree.component);
    if (subTree.suspense)
      list.push(...getInternalInstanceChildren(subTree.suspense.activeBranch));
    if (Array.isArray(subTree.children)) {
      subTree.children.forEach((childSubTree) => {
        if (childSubTree.component)
          list.push(childSubTree.component);
        else
          list.push(...getInternalInstanceChildren(childSubTree));
      });
    }
    return list.filter((child) => {
      var _a;
      return !isBeingDestroyed(child) && !((_a = child.type.devtools) == null ? void 0 : _a.hide);
    });
  }
  function getRootElementsFromComponentInstance(instance2) {
    if (isFragment(instance2))
      return getFragmentRootElements(instance2.subTree);
    return [instance2.subTree.el];
  }
  function getFragmentRootElements(vnode) {
    if (!vnode.children)
      return [];
    const list = [];
    for (let i = 0, l2 = vnode.children.length; i < l2; i++) {
      const childVnode = vnode.children[i];
      if (childVnode.component)
        list.push(...getRootElementsFromComponentInstance(childVnode.component));
      else if (childVnode.el)
        list.push(childVnode.el);
    }
    return list;
  }
  function buildComponentsTree2(instance2) {
    return {
      name: getInstanceName(instance2),
      children: getInternalInstanceChildren(instance2.subTree).map(buildComponentsTree2),
      rootElements: getRootElementsFromComponentInstance(instance2),
      props: instance2.props
    };
  }
  return buildComponentsTree2(instance);
}
function buildComponentsTreeVue2(instance) {
  function getComponentName2(options) {
    const name = options.displayName || options.name || options._componentTag;
    if (name)
      return name;
    const file = options.__file;
    if (file)
      return classify(basename(file, ".vue"));
  }
  function getInstanceName(instance2) {
    const name = getComponentName2(instance2.$options || instance2.fnOptions || {});
    if (name)
      return name;
    return instance2.$root === instance2 ? "Root" : "Anonymous Component";
  }
  function getInternalInstanceChildren(instance2) {
    if (instance2.$children)
      return instance2.$children;
    if (Array.isArray(instance2.subTree.children))
      return instance2.subTree.children.filter((vnode) => !!vnode.component).map((vnode) => vnode.component);
    return [];
  }
  function buildComponentsTree2(instance2) {
    return {
      name: getInstanceName(instance2),
      children: getInternalInstanceChildren(instance2).map(buildComponentsTree2),
      rootElements: [instance2.$el],
      props: instance2._props
    };
  }
  return buildComponentsTree2(instance);
}
function filterComponentsTree(treeNode, searchFn, result = []) {
  if (searchFn(treeNode))
    result.push(treeNode);
  for (const child of treeNode.children)
    filterComponentsTree(child, searchFn, result);
  return result;
}
function findVueRoots(root, roots = []) {
  const document2 = root.ownerDocument || root;
  const walker = document2.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  const vue2Roots = /* @__PURE__ */ new Set();
  do {
    const node = walker.currentNode;
    if (node.__vue__)
      vue2Roots.add(node.__vue__.$root);
    if (node.__vue_app__ && node._vnode && node._vnode.component)
      roots.push({ root: node._vnode.component, version: 3 });
    const shadowRoot = node instanceof Element ? node.shadowRoot : null;
    if (shadowRoot)
      findVueRoots(shadowRoot, roots);
  } while (walker.nextNode());
  for (const vue2root of vue2Roots) {
    roots.push({
      version: 2,
      root: vue2root
    });
  }
  return roots;
}
const VueEngine = {
  queryAll(scope, selector) {
    const document2 = scope.ownerDocument || scope;
    const { name, attributes } = parseAttributeSelector(selector, false);
    const vueRoots = findVueRoots(document2);
    const trees = vueRoots.map((vueRoot) => vueRoot.version === 3 ? buildComponentsTreeVue3(vueRoot.root) : buildComponentsTreeVue2(vueRoot.root));
    const treeNodes = trees.map((tree) => filterComponentsTree(tree, (treeNode) => {
      if (name && treeNode.name !== name)
        return false;
      if (treeNode.rootElements.some((rootElement) => !isInsideScope(scope, rootElement)))
        return false;
      for (const attr of attributes) {
        if (!matchesComponentAttribute(treeNode.props, attr))
          return false;
      }
      return true;
    })).flat();
    const allRootElements = /* @__PURE__ */ new Set();
    for (const treeNode of treeNodes) {
      for (const rootElement of treeNode.rootElements)
        allRootElements.add(rootElement);
    }
    return [...allRootElements];
  }
};
const kSupportedAttributes = ["selected", "checked", "pressed", "expanded", "level", "disabled", "name", "include-hidden"];
kSupportedAttributes.sort();
function validateSupportedRole(attr, roles, role) {
  if (!roles.includes(role))
    throw new Error(`"${attr}" attribute is only supported for roles: ${roles.slice().sort().map((role2) => `"${role2}"`).join(", ")}`);
}
function validateSupportedValues(attr, values) {
  if (attr.op !== "<truthy>" && !values.includes(attr.value))
    throw new Error(`"${attr.name}" must be one of ${values.map((v2) => JSON.stringify(v2)).join(", ")}`);
}
function validateSupportedOp(attr, ops) {
  if (!ops.includes(attr.op))
    throw new Error(`"${attr.name}" does not support "${attr.op}" matcher`);
}
function validateAttributes(attrs, role) {
  const options = { role };
  for (const attr of attrs) {
    switch (attr.name) {
      case "checked": {
        validateSupportedRole(attr.name, kAriaCheckedRoles, role);
        validateSupportedValues(attr, [true, false, "mixed"]);
        validateSupportedOp(attr, ["<truthy>", "="]);
        options.checked = attr.op === "<truthy>" ? true : attr.value;
        break;
      }
      case "pressed": {
        validateSupportedRole(attr.name, kAriaPressedRoles, role);
        validateSupportedValues(attr, [true, false, "mixed"]);
        validateSupportedOp(attr, ["<truthy>", "="]);
        options.pressed = attr.op === "<truthy>" ? true : attr.value;
        break;
      }
      case "selected": {
        validateSupportedRole(attr.name, kAriaSelectedRoles, role);
        validateSupportedValues(attr, [true, false]);
        validateSupportedOp(attr, ["<truthy>", "="]);
        options.selected = attr.op === "<truthy>" ? true : attr.value;
        break;
      }
      case "expanded": {
        validateSupportedRole(attr.name, kAriaExpandedRoles, role);
        validateSupportedValues(attr, [true, false]);
        validateSupportedOp(attr, ["<truthy>", "="]);
        options.expanded = attr.op === "<truthy>" ? true : attr.value;
        break;
      }
      case "level": {
        validateSupportedRole(attr.name, kAriaLevelRoles, role);
        if (typeof attr.value === "string")
          attr.value = +attr.value;
        if (attr.op !== "=" || typeof attr.value !== "number" || Number.isNaN(attr.value))
          throw new Error(`"level" attribute must be compared to a number`);
        options.level = attr.value;
        break;
      }
      case "disabled": {
        validateSupportedValues(attr, [true, false]);
        validateSupportedOp(attr, ["<truthy>", "="]);
        options.disabled = attr.op === "<truthy>" ? true : attr.value;
        break;
      }
      case "name": {
        if (attr.op === "<truthy>")
          throw new Error(`"name" attribute must have a value`);
        if (typeof attr.value !== "string" && !(attr.value instanceof RegExp))
          throw new Error(`"name" attribute must be a string or a regular expression`);
        options.name = attr.value;
        options.nameOp = attr.op;
        options.exact = attr.caseSensitive;
        break;
      }
      case "include-hidden": {
        validateSupportedValues(attr, [true, false]);
        validateSupportedOp(attr, ["<truthy>", "="]);
        options.includeHidden = attr.op === "<truthy>" ? true : attr.value;
        break;
      }
      default: {
        throw new Error(`Unknown attribute "${attr.name}", must be one of ${kSupportedAttributes.map((a) => `"${a}"`).join(", ")}.`);
      }
    }
  }
  return options;
}
function queryRole(scope, options, internal) {
  const result = [];
  const match = (element) => {
    if (getAriaRole(element) !== options.role)
      return;
    if (options.selected !== void 0 && getAriaSelected(element) !== options.selected)
      return;
    if (options.checked !== void 0 && getAriaChecked(element) !== options.checked)
      return;
    if (options.pressed !== void 0 && getAriaPressed(element) !== options.pressed)
      return;
    if (options.expanded !== void 0 && getAriaExpanded(element) !== options.expanded)
      return;
    if (options.level !== void 0 && getAriaLevel(element) !== options.level)
      return;
    if (options.disabled !== void 0 && getAriaDisabled(element) !== options.disabled)
      return;
    if (!options.includeHidden) {
      const isHidden = isElementHiddenForAria(element);
      if (isHidden)
        return;
    }
    if (options.name !== void 0) {
      const accessibleName = normalizeWhiteSpace(getElementAccessibleName(element, !!options.includeHidden));
      if (typeof options.name === "string")
        options.name = normalizeWhiteSpace(options.name);
      if (internal && !options.exact && options.nameOp === "=")
        options.nameOp = "*=";
      if (!matchesAttributePart(accessibleName, { name: "", jsonPath: [], op: options.nameOp || "=", value: options.name, caseSensitive: !!options.exact }))
        return;
    }
    result.push(element);
  };
  const query = (root) => {
    const shadows = [];
    if (root.shadowRoot)
      shadows.push(root.shadowRoot);
    for (const element of root.querySelectorAll("*")) {
      match(element);
      if (element.shadowRoot)
        shadows.push(element.shadowRoot);
    }
    shadows.forEach(query);
  };
  query(scope);
  return result;
}
function createRoleEngine(internal) {
  return {
    queryAll: (scope, selector) => {
      const parsed = parseAttributeSelector(selector, true);
      const role = parsed.name.toLowerCase();
      if (!role)
        throw new Error(`Role must not be empty`);
      const options = validateAttributes(parsed.attributes, role);
      beginAriaCaches();
      try {
        return queryRole(scope, options, internal);
      } finally {
        endAriaCaches();
      }
    }
  };
}
function boxRightOf(box1, box2, maxDistance) {
  const distance = box1.left - box2.right;
  if (distance < 0 || maxDistance !== void 0 && distance > maxDistance)
    return;
  return distance + Math.max(box2.bottom - box1.bottom, 0) + Math.max(box1.top - box2.top, 0);
}
function boxLeftOf(box1, box2, maxDistance) {
  const distance = box2.left - box1.right;
  if (distance < 0 || maxDistance !== void 0 && distance > maxDistance)
    return;
  return distance + Math.max(box2.bottom - box1.bottom, 0) + Math.max(box1.top - box2.top, 0);
}
function boxAbove(box1, box2, maxDistance) {
  const distance = box2.top - box1.bottom;
  if (distance < 0 || maxDistance !== void 0 && distance > maxDistance)
    return;
  return distance + Math.max(box1.left - box2.left, 0) + Math.max(box2.right - box1.right, 0);
}
function boxBelow(box1, box2, maxDistance) {
  const distance = box1.top - box2.bottom;
  if (distance < 0 || maxDistance !== void 0 && distance > maxDistance)
    return;
  return distance + Math.max(box1.left - box2.left, 0) + Math.max(box2.right - box1.right, 0);
}
function boxNear(box1, box2, maxDistance) {
  const kThreshold = maxDistance === void 0 ? 50 : maxDistance;
  let score = 0;
  if (box1.left - box2.right >= 0)
    score += box1.left - box2.right;
  if (box2.left - box1.right >= 0)
    score += box2.left - box1.right;
  if (box2.top - box1.bottom >= 0)
    score += box2.top - box1.bottom;
  if (box1.top - box2.bottom >= 0)
    score += box1.top - box2.bottom;
  return score > kThreshold ? void 0 : score;
}
const kLayoutSelectorNames = ["left-of", "right-of", "above", "below", "near"];
function layoutSelectorScore(name, element, inner, maxDistance) {
  const box = element.getBoundingClientRect();
  const scorer = { "left-of": boxLeftOf, "right-of": boxRightOf, "above": boxAbove, "below": boxBelow, "near": boxNear }[name];
  let bestScore;
  for (const e of inner) {
    if (e === element)
      continue;
    const score = scorer(box, e.getBoundingClientRect(), maxDistance);
    if (score === void 0)
      continue;
    if (bestScore === void 0 || score < bestScore)
      bestScore = score;
  }
  return bestScore;
}
class SelectorEvaluatorImpl {
  constructor(extraEngines) {
    this._engines = /* @__PURE__ */ new Map();
    this._cacheQueryCSS = /* @__PURE__ */ new Map();
    this._cacheMatches = /* @__PURE__ */ new Map();
    this._cacheQuery = /* @__PURE__ */ new Map();
    this._cacheMatchesSimple = /* @__PURE__ */ new Map();
    this._cacheMatchesParents = /* @__PURE__ */ new Map();
    this._cacheCallMatches = /* @__PURE__ */ new Map();
    this._cacheCallQuery = /* @__PURE__ */ new Map();
    this._cacheQuerySimple = /* @__PURE__ */ new Map();
    this._cacheText = /* @__PURE__ */ new Map();
    this._retainCacheCounter = 0;
    for (const [name, engine] of extraEngines)
      this._engines.set(name, engine);
    this._engines.set("not", notEngine);
    this._engines.set("is", isEngine);
    this._engines.set("where", isEngine);
    this._engines.set("has", hasEngine);
    this._engines.set("scope", scopeEngine);
    this._engines.set("light", lightEngine);
    this._engines.set("visible", visibleEngine);
    this._engines.set("text", textEngine);
    this._engines.set("text-is", textIsEngine);
    this._engines.set("text-matches", textMatchesEngine);
    this._engines.set("has-text", hasTextEngine);
    this._engines.set("right-of", createLayoutEngine("right-of"));
    this._engines.set("left-of", createLayoutEngine("left-of"));
    this._engines.set("above", createLayoutEngine("above"));
    this._engines.set("below", createLayoutEngine("below"));
    this._engines.set("near", createLayoutEngine("near"));
    this._engines.set("nth-match", nthMatchEngine);
    const allNames = [...this._engines.keys()];
    allNames.sort();
    const parserNames = [...customCSSNames];
    parserNames.sort();
    if (allNames.join("|") !== parserNames.join("|"))
      throw new Error(`Please keep customCSSNames in sync with evaluator engines: ${allNames.join("|")} vs ${parserNames.join("|")}`);
  }
  begin() {
    ++this._retainCacheCounter;
  }
  end() {
    --this._retainCacheCounter;
    if (!this._retainCacheCounter) {
      this._cacheQueryCSS.clear();
      this._cacheMatches.clear();
      this._cacheQuery.clear();
      this._cacheMatchesSimple.clear();
      this._cacheMatchesParents.clear();
      this._cacheCallMatches.clear();
      this._cacheCallQuery.clear();
      this._cacheQuerySimple.clear();
      this._cacheText.clear();
    }
  }
  _cached(cache, main, rest, cb2) {
    if (!cache.has(main))
      cache.set(main, []);
    const entries = cache.get(main);
    const entry = entries.find((e) => rest.every((value, index) => e.rest[index] === value));
    if (entry)
      return entry.result;
    const result = cb2();
    entries.push({ rest, result });
    return result;
  }
  _checkSelector(s) {
    const wellFormed = typeof s === "object" && s && (Array.isArray(s) || "simples" in s && s.simples.length);
    if (!wellFormed)
      throw new Error(`Malformed selector "${s}"`);
    return s;
  }
  matches(element, s, context2) {
    const selector = this._checkSelector(s);
    this.begin();
    try {
      return this._cached(this._cacheMatches, element, [selector, context2.scope, context2.pierceShadow, context2.originalScope], () => {
        if (Array.isArray(selector))
          return this._matchesEngine(isEngine, element, selector, context2);
        if (this._hasScopeClause(selector))
          context2 = this._expandContextForScopeMatching(context2);
        if (!this._matchesSimple(element, selector.simples[selector.simples.length - 1].selector, context2))
          return false;
        return this._matchesParents(element, selector, selector.simples.length - 2, context2);
      });
    } finally {
      this.end();
    }
  }
  query(context2, s) {
    const selector = this._checkSelector(s);
    this.begin();
    try {
      return this._cached(this._cacheQuery, selector, [context2.scope, context2.pierceShadow, context2.originalScope], () => {
        if (Array.isArray(selector))
          return this._queryEngine(isEngine, context2, selector);
        if (this._hasScopeClause(selector))
          context2 = this._expandContextForScopeMatching(context2);
        const previousScoreMap = this._scoreMap;
        this._scoreMap = /* @__PURE__ */ new Map();
        let elements = this._querySimple(context2, selector.simples[selector.simples.length - 1].selector);
        elements = elements.filter((element) => this._matchesParents(element, selector, selector.simples.length - 2, context2));
        if (this._scoreMap.size) {
          elements.sort((a, b) => {
            const aScore = this._scoreMap.get(a);
            const bScore = this._scoreMap.get(b);
            if (aScore === bScore)
              return 0;
            if (aScore === void 0)
              return 1;
            if (bScore === void 0)
              return -1;
            return aScore - bScore;
          });
        }
        this._scoreMap = previousScoreMap;
        return elements;
      });
    } finally {
      this.end();
    }
  }
  _markScore(element, score) {
    if (this._scoreMap)
      this._scoreMap.set(element, score);
  }
  _hasScopeClause(selector) {
    return selector.simples.some((simple) => simple.selector.functions.some((f2) => f2.name === "scope"));
  }
  _expandContextForScopeMatching(context2) {
    if (context2.scope.nodeType !== 1)
      return context2;
    const scope = parentElementOrShadowHost(context2.scope);
    if (!scope)
      return context2;
    return { ...context2, scope, originalScope: context2.originalScope || context2.scope };
  }
  _matchesSimple(element, simple, context2) {
    return this._cached(this._cacheMatchesSimple, element, [simple, context2.scope, context2.pierceShadow, context2.originalScope], () => {
      if (element === context2.scope)
        return false;
      if (simple.css && !this._matchesCSS(element, simple.css))
        return false;
      for (const func of simple.functions) {
        if (!this._matchesEngine(this._getEngine(func.name), element, func.args, context2))
          return false;
      }
      return true;
    });
  }
  _querySimple(context2, simple) {
    if (!simple.functions.length)
      return this._queryCSS(context2, simple.css || "*");
    return this._cached(this._cacheQuerySimple, simple, [context2.scope, context2.pierceShadow, context2.originalScope], () => {
      let css = simple.css;
      const funcs = simple.functions;
      if (css === "*" && funcs.length)
        css = void 0;
      let elements;
      let firstIndex = -1;
      if (css !== void 0) {
        elements = this._queryCSS(context2, css);
      } else {
        firstIndex = funcs.findIndex((func) => this._getEngine(func.name).query !== void 0);
        if (firstIndex === -1)
          firstIndex = 0;
        elements = this._queryEngine(this._getEngine(funcs[firstIndex].name), context2, funcs[firstIndex].args);
      }
      for (let i = 0; i < funcs.length; i++) {
        if (i === firstIndex)
          continue;
        const engine = this._getEngine(funcs[i].name);
        if (engine.matches !== void 0)
          elements = elements.filter((e) => this._matchesEngine(engine, e, funcs[i].args, context2));
      }
      for (let i = 0; i < funcs.length; i++) {
        if (i === firstIndex)
          continue;
        const engine = this._getEngine(funcs[i].name);
        if (engine.matches === void 0)
          elements = elements.filter((e) => this._matchesEngine(engine, e, funcs[i].args, context2));
      }
      return elements;
    });
  }
  _matchesParents(element, complex, index, context2) {
    if (index < 0)
      return true;
    return this._cached(this._cacheMatchesParents, element, [complex, index, context2.scope, context2.pierceShadow, context2.originalScope], () => {
      const { selector: simple, combinator } = complex.simples[index];
      if (combinator === ">") {
        const parent = parentElementOrShadowHostInContext(element, context2);
        if (!parent || !this._matchesSimple(parent, simple, context2))
          return false;
        return this._matchesParents(parent, complex, index - 1, context2);
      }
      if (combinator === "+") {
        const previousSibling = previousSiblingInContext(element, context2);
        if (!previousSibling || !this._matchesSimple(previousSibling, simple, context2))
          return false;
        return this._matchesParents(previousSibling, complex, index - 1, context2);
      }
      if (combinator === "") {
        let parent = parentElementOrShadowHostInContext(element, context2);
        while (parent) {
          if (this._matchesSimple(parent, simple, context2)) {
            if (this._matchesParents(parent, complex, index - 1, context2))
              return true;
            if (complex.simples[index - 1].combinator === "")
              break;
          }
          parent = parentElementOrShadowHostInContext(parent, context2);
        }
        return false;
      }
      if (combinator === "~") {
        let previousSibling = previousSiblingInContext(element, context2);
        while (previousSibling) {
          if (this._matchesSimple(previousSibling, simple, context2)) {
            if (this._matchesParents(previousSibling, complex, index - 1, context2))
              return true;
            if (complex.simples[index - 1].combinator === "~")
              break;
          }
          previousSibling = previousSiblingInContext(previousSibling, context2);
        }
        return false;
      }
      if (combinator === ">=") {
        let parent = element;
        while (parent) {
          if (this._matchesSimple(parent, simple, context2)) {
            if (this._matchesParents(parent, complex, index - 1, context2))
              return true;
            if (complex.simples[index - 1].combinator === "")
              break;
          }
          parent = parentElementOrShadowHostInContext(parent, context2);
        }
        return false;
      }
      throw new Error(`Unsupported combinator "${combinator}"`);
    });
  }
  _matchesEngine(engine, element, args, context2) {
    if (engine.matches)
      return this._callMatches(engine, element, args, context2);
    if (engine.query)
      return this._callQuery(engine, args, context2).includes(element);
    throw new Error(`Selector engine should implement "matches" or "query"`);
  }
  _queryEngine(engine, context2, args) {
    if (engine.query)
      return this._callQuery(engine, args, context2);
    if (engine.matches)
      return this._queryCSS(context2, "*").filter((element) => this._callMatches(engine, element, args, context2));
    throw new Error(`Selector engine should implement "matches" or "query"`);
  }
  _callMatches(engine, element, args, context2) {
    return this._cached(this._cacheCallMatches, element, [engine, context2.scope, context2.pierceShadow, context2.originalScope, ...args], () => {
      return engine.matches(element, args, context2, this);
    });
  }
  _callQuery(engine, args, context2) {
    return this._cached(this._cacheCallQuery, engine, [context2.scope, context2.pierceShadow, context2.originalScope, ...args], () => {
      return engine.query(context2, args, this);
    });
  }
  _matchesCSS(element, css) {
    return element.matches(css);
  }
  _queryCSS(context2, css) {
    return this._cached(this._cacheQueryCSS, css, [context2.scope, context2.pierceShadow, context2.originalScope], () => {
      let result = [];
      function query(root) {
        result = result.concat([...root.querySelectorAll(css)]);
        if (!context2.pierceShadow)
          return;
        if (root.shadowRoot)
          query(root.shadowRoot);
        for (const element of root.querySelectorAll("*")) {
          if (element.shadowRoot)
            query(element.shadowRoot);
        }
      }
      query(context2.scope);
      return result;
    });
  }
  _getEngine(name) {
    const engine = this._engines.get(name);
    if (!engine)
      throw new Error(`Unknown selector engine "${name}"`);
    return engine;
  }
}
const isEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length === 0)
      throw new Error(`"is" engine expects non-empty selector list`);
    return args.some((selector) => evaluator.matches(element, selector, context2));
  },
  query(context2, args, evaluator) {
    if (args.length === 0)
      throw new Error(`"is" engine expects non-empty selector list`);
    let elements = [];
    for (const arg of args)
      elements = elements.concat(evaluator.query(context2, arg));
    return args.length === 1 ? elements : sortInDOMOrder(elements);
  }
};
const hasEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length === 0)
      throw new Error(`"has" engine expects non-empty selector list`);
    return evaluator.query({ ...context2, scope: element }, args).length > 0;
  }
  // TODO: we can implement efficient "query" by matching "args" and returning
  // all parents/descendants, just have to be careful with the ":scope" matching.
};
const scopeEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length !== 0)
      throw new Error(`"scope" engine expects no arguments`);
    const actualScope = context2.originalScope || context2.scope;
    if (actualScope.nodeType === 9)
      return element === actualScope.documentElement;
    return element === actualScope;
  },
  query(context2, args, evaluator) {
    if (args.length !== 0)
      throw new Error(`"scope" engine expects no arguments`);
    const actualScope = context2.originalScope || context2.scope;
    if (actualScope.nodeType === 9) {
      const root = actualScope.documentElement;
      return root ? [root] : [];
    }
    if (actualScope.nodeType === 1)
      return [actualScope];
    return [];
  }
};
const notEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length === 0)
      throw new Error(`"not" engine expects non-empty selector list`);
    return !evaluator.matches(element, args, context2);
  }
};
const lightEngine = {
  query(context2, args, evaluator) {
    return evaluator.query({ ...context2, pierceShadow: false }, args);
  },
  matches(element, args, context2, evaluator) {
    return evaluator.matches(element, args, { ...context2, pierceShadow: false });
  }
};
const visibleEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length)
      throw new Error(`"visible" engine expects no arguments`);
    return isElementVisible(element);
  }
};
const textEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length !== 1 || typeof args[0] !== "string")
      throw new Error(`"text" engine expects a single string`);
    const text = normalizeWhiteSpace(args[0]).toLowerCase();
    const matcher = (elementText2) => normalizeWhiteSpace(elementText2.full).toLowerCase().includes(text);
    return elementMatchesText(evaluator._cacheText, element, matcher) === "self";
  }
};
const textIsEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length !== 1 || typeof args[0] !== "string")
      throw new Error(`"text-is" engine expects a single string`);
    const text = normalizeWhiteSpace(args[0]);
    const matcher = (elementText2) => {
      if (!text && !elementText2.immediate.length)
        return true;
      return elementText2.immediate.some((s) => normalizeWhiteSpace(s) === text);
    };
    return elementMatchesText(evaluator._cacheText, element, matcher) !== "none";
  }
};
const textMatchesEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length === 0 || typeof args[0] !== "string" || args.length > 2 || args.length === 2 && typeof args[1] !== "string")
      throw new Error(`"text-matches" engine expects a regexp body and optional regexp flags`);
    const re2 = new RegExp(args[0], args.length === 2 ? args[1] : void 0);
    const matcher = (elementText2) => re2.test(elementText2.full);
    return elementMatchesText(evaluator._cacheText, element, matcher) === "self";
  }
};
const hasTextEngine = {
  matches(element, args, context2, evaluator) {
    if (args.length !== 1 || typeof args[0] !== "string")
      throw new Error(`"has-text" engine expects a single string`);
    if (shouldSkipForTextMatching(element))
      return false;
    const text = normalizeWhiteSpace(args[0]).toLowerCase();
    const matcher = (elementText2) => normalizeWhiteSpace(elementText2.full).toLowerCase().includes(text);
    return matcher(elementText(evaluator._cacheText, element));
  }
};
function createLayoutEngine(name) {
  return {
    matches(element, args, context2, evaluator) {
      const maxDistance = args.length && typeof args[args.length - 1] === "number" ? args[args.length - 1] : void 0;
      const queryArgs = maxDistance === void 0 ? args : args.slice(0, args.length - 1);
      if (args.length < 1 + (maxDistance === void 0 ? 0 : 1))
        throw new Error(`"${name}" engine expects a selector list and optional maximum distance in pixels`);
      const inner = evaluator.query(context2, queryArgs);
      const score = layoutSelectorScore(name, element, inner, maxDistance);
      if (score === void 0)
        return false;
      evaluator._markScore(element, score);
      return true;
    }
  };
}
const nthMatchEngine = {
  query(context2, args, evaluator) {
    let index = args[args.length - 1];
    if (args.length < 2)
      throw new Error(`"nth-match" engine expects non-empty selector list and an index argument`);
    if (typeof index !== "number" || index < 1)
      throw new Error(`"nth-match" engine expects a one-based index as the last argument`);
    const elements = isEngine.query(context2, args.slice(0, args.length - 1), evaluator);
    index--;
    return index < elements.length ? [elements[index]] : [];
  }
};
function parentElementOrShadowHostInContext(element, context2) {
  if (element === context2.scope)
    return;
  if (!context2.pierceShadow)
    return element.parentElement || void 0;
  return parentElementOrShadowHost(element);
}
function previousSiblingInContext(element, context2) {
  if (element === context2.scope)
    return;
  return element.previousElementSibling || void 0;
}
function sortInDOMOrder(elements) {
  const elementToEntry = /* @__PURE__ */ new Map();
  const roots = [];
  const result = [];
  function append(element) {
    let entry = elementToEntry.get(element);
    if (entry)
      return entry;
    const parent = parentElementOrShadowHost(element);
    if (parent) {
      const parentEntry = append(parent);
      parentEntry.children.push(element);
    } else {
      roots.push(element);
    }
    entry = { children: [], taken: false };
    elementToEntry.set(element, entry);
    return entry;
  }
  for (const e of elements)
    append(e).taken = true;
  function visit(element) {
    const entry = elementToEntry.get(element);
    if (entry.taken)
      result.push(element);
    if (entry.children.length > 1) {
      const set = new Set(entry.children);
      entry.children = [];
      let child = element.firstElementChild;
      while (child && entry.children.length < set.size) {
        if (set.has(child))
          entry.children.push(child);
        child = child.nextElementSibling;
      }
      child = element.shadowRoot ? element.shadowRoot.firstElementChild : null;
      while (child && entry.children.length < set.size) {
        if (set.has(child))
          entry.children.push(child);
        child = child.nextElementSibling;
      }
    }
    entry.children.forEach(visit);
  }
  roots.forEach(visit);
  return result;
}
const cacheAllowText = /* @__PURE__ */ new Map();
const cacheDisallowText = /* @__PURE__ */ new Map();
const kTextScoreRange = 10;
const kExactPenalty = kTextScoreRange / 2;
const kTestIdScore = 1;
const kOtherTestIdScore = 2;
const kIframeByAttributeScore = 10;
const kBeginPenalizedScore = 50;
const kPlaceholderScore = 100;
const kLabelScore = 120;
const kRoleWithNameScore = 140;
const kAltTextScore = 160;
const kTextScore = 180;
const kTitleScore = 200;
const kTextScoreRegex = 250;
const kPlaceholderScoreExact = kPlaceholderScore + kExactPenalty;
const kLabelScoreExact = kLabelScore + kExactPenalty;
const kRoleWithNameScoreExact = kRoleWithNameScore + kExactPenalty;
const kAltTextScoreExact = kAltTextScore + kExactPenalty;
const kTextScoreExact = kTextScore + kExactPenalty;
const kTitleScoreExact = kTitleScore + kExactPenalty;
const kEndPenalizedScore = 300;
const kCSSIdScore = 500;
const kRoleWithoutNameScore = 510;
const kCSSInputTypeNameScore = 520;
const kCSSTagNameScore = 530;
const kNthScore = 1e4;
const kCSSFallbackScore = 1e7;
function generateSelector(injectedScript, targetElement, options) {
  injectedScript._evaluator.begin();
  beginAriaCaches();
  try {
    targetElement = closestCrossShadow(targetElement, "button,select,input,[role=button],[role=checkbox],[role=radio],a,[role=link]", options.root) || targetElement;
    const targetTokens = generateSelectorFor(injectedScript, targetElement, options);
    const selector = joinTokens(targetTokens);
    const parsedSelector = injectedScript.parseSelector(selector);
    return {
      selector,
      elements: injectedScript.querySelectorAll(parsedSelector, options.root ?? targetElement.ownerDocument)
    };
  } finally {
    cacheAllowText.clear();
    cacheDisallowText.clear();
    endAriaCaches();
    injectedScript._evaluator.end();
  }
}
function filterRegexTokens(textCandidates) {
  return textCandidates.filter((c) => c[0].selector[0] !== "/");
}
function generateSelectorFor(injectedScript, targetElement, options) {
  if (options.root && !isInsideScope(options.root, targetElement))
    throw new Error(`Target element must belong to the root's subtree`);
  if (targetElement === options.root)
    return [{ engine: "css", selector: ":scope", score: 1 }];
  if (targetElement.ownerDocument.documentElement === targetElement)
    return [{ engine: "css", selector: "html", score: 1 }];
  const calculate = (element, allowText) => {
    const allowNthMatch = element === targetElement;
    let textCandidates = allowText ? buildTextCandidates(injectedScript, element, element === targetElement) : [];
    if (element !== targetElement) {
      textCandidates = filterRegexTokens(textCandidates);
    }
    const noTextCandidates = buildNoTextCandidates(injectedScript, element, options).filter((token) => !options.omitInternalEngines || !token.engine.startsWith("internal:")).map((token) => [token]);
    let result = chooseFirstSelector(injectedScript, options.root ?? targetElement.ownerDocument, element, [...textCandidates, ...noTextCandidates], allowNthMatch);
    textCandidates = filterRegexTokens(textCandidates);
    const checkWithText = (textCandidatesToUse) => {
      const allowParentText = allowText && !textCandidatesToUse.length;
      const candidates = [...textCandidatesToUse, ...noTextCandidates].filter((c) => {
        if (!result)
          return true;
        return combineScores(c) < combineScores(result);
      });
      let bestPossibleInParent = candidates[0];
      if (!bestPossibleInParent)
        return;
      for (let parent = parentElementOrShadowHost(element); parent && parent !== options.root; parent = parentElementOrShadowHost(parent)) {
        const parentTokens = calculateCached(parent, allowParentText);
        if (!parentTokens)
          continue;
        if (result && combineScores([...parentTokens, ...bestPossibleInParent]) >= combineScores(result))
          continue;
        bestPossibleInParent = chooseFirstSelector(injectedScript, parent, element, candidates, allowNthMatch);
        if (!bestPossibleInParent)
          return;
        const combined = [...parentTokens, ...bestPossibleInParent];
        if (!result || combineScores(combined) < combineScores(result))
          result = combined;
      }
    };
    checkWithText(textCandidates);
    if (element === targetElement && textCandidates.length)
      checkWithText([]);
    return result;
  };
  const calculateCached = (element, allowText) => {
    const cache = allowText ? cacheAllowText : cacheDisallowText;
    let value = cache.get(element);
    if (value === void 0) {
      value = calculate(element, allowText);
      cache.set(element, value);
    }
    return value;
  };
  return calculateCached(targetElement, true) || cssFallback(injectedScript, targetElement, options);
}
function buildNoTextCandidates(injectedScript, element, options) {
  const candidates = [];
  {
    for (const attr of ["data-testid", "data-test-id", "data-test"]) {
      if (attr !== options.testIdAttributeName && element.getAttribute(attr))
        candidates.push({ engine: "css", selector: `[${attr}=${quoteAttributeValue(element.getAttribute(attr))}]`, score: kOtherTestIdScore });
    }
    const idAttr = element.getAttribute("id");
    if (idAttr && !isGuidLike(idAttr))
      candidates.push({ engine: "css", selector: makeSelectorForId(idAttr), score: kCSSIdScore });
    candidates.push({ engine: "css", selector: cssEscape(element.nodeName.toLowerCase()), score: kCSSTagNameScore });
  }
  if (element.nodeName === "IFRAME") {
    for (const attribute of ["name", "title"]) {
      if (element.getAttribute(attribute))
        candidates.push({ engine: "css", selector: `${cssEscape(element.nodeName.toLowerCase())}[${attribute}=${quoteAttributeValue(element.getAttribute(attribute))}]`, score: kIframeByAttributeScore });
    }
    if (element.getAttribute(options.testIdAttributeName))
      candidates.push({ engine: "css", selector: `[${options.testIdAttributeName}=${quoteAttributeValue(element.getAttribute(options.testIdAttributeName))}]`, score: kTestIdScore });
    penalizeScoreForLength([candidates]);
    return candidates;
  }
  if (element.getAttribute(options.testIdAttributeName))
    candidates.push({ engine: "internal:testid", selector: `[${options.testIdAttributeName}=${escapeForAttributeSelector(element.getAttribute(options.testIdAttributeName), true)}]`, score: kTestIdScore });
  if (element.nodeName === "INPUT" || element.nodeName === "TEXTAREA") {
    const input = element;
    if (input.placeholder) {
      candidates.push({ engine: "internal:attr", selector: `[placeholder=${escapeForAttributeSelector(input.placeholder, false)}]`, score: kPlaceholderScore });
      candidates.push({ engine: "internal:attr", selector: `[placeholder=${escapeForAttributeSelector(input.placeholder, true)}]`, score: kPlaceholderScoreExact });
    }
  }
  const labels = getElementLabels(injectedScript._evaluator._cacheText, element);
  for (const label of labels) {
    const labelText = label.full.trim();
    candidates.push({ engine: "internal:label", selector: escapeForTextSelector(labelText, false), score: kLabelScore });
    candidates.push({ engine: "internal:label", selector: escapeForTextSelector(labelText, true), score: kLabelScoreExact });
  }
  const ariaRole = getAriaRole(element);
  if (ariaRole && !["none", "presentation"].includes(ariaRole))
    candidates.push({ engine: "internal:role", selector: ariaRole, score: kRoleWithoutNameScore });
  if (element.getAttribute("alt") && ["APPLET", "AREA", "IMG", "INPUT"].includes(element.nodeName)) {
    candidates.push({ engine: "internal:attr", selector: `[alt=${escapeForAttributeSelector(element.getAttribute("alt"), false)}]`, score: kAltTextScore });
    candidates.push({ engine: "internal:attr", selector: `[alt=${escapeForAttributeSelector(element.getAttribute("alt"), true)}]`, score: kAltTextScoreExact });
  }
  if (element.getAttribute("name") && ["BUTTON", "FORM", "FIELDSET", "FRAME", "IFRAME", "INPUT", "KEYGEN", "OBJECT", "OUTPUT", "SELECT", "TEXTAREA", "MAP", "META", "PARAM"].includes(element.nodeName))
    candidates.push({ engine: "css", selector: `${cssEscape(element.nodeName.toLowerCase())}[name=${quoteAttributeValue(element.getAttribute("name"))}]`, score: kCSSInputTypeNameScore });
  if (element.getAttribute("title")) {
    candidates.push({ engine: "internal:attr", selector: `[title=${escapeForAttributeSelector(element.getAttribute("title"), false)}]`, score: kTitleScore });
    candidates.push({ engine: "internal:attr", selector: `[title=${escapeForAttributeSelector(element.getAttribute("title"), true)}]`, score: kTitleScoreExact });
  }
  if (["INPUT", "TEXTAREA"].includes(element.nodeName) && element.getAttribute("type") !== "hidden") {
    if (element.getAttribute("type"))
      candidates.push({ engine: "css", selector: `${cssEscape(element.nodeName.toLowerCase())}[type=${quoteAttributeValue(element.getAttribute("type"))}]`, score: kCSSInputTypeNameScore });
  }
  if (["INPUT", "TEXTAREA", "SELECT"].includes(element.nodeName) && element.getAttribute("type") !== "hidden")
    candidates.push({ engine: "css", selector: cssEscape(element.nodeName.toLowerCase()), score: kCSSInputTypeNameScore + 1 });
  penalizeScoreForLength([candidates]);
  return candidates;
}
function buildTextCandidates(injectedScript, element, isTargetNode) {
  if (element.nodeName === "SELECT")
    return [];
  const candidates = [];
  const fullText = normalizeWhiteSpace(elementText(injectedScript._evaluator._cacheText, element).full);
  const text = fullText.substring(0, 80);
  if (text) {
    const escaped = escapeForTextSelector(text, false);
    if (isTargetNode) {
      candidates.push([{ engine: "internal:text", selector: escaped, score: kTextScore }]);
      candidates.push([{ engine: "internal:text", selector: escapeForTextSelector(text, true), score: kTextScoreExact }]);
    }
    const cssToken = { engine: "css", selector: element.nodeName.toLowerCase(), score: kCSSTagNameScore };
    candidates.push([cssToken, { engine: "internal:has-text", selector: escaped, score: kTextScore }]);
    if (fullText.length <= 80)
      candidates.push([cssToken, { engine: "internal:has-text", selector: "/^" + escapeRegExp(fullText) + "$/", score: kTextScoreRegex }]);
  }
  const ariaRole = getAriaRole(element);
  if (ariaRole && !["none", "presentation"].includes(ariaRole)) {
    const ariaName = getElementAccessibleName(element, false);
    if (ariaName) {
      candidates.push([{ engine: "internal:role", selector: `${ariaRole}[name=${escapeForAttributeSelector(ariaName, false)}]`, score: kRoleWithNameScore }]);
      candidates.push([{ engine: "internal:role", selector: `${ariaRole}[name=${escapeForAttributeSelector(ariaName, true)}]`, score: kRoleWithNameScoreExact }]);
    }
  }
  penalizeScoreForLength(candidates);
  return candidates;
}
function makeSelectorForId(id2) {
  return /^[a-zA-Z][a-zA-Z0-9\-\_]+$/.test(id2) ? "#" + id2 : `[id="${cssEscape(id2)}"]`;
}
function cssFallback(injectedScript, targetElement, options) {
  const root = options.root ?? targetElement.ownerDocument;
  const tokens = [];
  function uniqueCSSSelector(prefix) {
    const path = tokens.slice();
    if (prefix)
      path.unshift(prefix);
    const selector = path.join(" > ");
    const parsedSelector = injectedScript.parseSelector(selector);
    const node = injectedScript.querySelector(parsedSelector, root, false);
    return node === targetElement ? selector : void 0;
  }
  function makeStrict(selector) {
    const token = { engine: "css", selector, score: kCSSFallbackScore };
    const parsedSelector = injectedScript.parseSelector(selector);
    const elements = injectedScript.querySelectorAll(parsedSelector, root);
    if (elements.length === 1)
      return [token];
    const nth = { engine: "nth", selector: String(elements.indexOf(targetElement)), score: kNthScore };
    return [token, nth];
  }
  for (let element = targetElement; element && element !== root; element = parentElementOrShadowHost(element)) {
    const nodeName = element.nodeName.toLowerCase();
    let bestTokenForLevel = "";
    if (element.id) {
      const token = makeSelectorForId(element.id);
      const selector = uniqueCSSSelector(token);
      if (selector)
        return makeStrict(selector);
      bestTokenForLevel = token;
    }
    const parent = element.parentNode;
    const classes = [...element.classList];
    for (let i = 0; i < classes.length; ++i) {
      const token = "." + cssEscape(classes.slice(0, i + 1).join("."));
      const selector = uniqueCSSSelector(token);
      if (selector)
        return makeStrict(selector);
      if (!bestTokenForLevel && parent) {
        const sameClassSiblings = parent.querySelectorAll(token);
        if (sameClassSiblings.length === 1)
          bestTokenForLevel = token;
      }
    }
    if (parent) {
      const siblings = [...parent.children];
      const sameTagSiblings = siblings.filter((sibling) => sibling.nodeName.toLowerCase() === nodeName);
      const token = sameTagSiblings.indexOf(element) === 0 ? cssEscape(nodeName) : `${cssEscape(nodeName)}:nth-child(${1 + siblings.indexOf(element)})`;
      const selector = uniqueCSSSelector(token);
      if (selector)
        return makeStrict(selector);
      if (!bestTokenForLevel)
        bestTokenForLevel = token;
    } else if (!bestTokenForLevel) {
      bestTokenForLevel = nodeName;
    }
    tokens.unshift(bestTokenForLevel);
  }
  return makeStrict(uniqueCSSSelector());
}
function quoteAttributeValue(text) {
  return `"${cssEscape(text).replace(/\\ /g, " ")}"`;
}
function penalizeScoreForLength(groups) {
  for (const group of groups) {
    for (const token of group) {
      if (token.score > kBeginPenalizedScore && token.score < kEndPenalizedScore)
        token.score += Math.min(kTextScoreRange, token.selector.length / 10 | 0);
    }
  }
}
function joinTokens(tokens) {
  const parts = [];
  let lastEngine = "";
  for (const { engine, selector } of tokens) {
    if (parts.length && (lastEngine !== "css" || engine !== "css" || selector.startsWith(":nth-match(")))
      parts.push(">>");
    lastEngine = engine;
    if (engine === "css")
      parts.push(selector);
    else
      parts.push(`${engine}=${selector}`);
  }
  return parts.join(" ");
}
function combineScores(tokens) {
  let score = 0;
  for (let i = 0; i < tokens.length; i++)
    score += tokens[i].score * (tokens.length - i);
  return score;
}
function chooseFirstSelector(injectedScript, scope, targetElement, selectors, allowNthMatch) {
  const joined = selectors.map((tokens) => ({ tokens, score: combineScores(tokens) }));
  joined.sort((a, b) => a.score - b.score);
  let bestWithIndex = null;
  for (const { tokens } of joined) {
    const parsedSelector = injectedScript.parseSelector(joinTokens(tokens));
    const result = injectedScript.querySelectorAll(parsedSelector, scope);
    if (result[0] === targetElement && result.length === 1) {
      return tokens;
    }
    const index = result.indexOf(targetElement);
    if (!allowNthMatch || bestWithIndex || index === -1 || result.length > 5)
      continue;
    const nth = { engine: "nth", selector: String(index), score: kNthScore };
    bestWithIndex = [...tokens, nth];
  }
  return bestWithIndex;
}
function isGuidLike(id2) {
  let lastCharacterType;
  let transitionCount = 0;
  for (let i = 0; i < id2.length; ++i) {
    const c = id2[i];
    let characterType;
    if (c === "-" || c === "_")
      continue;
    if (c >= "a" && c <= "z")
      characterType = "lower";
    else if (c >= "A" && c <= "Z")
      characterType = "upper";
    else if (c >= "0" && c <= "9")
      characterType = "digit";
    else
      characterType = "other";
    if (characterType === "lower" && lastCharacterType === "upper") {
      lastCharacterType = characterType;
      continue;
    }
    if (lastCharacterType && lastCharacterType !== characterType)
      ++transitionCount;
    lastCharacterType = characterType;
  }
  return transitionCount >= id2.length / 4;
}
function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
class Highlight {
  constructor(injectedScript) {
    this._highlightEntries = [];
    this._language = "javascript";
    this._injectedScript = injectedScript;
    const document2 = injectedScript.document;
    this._isUnderTest = injectedScript.isUnderTest;
    this._glassPaneElement = document2.createElement("x-pw-glass");
    this._glassPaneElement.style.position = "fixed";
    this._glassPaneElement.style.top = "0";
    this._glassPaneElement.style.right = "0";
    this._glassPaneElement.style.bottom = "0";
    this._glassPaneElement.style.left = "0";
    this._glassPaneElement.style.zIndex = "2147483647";
    this._glassPaneElement.style.pointerEvents = "none";
    this._glassPaneElement.style.display = "flex";
    this._glassPaneElement.style.backgroundColor = "transparent";
    this._actionPointElement = document2.createElement("x-pw-action-point");
    this._actionPointElement.setAttribute("hidden", "true");
    this._glassPaneShadow = this._glassPaneElement.attachShadow({ mode: this._isUnderTest ? "open" : "closed" });
    this._glassPaneShadow.appendChild(this._actionPointElement);
    const styleElement = document2.createElement("style");
    styleElement.textContent = `
        x-pw-tooltip {
          align-items: center;
          backdrop-filter: blur(5px);
          background-color: rgba(0, 0, 0, 0.7);
          border-radius: 2px;
          box-shadow: rgba(0, 0, 0, 0.1) 0px 3.6px 3.7px,
                      rgba(0, 0, 0, 0.15) 0px 12.1px 12.3px,
                      rgba(0, 0, 0, 0.1) 0px -2px 4px,
                      rgba(0, 0, 0, 0.15) 0px -12.1px 24px,
                      rgba(0, 0, 0, 0.25) 0px 54px 55px;
          color: rgb(204, 204, 204);
          display: none;
          font-family: 'Dank Mono', 'Operator Mono', Inconsolata, 'Fira Mono',
                      'SF Mono', Monaco, 'Droid Sans Mono', 'Source Code Pro', monospace;
          font-size: 12.8px;
          font-weight: normal;
          left: 0;
          line-height: 1.5;
          max-width: 600px;
          padding: 3.2px 5.12px 3.2px;
          position: absolute;
          top: 0;
        }
        x-pw-action-point {
          position: absolute;
          width: 20px;
          height: 20px;
          background: red;
          border-radius: 10px;
          pointer-events: none;
          margin: -10px 0 0 -10px;
          z-index: 2;
        }
        *[hidden] {
          display: none !important;
        }
    `;
    this._glassPaneShadow.appendChild(styleElement);
  }
  install() {
    this._injectedScript.document.documentElement.appendChild(this._glassPaneElement);
  }
  setLanguage(language) {
    this._language = language;
  }
  runHighlightOnRaf(selector) {
    if (this._rafRequest)
      cancelAnimationFrame(this._rafRequest);
    this.updateHighlight(this._injectedScript.querySelectorAll(selector, this._injectedScript.document.documentElement), stringifySelector(selector), false);
    this._rafRequest = requestAnimationFrame(() => this.runHighlightOnRaf(selector));
  }
  uninstall() {
    if (this._rafRequest)
      cancelAnimationFrame(this._rafRequest);
    this._glassPaneElement.remove();
  }
  isInstalled() {
    return this._glassPaneElement.parentElement === this._injectedScript.document.documentElement && !this._glassPaneElement.nextElementSibling;
  }
  showActionPoint(x2, y2) {
    this._actionPointElement.style.top = y2 + "px";
    this._actionPointElement.style.left = x2 + "px";
    this._actionPointElement.hidden = false;
    if (this._isUnderTest)
      console.error("Action point for test: " + JSON.stringify({ x: x2, y: y2 }));
  }
  hideActionPoint() {
    this._actionPointElement.hidden = true;
  }
  clearHighlight() {
    var _a, _b;
    for (const entry of this._highlightEntries) {
      (_a = entry.highlightElement) == null ? void 0 : _a.remove();
      (_b = entry.tooltipElement) == null ? void 0 : _b.remove();
    }
    this._highlightEntries = [];
  }
  updateHighlight(elements, selector, isRecording) {
    let color;
    if (isRecording)
      color = "#dc6f6f7f";
    else
      color = elements.length > 1 ? "#f6b26b7f" : "#6fa8dc7f";
    this._innerUpdateHighlight(elements, { color, tooltipText: selector ? asLocator(this._language, selector) : "" });
  }
  maskElements(elements, color) {
    this._innerUpdateHighlight(elements, { color: color ? color : "#F0F" });
  }
  _innerUpdateHighlight(elements, options) {
    if (this._highlightIsUpToDate(elements, options.tooltipText))
      return;
    this.clearHighlight();
    for (let i = 0; i < elements.length; ++i) {
      const highlightElement = this._createHighlightElement();
      this._glassPaneShadow.appendChild(highlightElement);
      let tooltipElement;
      if (options.tooltipText) {
        tooltipElement = this._injectedScript.document.createElement("x-pw-tooltip");
        this._glassPaneShadow.appendChild(tooltipElement);
        const suffix = elements.length > 1 ? ` [${i + 1} of ${elements.length}]` : "";
        tooltipElement.textContent = options.tooltipText + suffix;
        tooltipElement.style.top = "0";
        tooltipElement.style.left = "0";
        tooltipElement.style.display = "flex";
      }
      this._highlightEntries.push({ targetElement: elements[i], tooltipElement, highlightElement, tooltipText: options.tooltipText });
    }
    for (const entry of this._highlightEntries) {
      entry.box = entry.targetElement.getBoundingClientRect();
      if (!entry.tooltipElement)
        continue;
      const tooltipWidth = entry.tooltipElement.offsetWidth;
      const tooltipHeight = entry.tooltipElement.offsetHeight;
      const totalWidth = this._glassPaneElement.offsetWidth;
      const totalHeight = this._glassPaneElement.offsetHeight;
      let anchorLeft = entry.box.left;
      if (anchorLeft + tooltipWidth > totalWidth - 5)
        anchorLeft = totalWidth - tooltipWidth - 5;
      let anchorTop = entry.box.bottom + 5;
      if (anchorTop + tooltipHeight > totalHeight - 5) {
        if (entry.box.top > tooltipHeight + 5) {
          anchorTop = entry.box.top - tooltipHeight - 5;
        } else {
          anchorTop = totalHeight - 5 - tooltipHeight;
        }
      }
      entry.tooltipTop = anchorTop;
      entry.tooltipLeft = anchorLeft;
    }
    for (const entry of this._highlightEntries) {
      if (entry.tooltipElement) {
        entry.tooltipElement.style.top = entry.tooltipTop + "px";
        entry.tooltipElement.style.left = entry.tooltipLeft + "px";
      }
      const box = entry.box;
      entry.highlightElement.style.backgroundColor = options.color;
      entry.highlightElement.style.left = box.x + "px";
      entry.highlightElement.style.top = box.y + "px";
      entry.highlightElement.style.width = box.width + "px";
      entry.highlightElement.style.height = box.height + "px";
      entry.highlightElement.style.display = "block";
      if (this._isUnderTest)
        console.error("Highlight box for test: " + JSON.stringify({ x: box.x, y: box.y, width: box.width, height: box.height }));
    }
  }
  _highlightIsUpToDate(elements, tooltipText) {
    if (elements.length !== this._highlightEntries.length)
      return false;
    for (let i = 0; i < this._highlightEntries.length; ++i) {
      if (tooltipText !== this._highlightEntries[i].tooltipText)
        return false;
      if (elements[i] !== this._highlightEntries[i].targetElement)
        return false;
      const oldBox = this._highlightEntries[i].box;
      if (!oldBox)
        return false;
      const box = elements[i].getBoundingClientRect();
      if (box.top !== oldBox.top || box.right !== oldBox.right || box.bottom !== oldBox.bottom || box.left !== oldBox.left)
        return false;
    }
    return true;
  }
  _createHighlightElement() {
    const highlightElement = this._injectedScript.document.createElement("x-pw-highlight");
    highlightElement.style.position = "absolute";
    highlightElement.style.top = "0";
    highlightElement.style.left = "0";
    highlightElement.style.width = "0";
    highlightElement.style.height = "0";
    highlightElement.style.boxSizing = "border-box";
    return highlightElement;
  }
}
class InjectedScript {
  // eslint-disable-next-line no-restricted-globals
  constructor(window2, isUnderTest, sdkLanguage, testIdAttributeNameForStrictErrorAndConsoleCodegen, stableRafCount, browserName, customEngines) {
    this.onGlobalListenersRemoved = /* @__PURE__ */ new Set();
    this._testIdAttributeNameForStrictErrorAndConsoleCodegen = "data-testid";
    this.window = window2;
    this.document = window2.document;
    this.isUnderTest = isUnderTest;
    this._sdkLanguage = sdkLanguage;
    this._testIdAttributeNameForStrictErrorAndConsoleCodegen = testIdAttributeNameForStrictErrorAndConsoleCodegen;
    this._evaluator = new SelectorEvaluatorImpl(/* @__PURE__ */ new Map());
    this._engines = /* @__PURE__ */ new Map();
    this._engines.set("xpath", XPathEngine);
    this._engines.set("xpath:light", XPathEngine);
    this._engines.set("_react", ReactEngine);
    this._engines.set("_vue", VueEngine);
    this._engines.set("role", createRoleEngine(false));
    this._engines.set("text", this._createTextEngine(true, false));
    this._engines.set("text:light", this._createTextEngine(false, false));
    this._engines.set("id", this._createAttributeEngine("id", true));
    this._engines.set("id:light", this._createAttributeEngine("id", false));
    this._engines.set("data-testid", this._createAttributeEngine("data-testid", true));
    this._engines.set("data-testid:light", this._createAttributeEngine("data-testid", false));
    this._engines.set("data-test-id", this._createAttributeEngine("data-test-id", true));
    this._engines.set("data-test-id:light", this._createAttributeEngine("data-test-id", false));
    this._engines.set("data-test", this._createAttributeEngine("data-test", true));
    this._engines.set("data-test:light", this._createAttributeEngine("data-test", false));
    this._engines.set("css", this._createCSSEngine());
    this._engines.set("nth", { queryAll: () => [] });
    this._engines.set("visible", this._createVisibleEngine());
    this._engines.set("internal:control", this._createControlEngine());
    this._engines.set("internal:has", this._createHasEngine());
    this._engines.set("internal:has-not", this._createHasNotEngine());
    this._engines.set("internal:and", { queryAll: () => [] });
    this._engines.set("internal:or", { queryAll: () => [] });
    this._engines.set("internal:label", this._createInternalLabelEngine());
    this._engines.set("internal:text", this._createTextEngine(true, true));
    this._engines.set("internal:has-text", this._createInternalHasTextEngine());
    this._engines.set("internal:has-not-text", this._createInternalHasNotTextEngine());
    this._engines.set("internal:attr", this._createNamedAttributeEngine());
    this._engines.set("internal:testid", this._createNamedAttributeEngine());
    this._engines.set("internal:role", createRoleEngine(true));
    for (const { name, engine } of customEngines)
      this._engines.set(name, engine);
    this._stableRafCount = stableRafCount;
    this._browserName = browserName;
    this._setupGlobalListenersRemovalDetection();
    this._setupHitTargetInterceptors();
    if (isUnderTest)
      this.window.__injectedScript = this;
  }
  eval(expression) {
    return this.window.eval(expression);
  }
  testIdAttributeNameForStrictErrorAndConsoleCodegen() {
    return this._testIdAttributeNameForStrictErrorAndConsoleCodegen;
  }
  parseSelector(selector) {
    const result = parseSelector(selector);
    visitAllSelectorParts(result, (part2) => {
      if (!this._engines.has(part2.name))
        throw this.createStacklessError(`Unknown engine "${part2.name}" while parsing selector ${selector}`);
    });
    return result;
  }
  generateSelector(targetElement, options) {
    return generateSelector(this, targetElement, { ...options, testIdAttributeName: this._testIdAttributeNameForStrictErrorAndConsoleCodegen }).selector;
  }
  querySelector(selector, root, strict) {
    const result = this.querySelectorAll(selector, root);
    if (strict && result.length > 1)
      throw this.strictModeViolationError(selector, result);
    return result[0];
  }
  _queryNth(elements, part2) {
    const list = [...elements];
    let nth = +part2.body;
    if (nth === -1)
      nth = list.length - 1;
    return new Set(list.slice(nth, nth + 1));
  }
  _queryLayoutSelector(elements, part2, originalRoot) {
    const name = part2.name;
    const body = part2.body;
    const result = [];
    const inner = this.querySelectorAll(body.parsed, originalRoot);
    for (const element of elements) {
      const score = layoutSelectorScore(name, element, inner, body.distance);
      if (score !== void 0)
        result.push({ element, score });
    }
    result.sort((a, b) => a.score - b.score);
    return new Set(result.map((r2) => r2.element));
  }
  querySelectorAll(selector, root) {
    if (selector.capture !== void 0) {
      if (selector.parts.some((part2) => part2.name === "nth"))
        throw this.createStacklessError(`Can't query n-th element in a request with the capture.`);
      const withHas = { parts: selector.parts.slice(0, selector.capture + 1) };
      if (selector.capture < selector.parts.length - 1) {
        const parsed = { parts: selector.parts.slice(selector.capture + 1) };
        const has = { name: "internal:has", body: { parsed }, source: stringifySelector(parsed) };
        withHas.parts.push(has);
      }
      return this.querySelectorAll(withHas, root);
    }
    if (!root["querySelectorAll"])
      throw this.createStacklessError("Node is not queryable.");
    if (selector.capture !== void 0) {
      throw this.createStacklessError("Internal error: there should not be a capture in the selector.");
    }
    this._evaluator.begin();
    try {
      let roots = /* @__PURE__ */ new Set([root]);
      for (const part2 of selector.parts) {
        if (part2.name === "nth") {
          roots = this._queryNth(roots, part2);
        } else if (part2.name === "internal:and") {
          const andElements = this.querySelectorAll(part2.body.parsed, root);
          roots = new Set(andElements.filter((e) => roots.has(e)));
        } else if (part2.name === "internal:or") {
          const orElements = this.querySelectorAll(part2.body.parsed, root);
          roots = new Set(sortInDOMOrder(/* @__PURE__ */ new Set([...roots, ...orElements])));
        } else if (kLayoutSelectorNames.includes(part2.name)) {
          roots = this._queryLayoutSelector(roots, part2, root);
        } else {
          const next = /* @__PURE__ */ new Set();
          for (const root2 of roots) {
            const all = this._queryEngineAll(part2, root2);
            for (const one of all)
              next.add(one);
          }
          roots = next;
        }
      }
      return [...roots];
    } finally {
      this._evaluator.end();
    }
  }
  _queryEngineAll(part2, root) {
    const result = this._engines.get(part2.name).queryAll(root, part2.body);
    for (const element of result) {
      if (!("nodeName" in element))
        throw this.createStacklessError(`Expected a Node but got ${Object.prototype.toString.call(element)}`);
    }
    return result;
  }
  _createAttributeEngine(attribute, shadow) {
    const toCSS = (selector) => {
      const css = `[${attribute}=${JSON.stringify(selector)}]`;
      return [{ simples: [{ selector: { css, functions: [] }, combinator: "" }] }];
    };
    return {
      queryAll: (root, selector) => {
        return this._evaluator.query({ scope: root, pierceShadow: shadow }, toCSS(selector));
      }
    };
  }
  _createCSSEngine() {
    return {
      queryAll: (root, body) => {
        return this._evaluator.query({ scope: root, pierceShadow: true }, body);
      }
    };
  }
  _createTextEngine(shadow, internal) {
    const queryAll = (root, selector) => {
      const { matcher, kind } = createTextMatcher(selector, internal);
      const result = [];
      let lastDidNotMatchSelf = null;
      const appendElement = (element) => {
        if (kind === "lax" && lastDidNotMatchSelf && lastDidNotMatchSelf.contains(element))
          return false;
        const matches = elementMatchesText(this._evaluator._cacheText, element, matcher);
        if (matches === "none")
          lastDidNotMatchSelf = element;
        if (matches === "self" || matches === "selfAndChildren" && kind === "strict" && !internal)
          result.push(element);
      };
      if (root.nodeType === Node.ELEMENT_NODE)
        appendElement(root);
      const elements = this._evaluator._queryCSS({ scope: root, pierceShadow: shadow }, "*");
      for (const element of elements)
        appendElement(element);
      return result;
    };
    return { queryAll };
  }
  _createInternalHasTextEngine() {
    return {
      queryAll: (root, selector) => {
        if (root.nodeType !== 1)
          return [];
        const element = root;
        const text = elementText(this._evaluator._cacheText, element);
        const { matcher } = createTextMatcher(selector, true);
        return matcher(text) ? [element] : [];
      }
    };
  }
  _createInternalHasNotTextEngine() {
    return {
      queryAll: (root, selector) => {
        if (root.nodeType !== 1)
          return [];
        const element = root;
        const text = elementText(this._evaluator._cacheText, element);
        const { matcher } = createTextMatcher(selector, true);
        return matcher(text) ? [] : [element];
      }
    };
  }
  _createInternalLabelEngine() {
    return {
      queryAll: (root, selector) => {
        const { matcher } = createTextMatcher(selector, true);
        const allElements = this._evaluator._queryCSS({ scope: root, pierceShadow: true }, "*");
        return allElements.filter((element) => {
          return getElementLabels(this._evaluator._cacheText, element).some((label) => matcher(label));
        });
      }
    };
  }
  _createNamedAttributeEngine() {
    const queryAll = (root, selector) => {
      const parsed = parseAttributeSelector(selector, true);
      if (parsed.name || parsed.attributes.length !== 1)
        throw new Error("Malformed attribute selector: " + selector);
      const { name, value, caseSensitive } = parsed.attributes[0];
      const lowerCaseValue = caseSensitive ? null : value.toLowerCase();
      let matcher;
      if (value instanceof RegExp)
        matcher = (s) => !!s.match(value);
      else if (caseSensitive)
        matcher = (s) => s === value;
      else
        matcher = (s) => s.toLowerCase().includes(lowerCaseValue);
      const elements = this._evaluator._queryCSS({ scope: root, pierceShadow: true }, `[${name}]`);
      return elements.filter((e) => matcher(e.getAttribute(name)));
    };
    return { queryAll };
  }
  _createControlEngine() {
    return {
      queryAll(root, body) {
        if (body === "enter-frame")
          return [];
        if (body === "return-empty")
          return [];
        if (body === "component") {
          if (root.nodeType !== 1)
            return [];
          return [root.childElementCount === 1 ? root.firstElementChild : root];
        }
        throw new Error(`Internal error, unknown internal:control selector ${body}`);
      }
    };
  }
  _createHasEngine() {
    const queryAll = (root, body) => {
      if (root.nodeType !== 1)
        return [];
      const has = !!this.querySelector(body.parsed, root, false);
      return has ? [root] : [];
    };
    return { queryAll };
  }
  _createHasNotEngine() {
    const queryAll = (root, body) => {
      if (root.nodeType !== 1)
        return [];
      const has = !!this.querySelector(body.parsed, root, false);
      return has ? [] : [root];
    };
    return { queryAll };
  }
  _createVisibleEngine() {
    const queryAll = (root, body) => {
      if (root.nodeType !== 1)
        return [];
      return isElementVisible(root) === Boolean(body) ? [root] : [];
    };
    return { queryAll };
  }
  extend(source, params) {
    const constrFunction = this.window.eval(`
    (() => {
      const module = {};
      ${source}
      return module.exports.default();
    })()`);
    return new constrFunction(this, params);
  }
  isVisible(element) {
    return isElementVisible(element);
  }
  async viewportRatio(element) {
    return await new Promise((resolve) => {
      const observer = new IntersectionObserver((entries) => {
        resolve(entries[0].intersectionRatio);
        observer.disconnect();
      });
      observer.observe(element);
      requestAnimationFrame(() => {
      });
    });
  }
  pollRaf(predicate) {
    return this.poll(predicate, (next) => requestAnimationFrame(next));
  }
  poll(predicate, scheduleNext) {
    return this._runAbortableTask((progress) => {
      let fulfill;
      let reject;
      const result = new Promise((f2, r2) => {
        fulfill = f2;
        reject = r2;
      });
      const next = () => {
        if (progress.aborted)
          return;
        try {
          const success = predicate(progress);
          if (success !== progress.continuePolling)
            fulfill(success);
          else
            scheduleNext(next);
        } catch (e) {
          progress.log("  " + e.message);
          reject(e);
        }
      };
      next();
      return result;
    });
  }
  _runAbortableTask(task) {
    let unsentLog = [];
    let takeNextLogsCallback;
    let taskFinished = false;
    const logReady = () => {
      if (!takeNextLogsCallback)
        return;
      takeNextLogsCallback(unsentLog);
      unsentLog = [];
      takeNextLogsCallback = void 0;
    };
    const takeNextLogs = () => new Promise((fulfill) => {
      takeNextLogsCallback = fulfill;
      if (unsentLog.length || taskFinished)
        logReady();
    });
    let lastMessage = "";
    const progress = {
      injectedScript: this,
      aborted: false,
      continuePolling: Symbol("continuePolling"),
      log: (message) => {
        lastMessage = message;
        unsentLog.push({ message });
        logReady();
      },
      logRepeating: (message) => {
        if (message !== lastMessage)
          progress.log(message);
      }
    };
    const run = () => {
      const result = task(progress);
      result.finally(() => {
        taskFinished = true;
        logReady();
      });
      return result;
    };
    return {
      takeNextLogs,
      run,
      cancel: () => {
        progress.aborted = true;
      },
      takeLastLogs: () => unsentLog
    };
  }
  getElementBorderWidth(node) {
    if (node.nodeType !== Node.ELEMENT_NODE || !node.ownerDocument || !node.ownerDocument.defaultView)
      return { left: 0, top: 0 };
    const style = node.ownerDocument.defaultView.getComputedStyle(node);
    return { left: parseInt(style.borderLeftWidth || "", 10), top: parseInt(style.borderTopWidth || "", 10) };
  }
  describeIFrameStyle(iframe) {
    if (!iframe.ownerDocument || !iframe.ownerDocument.defaultView)
      return "error:notconnected";
    const defaultView = iframe.ownerDocument.defaultView;
    for (let e = iframe; e; e = parentElementOrShadowHost(e)) {
      if (defaultView.getComputedStyle(e).transform !== "none")
        return "transformed";
    }
    const iframeStyle = defaultView.getComputedStyle(iframe);
    return {
      left: parseInt(iframeStyle.borderLeftWidth || "", 10) + parseInt(iframeStyle.paddingLeft || "", 10),
      top: parseInt(iframeStyle.borderTopWidth || "", 10) + parseInt(iframeStyle.paddingTop || "", 10)
    };
  }
  retarget(node, behavior) {
    let element = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    if (!element)
      return null;
    if (behavior === "none")
      return element;
    if (!element.matches("input, textarea, select")) {
      if (behavior === "button-link")
        element = element.closest("button, [role=button], a, [role=link]") || element;
      else
        element = element.closest("button, [role=button], [role=checkbox], [role=radio]") || element;
    }
    if (behavior === "follow-label") {
      if (!element.matches("input, textarea, button, select, [role=button], [role=checkbox], [role=radio]") && !element.isContentEditable) {
        element = element.closest("label") || element;
      }
      if (element.nodeName === "LABEL")
        element = element.control || element;
    }
    return element;
  }
  waitForElementStatesAndPerformAction(node, states, force, callback) {
    let lastRect;
    let counter = 0;
    let samePositionCounter = 0;
    let lastTime = 0;
    return this.pollRaf((progress) => {
      if (force) {
        progress.log(`    forcing action`);
        return callback(node, progress);
      }
      for (const state of states) {
        if (state !== "stable") {
          const result = this.elementState(node, state);
          if (typeof result !== "boolean")
            return result;
          if (!result) {
            progress.logRepeating(`    element is not ${state} - waiting...`);
            return progress.continuePolling;
          }
          continue;
        }
        const element = this.retarget(node, "no-follow-label");
        if (!element)
          return "error:notconnected";
        if (++counter === 1)
          return progress.continuePolling;
        const time = performance.now();
        if (this._stableRafCount > 1 && time - lastTime < 15)
          return progress.continuePolling;
        lastTime = time;
        const clientRect = element.getBoundingClientRect();
        const rect2 = { x: clientRect.top, y: clientRect.left, width: clientRect.width, height: clientRect.height };
        const samePosition = lastRect && rect2.x === lastRect.x && rect2.y === lastRect.y && rect2.width === lastRect.width && rect2.height === lastRect.height;
        if (samePosition)
          ++samePositionCounter;
        else
          samePositionCounter = 0;
        const isStable = samePositionCounter >= this._stableRafCount;
        const isStableForLogs = isStable || !lastRect;
        lastRect = rect2;
        if (!isStableForLogs)
          progress.logRepeating(`    element is not stable - waiting...`);
        if (!isStable)
          return progress.continuePolling;
      }
      return callback(node, progress);
    });
  }
  elementState(node, state) {
    const element = this.retarget(node, ["stable", "visible", "hidden"].includes(state) ? "none" : "follow-label");
    if (!element || !element.isConnected) {
      if (state === "hidden")
        return true;
      return "error:notconnected";
    }
    if (state === "visible")
      return this.isVisible(element);
    if (state === "hidden")
      return !this.isVisible(element);
    const disabled = getAriaDisabled(element);
    if (state === "disabled")
      return disabled;
    if (state === "enabled")
      return !disabled;
    const editable = !(["INPUT", "TEXTAREA", "SELECT"].includes(element.nodeName) && element.hasAttribute("readonly"));
    if (state === "editable")
      return !disabled && editable;
    if (state === "checked" || state === "unchecked") {
      const need = state === "checked";
      const checked = getChecked(element, false);
      if (checked === "error")
        throw this.createStacklessError("Not a checkbox or radio button");
      return need === checked;
    }
    throw this.createStacklessError(`Unexpected element state "${state}"`);
  }
  selectOptions(optionsToSelect, node, progress) {
    const element = this.retarget(node, "follow-label");
    if (!element)
      return "error:notconnected";
    if (element.nodeName.toLowerCase() !== "select")
      throw this.createStacklessError("Element is not a <select> element");
    const select = element;
    const options = [...select.options];
    const selectedOptions = [];
    let remainingOptionsToSelect = optionsToSelect.slice();
    for (let index = 0; index < options.length; index++) {
      const option = options[index];
      const filter = (optionToSelect) => {
        if (optionToSelect instanceof Node)
          return option === optionToSelect;
        let matches = true;
        if (optionToSelect.valueOrLabel !== void 0)
          matches = matches && (optionToSelect.valueOrLabel === option.value || optionToSelect.valueOrLabel === option.label);
        if (optionToSelect.value !== void 0)
          matches = matches && optionToSelect.value === option.value;
        if (optionToSelect.label !== void 0)
          matches = matches && optionToSelect.label === option.label;
        if (optionToSelect.index !== void 0)
          matches = matches && optionToSelect.index === index;
        return matches;
      };
      if (!remainingOptionsToSelect.some(filter))
        continue;
      selectedOptions.push(option);
      if (select.multiple) {
        remainingOptionsToSelect = remainingOptionsToSelect.filter((o) => !filter(o));
      } else {
        remainingOptionsToSelect = [];
        break;
      }
    }
    if (remainingOptionsToSelect.length) {
      progress.logRepeating("    did not find some options - waiting... ");
      return progress.continuePolling;
    }
    select.value = void 0;
    selectedOptions.forEach((option) => option.selected = true);
    progress.log("    selected specified option(s)");
    select.dispatchEvent(new Event("input", { "bubbles": true }));
    select.dispatchEvent(new Event("change", { "bubbles": true }));
    return selectedOptions.map((option) => option.value);
  }
  fill(value, node, progress) {
    const element = this.retarget(node, "follow-label");
    if (!element)
      return "error:notconnected";
    if (element.nodeName.toLowerCase() === "input") {
      const input = element;
      const type = input.type.toLowerCase();
      const kInputTypesToSetValue = /* @__PURE__ */ new Set(["color", "date", "time", "datetime", "datetime-local", "month", "range", "week"]);
      const kInputTypesToTypeInto = /* @__PURE__ */ new Set(["", "email", "number", "password", "search", "tel", "text", "url"]);
      if (!kInputTypesToTypeInto.has(type) && !kInputTypesToSetValue.has(type)) {
        progress.log(`    input of type "${type}" cannot be filled`);
        throw this.createStacklessError(`Input of type "${type}" cannot be filled`);
      }
      if (type === "number") {
        value = value.trim();
        if (isNaN(Number(value)))
          throw this.createStacklessError("Cannot type text into input[type=number]");
      }
      if (kInputTypesToSetValue.has(type)) {
        value = value.trim();
        input.focus();
        input.value = value;
        if (input.value !== value)
          throw this.createStacklessError("Malformed value");
        element.dispatchEvent(new Event("input", { "bubbles": true }));
        element.dispatchEvent(new Event("change", { "bubbles": true }));
        return "done";
      }
    } else if (element.nodeName.toLowerCase() === "textarea")
      ;
    else if (!element.isContentEditable) {
      throw this.createStacklessError("Element is not an <input>, <textarea> or [contenteditable] element");
    }
    this.selectText(element);
    return "needsinput";
  }
  selectText(node) {
    const element = this.retarget(node, "follow-label");
    if (!element)
      return "error:notconnected";
    if (element.nodeName.toLowerCase() === "input") {
      const input = element;
      input.select();
      input.focus();
      return "done";
    }
    if (element.nodeName.toLowerCase() === "textarea") {
      const textarea = element;
      textarea.selectionStart = 0;
      textarea.selectionEnd = textarea.value.length;
      textarea.focus();
      return "done";
    }
    const range2 = element.ownerDocument.createRange();
    range2.selectNodeContents(element);
    const selection = element.ownerDocument.defaultView.getSelection();
    if (selection) {
      selection.removeAllRanges();
      selection.addRange(range2);
    }
    element.focus();
    return "done";
  }
  _activelyFocused(node) {
    const activeElement = node.getRootNode().activeElement;
    const isFocused = activeElement === node && !!node.ownerDocument && node.ownerDocument.hasFocus();
    return { activeElement, isFocused };
  }
  focusNode(node, resetSelectionIfNotFocused) {
    if (!node.isConnected)
      return "error:notconnected";
    if (node.nodeType !== Node.ELEMENT_NODE)
      throw this.createStacklessError("Node is not an element");
    const { activeElement, isFocused: wasFocused } = this._activelyFocused(node);
    if (node.isContentEditable && !wasFocused && activeElement && activeElement.blur) {
      activeElement.blur();
    }
    node.focus();
    node.focus();
    if (resetSelectionIfNotFocused && !wasFocused && node.nodeName.toLowerCase() === "input") {
      try {
        const input = node;
        input.setSelectionRange(0, 0);
      } catch (e) {
      }
    }
    return "done";
  }
  blurNode(node) {
    if (!node.isConnected)
      return "error:notconnected";
    if (node.nodeType !== Node.ELEMENT_NODE)
      throw this.createStacklessError("Node is not an element");
    node.blur();
    return "done";
  }
  setInputFiles(node, payloads) {
    if (node.nodeType !== Node.ELEMENT_NODE)
      return "Node is not of type HTMLElement";
    const element = node;
    if (element.nodeName !== "INPUT")
      return "Not an <input> element";
    const input = element;
    const type = (input.getAttribute("type") || "").toLowerCase();
    if (type !== "file")
      return "Not an input[type=file] element";
    const files = payloads.map((file) => {
      const bytes = Uint8Array.from(atob(file.buffer), (c) => c.charCodeAt(0));
      return new File([bytes], file.name, { type: file.mimeType });
    });
    const dt = new DataTransfer();
    for (const file of files)
      dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event("input", { "bubbles": true }));
    input.dispatchEvent(new Event("change", { "bubbles": true }));
  }
  expectHitTarget(hitPoint, targetElement) {
    const roots = [];
    let parentElement = targetElement;
    while (parentElement) {
      const root = enclosingShadowRootOrDocument(parentElement);
      if (!root)
        break;
      roots.push(root);
      if (root.nodeType === 9)
        break;
      parentElement = root.host;
    }
    let hitElement;
    for (let index = roots.length - 1; index >= 0; index--) {
      const root = roots[index];
      const elements = root.elementsFromPoint(hitPoint.x, hitPoint.y);
      const singleElement = root.elementFromPoint(hitPoint.x, hitPoint.y);
      if (singleElement && elements[0] && parentElementOrShadowHost(singleElement) === elements[0]) {
        const style = this.window.getComputedStyle(singleElement);
        if ((style == null ? void 0 : style.display) === "contents") {
          elements.unshift(singleElement);
        }
      }
      if (elements[0] && elements[0].shadowRoot === root && elements[1] === singleElement) {
        elements.shift();
      }
      const innerElement = elements[0];
      if (!innerElement)
        break;
      hitElement = innerElement;
      if (index && innerElement !== roots[index - 1].host)
        break;
    }
    const hitParents = [];
    while (hitElement && hitElement !== targetElement) {
      hitParents.push(hitElement);
      hitElement = parentElementOrShadowHost(hitElement);
    }
    if (hitElement === targetElement)
      return "done";
    const hitTargetDescription = this.previewNode(hitParents[0] || this.document.documentElement);
    let rootHitTargetDescription;
    let element = targetElement;
    while (element) {
      const index = hitParents.indexOf(element);
      if (index !== -1) {
        if (index > 1)
          rootHitTargetDescription = this.previewNode(hitParents[index - 1]);
        break;
      }
      element = parentElementOrShadowHost(element);
    }
    if (rootHitTargetDescription)
      return { hitTargetDescription: `${hitTargetDescription} from ${rootHitTargetDescription} subtree` };
    return { hitTargetDescription };
  }
  // Life of a pointer action, for example click.
  //
  // 0. Retry items 1 and 2 while action fails due to navigation or element being detached.
  //   1. Resolve selector to an element.
  //   2. Retry the following steps until the element is detached or frame navigates away.
  //     2a. Wait for the element to be stable (not moving), visible and enabled.
  //     2b. Scroll element into view. Scrolling alternates between:
  //         - Built-in protocol scrolling.
  //         - Anchoring to the top/left, bottom/right and center/center.
  //         This is to scroll elements from under sticky headers/footers.
  //     2c. Click point is calculated, either based on explicitly specified position,
  //         or some visible point of the element based on protocol content quads.
  //     2d. Click point relative to page viewport is converted relative to the target iframe
  //         for the next hit-point check.
  //     2e. (injected) Hit target at the click point must be a descendant of the target element.
  //         This prevents mis-clicking in edge cases like <iframe> overlaying the target.
  //     2f. (injected) Events specific for click (or some other action type) are intercepted on
  //         the Window with capture:true. See 2i for details.
  //         Note: this step is skipped for drag&drop (see inline comments for the reason).
  //     2g. Necessary keyboard modifiers are pressed.
  //     2h. Click event is issued (mousemove + mousedown + mouseup).
  //     2i. (injected) For each event, we check that hit target at the event point
  //         is a descendant of the target element.
  //         This guarantees no race between issuing the event and handling it in the page,
  //         for example due to layout shift.
  //         When hit target check fails, we block all future events in the page.
  //     2j. Keyboard modifiers are restored.
  //     2k. (injected) Event interceptor is removed.
  //     2l. All navigations triggered between 2g-2k are awaited to be either committed or canceled.
  //     2m. If failed, wait for increasing amount of time before the next retry.
  setupHitTargetInterceptor(node, action, hitPoint, blockAllEvents) {
    const element = this.retarget(node, "button-link");
    if (!element || !element.isConnected)
      return "error:notconnected";
    if (hitPoint) {
      const preliminaryResult = this.expectHitTarget(hitPoint, element);
      if (preliminaryResult !== "done")
        return preliminaryResult.hitTargetDescription;
    }
    if (action === "drag")
      return { stop: () => "done" };
    const events = {
      "hover": kHoverHitTargetInterceptorEvents,
      "tap": kTapHitTargetInterceptorEvents,
      "mouse": kMouseHitTargetInterceptorEvents
    }[action];
    let result;
    const listener = (event) => {
      if (!events.has(event.type))
        return;
      if (!event.isTrusted)
        return;
      const point = !!this.window.TouchEvent && event instanceof this.window.TouchEvent ? event.touches[0] : event;
      if (result === void 0 && point)
        result = this.expectHitTarget({ x: point.clientX, y: point.clientY }, element);
      if (blockAllEvents || result !== "done" && result !== void 0) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
      }
    };
    const stop = () => {
      if (this._hitTargetInterceptor === listener)
        this._hitTargetInterceptor = void 0;
      return result || "done";
    };
    this._hitTargetInterceptor = listener;
    return { stop };
  }
  dispatchEvent(node, type, eventInit) {
    let event;
    eventInit = { bubbles: true, cancelable: true, composed: true, ...eventInit };
    switch (eventType.get(type)) {
      case "mouse":
        event = new MouseEvent(type, eventInit);
        break;
      case "keyboard":
        event = new KeyboardEvent(type, eventInit);
        break;
      case "touch":
        event = new TouchEvent(type, eventInit);
        break;
      case "pointer":
        event = new PointerEvent(type, eventInit);
        break;
      case "focus":
        event = new FocusEvent(type, eventInit);
        break;
      case "drag":
        event = new DragEvent(type, eventInit);
        break;
      case "wheel":
        event = new WheelEvent(type, eventInit);
        break;
      default:
        event = new Event(type, eventInit);
        break;
    }
    node.dispatchEvent(event);
  }
  previewNode(node) {
    if (node.nodeType === Node.TEXT_NODE)
      return oneLine(`#text=${node.nodeValue || ""}`);
    if (node.nodeType !== Node.ELEMENT_NODE)
      return oneLine(`<${node.nodeName.toLowerCase()} />`);
    const element = node;
    const attrs = [];
    for (let i = 0; i < element.attributes.length; i++) {
      const { name, value } = element.attributes[i];
      if (name === "style")
        continue;
      if (!value && booleanAttributes.has(name))
        attrs.push(` ${name}`);
      else
        attrs.push(` ${name}="${value}"`);
    }
    attrs.sort((a, b) => a.length - b.length);
    let attrText = attrs.join("");
    if (attrText.length > 50)
      attrText = attrText.substring(0, 49) + "…";
    if (autoClosingTags.has(element.nodeName))
      return oneLine(`<${element.nodeName.toLowerCase()}${attrText}/>`);
    const children = element.childNodes;
    let onlyText = false;
    if (children.length <= 5) {
      onlyText = true;
      for (let i = 0; i < children.length; i++)
        onlyText = onlyText && children[i].nodeType === Node.TEXT_NODE;
    }
    let text = onlyText ? element.textContent || "" : children.length ? "…" : "";
    if (text.length > 50)
      text = text.substring(0, 49) + "…";
    return oneLine(`<${element.nodeName.toLowerCase()}${attrText}>${text}</${element.nodeName.toLowerCase()}>`);
  }
  strictModeViolationError(selector, matches) {
    const infos = matches.slice(0, 10).map((m2) => ({
      preview: this.previewNode(m2),
      selector: this.generateSelector(m2)
    }));
    const lines = infos.map((info, i) => `
    ${i + 1}) ${info.preview} aka ${asLocator(this._sdkLanguage, info.selector)}`);
    if (infos.length < matches.length)
      lines.push("\n    ...");
    return this.createStacklessError(`strict mode violation: ${asLocator(this._sdkLanguage, stringifySelector(selector))} resolved to ${matches.length} elements:${lines.join("")}
`);
  }
  createStacklessError(message) {
    if (this._browserName === "firefox") {
      const error2 = new Error("Error: " + message);
      error2.stack = "";
      return error2;
    }
    const error = new Error(message);
    delete error.stack;
    return error;
  }
  maskSelectors(selectors, color) {
    if (this._highlight)
      this.hideHighlight();
    this._highlight = new Highlight(this);
    this._highlight.install();
    const elements = [];
    for (const selector of selectors)
      elements.push(this.querySelectorAll(selector, this.document.documentElement));
    this._highlight.maskElements(elements.flat(), color);
  }
  highlight(selector) {
    if (!this._highlight) {
      this._highlight = new Highlight(this);
      this._highlight.install();
    }
    this._highlight.runHighlightOnRaf(selector);
  }
  hideHighlight() {
    if (this._highlight) {
      this._highlight.uninstall();
      delete this._highlight;
    }
  }
  markTargetElements(markedElements, callId) {
    const customEvent = new CustomEvent("__playwright_target__", {
      bubbles: true,
      cancelable: true,
      detail: callId,
      composed: false
    });
    for (const element of markedElements)
      element.dispatchEvent(customEvent);
  }
  _setupGlobalListenersRemovalDetection() {
    const customEventName = "__playwright_global_listeners_check__";
    let seenEvent = false;
    const handleCustomEvent = () => seenEvent = true;
    this.window.addEventListener(customEventName, handleCustomEvent);
    new MutationObserver((entries) => {
      const newDocumentElement = entries.some((entry) => Array.from(entry.addedNodes).includes(this.document.documentElement));
      if (!newDocumentElement)
        return;
      seenEvent = false;
      this.window.dispatchEvent(new CustomEvent(customEventName));
      if (seenEvent)
        return;
      this.window.addEventListener(customEventName, handleCustomEvent);
      for (const callback of this.onGlobalListenersRemoved)
        callback();
    }).observe(this.document, { childList: true });
  }
  _setupHitTargetInterceptors() {
    const listener = (event) => {
      var _a;
      return (_a = this._hitTargetInterceptor) == null ? void 0 : _a.call(this, event);
    };
    const addHitTargetInterceptorListeners = () => {
      for (const event of kAllHitTargetInterceptorEvents)
        this.window.addEventListener(event, listener, { capture: true, passive: false });
    };
    addHitTargetInterceptorListeners();
    this.onGlobalListenersRemoved.add(addHitTargetInterceptorListeners);
  }
  async expect(element, options, elements) {
    const isArray = options.expression === "to.have.count" || options.expression.endsWith(".array");
    if (isArray)
      return this.expectArray(elements, options);
    if (!element) {
      if (!options.isNot && options.expression === "to.be.hidden")
        return { matches: true };
      if (options.isNot && options.expression === "to.be.visible")
        return { matches: false };
      if (!options.isNot && options.expression === "to.be.detached")
        return { matches: true };
      if (options.isNot && options.expression === "to.be.attached")
        return { matches: false };
      if (options.isNot && options.expression === "to.be.in.viewport")
        return { matches: false };
      return { matches: options.isNot, missingRecevied: true };
    }
    return await this.expectSingleElement(element, options);
  }
  async expectSingleElement(element, options) {
    var _a;
    const expression = options.expression;
    {
      let elementState;
      if (expression === "to.be.checked") {
        elementState = this.elementState(element, "checked");
      } else if (expression === "to.be.unchecked") {
        elementState = this.elementState(element, "unchecked");
      } else if (expression === "to.be.disabled") {
        elementState = this.elementState(element, "disabled");
      } else if (expression === "to.be.editable") {
        elementState = this.elementState(element, "editable");
      } else if (expression === "to.be.readonly") {
        elementState = !this.elementState(element, "editable");
      } else if (expression === "to.be.empty") {
        if (element.nodeName === "INPUT" || element.nodeName === "TEXTAREA")
          elementState = !element.value;
        else
          elementState = !((_a = element.textContent) == null ? void 0 : _a.trim());
      } else if (expression === "to.be.enabled") {
        elementState = this.elementState(element, "enabled");
      } else if (expression === "to.be.focused") {
        elementState = this._activelyFocused(element).isFocused;
      } else if (expression === "to.be.hidden") {
        elementState = this.elementState(element, "hidden");
      } else if (expression === "to.be.visible") {
        elementState = this.elementState(element, "visible");
      } else if (expression === "to.be.attached") {
        elementState = true;
      } else if (expression === "to.be.detached") {
        elementState = false;
      }
      if (elementState !== void 0) {
        if (elementState === "error:notcheckbox")
          throw this.createStacklessError("Element is not a checkbox");
        if (elementState === "error:notconnected")
          throw this.createStacklessError("Element is not connected");
        return { received: elementState, matches: elementState };
      }
    }
    {
      if (expression === "to.have.property") {
        const received = element[options.expressionArg];
        const matches = deepEquals(received, options.expectedValue);
        return { received, matches };
      }
    }
    {
      if (expression === "to.be.in.viewport") {
        const ratio2 = await this.viewportRatio(element);
        return { received: `viewport ratio ${ratio2}`, matches: ratio2 > 0 && ratio2 > (options.expectedNumber ?? 0) - 1e-9 };
      }
    }
    {
      if (expression === "to.have.values") {
        element = this.retarget(element, "follow-label");
        if (element.nodeName !== "SELECT" || !element.multiple)
          throw this.createStacklessError("Not a select element with a multiple attribute");
        const received = [...element.selectedOptions].map((o) => o.value);
        if (received.length !== options.expectedText.length)
          return { received, matches: false };
        return { received, matches: received.map((r2, i) => new ExpectedTextMatcher(options.expectedText[i]).matches(r2)).every(Boolean) };
      }
    }
    {
      let received;
      if (expression === "to.have.attribute") {
        const value = element.getAttribute(options.expressionArg);
        if (value === null)
          return { received: null, matches: false };
        received = value;
      } else if (expression === "to.have.class") {
        received = element.classList.toString();
      } else if (expression === "to.have.css") {
        received = this.window.getComputedStyle(element).getPropertyValue(options.expressionArg);
      } else if (expression === "to.have.id") {
        received = element.id;
      } else if (expression === "to.have.text") {
        received = options.useInnerText ? element.innerText : elementText(/* @__PURE__ */ new Map(), element).full;
      } else if (expression === "to.have.title") {
        received = this.document.title;
      } else if (expression === "to.have.url") {
        received = this.document.location.href;
      } else if (expression === "to.have.value") {
        element = this.retarget(element, "follow-label");
        if (element.nodeName !== "INPUT" && element.nodeName !== "TEXTAREA" && element.nodeName !== "SELECT")
          throw this.createStacklessError("Not an input element");
        received = element.value;
      }
      if (received !== void 0 && options.expectedText) {
        const matcher = new ExpectedTextMatcher(options.expectedText[0]);
        return { received, matches: matcher.matches(received) };
      }
    }
    throw this.createStacklessError("Unknown expect matcher: " + expression);
  }
  expectArray(elements, options) {
    const expression = options.expression;
    if (expression === "to.have.count") {
      const received2 = elements.length;
      const matches = received2 === options.expectedNumber;
      return { received: received2, matches };
    }
    let received;
    if (expression === "to.have.text.array" || expression === "to.contain.text.array")
      received = elements.map((e) => options.useInnerText ? e.innerText : elementText(/* @__PURE__ */ new Map(), e).full);
    else if (expression === "to.have.class.array")
      received = elements.map((e) => e.classList.toString());
    if (received && options.expectedText) {
      const lengthShouldMatch = expression !== "to.contain.text.array";
      const matchesLength = received.length === options.expectedText.length || !lengthShouldMatch;
      if (!matchesLength)
        return { received, matches: false };
      const matchers = options.expectedText.map((e) => new ExpectedTextMatcher(e));
      let mIndex = 0, rIndex = 0;
      while (mIndex < matchers.length && rIndex < received.length) {
        if (matchers[mIndex].matches(received[rIndex]))
          ++mIndex;
        ++rIndex;
      }
      return { received, matches: mIndex === matchers.length };
    }
    throw this.createStacklessError("Unknown expect matcher: " + expression);
  }
  getElementAccessibleName(element, includeHidden) {
    return getElementAccessibleName(element, !!includeHidden);
  }
  getAriaRole(element) {
    return getAriaRole(element);
  }
}
const autoClosingTags = /* @__PURE__ */ new Set(["AREA", "BASE", "BR", "COL", "COMMAND", "EMBED", "HR", "IMG", "INPUT", "KEYGEN", "LINK", "MENUITEM", "META", "PARAM", "SOURCE", "TRACK", "WBR"]);
const booleanAttributes = /* @__PURE__ */ new Set(["checked", "selected", "disabled", "readonly", "multiple"]);
function oneLine(s) {
  return s.replace(/\n/g, "↵").replace(/\t/g, "⇆");
}
const eventType = /* @__PURE__ */ new Map([
  ["auxclick", "mouse"],
  ["click", "mouse"],
  ["dblclick", "mouse"],
  ["mousedown", "mouse"],
  ["mouseeenter", "mouse"],
  ["mouseleave", "mouse"],
  ["mousemove", "mouse"],
  ["mouseout", "mouse"],
  ["mouseover", "mouse"],
  ["mouseup", "mouse"],
  ["mouseleave", "mouse"],
  ["mousewheel", "mouse"],
  ["keydown", "keyboard"],
  ["keyup", "keyboard"],
  ["keypress", "keyboard"],
  ["textInput", "keyboard"],
  ["touchstart", "touch"],
  ["touchmove", "touch"],
  ["touchend", "touch"],
  ["touchcancel", "touch"],
  ["pointerover", "pointer"],
  ["pointerout", "pointer"],
  ["pointerenter", "pointer"],
  ["pointerleave", "pointer"],
  ["pointerdown", "pointer"],
  ["pointerup", "pointer"],
  ["pointermove", "pointer"],
  ["pointercancel", "pointer"],
  ["gotpointercapture", "pointer"],
  ["lostpointercapture", "pointer"],
  ["focus", "focus"],
  ["blur", "focus"],
  ["drag", "drag"],
  ["dragstart", "drag"],
  ["dragend", "drag"],
  ["dragover", "drag"],
  ["dragenter", "drag"],
  ["dragleave", "drag"],
  ["dragexit", "drag"],
  ["drop", "drag"],
  ["wheel", "wheel"]
]);
const kHoverHitTargetInterceptorEvents = /* @__PURE__ */ new Set(["mousemove"]);
const kTapHitTargetInterceptorEvents = /* @__PURE__ */ new Set(["pointerdown", "pointerup", "touchstart", "touchend", "touchcancel"]);
const kMouseHitTargetInterceptorEvents = /* @__PURE__ */ new Set(["mousedown", "mouseup", "pointerdown", "pointerup", "click", "auxclick", "dblclick", "contextmenu"]);
const kAllHitTargetInterceptorEvents = /* @__PURE__ */ new Set([...kHoverHitTargetInterceptorEvents, ...kTapHitTargetInterceptorEvents, ...kMouseHitTargetInterceptorEvents]);
function cssUnquote(s) {
  s = s.substring(1, s.length - 1);
  if (!s.includes("\\"))
    return s;
  const r2 = [];
  let i = 0;
  while (i < s.length) {
    if (s[i] === "\\" && i + 1 < s.length)
      i++;
    r2.push(s[i++]);
  }
  return r2.join("");
}
function createTextMatcher(selector, internal) {
  if (selector[0] === "/" && selector.lastIndexOf("/") > 0) {
    const lastSlash = selector.lastIndexOf("/");
    const re2 = new RegExp(selector.substring(1, lastSlash), selector.substring(lastSlash + 1));
    return { matcher: (elementText2) => re2.test(elementText2.full), kind: "regex" };
  }
  const unquote = internal ? JSON.parse.bind(JSON) : cssUnquote;
  let strict = false;
  if (selector.length > 1 && selector[0] === '"' && selector[selector.length - 1] === '"') {
    selector = unquote(selector);
    strict = true;
  } else if (internal && selector.length > 1 && selector[0] === '"' && selector[selector.length - 2] === '"' && selector[selector.length - 1] === "i") {
    selector = unquote(selector.substring(0, selector.length - 1));
    strict = false;
  } else if (internal && selector.length > 1 && selector[0] === '"' && selector[selector.length - 2] === '"' && selector[selector.length - 1] === "s") {
    selector = unquote(selector.substring(0, selector.length - 1));
    strict = true;
  } else if (selector.length > 1 && selector[0] === "'" && selector[selector.length - 1] === "'") {
    selector = unquote(selector);
    strict = true;
  }
  selector = normalizeWhiteSpace(selector);
  if (strict) {
    if (internal)
      return { kind: "strict", matcher: (elementText2) => normalizeWhiteSpace(elementText2.full) === selector };
    const strictTextNodeMatcher = (elementText2) => {
      if (!selector && !elementText2.immediate.length)
        return true;
      return elementText2.immediate.some((s) => normalizeWhiteSpace(s) === selector);
    };
    return { matcher: strictTextNodeMatcher, kind: "strict" };
  }
  selector = selector.toLowerCase();
  return { kind: "lax", matcher: (elementText2) => normalizeWhiteSpace(elementText2.full).toLowerCase().includes(selector) };
}
class ExpectedTextMatcher {
  constructor(expected) {
    this._normalizeWhiteSpace = expected.normalizeWhiteSpace;
    this._ignoreCase = expected.ignoreCase;
    this._string = expected.matchSubstring ? void 0 : this.normalize(expected.string);
    this._substring = expected.matchSubstring ? this.normalize(expected.string) : void 0;
    if (expected.regexSource) {
      const flags = new Set((expected.regexFlags || "").split(""));
      if (expected.ignoreCase === false)
        flags.delete("i");
      if (expected.ignoreCase === true)
        flags.add("i");
      this._regex = new RegExp(expected.regexSource, [...flags].join(""));
    }
  }
  matches(text) {
    if (!this._regex)
      text = this.normalize(text);
    if (this._string !== void 0)
      return text === this._string;
    if (this._substring !== void 0)
      return text.includes(this._substring);
    if (this._regex)
      return !!this._regex.test(text);
    return false;
  }
  normalize(s) {
    if (!s)
      return s;
    if (this._normalizeWhiteSpace)
      s = normalizeWhiteSpace(s);
    if (this._ignoreCase)
      s = s.toLocaleLowerCase();
    return s;
  }
}
function deepEquals(a, b) {
  if (a === b)
    return true;
  if (a && b && typeof a === "object" && typeof b === "object") {
    if (a.constructor !== b.constructor)
      return false;
    if (Array.isArray(a)) {
      if (a.length !== b.length)
        return false;
      for (let i = 0; i < a.length; ++i) {
        if (!deepEquals(a[i], b[i]))
          return false;
      }
      return true;
    }
    if (a instanceof RegExp)
      return a.source === b.source && a.flags === b.flags;
    if (a.valueOf !== Object.prototype.valueOf)
      return a.valueOf() === b.valueOf();
    if (a.toString !== Object.prototype.toString)
      return a.toString() === b.toString();
    const keys = Object.keys(a);
    if (keys.length !== Object.keys(b).length)
      return false;
    for (let i = 0; i < keys.length; ++i) {
      if (!b.hasOwnProperty(keys[i]))
        return false;
    }
    for (const key of keys) {
      if (!deepEquals(a[key], b[key]))
        return false;
    }
    return true;
  }
  if (typeof a === "number" && typeof b === "number")
    return isNaN(a) && isNaN(b);
  return false;
}
class Recorder {
  constructor(injectedScript, delegate) {
    this._performingAction = false;
    this._listeners = [];
    this._hoveredModel = null;
    this._hoveredElement = null;
    this._activeModel = null;
    this._expectProgrammaticKeyUp = false;
    this._mode = "none";
    this._testIdAttributeName = "data-testid";
    this.document = injectedScript.document;
    this._injectedScript = injectedScript;
    this._delegate = delegate;
    this._highlight = new Highlight(injectedScript);
    this.refreshListenersIfNeeded();
    if (injectedScript.isUnderTest)
      console.error("Recorder script ready for test");
  }
  refreshListenersIfNeeded() {
    if (this._highlight.isInstalled())
      return;
    removeEventListeners(this._listeners);
    this._listeners = [
      addEventListener(this.document, "click", (event) => this._onClick(event), true),
      addEventListener(this.document, "auxclick", (event) => this._onClick(event), true),
      addEventListener(this.document, "input", (event) => this._onInput(event), true),
      addEventListener(this.document, "keydown", (event) => this._onKeyDown(event), true),
      addEventListener(this.document, "keyup", (event) => this._onKeyUp(event), true),
      addEventListener(this.document, "mousedown", (event) => this._onMouseDown(event), true),
      addEventListener(this.document, "mouseup", (event) => this._onMouseUp(event), true),
      addEventListener(this.document, "mousemove", (event) => this._onMouseMove(event), true),
      addEventListener(this.document, "mouseleave", (event) => this._onMouseLeave(event), true),
      addEventListener(this.document, "focus", (event) => event.isTrusted && this._onFocus(true), true),
      addEventListener(this.document, "scroll", (event) => {
        if (!event.isTrusted)
          return;
        this._hoveredModel = null;
        this._highlight.hideActionPoint();
        this._updateHighlight();
      }, true)
    ];
    this._highlight.install();
  }
  setUIState(state) {
    var _a;
    const { mode, actionPoint, actionSelector, language, testIdAttributeName } = state;
    this._testIdAttributeName = testIdAttributeName;
    this._highlight.setLanguage(language);
    if (mode !== this._mode) {
      this._mode = mode;
      this._clearHighlight();
    }
    if (actionPoint && this._actionPoint && actionPoint.x === this._actionPoint.x && actionPoint.y === this._actionPoint.y)
      ;
    else if (!actionPoint && !this._actionPoint)
      ;
    else {
      if (actionPoint)
        this._highlight.showActionPoint(actionPoint.x, actionPoint.y);
      else
        this._highlight.hideActionPoint();
      this._actionPoint = actionPoint;
    }
    if (this._actionSelector && !((_a = this._hoveredModel) == null ? void 0 : _a.elements.length))
      this._actionSelector = void 0;
    if (actionSelector !== this._actionSelector) {
      this._hoveredModel = actionSelector ? querySelector(this._injectedScript, actionSelector, this.document) : null;
      this._updateHighlight();
      this._actionSelector = actionSelector;
    }
  }
  _clearHighlight() {
    this._hoveredModel = null;
    this._activeModel = null;
    this._updateHighlight();
  }
  _actionInProgress(event) {
    if (this._performingAction)
      return true;
    consumeEvent(event);
    return false;
  }
  _consumedDueToNoModel(event, model) {
    if (model)
      return false;
    consumeEvent(event);
    return true;
  }
  _consumedDueWrongTarget(event) {
    if (this._activeModel && this._activeModel.elements[0] === this._deepEventTarget(event))
      return false;
    consumeEvent(event);
    return true;
  }
  _onClick(event) {
    var _a, _b;
    if (!event.isTrusted)
      return;
    if (this._mode === "inspecting")
      (_b = (_a = this._delegate).setSelector) == null ? void 0 : _b.call(_a, this._hoveredModel ? this._hoveredModel.selector : "");
    if (this._shouldIgnoreMouseEvent(event))
      return;
    if (this._actionInProgress(event))
      return;
    if (this._consumedDueToNoModel(event, this._hoveredModel))
      return;
    const checkbox = asCheckbox(this._deepEventTarget(event));
    if (checkbox) {
      this._performAction({
        name: checkbox.checked ? "check" : "uncheck",
        selector: this._hoveredModel.selector,
        signals: []
      });
      return;
    }
    this._performAction({
      name: "click",
      selector: this._hoveredModel.selector,
      position: positionForEvent(event),
      signals: [],
      button: buttonForEvent(event),
      modifiers: modifiersForEvent(event),
      clickCount: event.detail
    });
  }
  _shouldIgnoreMouseEvent(event) {
    const target2 = this._deepEventTarget(event);
    if (this._mode === "none")
      return true;
    if (this._mode === "inspecting") {
      consumeEvent(event);
      return true;
    }
    const nodeName = target2.nodeName;
    if (nodeName === "SELECT" || nodeName === "OPTION")
      return true;
    if (nodeName === "INPUT" && ["date"].includes(target2.type))
      return true;
    return false;
  }
  _onMouseDown(event) {
    if (!event.isTrusted)
      return;
    if (this._shouldIgnoreMouseEvent(event))
      return;
    if (!this._performingAction)
      consumeEvent(event);
    this._activeModel = this._hoveredModel;
  }
  _onMouseUp(event) {
    if (!event.isTrusted)
      return;
    if (this._shouldIgnoreMouseEvent(event))
      return;
    if (!this._performingAction)
      consumeEvent(event);
  }
  _onMouseMove(event) {
    if (!event.isTrusted)
      return;
    if (this._mode === "none")
      return;
    const target2 = this._deepEventTarget(event);
    if (this._hoveredElement === target2)
      return;
    this._hoveredElement = target2;
    this._updateModelForHoveredElement();
  }
  _onMouseLeave(event) {
    if (!event.isTrusted)
      return;
    if (this._injectedScript.window.top !== this._injectedScript.window && this._deepEventTarget(event).nodeType === Node.DOCUMENT_NODE) {
      this._hoveredElement = null;
      this._updateModelForHoveredElement();
    }
  }
  _onFocus(userGesture) {
    if (this._mode === "none")
      return;
    const activeElement = this._deepActiveElement(this.document);
    if (userGesture && activeElement === this.document.body)
      return;
    const result = activeElement ? generateSelector(this._injectedScript, activeElement, { testIdAttributeName: this._testIdAttributeName }) : null;
    this._activeModel = result && result.selector ? result : null;
    if (userGesture)
      this._hoveredElement = activeElement;
    this._updateModelForHoveredElement();
  }
  _updateModelForHoveredElement() {
    if (!this._hoveredElement || !this._hoveredElement.isConnected) {
      this._hoveredModel = null;
      this._hoveredElement = null;
      this._updateHighlight();
      return;
    }
    const hoveredElement = this._hoveredElement;
    const { selector, elements } = generateSelector(this._injectedScript, hoveredElement, { testIdAttributeName: this._testIdAttributeName });
    if (this._hoveredModel && this._hoveredModel.selector === selector)
      return;
    this._hoveredModel = selector ? { selector, elements } : null;
    this._updateHighlight();
  }
  _updateHighlight() {
    const elements = this._hoveredModel ? this._hoveredModel.elements : [];
    const selector = this._hoveredModel ? this._hoveredModel.selector : "";
    this._highlight.updateHighlight(elements, selector, this._mode === "recording");
  }
  _onInput(event) {
    var _a, _b, _c, _d;
    if (this._mode !== "recording")
      return true;
    const target2 = this._deepEventTarget(event);
    if (target2.nodeName === "INPUT" && target2.type.toLowerCase() === "file") {
      (_b = (_a = this._delegate).recordAction) == null ? void 0 : _b.call(_a, {
        name: "setInputFiles",
        selector: this._activeModel.selector,
        signals: [],
        files: [...target2.files || []].map((file) => file.name)
      });
      return;
    }
    if (["INPUT", "TEXTAREA"].includes(target2.nodeName) || target2.isContentEditable) {
      if (target2.nodeName === "INPUT" && ["checkbox", "radio"].includes(target2.type.toLowerCase())) {
        return;
      }
      if (this._consumedDueWrongTarget(event))
        return;
      (_d = (_c = this._delegate).recordAction) == null ? void 0 : _d.call(_c, {
        name: "fill",
        selector: this._activeModel.selector,
        signals: [],
        text: target2.isContentEditable ? target2.innerText : target2.value
      });
    }
    if (target2.nodeName === "SELECT") {
      const selectElement = target2;
      if (this._actionInProgress(event))
        return;
      this._performAction({
        name: "select",
        selector: this._hoveredModel.selector,
        options: [...selectElement.selectedOptions].map((option) => option.value),
        signals: []
      });
    }
  }
  _shouldGenerateKeyPressFor(event) {
    if (event.key === "Enter" && (this._deepEventTarget(event).nodeName === "TEXTAREA" || this._deepEventTarget(event).isContentEditable))
      return false;
    if (["Backspace", "Delete", "AltGraph"].includes(event.key))
      return false;
    if (event.key === "@" && event.code === "KeyL")
      return false;
    if (navigator.platform.includes("Mac")) {
      if (event.key === "v" && event.metaKey)
        return false;
    } else {
      if (event.key === "v" && event.ctrlKey)
        return false;
      if (event.key === "Insert" && event.shiftKey)
        return false;
    }
    if (["Shift", "Control", "Meta", "Alt", "Process"].includes(event.key))
      return false;
    const hasModifier = event.ctrlKey || event.altKey || event.metaKey;
    if (event.key.length === 1 && !hasModifier)
      return !!asCheckbox(this._deepEventTarget(event));
    return true;
  }
  _onKeyDown(event) {
    if (!event.isTrusted)
      return;
    if (this._mode === "inspecting") {
      consumeEvent(event);
      return;
    }
    if (this._mode !== "recording")
      return;
    if (!this._shouldGenerateKeyPressFor(event))
      return;
    if (this._actionInProgress(event)) {
      this._expectProgrammaticKeyUp = true;
      return;
    }
    if (this._consumedDueWrongTarget(event))
      return;
    if (event.key === " ") {
      const checkbox = asCheckbox(this._deepEventTarget(event));
      if (checkbox) {
        this._performAction({
          name: checkbox.checked ? "uncheck" : "check",
          selector: this._activeModel.selector,
          signals: []
        });
        return;
      }
    }
    this._performAction({
      name: "press",
      selector: this._activeModel.selector,
      signals: [],
      key: event.key,
      modifiers: modifiersForEvent(event)
    });
  }
  _onKeyUp(event) {
    if (!event.isTrusted)
      return;
    if (this._mode === "none")
      return;
    if (!this._shouldGenerateKeyPressFor(event))
      return;
    if (!this._expectProgrammaticKeyUp) {
      consumeEvent(event);
      return;
    }
    this._expectProgrammaticKeyUp = false;
  }
  async _performAction(action) {
    var _a, _b;
    this._clearHighlight();
    this._performingAction = true;
    await ((_b = (_a = this._delegate).performAction) == null ? void 0 : _b.call(_a, action).catch(() => {
    }));
    this._performingAction = false;
    this._onFocus(false);
    if (this._injectedScript.isUnderTest) {
      console.error("Action performed for test: " + JSON.stringify({
        // eslint-disable-line no-console
        hovered: this._hoveredModel ? this._hoveredModel.selector : null,
        active: this._activeModel ? this._activeModel.selector : null
      }));
    }
  }
  _deepEventTarget(event) {
    return event.composedPath()[0];
  }
  _deepActiveElement(document2) {
    let activeElement = document2.activeElement;
    while (activeElement && activeElement.shadowRoot && activeElement.shadowRoot.activeElement)
      activeElement = activeElement.shadowRoot.activeElement;
    return activeElement;
  }
}
function modifiersForEvent(event) {
  return (event.altKey ? 1 : 0) | (event.ctrlKey ? 2 : 0) | (event.metaKey ? 4 : 0) | (event.shiftKey ? 8 : 0);
}
function buttonForEvent(event) {
  switch (event.which) {
    case 1:
      return "left";
    case 2:
      return "middle";
    case 3:
      return "right";
  }
  return "left";
}
function positionForEvent(event) {
  const targetElement = event.target;
  if (targetElement.nodeName !== "CANVAS")
    return;
  return {
    x: event.offsetX,
    y: event.offsetY
  };
}
function consumeEvent(e) {
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();
}
function asCheckbox(node) {
  if (!node || node.nodeName !== "INPUT")
    return null;
  const inputElement = node;
  return ["checkbox", "radio"].includes(inputElement.type) ? inputElement : null;
}
function addEventListener(target2, eventName, listener, useCapture) {
  target2.addEventListener(eventName, listener, useCapture);
  const remove = () => {
    target2.removeEventListener(eventName, listener, useCapture);
  };
  return remove;
}
function removeEventListeners(listeners2) {
  for (const listener of listeners2)
    listener();
  listeners2.splice(0, listeners2.length);
}
function querySelector(injectedScript, selector, ownerDocument) {
  try {
    const parsedSelector = injectedScript.parseSelector(selector);
    return {
      selector,
      elements: injectedScript.querySelectorAll(parsedSelector, ownerDocument)
    };
  } catch (e) {
    return {
      selector,
      elements: []
    };
  }
}
function getByAttributeTextSelector(attrName, text, options) {
  return `internal:attr=[${attrName}=${escapeForAttributeSelector(text, (options == null ? void 0 : options.exact) || false)}]`;
}
function getByTestIdSelector(testIdAttributeName, testId) {
  return `internal:testid=[${testIdAttributeName}=${escapeForAttributeSelector(testId, true)}]`;
}
function getByLabelSelector(text, options) {
  return "internal:label=" + escapeForTextSelector(text, !!(options == null ? void 0 : options.exact));
}
function getByAltTextSelector(text, options) {
  return getByAttributeTextSelector("alt", text, options);
}
function getByTitleSelector(text, options) {
  return getByAttributeTextSelector("title", text, options);
}
function getByPlaceholderSelector(text, options) {
  return getByAttributeTextSelector("placeholder", text, options);
}
function getByTextSelector(text, options) {
  return "internal:text=" + escapeForTextSelector(text, !!(options == null ? void 0 : options.exact));
}
function getByRoleSelector(role, options = {}) {
  const props = [];
  if (options.checked !== void 0)
    props.push(["checked", String(options.checked)]);
  if (options.disabled !== void 0)
    props.push(["disabled", String(options.disabled)]);
  if (options.selected !== void 0)
    props.push(["selected", String(options.selected)]);
  if (options.expanded !== void 0)
    props.push(["expanded", String(options.expanded)]);
  if (options.includeHidden !== void 0)
    props.push(["include-hidden", String(options.includeHidden)]);
  if (options.level !== void 0)
    props.push(["level", String(options.level)]);
  if (options.name !== void 0)
    props.push(["name", isString(options.name) ? escapeForAttributeSelector(options.name, !!options.exact) : String(options.name)]);
  if (options.pressed !== void 0)
    props.push(["pressed", String(options.pressed)]);
  return `internal:role=${role}${props.map(([n2, v2]) => `[${n2}=${v2}]`).join("")}`;
}
const selectorSymbol = Symbol("selector");
const injectedScriptSymbol = Symbol("injectedScript");
class Locator {
  constructor(injectedScript, selector, options) {
    this[selectorSymbol] = selector;
    this[injectedScriptSymbol] = injectedScript;
    if (options == null ? void 0 : options.hasText)
      selector += ` >> internal:has-text=${escapeForTextSelector(options.hasText, false)}`;
    if (options == null ? void 0 : options.hasNotText)
      selector += ` >> internal:has-not-text=${escapeForTextSelector(options.hasNotText, false)}`;
    if (options == null ? void 0 : options.has)
      selector += ` >> internal:has=` + JSON.stringify(options.has[selectorSymbol]);
    if (options == null ? void 0 : options.hasNot)
      selector += ` >> internal:has-not=` + JSON.stringify(options.hasNot[selectorSymbol]);
    if (selector) {
      const parsed = injectedScript.parseSelector(selector);
      this.element = injectedScript.querySelector(parsed, injectedScript.document, false);
      this.elements = injectedScript.querySelectorAll(parsed, injectedScript.document);
    }
    const selectorBase = selector;
    const self2 = this;
    self2.locator = (selector2, options2) => {
      return new Locator(injectedScript, selectorBase ? selectorBase + " >> " + selector2 : selector2, options2);
    };
    self2.getByTestId = (testId) => self2.locator(getByTestIdSelector(injectedScript.testIdAttributeNameForStrictErrorAndConsoleCodegen(), testId));
    self2.getByAltText = (text, options2) => self2.locator(getByAltTextSelector(text, options2));
    self2.getByLabel = (text, options2) => self2.locator(getByLabelSelector(text, options2));
    self2.getByPlaceholder = (text, options2) => self2.locator(getByPlaceholderSelector(text, options2));
    self2.getByText = (text, options2) => self2.locator(getByTextSelector(text, options2));
    self2.getByTitle = (text, options2) => self2.locator(getByTitleSelector(text, options2));
    self2.getByRole = (role, options2 = {}) => self2.locator(getByRoleSelector(role, options2));
    self2.filter = (options2) => new Locator(injectedScript, selector, options2);
    self2.first = () => self2.locator("nth=0");
    self2.last = () => self2.locator("nth=-1");
    self2.nth = (index) => self2.locator(`nth=${index}`);
    self2.and = (locator) => new Locator(injectedScript, selectorBase + ` >> internal:and=` + JSON.stringify(locator[selectorSymbol]));
    self2.or = (locator) => new Locator(injectedScript, selectorBase + ` >> internal:or=` + JSON.stringify(locator[selectorSymbol]));
  }
}
class ConsoleAPI {
  constructor(injectedScript) {
    this._injectedScript = injectedScript;
    if (this._injectedScript.window.playwright)
      return;
    this._injectedScript.window.playwright = {
      $: (selector, strict) => this._querySelector(selector, !!strict),
      $$: (selector) => this._querySelectorAll(selector),
      inspect: (selector) => this._inspect(selector),
      selector: (element) => this._selector(element),
      generateLocator: (element, language) => this._generateLocator(element, language),
      resume: () => this._resume(),
      ...new Locator(injectedScript, "")
    };
    delete this._injectedScript.window.playwright.filter;
    delete this._injectedScript.window.playwright.first;
    delete this._injectedScript.window.playwright.last;
    delete this._injectedScript.window.playwright.nth;
    delete this._injectedScript.window.playwright.and;
    delete this._injectedScript.window.playwright.or;
  }
  _querySelector(selector, strict) {
    if (typeof selector !== "string")
      throw new Error(`Usage: playwright.query('Playwright >> selector').`);
    const parsed = this._injectedScript.parseSelector(selector);
    return this._injectedScript.querySelector(parsed, this._injectedScript.document, strict);
  }
  _querySelectorAll(selector) {
    if (typeof selector !== "string")
      throw new Error(`Usage: playwright.$$('Playwright >> selector').`);
    const parsed = this._injectedScript.parseSelector(selector);
    return this._injectedScript.querySelectorAll(parsed, this._injectedScript.document);
  }
  _inspect(selector) {
    if (typeof selector !== "string")
      throw new Error(`Usage: playwright.inspect('Playwright >> selector').`);
    this._injectedScript.window.inspect(this._querySelector(selector, false));
  }
  _selector(element) {
    if (!(element instanceof Element))
      throw new Error(`Usage: playwright.selector(element).`);
    return this._injectedScript.generateSelector(element);
  }
  _generateLocator(element, language) {
    if (!(element instanceof Element))
      throw new Error(`Usage: playwright.locator(element).`);
    const selector = this._injectedScript.generateSelector(element);
    return asLocator(language || "javascript", selector);
  }
  _resume() {
    this._injectedScript.window.__pw_resume().catch(() => {
    });
  }
}
function parseLocator(locator, testIdAttributeName) {
  locator = locator.replace(/AriaRole\s*\.\s*([\w]+)/g, (_, group) => group.toLowerCase()).replace(/(get_by_role|getByRole)\s*\(\s*(?:["'`])([^'"`]+)['"`]/g, (_, group1, group2) => `${group1}(${group2.toLowerCase()}`);
  const params = [];
  let template = "";
  for (let i = 0; i < locator.length; ++i) {
    const quote = locator[i];
    if (quote !== '"' && quote !== "'" && quote !== "`" && quote !== "/") {
      template += quote;
      continue;
    }
    const isRegexEscaping = locator[i - 1] === "r" || locator[i] === "/";
    ++i;
    let text = "";
    while (i < locator.length) {
      if (locator[i] === "\\") {
        if (isRegexEscaping) {
          if (locator[i + 1] !== quote)
            text += locator[i];
          ++i;
          text += locator[i];
        } else {
          ++i;
          if (locator[i] === "n")
            text += "\n";
          else if (locator[i] === "r")
            text += "\r";
          else if (locator[i] === "t")
            text += "	";
          else
            text += locator[i];
        }
        ++i;
        continue;
      }
      if (locator[i] !== quote) {
        text += locator[i++];
        continue;
      }
      break;
    }
    params.push({ quote, text });
    template += (quote === "/" ? "r" : "") + "$" + params.length;
  }
  template = template.toLowerCase().replace(/get_by_alt_text/g, "getbyalttext").replace(/get_by_test_id/g, "getbytestid").replace(/get_by_([\w]+)/g, "getby$1").replace(/has_not_text/g, "hasnottext").replace(/has_text/g, "hastext").replace(/has_not/g, "hasnot").replace(/frame_locator/g, "framelocator").replace(/[{}\s]/g, "").replace(/new\(\)/g, "").replace(/new[\w]+\.[\w]+options\(\)/g, "").replace(/\.set/g, ",set").replace(/\.or_\(/g, "or(").replace(/\.and_\(/g, "and(").replace(/:/g, "=").replace(/,re\.ignorecase/g, "i").replace(/,pattern.case_insensitive/g, "i").replace(/,regexoptions.ignorecase/g, "i").replace(/re.compile\(([^)]+)\)/g, "$1").replace(/pattern.compile\(([^)]+)\)/g, "r$1").replace(/newregex\(([^)]+)\)/g, "r$1").replace(/string=/g, "=").replace(/regex=/g, "=").replace(/,,/g, ",");
  return transform(template, params, testIdAttributeName);
}
function countParams(template) {
  return [...template.matchAll(/\$\d+/g)].length;
}
function shiftParams(template, sub2) {
  return template.replace(/\$(\d+)/g, (_, ordinal) => `$${ordinal - sub2}`);
}
function transform(template, params, testIdAttributeName) {
  while (true) {
    const hasMatch = template.match(/filter\(,?(has=|hasnot=|sethas\(|sethasnot\()/);
    if (!hasMatch)
      break;
    const start = hasMatch.index + hasMatch[0].length;
    let balance = 0;
    let end = start;
    for (; end < template.length; end++) {
      if (template[end] === "(")
        balance++;
      else if (template[end] === ")")
        balance--;
      if (balance < 0)
        break;
    }
    let prefix = template.substring(0, start);
    let extraSymbol = 0;
    if (["sethas(", "sethasnot("].includes(hasMatch[1])) {
      extraSymbol = 1;
      prefix = prefix.replace(/sethas\($/, "has=").replace(/sethasnot\($/, "hasnot=");
    }
    const paramsCountBeforeHas = countParams(template.substring(0, start));
    const hasTemplate = shiftParams(template.substring(start, end), paramsCountBeforeHas);
    const paramsCountInHas = countParams(hasTemplate);
    const hasParams = params.slice(paramsCountBeforeHas, paramsCountBeforeHas + paramsCountInHas);
    const hasSelector = JSON.stringify(transform(hasTemplate, hasParams, testIdAttributeName));
    template = prefix.replace(/=$/, "2=") + `$${paramsCountBeforeHas + 1}` + shiftParams(template.substring(end + extraSymbol), paramsCountInHas - 1);
    const paramsBeforeHas = params.slice(0, paramsCountBeforeHas);
    const paramsAfterHas = params.slice(paramsCountBeforeHas + paramsCountInHas);
    params = paramsBeforeHas.concat([{ quote: '"', text: hasSelector }]).concat(paramsAfterHas);
  }
  template = template.replace(/\,set([\w]+)\(([^)]+)\)/g, (_, group1, group2) => "," + group1.toLowerCase() + "=" + group2.toLowerCase()).replace(/framelocator\(([^)]+)\)/g, "$1.internal:control=enter-frame").replace(/locator\(([^)]+),hastext=([^),]+)\)/g, "locator($1).internal:has-text=$2").replace(/locator\(([^)]+),hasnottext=([^),]+)\)/g, "locator($1).internal:has-not-text=$2").replace(/locator\(([^)]+),hastext=([^),]+)\)/g, "locator($1).internal:has-text=$2").replace(/locator\(([^)]+)\)/g, "$1").replace(/getbyrole\(([^)]+)\)/g, "internal:role=$1").replace(/getbytext\(([^)]+)\)/g, "internal:text=$1").replace(/getbylabel\(([^)]+)\)/g, "internal:label=$1").replace(/getbytestid\(([^)]+)\)/g, `internal:testid=[${testIdAttributeName}=$1]`).replace(/getby(placeholder|alt|title)(?:text)?\(([^)]+)\)/g, "internal:attr=[$1=$2]").replace(/first(\(\))?/g, "nth=0").replace(/last(\(\))?/g, "nth=-1").replace(/nth\(([^)]+)\)/g, "nth=$1").replace(/filter\(,?hastext=([^)]+)\)/g, "internal:has-text=$1").replace(/filter\(,?hasnottext=([^)]+)\)/g, "internal:has-not-text=$1").replace(/filter\(,?has2=([^)]+)\)/g, "internal:has=$1").replace(/filter\(,?hasnot2=([^)]+)\)/g, "internal:has-not=$1").replace(/,exact=false/g, "").replace(/,exact=true/g, "s").replace(/\,/g, "][");
  const parts = template.split(".");
  for (let index = 0; index < parts.length - 1; index++) {
    if (parts[index] === "internal:control=enter-frame" && parts[index + 1].startsWith("nth=")) {
      const [nth] = parts.splice(index, 1);
      parts.splice(index + 1, 0, nth);
    }
  }
  return parts.map((t2) => {
    if (!t2.startsWith("internal:") || t2 === "internal:control")
      return t2.replace(/\$(\d+)/g, (_, ordinal) => {
        const param = params[+ordinal - 1];
        return param.text;
      });
    t2 = t2.includes("[") ? t2.replace(/\]/, "") + "]" : t2;
    t2 = t2.replace(/(?:r)\$(\d+)(i)?/g, (_, ordinal, suffix) => {
      const param = params[+ordinal - 1];
      if (t2.startsWith("internal:attr") || t2.startsWith("internal:testid") || t2.startsWith("internal:role"))
        return new RegExp(param.text) + (suffix || "");
      return escapeForTextSelector(new RegExp(param.text, suffix), false);
    }).replace(/\$(\d+)(i|s)?/g, (_, ordinal, suffix) => {
      const param = params[+ordinal - 1];
      if (t2.startsWith("internal:has=") || t2.startsWith("internal:has-not="))
        return param.text;
      if (t2.startsWith("internal:testid"))
        return escapeForAttributeSelector(param.text, true);
      if (t2.startsWith("internal:attr") || t2.startsWith("internal:role"))
        return escapeForAttributeSelector(param.text, suffix === "s");
      return escapeForTextSelector(param.text, suffix === "s");
    });
    return t2;
  }).join(" >> ");
}
function locatorOrSelectorAsSelector(language, locator, testIdAttributeName) {
  try {
    parseSelector(locator);
    return locator;
  } catch (e) {
  }
  try {
    const selector = parseLocator(locator, testIdAttributeName);
    const locators = asLocators(language, selector);
    const digest = digestForComparison(locator);
    if (locators.some((candidate) => digestForComparison(candidate) === digest))
      return selector;
  } catch (e) {
  }
  return "";
}
function digestForComparison(locator) {
  return locator.replace(/\s/g, "").replace(/["`]/g, "'");
}
const tabbedPane = "";
const TabbedPane = ({ tabs, selectedTab, setSelectedTab, leftToolbar, rightToolbar }) => {
  return /* @__PURE__ */ jsx("div", { className: "tabbed-pane", children: /* @__PURE__ */ jsxs("div", { className: "vbox", children: [
    /* @__PURE__ */ jsx(Toolbar, { children: [
      ...leftToolbar || [],
      ...tabs.map((tab) => /* @__PURE__ */ jsx(
        TabbedPaneTab,
        {
          id: tab.id,
          title: tab.title,
          count: tab.count,
          selected: selectedTab === tab.id,
          onSelect: setSelectedTab
        }
      )),
      /* @__PURE__ */ jsx("div", { className: "spacer" }),
      ...rightToolbar || []
    ] }),
    tabs.map((tab) => {
      if (tab.component)
        return /* @__PURE__ */ jsx("div", { className: "tab-content", style: { display: selectedTab === tab.id ? "inherit" : "none" }, children: tab.component }, tab.id);
      if (selectedTab === tab.id)
        return /* @__PURE__ */ jsx("div", { className: "tab-content", children: tab.render() }, tab.id);
    })
  ] }) });
};
const TabbedPaneTab = ({ id: id2, title, count, selected, onSelect }) => {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "tabbed-pane-tab " + (selected ? "selected" : ""),
      onClick: () => onSelect(id2),
      children: [
        /* @__PURE__ */ jsx("div", { className: "tabbed-pane-tab-label", children: title }),
        /* @__PURE__ */ jsx("div", { className: "tabbed-pane-tab-count", children: count || "" })
      ]
    },
    id2
  );
};
const SnapshotTab = ({ action, sdkLanguage, testIdAttributeName }) => {
  const [measure, ref] = useMeasure();
  const [snapshotTab2, setSnapshotTab] = reactExports.useState("action");
  const [isInspecting, setIsInspecting] = reactExports.useState(false);
  const [highlightedLocator, setHighlightedLocator] = reactExports.useState("");
  const [pickerVisible, setPickerVisible] = reactExports.useState(false);
  const { snapshots } = reactExports.useMemo(() => {
    if (!action)
      return { snapshots: {} };
    let beforeSnapshot = action.beforeSnapshot ? { action, snapshotName: action.beforeSnapshot } : void 0;
    let a = action;
    while (!beforeSnapshot && a) {
      a = prevInList(a);
      beforeSnapshot = (a == null ? void 0 : a.afterSnapshot) ? { action: a, snapshotName: a == null ? void 0 : a.afterSnapshot } : void 0;
    }
    const afterSnapshot = action.afterSnapshot ? { action, snapshotName: action.afterSnapshot } : beforeSnapshot;
    const actionSnapshot = action.inputSnapshot ? { action, snapshotName: action.inputSnapshot } : afterSnapshot;
    return { snapshots: { action: actionSnapshot, before: beforeSnapshot, after: afterSnapshot } };
  }, [action]);
  const { snapshotInfoUrl, snapshotUrl, pointX, pointY, popoutUrl } = reactExports.useMemo(() => {
    var _a, _b;
    const snapshot = snapshots[snapshotTab2];
    if (!snapshot)
      return { snapshotUrl: kBlankSnapshotUrl };
    const params = new URLSearchParams();
    params.set("trace", context(snapshot.action).traceUrl);
    params.set("name", snapshot.snapshotName);
    const snapshotUrl2 = new URL(`snapshot/${snapshot.action.pageId}?${params.toString()}`, window.location.href).toString();
    const snapshotInfoUrl2 = new URL(`snapshotInfo/${snapshot.action.pageId}?${params.toString()}`, window.location.href).toString();
    const pointX2 = snapshotTab2 === "action" ? (_a = snapshot.action.point) == null ? void 0 : _a.x : void 0;
    const pointY2 = snapshotTab2 === "action" ? (_b = snapshot.action.point) == null ? void 0 : _b.y : void 0;
    const popoutParams = new URLSearchParams();
    popoutParams.set("r", snapshotUrl2);
    popoutParams.set("trace", context(snapshot.action).traceUrl);
    const popoutUrl2 = new URL(`snapshot.html?${popoutParams.toString()}`, window.location.href).toString();
    return { snapshots, snapshotInfoUrl: snapshotInfoUrl2, snapshotUrl: snapshotUrl2, pointX: pointX2, pointY: pointY2, popoutUrl: popoutUrl2 };
  }, [snapshots, snapshotTab2]);
  const iframeRef0 = reactExports.useRef(null);
  const iframeRef1 = reactExports.useRef(null);
  const [snapshotInfo, setSnapshotInfo] = reactExports.useState({ viewport: kDefaultViewport, url: "" });
  const loadingRef = reactExports.useRef({ iteration: 0, visibleIframe: 0 });
  reactExports.useEffect(() => {
    (async () => {
      const thisIteration = loadingRef.current.iteration + 1;
      const newVisibleIframe = 1 - loadingRef.current.visibleIframe;
      loadingRef.current.iteration = thisIteration;
      const newSnapshotInfo = { url: "", viewport: kDefaultViewport };
      if (snapshotInfoUrl) {
        const response = await fetch(snapshotInfoUrl);
        const info = await response.json();
        if (!info.error) {
          newSnapshotInfo.url = info.url;
          newSnapshotInfo.viewport = info.viewport;
        }
      }
      if (loadingRef.current.iteration !== thisIteration)
        return;
      const iframe = [iframeRef0, iframeRef1][newVisibleIframe].current;
      if (iframe) {
        let loadedCallback = () => {
        };
        const loadedPromise = new Promise((f2) => loadedCallback = f2);
        try {
          iframe.addEventListener("load", loadedCallback);
          iframe.addEventListener("error", loadedCallback);
          const newUrl = snapshotUrl + (pointX === void 0 ? "" : `&pointX=${pointX}&pointY=${pointY}`);
          if (iframe.contentWindow)
            iframe.contentWindow.location.replace(newUrl);
          else
            iframe.src = newUrl;
          await loadedPromise;
        } catch {
        } finally {
          iframe.removeEventListener("load", loadedCallback);
          iframe.removeEventListener("error", loadedCallback);
        }
      }
      if (loadingRef.current.iteration !== thisIteration)
        return;
      loadingRef.current.visibleIframe = newVisibleIframe;
      setSnapshotInfo(newSnapshotInfo);
    })();
  }, [snapshotUrl, snapshotInfoUrl, pointX, pointY]);
  const windowHeaderHeight = 40;
  const snapshotContainerSize = {
    width: snapshotInfo.viewport.width,
    height: snapshotInfo.viewport.height + windowHeaderHeight
  };
  const scale = Math.min(measure.width / snapshotContainerSize.width, measure.height / snapshotContainerSize.height, 1);
  const translate = {
    x: (measure.width - snapshotContainerSize.width) / 2,
    y: (measure.height - snapshotContainerSize.height) / 2
  };
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "snapshot-tab",
      tabIndex: 0,
      onKeyDown: (event) => {
        if (event.key === "Escape") {
          if (isInspecting)
            setIsInspecting(false);
        }
      },
      children: [
        /* @__PURE__ */ jsx(
          InspectModeController,
          {
            isInspecting,
            sdkLanguage,
            testIdAttributeName,
            highlightedLocator,
            setHighlightedLocator,
            iframe: iframeRef0.current,
            iteration: loadingRef.current.iteration
          }
        ),
        /* @__PURE__ */ jsx(
          InspectModeController,
          {
            isInspecting,
            sdkLanguage,
            testIdAttributeName,
            highlightedLocator,
            setHighlightedLocator,
            iframe: iframeRef1.current,
            iteration: loadingRef.current.iteration
          }
        ),
        /* @__PURE__ */ jsxs(Toolbar, { children: [
          /* @__PURE__ */ jsx(ToolbarButton, { title: "Pick locator", disabled: !popoutUrl, toggled: pickerVisible, onClick: () => {
            setPickerVisible(!pickerVisible);
            setHighlightedLocator("");
            setIsInspecting(!pickerVisible);
          }, children: "Pick locator" }),
          ["action", "before", "after"].map((tab) => {
            return /* @__PURE__ */ jsx(
              TabbedPaneTab,
              {
                id: tab,
                title: renderTitle(tab),
                selected: snapshotTab2 === tab,
                onSelect: () => setSnapshotTab(tab)
              }
            );
          }),
          /* @__PURE__ */ jsx("div", { style: { flex: "auto" } }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "link-external", title: "Open snapshot in a new tab", disabled: !popoutUrl, onClick: () => {
            const win = window.open(popoutUrl || "", "_blank");
            win == null ? void 0 : win.addEventListener("DOMContentLoaded", () => {
              const injectedScript = new InjectedScript(win, false, sdkLanguage, testIdAttributeName, 1, "chromium", []);
              new ConsoleAPI(injectedScript);
            });
          } })
        ] }),
        pickerVisible && /* @__PURE__ */ jsxs(Toolbar, { noMinHeight: true, children: [
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "microscope", title: "Pick locator", disabled: !popoutUrl, toggled: isInspecting, onClick: () => {
            setIsInspecting(!isInspecting);
          } }),
          /* @__PURE__ */ jsx(CodeMirrorWrapper, { text: highlightedLocator, language: sdkLanguage, readOnly: !popoutUrl, focusOnChange: true, wrapLines: true, onChange: (text) => {
            setHighlightedLocator(text);
            setIsInspecting(false);
          } }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "files", title: "Copy locator", disabled: !popoutUrl, onClick: () => {
            copy$2(highlightedLocator);
          } })
        ] }),
        /* @__PURE__ */ jsx("div", { ref, className: "snapshot-wrapper", children: /* @__PURE__ */ jsxs("div", { className: "snapshot-container", style: {
          width: snapshotContainerSize.width + "px",
          height: snapshotContainerSize.height + "px",
          transform: `translate(${translate.x}px, ${translate.y}px) scale(${scale})`
        }, children: [
          /* @__PURE__ */ jsxs("div", { className: "window-header", children: [
            /* @__PURE__ */ jsxs("div", { style: { whiteSpace: "nowrap" }, children: [
              /* @__PURE__ */ jsx("span", { className: "window-dot", style: { backgroundColor: "rgb(242, 95, 88)" } }),
              /* @__PURE__ */ jsx("span", { className: "window-dot", style: { backgroundColor: "rgb(251, 190, 60)" } }),
              /* @__PURE__ */ jsx("span", { className: "window-dot", style: { backgroundColor: "rgb(88, 203, 66)" } })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "window-address-bar", title: snapshotInfo.url || "about:blank", children: snapshotInfo.url || "about:blank" }),
            /* @__PURE__ */ jsx("div", { style: { marginLeft: "auto" }, children: /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("span", { className: "window-menu-bar" }),
              /* @__PURE__ */ jsx("span", { className: "window-menu-bar" }),
              /* @__PURE__ */ jsx("span", { className: "window-menu-bar" })
            ] }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "snapshot-switcher", children: [
            /* @__PURE__ */ jsx("iframe", { ref: iframeRef0, name: "snapshot", className: loadingRef.current.visibleIframe === 0 ? "snapshot-visible" : "" }),
            /* @__PURE__ */ jsx("iframe", { ref: iframeRef1, name: "snapshot", className: loadingRef.current.visibleIframe === 1 ? "snapshot-visible" : "" })
          ] })
        ] }) })
      ]
    }
  );
};
function renderTitle(snapshotTitle) {
  if (snapshotTitle === "before")
    return "Before";
  if (snapshotTitle === "after")
    return "After";
  if (snapshotTitle === "action")
    return "Action";
  return snapshotTitle;
}
const InspectModeController = ({ iframe, isInspecting, sdkLanguage, testIdAttributeName, highlightedLocator, setHighlightedLocator, iteration }) => {
  reactExports.useEffect(() => {
    const win = iframe == null ? void 0 : iframe.contentWindow;
    let recorder;
    try {
      if (!win)
        return;
      recorder = win._recorder;
      if (!recorder && !isInspecting && !highlightedLocator)
        return;
    } catch {
      return;
    }
    if (!recorder) {
      const injectedScript = new InjectedScript(win, false, sdkLanguage, testIdAttributeName, 1, "chromium", []);
      recorder = new Recorder(injectedScript, {
        async setSelector(selector) {
          setHighlightedLocator(asLocator(
            "javascript",
            selector,
            false,
            true
            /* playSafe */
          ));
        }
      });
      win._recorder = recorder;
    }
    const actionSelector = locatorOrSelectorAsSelector(sdkLanguage, highlightedLocator, testIdAttributeName);
    recorder.setUIState({
      mode: isInspecting ? "inspecting" : "none",
      actionSelector,
      language: sdkLanguage,
      testIdAttributeName
    });
  }, [iframe, isInspecting, highlightedLocator, setHighlightedLocator, sdkLanguage, testIdAttributeName, iteration]);
  return /* @__PURE__ */ jsx(Fragment, {});
};
const kDefaultViewport = { width: 1280, height: 720 };
const kBlankSnapshotUrl = 'data:text/html,<body style="background: #ddd"></body>';
const sourceTab = "";
const stackTrace = "";
const StackFrameListView = ListView;
const StackTraceView = ({ action, setSelectedFrame, selectedFrame }) => {
  const frames = (action == null ? void 0 : action.stack) || [];
  return /* @__PURE__ */ jsx(
    StackFrameListView,
    {
      dataTestId: "stack-trace",
      items: frames,
      selectedItem: frames[selectedFrame],
      render: (frame) => {
        const pathSep = frame.file[1] === ":" ? "\\" : "/";
        return /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("span", { className: "stack-trace-frame-function", children: frame.function || "(anonymous)" }),
          /* @__PURE__ */ jsx("span", { className: "stack-trace-frame-location", children: frame.file.split(pathSep).pop() }),
          /* @__PURE__ */ jsx("span", { className: "stack-trace-frame-line", children: ":" + frame.line })
        ] });
      },
      onSelected: (frame) => setSelectedFrame(frames.indexOf(frame))
    }
  );
};
const SourceTab = ({ action, sources, hideStackFrames, rootDir, fallbackLocation }) => {
  const [lastAction, setLastAction] = reactExports.useState();
  const [selectedFrame, setSelectedFrame] = reactExports.useState(0);
  reactExports.useEffect(() => {
    if (lastAction !== action) {
      setLastAction(action);
      setSelectedFrame(0);
    }
  }, [action, lastAction, setLastAction, setSelectedFrame]);
  const { source, highlight, targetLine, fileName } = useAsyncMemo(async () => {
    var _a, _b, _c;
    const actionLocation = (_a = action == null ? void 0 : action.stack) == null ? void 0 : _a[selectedFrame];
    const shouldUseFallback = !(actionLocation == null ? void 0 : actionLocation.file);
    if (shouldUseFallback && !fallbackLocation)
      return { source: { file: "", errors: [], content: void 0 }, targetLine: 0, highlight: [] };
    const file = shouldUseFallback ? fallbackLocation.file : actionLocation.file;
    let source2 = sources.get(file);
    if (!source2) {
      source2 = { errors: ((_b = fallbackLocation == null ? void 0 : fallbackLocation.source) == null ? void 0 : _b.errors) || [], content: void 0 };
      sources.set(file, source2);
    }
    const targetLine2 = shouldUseFallback ? (fallbackLocation == null ? void 0 : fallbackLocation.line) || ((_c = source2.errors[0]) == null ? void 0 : _c.line) || 0 : actionLocation.line;
    const fileName2 = rootDir && file.startsWith(rootDir) ? file.substring(rootDir.length + 1) : file;
    const highlight2 = source2.errors.map((e) => ({ type: "error", line: e.line, message: e.message }));
    highlight2.push({ line: targetLine2, type: "running" });
    if (source2.content === void 0 || shouldUseFallback) {
      const sha1 = await calculateSha1(file);
      try {
        let response = await fetch(`sha1/src@${sha1}.txt`);
        if (response.status === 404)
          response = await fetch(`file?path=${encodeURIComponent(file)}`);
        source2.content = await response.text();
      } catch {
        source2.content = `<Unable to read "${file}">`;
      }
    }
    return { source: source2, highlight: highlight2, targetLine: targetLine2, fileName: fileName2 };
  }, [action, selectedFrame, rootDir, fallbackLocation], { source: { errors: [], content: "Loading…" }, highlight: [] });
  return /* @__PURE__ */ jsxs(SplitView, { sidebarSize: 200, orientation: "vertical", sidebarHidden: hideStackFrames, children: [
    /* @__PURE__ */ jsxs("div", { className: "vbox", "data-testid": "source-code", children: [
      fileName && /* @__PURE__ */ jsx("div", { className: "source-tab-file-name", children: fileName }),
      /* @__PURE__ */ jsx(CodeMirrorWrapper, { text: source.content || "", language: "javascript", highlight, revealLine: targetLine, readOnly: true, lineNumbers: true })
    ] }),
    /* @__PURE__ */ jsx(StackTraceView, { action, selectedFrame, setSelectedFrame })
  ] });
};
async function calculateSha1(text) {
  const buffer = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-1", buffer);
  const hexCodes = [];
  const view = new DataView(hash);
  for (let i = 0; i < view.byteLength; i += 1) {
    const byte = view.getUint8(i).toString(16).padStart(2, "0");
    hexCodes.push(byte);
  }
  return hexCodes.join("");
}
const filmStrip = "";
const tileSize = { width: 200, height: 45 };
const frameMargin = 2.5;
const rowHeight = tileSize.height + frameMargin * 2;
const FilmStrip = ({ model, boundaries, previewPoint }) => {
  var _a, _b;
  const [measure, ref] = useMeasure();
  const lanesRef = reactExports.useRef(null);
  let pageIndex = 0;
  if (lanesRef.current && previewPoint) {
    const bounds = lanesRef.current.getBoundingClientRect();
    pageIndex = (previewPoint.clientY - bounds.top + lanesRef.current.scrollTop) / rowHeight | 0;
  }
  const screencastFrames = (_b = (_a = model == null ? void 0 : model.pages) == null ? void 0 : _a[pageIndex]) == null ? void 0 : _b.screencastFrames;
  let previewImage = void 0;
  let previewSize = void 0;
  if (previewPoint !== void 0 && screencastFrames) {
    const previewTime = boundaries.minimum + (boundaries.maximum - boundaries.minimum) * previewPoint.x / measure.width;
    previewImage = screencastFrames[upperBound(screencastFrames, previewTime, timeComparator) - 1];
    previewSize = previewImage ? inscribe({ width: previewImage.width, height: previewImage.height }, { width: window.innerWidth * 3 / 4 | 0, height: window.innerHeight * 3 / 4 | 0 }) : void 0;
  }
  return /* @__PURE__ */ jsxs("div", { className: "film-strip", ref, children: [
    /* @__PURE__ */ jsx("div", { className: "film-strip-lanes", ref: lanesRef, children: model == null ? void 0 : model.pages.map((page, index) => /* @__PURE__ */ jsx(
      FilmStripLane,
      {
        boundaries,
        page,
        width: measure.width
      },
      index
    )) }),
    previewImage && previewSize && (previewPoint == null ? void 0 : previewPoint.x) !== void 0 && /* @__PURE__ */ jsx("div", { className: "film-strip-hover", style: {
      width: previewSize.width,
      height: previewSize.height,
      top: measure.bottom + 5,
      left: Math.min(previewPoint.x, measure.width - previewSize.width - 10)
    }, children: /* @__PURE__ */ jsx("img", { src: `sha1/${previewImage.sha1}`, width: previewSize.width, height: previewSize.height }) })
  ] });
};
const FilmStripLane = ({ boundaries, page, width }) => {
  const viewportSize = { width: 0, height: 0 };
  const screencastFrames = page.screencastFrames;
  for (const frame of screencastFrames) {
    viewportSize.width = Math.max(viewportSize.width, frame.width);
    viewportSize.height = Math.max(viewportSize.height, frame.height);
  }
  const frameSize = inscribe(viewportSize, tileSize);
  const startTime = screencastFrames[0].timestamp;
  const endTime = screencastFrames[screencastFrames.length - 1].timestamp;
  const boundariesDuration = boundaries.maximum - boundaries.minimum;
  const gapLeft = (startTime - boundaries.minimum) / boundariesDuration * width;
  const gapRight = (boundaries.maximum - endTime) / boundariesDuration * width;
  const effectiveWidth = (endTime - startTime) / boundariesDuration * width;
  const frameCount = effectiveWidth / (frameSize.width + 2 * frameMargin) | 0;
  const frameDuration = (endTime - startTime) / frameCount;
  const frames = [];
  for (let i = 0; startTime && frameDuration && i < frameCount; ++i) {
    const time = startTime + frameDuration * i;
    const index = upperBound(screencastFrames, time, timeComparator) - 1;
    frames.push(/* @__PURE__ */ jsx("div", { className: "film-strip-frame", style: {
      width: frameSize.width,
      height: frameSize.height,
      backgroundImage: `url(sha1/${screencastFrames[index].sha1})`,
      backgroundSize: `${frameSize.width}px ${frameSize.height}px`,
      margin: frameMargin,
      marginRight: frameMargin
    } }, i));
  }
  frames.push(/* @__PURE__ */ jsx("div", { className: "film-strip-frame", style: {
    width: frameSize.width,
    height: frameSize.height,
    backgroundImage: `url(sha1/${screencastFrames[screencastFrames.length - 1].sha1})`,
    backgroundSize: `${frameSize.width}px ${frameSize.height}px`,
    margin: frameMargin,
    marginRight: frameMargin
  } }, frames.length));
  return /* @__PURE__ */ jsx("div", { className: "film-strip-lane", style: {
    marginLeft: gapLeft + "px",
    marginRight: gapRight + "px"
  }, children: frames });
};
function timeComparator(time, frame) {
  return time - frame.timestamp;
}
function inscribe(object, area) {
  const scale = Math.max(object.width / area.width, object.height / area.height);
  return {
    width: object.width / scale | 0,
    height: object.height / scale | 0
  };
}
const timeline = "";
const Timeline = ({ model, selectedAction, onSelected, hideTimelineBars, sdkLanguage }) => {
  const [measure, ref] = useMeasure();
  const barsRef = reactExports.useRef(null);
  const [previewPoint, setPreviewPoint] = reactExports.useState();
  const [hoveredBarIndex, setHoveredBarIndex] = reactExports.useState();
  const { boundaries, offsets } = reactExports.useMemo(() => {
    const boundaries2 = { minimum: (model == null ? void 0 : model.startTime) || 0, maximum: (model == null ? void 0 : model.endTime) || 3e4 };
    if (boundaries2.minimum > boundaries2.maximum) {
      boundaries2.minimum = 0;
      boundaries2.maximum = 3e4;
    }
    boundaries2.maximum += (boundaries2.maximum - boundaries2.minimum) / 20;
    return { boundaries: boundaries2, offsets: calculateDividerOffsets(measure.width, boundaries2) };
  }, [measure.width, model]);
  const bars = reactExports.useMemo(() => {
    const bars2 = [];
    for (const entry of (model == null ? void 0 : model.actions) || []) {
      const locator = asLocator(
        sdkLanguage || "javascript",
        entry.params.selector,
        false,
        true
        /* playSafe */
      );
      let detail = trimRight(locator || "", 50);
      if (entry.method === "goto")
        detail = trimRight(entry.params.url || "", 50);
      bars2.push({
        action: entry,
        leftTime: entry.startTime,
        rightTime: entry.endTime,
        leftPosition: timeToPosition(measure.width, boundaries, entry.startTime),
        rightPosition: timeToPosition(measure.width, boundaries, entry.endTime),
        label: entry.apiName + " " + detail,
        title: entry.endTime ? msToString(entry.endTime - entry.startTime) : "Timed Out",
        type: entry.type + "." + entry.method,
        className: `${entry.type}_${entry.method}`.toLowerCase()
      });
    }
    for (const event of (model == null ? void 0 : model.events) || []) {
      const startTime = event.time;
      bars2.push({
        event,
        leftTime: startTime,
        rightTime: startTime,
        leftPosition: timeToPosition(measure.width, boundaries, startTime),
        rightPosition: timeToPosition(measure.width, boundaries, startTime),
        label: event.method,
        title: void 0,
        type: event.class + "." + event.method,
        className: `${event.class}_${event.method}`.toLowerCase()
      });
    }
    return bars2;
  }, [model, boundaries, measure.width, sdkLanguage]);
  const hoveredBar = hoveredBarIndex !== void 0 ? bars[hoveredBarIndex] : void 0;
  let targetBar = bars.find((bar) => bar.action === selectedAction);
  targetBar = hoveredBar || targetBar;
  const findHoveredBarIndex = (x2) => {
    const time = positionToTime(measure.width, boundaries, x2);
    const time1 = positionToTime(measure.width, boundaries, x2 - 5);
    const time2 = positionToTime(measure.width, boundaries, x2 + 5);
    let index;
    let xDistance;
    for (let i = 0; i < bars.length; i++) {
      const bar = bars[i];
      const left = Math.max(bar.leftTime, time1);
      const right = Math.min(bar.rightTime, time2);
      const xMiddle = (bar.leftTime + bar.rightTime) / 2;
      const xd2 = Math.abs(time - xMiddle);
      if (left > right)
        continue;
      if (index === void 0 || xd2 < xDistance) {
        index = i;
        xDistance = xd2;
      }
    }
    return index;
  };
  const onMouseMove = (event) => {
    if (!ref.current)
      return;
    const x2 = event.clientX - ref.current.getBoundingClientRect().left;
    const index = findHoveredBarIndex(x2);
    setPreviewPoint({ x: x2, clientY: event.clientY });
    setHoveredBarIndex(index);
  };
  const onMouseLeave = () => {
    setPreviewPoint(void 0);
    setHoveredBarIndex(void 0);
  };
  const onClick = (event) => {
    setPreviewPoint(void 0);
    if (!ref.current)
      return;
    const x2 = event.clientX - ref.current.getBoundingClientRect().left;
    const index = findHoveredBarIndex(x2);
    if (index === void 0)
      return;
    const entry = bars[index].action;
    if (entry)
      onSelected(entry);
  };
  return /* @__PURE__ */ jsx("div", { style: { flex: "none", borderBottom: "1px solid var(--vscode-panel-border)" }, children: /* @__PURE__ */ jsxs("div", { ref, className: "timeline-view", onMouseMove, onMouseOver: onMouseMove, onMouseLeave, onClick, children: [
    /* @__PURE__ */ jsx("div", { className: "timeline-grid", children: offsets.map((offset, index) => {
      return /* @__PURE__ */ jsx("div", { className: "timeline-divider", style: { left: offset.position + "px" }, children: /* @__PURE__ */ jsx("div", { className: "timeline-time", children: msToString(offset.time - boundaries.minimum) }) }, index);
    }) }),
    !hideTimelineBars && /* @__PURE__ */ jsx("div", { className: "timeline-lane timeline-labels", children: bars.map((bar, index) => {
      return /* @__PURE__ */ jsx(
        "div",
        {
          className: "timeline-label " + bar.className + (targetBar === bar ? " selected" : ""),
          style: {
            left: bar.leftPosition,
            maxWidth: 100
          },
          children: bar.label
        },
        index
      );
    }) }),
    !hideTimelineBars && /* @__PURE__ */ jsx("div", { className: "timeline-lane timeline-bars", ref: barsRef, children: bars.map((bar, index) => {
      return /* @__PURE__ */ jsx(
        "div",
        {
          className: "timeline-bar " + (bar.action ? "action " : "") + (bar.event ? "event " : "") + bar.className + (targetBar === bar ? " selected" : ""),
          style: {
            left: bar.leftPosition + "px",
            width: Math.max(1, bar.rightPosition - bar.leftPosition) + "px",
            top: barTop(bar) + "px"
          },
          title: bar.title
        },
        index
      );
    }) }),
    /* @__PURE__ */ jsx(FilmStrip, { model, boundaries, previewPoint }),
    /* @__PURE__ */ jsx("div", { className: "timeline-marker timeline-marker-hover", style: {
      display: previewPoint !== void 0 ? "block" : "none",
      left: ((previewPoint == null ? void 0 : previewPoint.x) || 0) + "px"
    } })
  ] }) });
};
function calculateDividerOffsets(clientWidth, boundaries) {
  const minimumGap = 64;
  let dividerCount = clientWidth / minimumGap;
  const boundarySpan = boundaries.maximum - boundaries.minimum;
  const pixelsPerMillisecond = clientWidth / boundarySpan;
  let sectionTime = boundarySpan / dividerCount;
  const logSectionTime = Math.ceil(Math.log(sectionTime) / Math.LN10);
  sectionTime = Math.pow(10, logSectionTime);
  if (sectionTime * pixelsPerMillisecond >= 5 * minimumGap)
    sectionTime = sectionTime / 5;
  if (sectionTime * pixelsPerMillisecond >= 2 * minimumGap)
    sectionTime = sectionTime / 2;
  const firstDividerTime = boundaries.minimum;
  let lastDividerTime = boundaries.maximum;
  lastDividerTime += minimumGap / pixelsPerMillisecond;
  dividerCount = Math.ceil((lastDividerTime - firstDividerTime) / sectionTime);
  if (!sectionTime)
    dividerCount = 0;
  const offsets = [];
  for (let i = 0; i < dividerCount; ++i) {
    const time = firstDividerTime + sectionTime * i;
    offsets.push({ position: timeToPosition(clientWidth, boundaries, time), time });
  }
  return offsets;
}
function timeToPosition(clientWidth, boundaries, time) {
  return (time - boundaries.minimum) / (boundaries.maximum - boundaries.minimum) * clientWidth;
}
function positionToTime(clientWidth, boundaries, x2) {
  return x2 / clientWidth * (boundaries.maximum - boundaries.minimum) + boundaries.minimum;
}
function trimRight(s, maxLength) {
  return s.length <= maxLength ? s : s.substring(0, maxLength - 1) + "…";
}
function barTop(bar) {
  var _a;
  return bar.event ? 22 : ((_a = bar.action) == null ? void 0 : _a.method) === "waitForEventInfo" ? 0 : 11;
}
const MetadataView = ({ model }) => {
  var _a, _b;
  if (!model)
    return /* @__PURE__ */ jsx(Fragment, {});
  return /* @__PURE__ */ jsxs("div", { className: "metadata-view vbox", children: [
    /* @__PURE__ */ jsx("div", { className: "call-section", style: { paddingTop: 2 }, children: "Time" }),
    !!model.wallTime && /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "start time:",
      /* @__PURE__ */ jsx("span", { className: "call-value datetime", title: new Date(model.wallTime).toLocaleString(), children: new Date(model.wallTime).toLocaleString() })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "duration:",
      /* @__PURE__ */ jsx("span", { className: "call-value number", title: msToString(model.endTime - model.startTime), children: msToString(model.endTime - model.startTime) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "call-section", children: "Browser" }),
    /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "engine:",
      /* @__PURE__ */ jsx("span", { className: "call-value string", title: model.browserName, children: model.browserName })
    ] }),
    model.platform && /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "platform:",
      /* @__PURE__ */ jsx("span", { className: "call-value string", title: model.platform, children: model.platform })
    ] }),
    model.options.userAgent && /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "user agent:",
      /* @__PURE__ */ jsx("span", { className: "call-value datetime", title: model.options.userAgent, children: model.options.userAgent })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "call-section", children: "Viewport" }),
    model.options.viewport && /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "width:",
      /* @__PURE__ */ jsx("span", { className: "call-value number", title: String(!!((_a = model.options.viewport) == null ? void 0 : _a.width)), children: model.options.viewport.width })
    ] }),
    model.options.viewport && /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "height:",
      /* @__PURE__ */ jsx("span", { className: "call-value number", title: String(!!((_b = model.options.viewport) == null ? void 0 : _b.height)), children: model.options.viewport.height })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "is mobile:",
      /* @__PURE__ */ jsx("span", { className: "call-value boolean", title: String(!!model.options.isMobile), children: String(!!model.options.isMobile) })
    ] }),
    model.options.deviceScaleFactor && /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "device scale:",
      /* @__PURE__ */ jsx("span", { className: "call-value number", title: String(model.options.deviceScaleFactor), children: String(model.options.deviceScaleFactor) })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "call-section", children: "Counts" }),
    /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "pages:",
      /* @__PURE__ */ jsx("span", { className: "call-value number", children: model.pages.length })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "actions:",
      /* @__PURE__ */ jsx("span", { className: "call-value number", children: model.actions.length })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "call-line", children: [
      "events:",
      /* @__PURE__ */ jsx("span", { className: "call-value number", children: model.events.length })
    ] })
  ] });
};
const attachmentsTab = "";
const imageDiffView = "";
const ImageDiffView = ({ imageDiff: diff }) => {
  const [mode, setMode] = reactExports.useState(diff.diff ? "diff" : "actual");
  const diffElement = reactExports.useRef(null);
  const imageElement = reactExports.useRef(null);
  const [sliderPosition, setSliderPosition] = reactExports.useState(0);
  const onImageLoaded = (side) => {
    if (diffElement.current)
      diffElement.current.style.minHeight = diffElement.current.offsetHeight + "px";
    if (side && diffElement.current && imageElement.current) {
      const gap2 = Math.max(0, (diffElement.current.offsetWidth - imageElement.current.offsetWidth) / 2 - 20);
      if (side === "left")
        setSliderPosition(gap2);
      else if (side === "right")
        setSliderPosition(diffElement.current.offsetWidth - gap2);
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "vbox image-diff-view", children: [
    /* @__PURE__ */ jsxs("div", { className: "hbox modes", children: [
      diff.diff && /* @__PURE__ */ jsx("div", { onClick: () => setMode("diff"), children: "Diff" }),
      /* @__PURE__ */ jsx("div", { onClick: () => setMode("actual"), children: "Actual" }),
      /* @__PURE__ */ jsx("div", { onClick: () => setMode("expected"), children: "Expected" })
    ] }),
    /* @__PURE__ */ jsxs("div", { style: { position: "relative" }, ref: diffElement, children: [
      diff.diff && mode === "diff" && /* @__PURE__ */ jsx(ImageWithSize, { src: diff.diff.attachment.path, onLoad: () => onImageLoaded() }),
      diff.diff && mode === "actual" && /* @__PURE__ */ jsxs(ImageDiffSlider, { sliderPosition, setSliderPosition, children: [
        /* @__PURE__ */ jsx(ImageWithSize, { src: diff.expected.attachment.path, onLoad: () => onImageLoaded("right"), imageRef: imageElement, style: { boxShadow: "none" } }),
        /* @__PURE__ */ jsx(ImageWithSize, { src: diff.actual.attachment.path })
      ] }),
      diff.diff && mode === "expected" && /* @__PURE__ */ jsxs(ImageDiffSlider, { sliderPosition, setSliderPosition, children: [
        /* @__PURE__ */ jsx(ImageWithSize, { src: diff.expected.attachment.path, onLoad: () => onImageLoaded("left"), imageRef: imageElement }),
        /* @__PURE__ */ jsx(ImageWithSize, { src: diff.actual.attachment.path, style: { boxShadow: "none" } })
      ] }),
      !diff.diff && mode === "actual" && /* @__PURE__ */ jsx(ImageWithSize, { src: diff.actual.attachment.path, onLoad: () => onImageLoaded() }),
      !diff.diff && mode === "expected" && /* @__PURE__ */ jsx(ImageWithSize, { src: diff.expected.attachment.path, onLoad: () => onImageLoaded() })
    ] })
  ] });
};
const ImageDiffSlider = ({ children, sliderPosition, setSliderPosition }) => {
  const [resizing, setResizing] = reactExports.useState(null);
  const size = sliderPosition;
  const childrenArray = reactExports.Children.toArray(children);
  document.body.style.userSelect = resizing ? "none" : "inherit";
  const gripStyle = {
    ...absolute,
    zIndex: 100,
    cursor: "ew-resize",
    left: resizing ? 0 : size - 4,
    right: resizing ? 0 : void 0,
    width: resizing ? "initial" : 8
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    childrenArray[0],
    /* @__PURE__ */ jsxs("div", { style: { ...absolute }, children: [
      /* @__PURE__ */ jsx("div", { style: {
        ...absolute,
        display: "flex",
        zIndex: 50,
        clip: `rect(0, ${size}px, auto, 0)`,
        backgroundColor: "var(--vscode-panel-background)"
      }, children: childrenArray[1] }),
      /* @__PURE__ */ jsx(
        "div",
        {
          style: gripStyle,
          onMouseDown: (event) => setResizing({ offset: event.clientX, size }),
          onMouseUp: () => setResizing(null),
          onMouseMove: (event) => {
            if (!event.buttons) {
              setResizing(null);
            } else if (resizing) {
              const offset = event.clientX;
              const delta2 = offset - resizing.offset;
              const newSize = resizing.size + delta2;
              const splitView2 = event.target.parentElement;
              const rect2 = splitView2.getBoundingClientRect();
              const size2 = Math.min(Math.max(0, newSize), rect2.width);
              setSliderPosition(size2);
            }
          }
        }
      ),
      /* @__PURE__ */ jsxs("div", { "data-testid": "test-result-image-mismatch-grip", style: {
        ...absolute,
        left: size - 1,
        width: 20,
        zIndex: 80,
        margin: "10px -10px",
        pointerEvents: "none",
        display: "flex"
      }, children: [
        /* @__PURE__ */ jsx("div", { style: {
          position: "absolute",
          top: 0,
          bottom: 0,
          left: 9,
          width: 2,
          backgroundColor: "var(--vscode-panel-border)"
        } }),
        /* @__PURE__ */ jsxs("svg", { style: { fill: "var(--vscode-panel-border)" }, viewBox: "0 0 27 20", children: [
          /* @__PURE__ */ jsx("path", { d: "M9.6 0L0 9.6l9.6 9.6z" }),
          /* @__PURE__ */ jsx("path", { d: "M17 19.2l9.5-9.6L16.9 0z" })
        ] })
      ] })
    ] })
  ] });
};
const ImageWithSize = ({ src, onLoad, imageRef, style }) => {
  const newRef = reactExports.useRef(null);
  const ref = imageRef ?? newRef;
  const [size, setSize] = reactExports.useState(null);
  return /* @__PURE__ */ jsxs("div", { className: "image-wrapper", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("span", { style: { flex: "1 1 0", textAlign: "end" }, children: size ? size.width : "" }),
      /* @__PURE__ */ jsx("span", { style: { flex: "none", margin: "0 5px" }, children: "x" }),
      /* @__PURE__ */ jsx("span", { style: { flex: "1 1 0", textAlign: "start" }, children: size ? size.height : "" })
    ] }),
    /* @__PURE__ */ jsx("img", { draggable: "false", src, onLoad: () => {
      onLoad == null ? void 0 : onLoad();
      if (ref.current)
        setSize({ width: ref.current.naturalWidth, height: ref.current.naturalHeight });
    }, ref, style })
  ] });
};
const absolute = {
  position: "absolute",
  top: 0,
  right: 0,
  bottom: 0,
  left: 0
};
const AttachmentsTab = ({ action }) => {
  var _a, _b, _c, _d;
  if (!action)
    return null;
  const expected = (_a = action.attachments) == null ? void 0 : _a.find((a) => a.name.endsWith("-expected.png") && (a.path || a.sha1));
  const actual = (_b = action.attachments) == null ? void 0 : _b.find((a) => a.name.endsWith("-actual.png") && (a.path || a.sha1));
  const diff = (_c = action.attachments) == null ? void 0 : _c.find((a) => a.name.endsWith("-diff.png") && (a.path || a.sha1));
  const screenshots = new Set((_d = action.attachments) == null ? void 0 : _d.filter((a) => a.contentType.startsWith("image/")));
  const otherAttachments = new Set(action.attachments || []);
  screenshots.forEach((a) => otherAttachments.delete(a));
  const traceUrl = action.context.traceUrl;
  return /* @__PURE__ */ jsxs("div", { className: "attachments-tab", children: [
    expected && actual && /* @__PURE__ */ jsx("div", { className: "attachments-section", children: "Image diff" }),
    expected && actual && /* @__PURE__ */ jsx(ImageDiffView, { imageDiff: {
      name: "Image diff",
      expected: { attachment: { ...expected, path: attachmentURL(traceUrl, expected) }, title: "Expected" },
      actual: { attachment: { ...actual, path: attachmentURL(traceUrl, actual) } },
      diff: diff ? { attachment: { ...diff, path: attachmentURL(traceUrl, diff) } } : void 0
    } }),
    screenshots.size ? /* @__PURE__ */ jsx("div", { className: "attachments-section", children: "Screenshots" }) : void 0,
    [...screenshots].map((a, i) => {
      return /* @__PURE__ */ jsxs("div", { className: "attachment-item", children: [
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("img", { draggable: "false", src: attachmentURL(traceUrl, a) }) }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("a", { target: "_blank", href: attachmentURL(traceUrl, a), children: a.name }) })
      ] }, `screenshot-${i}`);
    }),
    otherAttachments.size ? /* @__PURE__ */ jsx("div", { className: "attachments-section", children: "Attachments" }) : void 0,
    [...otherAttachments].map((a, i) => {
      return /* @__PURE__ */ jsx("div", { className: "attachment-item", children: /* @__PURE__ */ jsx("a", { target: "_blank", href: attachmentURL(traceUrl, a), children: a.name }) }, `attachment-${i}`);
    })
  ] });
};
function attachmentURL(traceUrl, attachment) {
  if (attachment.sha1)
    return "sha1/" + attachment.sha1 + "?trace=" + encodeURIComponent(traceUrl);
  return "file?path=" + encodeURIComponent(attachment.path);
}
const Workbench = ({ model, hideTimelineBars, hideStackFrames, showSourcesFirst, rootDir, fallbackLocation, initialSelection, onSelectionChanged, isLive, drawer }) => {
  const [selectedAction, setSelectedAction] = reactExports.useState(void 0);
  const [highlightedAction, setHighlightedAction] = reactExports.useState();
  const [selectedNavigatorTab, setSelectedNavigatorTab] = reactExports.useState("actions");
  const [selectedPropertiesTab, setSelectedPropertiesTab] = reactExports.useState(showSourcesFirst ? "source" : "call");
  const activeAction = model ? highlightedAction || selectedAction : void 0;
  const sources = reactExports.useMemo(() => (model == null ? void 0 : model.sources) || /* @__PURE__ */ new Map(), [model]);
  reactExports.useEffect(() => {
    if (selectedAction && (model == null ? void 0 : model.actions.includes(selectedAction)))
      return;
    const failedAction = model == null ? void 0 : model.actions.find((a) => a.error);
    if (initialSelection && (model == null ? void 0 : model.actions.includes(initialSelection)))
      setSelectedAction(initialSelection);
    else if (failedAction)
      setSelectedAction(failedAction);
    else if (model == null ? void 0 : model.actions.length)
      setSelectedAction(model.actions[model.actions.length - 1]);
  }, [model, selectedAction, setSelectedAction, setSelectedPropertiesTab, initialSelection]);
  const onActionSelected = reactExports.useCallback((action) => {
    setSelectedAction(action);
    onSelectionChanged == null ? void 0 : onSelectionChanged(action);
  }, [setSelectedAction, onSelectionChanged]);
  const { errors, warnings } = activeAction ? stats(activeAction) : { errors: 0, warnings: 0 };
  const consoleCount = errors + warnings;
  const networkCount = activeAction ? resourcesForAction(activeAction).length : 0;
  const sdkLanguage = (model == null ? void 0 : model.sdkLanguage) || "javascript";
  const callTab2 = {
    id: "call",
    title: "Call",
    render: () => /* @__PURE__ */ jsx(CallTab, { action: activeAction, sdkLanguage })
  };
  const sourceTab2 = {
    id: "source",
    title: "Source",
    render: () => /* @__PURE__ */ jsx(
      SourceTab,
      {
        action: activeAction,
        sources,
        hideStackFrames,
        rootDir,
        fallbackLocation
      }
    )
  };
  const consoleTab2 = {
    id: "console",
    title: "Console",
    count: consoleCount,
    render: () => /* @__PURE__ */ jsx(ConsoleTab, { action: activeAction })
  };
  const networkTab2 = {
    id: "network",
    title: "Network",
    count: networkCount,
    render: () => /* @__PURE__ */ jsx(NetworkTab, { action: activeAction })
  };
  const attachmentsTab2 = {
    id: "attachments",
    title: "Attachments",
    render: () => /* @__PURE__ */ jsx(AttachmentsTab, { action: activeAction })
  };
  const tabs = showSourcesFirst ? [
    sourceTab2,
    consoleTab2,
    networkTab2,
    callTab2,
    attachmentsTab2
  ] : [
    callTab2,
    consoleTab2,
    networkTab2,
    sourceTab2,
    attachmentsTab2
  ];
  return /* @__PURE__ */ jsxs("div", { className: "vbox", children: [
    /* @__PURE__ */ jsx(
      Timeline,
      {
        model,
        selectedAction: activeAction,
        onSelected: onActionSelected,
        hideTimelineBars,
        sdkLanguage
      }
    ),
    /* @__PURE__ */ jsxs(SplitView, { sidebarSize: 250, orientation: drawer === "bottom" ? "vertical" : "horizontal", children: [
      /* @__PURE__ */ jsxs(SplitView, { sidebarSize: 250, orientation: "horizontal", sidebarIsFirst: true, children: [
        /* @__PURE__ */ jsx(SnapshotTab, { action: activeAction, sdkLanguage, testIdAttributeName: (model == null ? void 0 : model.testIdAttributeName) || "data-testid" }),
        /* @__PURE__ */ jsx(TabbedPane, { tabs: [
          {
            id: "actions",
            title: "Actions",
            count: 0,
            component: /* @__PURE__ */ jsx(
              ActionList,
              {
                sdkLanguage,
                actions: (model == null ? void 0 : model.actions) || [],
                selectedAction: model ? selectedAction : void 0,
                onSelected: onActionSelected,
                onHighlighted: setHighlightedAction,
                revealConsole: () => setSelectedPropertiesTab("console"),
                isLive
              }
            )
          },
          {
            id: "metadata",
            title: "Metadata",
            count: 0,
            component: /* @__PURE__ */ jsx(MetadataView, { model })
          }
        ], selectedTab: selectedNavigatorTab, setSelectedTab: setSelectedNavigatorTab })
      ] }),
      /* @__PURE__ */ jsx(TabbedPane, { tabs, selectedTab: selectedPropertiesTab, setSelectedTab: setSelectedPropertiesTab })
    ] })
  ] });
};
let lastId = 0;
let _ws;
const callbacks = /* @__PURE__ */ new Map();
async function connect(options) {
  const guid = new URLSearchParams(window.location.search).get("ws");
  const ws = new WebSocket(`${window.location.protocol === "https:" ? "wss" : "ws"}://${window.location.hostname}:${window.location.port}/${guid}`);
  await new Promise((f2) => ws.addEventListener("open", f2));
  ws.addEventListener("close", options.onClose);
  ws.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    const { id: id2, result, error, method, params } = message;
    if (id2) {
      const callback = callbacks.get(id2);
      if (!callback)
        return;
      callbacks.delete(id2);
      if (error)
        callback.reject(new Error(error));
      else
        callback.resolve(result);
    } else {
      options.onEvent(method, params);
    }
  });
  _ws = ws;
  setInterval(() => sendMessage("ping").catch(() => {
  }), 3e4);
  return sendMessage;
}
const sendMessage = async (method, params) => {
  const id2 = ++lastId;
  const message = { id: id2, method, params };
  _ws.send(JSON.stringify(message));
  return new Promise((resolve, reject) => {
    callbacks.set(id2, { resolve, reject });
  });
};
export {
  Expandable as E,
  MultiTraceModel as M,
  React as R,
  SplitView as S,
  ToolbarButton as T,
  Workbench as W,
  __vitePreload as _,
  jsx as a,
  applyTheme as b,
  connect as c,
  reactDomExports as d,
  currentTheme as e,
  addThemeListener as f,
  removeThemeListener as g,
  useSetting as h,
  Toolbar as i,
  jsxs as j,
  idForAction as k,
  TreeView as l,
  msToString as m,
  commonjsGlobal as n,
  getDefaultExportFromCjs as o,
  reactExports as r,
  settings as s,
  toggleTheme as t,
  useMeasure as u
};
//# sourceMappingURL=wsPort-078ee11a.js.map
