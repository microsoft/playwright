import { u as useMeasure, r as reactExports, e as currentTheme, _ as __vitePreload, f as addThemeListener, g as removeThemeListener, a as jsx, R as React, h as useSetting, c as connect, s as settings, j as jsxs, S as SplitView, i as Toolbar, T as ToolbarButton, t as toggleTheme, E as Expandable, m as msToString, k as idForAction, W as Workbench, M as MultiTraceModel, l as TreeView, b as applyTheme, d as reactDomExports } from "./assets/wsPort-12bc8892.js";
class TeleReporterReceiver {
  constructor(pathSeparator2, reporter, reuseTestCases, reportConfig) {
    this._tests = /* @__PURE__ */ new Map();
    this._listOnly = false;
    this._clearPreviousResultsWhenTestBegins = false;
    this._rootSuite = new TeleSuite("", "root");
    this._pathSeparator = pathSeparator2;
    this._reporter = reporter;
    this._reuseTestCases = reuseTestCases;
    this._reportConfig = reportConfig;
  }
  dispatch(message) {
    const { method, params } = message;
    if (method === "onConfigure") {
      this._onConfigure(params.config);
      return;
    }
    if (method === "onBegin") {
      this._onBegin(params.projects);
      return;
    }
    if (method === "onTestBegin") {
      this._onTestBegin(params.testId, params.result);
      return;
    }
    if (method === "onTestEnd") {
      this._onTestEnd(params.test, params.result);
      return;
    }
    if (method === "onStepBegin") {
      this._onStepBegin(params.testId, params.resultId, params.step);
      return;
    }
    if (method === "onStepEnd") {
      this._onStepEnd(params.testId, params.resultId, params.step);
      return;
    }
    if (method === "onError") {
      this._onError(params.error);
      return;
    }
    if (method === "onStdIO") {
      this._onStdIO(params.type, params.testId, params.resultId, params.data, params.isBase64);
      return;
    }
    if (method === "onEnd")
      return this._onEnd(params.result);
    if (method === "onExit")
      return this._onExit();
  }
  _setClearPreviousResultsWhenTestBegins() {
    this._clearPreviousResultsWhenTestBegins = true;
  }
  _onConfigure(config) {
    var _a;
    this._rootDir = ((_a = this._reportConfig) == null ? void 0 : _a.rootDir) || config.rootDir;
    this._listOnly = config.listOnly;
    this._config = this._parseConfig(config);
    this._reporter.onConfigure(this._config);
  }
  _onBegin(projects) {
    var _a, _b;
    for (const project of projects) {
      let projectSuite = this._rootSuite.suites.find((suite) => suite.project().id === project.id);
      if (!projectSuite) {
        projectSuite = new TeleSuite(project.name, "project");
        this._rootSuite.suites.push(projectSuite);
        projectSuite.parent = this._rootSuite;
      }
      const p = this._parseProject(project);
      projectSuite.project = () => p;
      this._mergeSuitesInto(project.suites, projectSuite);
      if (this._listOnly) {
        const testIds = /* @__PURE__ */ new Set();
        const collectIds = (suite) => {
          suite.tests.map((t) => t.testId).forEach((testId) => testIds.add(testId));
          suite.suites.forEach(collectIds);
        };
        project.suites.forEach(collectIds);
        const filterTests = (suite) => {
          suite.tests = suite.tests.filter((t) => testIds.has(t.id));
          suite.suites.forEach(filterTests);
        };
        filterTests(projectSuite);
      }
    }
    (_b = (_a = this._reporter).onBegin) == null ? void 0 : _b.call(_a, this._rootSuite);
  }
  _onTestBegin(testId, payload) {
    var _a, _b;
    const test = this._tests.get(testId);
    if (this._clearPreviousResultsWhenTestBegins)
      test._clearResults();
    const testResult = test._createTestResult(payload.id);
    testResult.retry = payload.retry;
    testResult.workerIndex = payload.workerIndex;
    testResult.parallelIndex = payload.parallelIndex;
    testResult.startTime = new Date(payload.startTime);
    testResult.statusEx = "running";
    (_b = (_a = this._reporter).onTestBegin) == null ? void 0 : _b.call(_a, test, testResult);
  }
  _onTestEnd(testEndPayload, payload) {
    var _a, _b, _c;
    const test = this._tests.get(testEndPayload.testId);
    test.timeout = testEndPayload.timeout;
    test.expectedStatus = testEndPayload.expectedStatus;
    test.annotations = testEndPayload.annotations;
    const result = test.resultsMap.get(payload.id);
    result.duration = payload.duration;
    result.status = payload.status;
    result.statusEx = payload.status;
    result.errors = payload.errors;
    result.error = (_a = result.errors) == null ? void 0 : _a[0];
    result.attachments = this._parseAttachments(payload.attachments);
    (_c = (_b = this._reporter).onTestEnd) == null ? void 0 : _c.call(_b, test, result);
  }
  _onStepBegin(testId, resultId, payload) {
    var _a, _b;
    const test = this._tests.get(testId);
    const result = test.resultsMap.get(resultId);
    const parentStep = payload.parentStepId ? result.stepMap.get(payload.parentStepId) : void 0;
    const step = {
      titlePath: () => {
        const parentPath = (parentStep == null ? void 0 : parentStep.titlePath()) || [];
        return [...parentPath, payload.title];
      },
      title: payload.title,
      category: payload.category,
      location: this._absoluteLocation(payload.location),
      parent: parentStep,
      startTime: new Date(payload.startTime),
      duration: -1,
      steps: []
    };
    if (parentStep)
      parentStep.steps.push(step);
    else
      result.steps.push(step);
    result.stepMap.set(payload.id, step);
    (_b = (_a = this._reporter).onStepBegin) == null ? void 0 : _b.call(_a, test, result, step);
  }
  _onStepEnd(testId, resultId, payload) {
    var _a, _b;
    const test = this._tests.get(testId);
    const result = test.resultsMap.get(resultId);
    const step = result.stepMap.get(payload.id);
    step.duration = payload.duration;
    step.error = payload.error;
    (_b = (_a = this._reporter).onStepEnd) == null ? void 0 : _b.call(_a, test, result, step);
  }
  _onError(error) {
    var _a, _b;
    (_b = (_a = this._reporter).onError) == null ? void 0 : _b.call(_a, error);
  }
  _onStdIO(type, testId, resultId, data, isBase64) {
    var _a, _b, _c, _d;
    const chunk = isBase64 ? globalThis.Buffer ? Buffer.from(data, "base64") : atob(data) : data;
    const test = testId ? this._tests.get(testId) : void 0;
    const result = test && resultId ? test.resultsMap.get(resultId) : void 0;
    if (type === "stdout") {
      result == null ? void 0 : result.stdout.push(chunk);
      (_b = (_a = this._reporter).onStdOut) == null ? void 0 : _b.call(_a, chunk, test, result);
    } else {
      result == null ? void 0 : result.stderr.push(chunk);
      (_d = (_c = this._reporter).onStdErr) == null ? void 0 : _d.call(_c, chunk, test, result);
    }
  }
  _onEnd(result) {
    var _a, _b;
    return (_b = (_a = this._reporter).onEnd) == null ? void 0 : _b.call(_a, result);
  }
  _onExit() {
    var _a, _b;
    return (_b = (_a = this._reporter).onExit) == null ? void 0 : _b.call(_a);
  }
  _parseConfig(config) {
    const result = { ...baseFullConfig, ...config };
    if (this._reportConfig) {
      result.configFile = this._reportConfig.configFile;
      result.rootDir = this._reportConfig.rootDir;
      result.reportSlowTests = this._reportConfig.reportSlowTests;
      result.quiet = this._reportConfig.quiet;
    }
    return result;
  }
  _parseProject(project) {
    return {
      id: project.id,
      metadata: project.metadata,
      name: project.name,
      outputDir: this._absolutePath(project.outputDir),
      repeatEach: project.repeatEach,
      retries: project.retries,
      testDir: this._absolutePath(project.testDir),
      testIgnore: parseRegexPatterns(project.testIgnore),
      testMatch: parseRegexPatterns(project.testMatch),
      timeout: project.timeout,
      grep: parseRegexPatterns(project.grep),
      grepInvert: parseRegexPatterns(project.grepInvert),
      dependencies: project.dependencies,
      teardown: project.teardown,
      snapshotDir: this._absolutePath(project.snapshotDir),
      use: {}
    };
  }
  _parseAttachments(attachments) {
    return attachments.map((a) => {
      return {
        ...a,
        body: a.base64 && globalThis.Buffer ? Buffer.from(a.base64, "base64") : void 0
      };
    });
  }
  _mergeSuitesInto(jsonSuites, parent) {
    for (const jsonSuite of jsonSuites) {
      let targetSuite = parent.suites.find((s) => s.title === jsonSuite.title);
      if (!targetSuite) {
        targetSuite = new TeleSuite(jsonSuite.title, jsonSuite.type);
        targetSuite.parent = parent;
        parent.suites.push(targetSuite);
      }
      targetSuite.location = this._absoluteLocation(jsonSuite.location);
      targetSuite._fileId = jsonSuite.fileId;
      targetSuite._parallelMode = jsonSuite.parallelMode;
      this._mergeSuitesInto(jsonSuite.suites, targetSuite);
      this._mergeTestsInto(jsonSuite.tests, targetSuite);
    }
  }
  _mergeTestsInto(jsonTests, parent) {
    for (const jsonTest of jsonTests) {
      let targetTest = this._reuseTestCases ? parent.tests.find((s) => s.title === jsonTest.title) : void 0;
      if (!targetTest) {
        targetTest = new TeleTestCase(jsonTest.testId, jsonTest.title, this._absoluteLocation(jsonTest.location));
        targetTest.parent = parent;
        parent.tests.push(targetTest);
        this._tests.set(targetTest.id, targetTest);
      }
      this._updateTest(jsonTest, targetTest);
    }
  }
  _updateTest(payload, test) {
    test.id = payload.testId;
    test.location = this._absoluteLocation(payload.location);
    test.retries = payload.retries;
    return test;
  }
  _absoluteLocation(location) {
    if (!location)
      return location;
    return {
      ...location,
      file: this._absolutePath(location.file)
    };
  }
  _absolutePath(relativePath) {
    if (!relativePath)
      return relativePath;
    return this._rootDir + this._pathSeparator + relativePath;
  }
}
class TeleSuite {
  constructor(title, type) {
    this._requireFile = "";
    this.suites = [];
    this.tests = [];
    this._parallelMode = "none";
    this.title = title;
    this._type = type;
  }
  allTests() {
    const result = [];
    const visit = (suite) => {
      for (const entry of [...suite.suites, ...suite.tests]) {
        if (entry instanceof TeleSuite)
          visit(entry);
        else
          result.push(entry);
      }
    };
    visit(this);
    return result;
  }
  titlePath() {
    const titlePath = this.parent ? this.parent.titlePath() : [];
    if (this.title || this._type !== "describe")
      titlePath.push(this.title);
    return titlePath;
  }
  project() {
    return void 0;
  }
}
class TeleTestCase {
  constructor(id, title, location) {
    this.fn = () => {
    };
    this.results = [];
    this.expectedStatus = "passed";
    this.timeout = 0;
    this.annotations = [];
    this.retries = 0;
    this.repeatEachIndex = 0;
    this.resultsMap = /* @__PURE__ */ new Map();
    this.id = id;
    this.title = title;
    this.location = location;
  }
  titlePath() {
    const titlePath = this.parent ? this.parent.titlePath() : [];
    titlePath.push(this.title);
    return titlePath;
  }
  outcome() {
    const nonSkipped = this.results.filter((result) => result.status !== "skipped" && result.status !== "interrupted");
    if (!nonSkipped.length)
      return "skipped";
    if (nonSkipped.every((result) => result.status === this.expectedStatus))
      return "expected";
    if (nonSkipped.some((result) => result.status === this.expectedStatus))
      return "flaky";
    return "unexpected";
  }
  ok() {
    const status = this.outcome();
    return status === "expected" || status === "flaky" || status === "skipped";
  }
  _clearResults() {
    this.results = [];
    this.resultsMap.clear();
  }
  _createTestResult(id) {
    const result = {
      retry: this.results.length,
      parallelIndex: -1,
      workerIndex: -1,
      duration: -1,
      startTime: /* @__PURE__ */ new Date(),
      stdout: [],
      stderr: [],
      attachments: [],
      status: "skipped",
      statusEx: "scheduled",
      steps: [],
      errors: [],
      stepMap: /* @__PURE__ */ new Map()
    };
    this.results.push(result);
    this.resultsMap.set(id, result);
    return result;
  }
}
const baseFullConfig = {
  forbidOnly: false,
  fullyParallel: false,
  globalSetup: null,
  globalTeardown: null,
  globalTimeout: 0,
  grep: /.*/,
  grepInvert: null,
  maxFailures: 0,
  metadata: {},
  preserveOutput: "always",
  projects: [],
  reporter: [[{}.CI ? "dot" : "list"]],
  reportSlowTests: { max: 5, threshold: 15e3 },
  configFile: "",
  rootDir: "",
  quiet: false,
  shard: null,
  updateSnapshots: "missing",
  version: "",
  workers: 0,
  webServer: null
};
function parseRegexPatterns(patterns) {
  return patterns.map((p) => {
    if (p.s)
      return p.s;
    return new RegExp(p.r.source, p.r.flags);
  });
}
const uiModeView = "";
const xtermWrapper = "";
const XtermWrapper = ({
  source
}) => {
  const [measure, xtermElement] = useMeasure();
  const [theme, setTheme] = reactExports.useState(currentTheme());
  const [modulePromise] = reactExports.useState(__vitePreload(() => import("./assets/xtermModule-60687b6b.js"), true ? ["./assets/xtermModule-60687b6b.js","./xtermModule.125f4259.css"] : void 0, import.meta.url).then((m) => m.default));
  const terminal = reactExports.useRef(null);
  reactExports.useEffect(() => {
    addThemeListener(setTheme);
    return () => removeThemeListener(setTheme);
  }, []);
  reactExports.useEffect(() => {
    const oldSourceWrite = source.write;
    const oldSourceClear = source.clear;
    (async () => {
      const { Terminal, FitAddon } = await modulePromise;
      const element = xtermElement.current;
      if (!element)
        return;
      const terminalTheme = theme === "dark-mode" ? darkTheme : lightTheme;
      if (terminal.current && terminal.current.terminal.options.theme === terminalTheme)
        return;
      if (terminal.current)
        element.textContent = "";
      const newTerminal = new Terminal({
        convertEol: true,
        fontSize: 13,
        scrollback: 1e4,
        fontFamily: "var(--vscode-editor-font-family)",
        theme: terminalTheme
      });
      const fitAddon = new FitAddon();
      newTerminal.loadAddon(fitAddon);
      for (const p of source.pending)
        newTerminal.write(p);
      source.write = (data) => {
        source.pending.push(data);
        newTerminal.write(data);
      };
      source.clear = () => {
        source.pending = [];
        newTerminal.clear();
      };
      newTerminal.open(element);
      fitAddon.fit();
      terminal.current = { terminal: newTerminal, fitAddon };
    })();
    return () => {
      source.clear = oldSourceClear;
      source.write = oldSourceWrite;
    };
  }, [modulePromise, terminal, xtermElement, source, theme]);
  reactExports.useEffect(() => {
    setTimeout(() => {
      if (!terminal.current)
        return;
      terminal.current.fitAddon.fit();
      source.resize(terminal.current.terminal.cols, terminal.current.terminal.rows);
    }, 250);
  }, [measure, source]);
  return /* @__PURE__ */ jsx("div", { "data-testid": "output", className: "xterm-wrapper", style: { flex: "auto" }, ref: xtermElement });
};
const lightTheme = {
  foreground: "#383a42",
  background: "#fafafa",
  cursor: "#383a42",
  black: "#000000",
  red: "#e45649",
  green: "#50a14f",
  yellow: "#c18401",
  blue: "#4078f2",
  magenta: "#a626a4",
  cyan: "#0184bc",
  white: "#a0a0a0",
  brightBlack: "#000000",
  brightRed: "#e06c75",
  brightGreen: "#98c379",
  brightYellow: "#d19a66",
  brightBlue: "#4078f2",
  brightMagenta: "#a626a4",
  brightCyan: "#0184bc",
  brightWhite: "#383a42",
  selectionBackground: "#d7d7d7",
  selectionForeground: "#383a42"
};
const darkTheme = {
  foreground: "#f8f8f2",
  background: "#1e1e1e",
  cursor: "#f8f8f0",
  black: "#000000",
  red: "#ff5555",
  green: "#50fa7b",
  yellow: "#f1fa8c",
  blue: "#bd93f9",
  magenta: "#ff79c6",
  cyan: "#8be9fd",
  white: "#bfbfbf",
  brightBlack: "#4d4d4d",
  brightRed: "#ff6e6e",
  brightGreen: "#69ff94",
  brightYellow: "#ffffa5",
  brightBlue: "#d6acff",
  brightMagenta: "#ff92df",
  brightCyan: "#a4ffff",
  brightWhite: "#e6e6e6",
  selectionBackground: "#44475a",
  selectionForeground: "#f8f8f2"
};
function artifactsFolderName(workerIndex) {
  return `.playwright-artifacts-${workerIndex}`;
}
let updateRootSuite = () => {
};
let runWatchedTests = (fileNames) => {
};
let xtermSize = { cols: 80, rows: 24 };
let sendMessage = async () => {
};
const xtermDataSource = {
  pending: [],
  clear: () => {
  },
  write: (data) => xtermDataSource.pending.push(data),
  resize: (cols, rows) => {
    xtermSize = { cols, rows };
    sendMessageNoReply("resizeTerminal", { cols, rows });
  }
};
const UIModeView = ({}) => {
  var _a;
  const [filterText, setFilterText] = React.useState("");
  const [isShowingOutput, setIsShowingOutput] = React.useState(false);
  const [statusFilters, setStatusFilters] = React.useState(/* @__PURE__ */ new Map([
    ["passed", false],
    ["failed", false],
    ["skipped", false]
  ]));
  const [projectFilters, setProjectFilters] = React.useState(/* @__PURE__ */ new Map());
  const [testModel, setTestModel] = React.useState({ config: void 0, rootSuite: void 0, loadErrors: [] });
  const [progress, setProgress] = React.useState();
  const [selectedItem, setSelectedItem] = React.useState({});
  const [visibleTestIds, setVisibleTestIds] = React.useState(/* @__PURE__ */ new Set());
  const [isLoading, setIsLoading] = React.useState(false);
  const [runningState, setRunningState] = React.useState();
  const [watchAll, setWatchAll] = useSetting("watch-all", false);
  const [watchedTreeIds, setWatchedTreeIds] = React.useState({ value: /* @__PURE__ */ new Set() });
  const runTestPromiseChain = React.useRef(Promise.resolve());
  const runTestBacklog = React.useRef(/* @__PURE__ */ new Set());
  const [collapseAllCount, setCollapseAllCount] = React.useState(0);
  const [isDisconnected, setIsDisconnected] = React.useState(false);
  const inputRef = React.useRef(null);
  const reloadTests = React.useCallback(() => {
    setIsLoading(true);
    setWatchedTreeIds({ value: /* @__PURE__ */ new Set() });
    updateRootSuite(baseFullConfig, new TeleSuite("", "root"), [], void 0);
    refreshRootSuite(true).then(() => {
      setIsLoading(false);
    });
  }, []);
  React.useEffect(() => {
    var _a2;
    (_a2 = inputRef.current) == null ? void 0 : _a2.focus();
    setIsLoading(true);
    connect({ onEvent: dispatchEvent, onClose: () => setIsDisconnected(true) }).then((send) => {
      sendMessage = send;
      reloadTests();
    });
  }, [reloadTests]);
  updateRootSuite = React.useCallback((config, rootSuite, loadErrors, newProgress) => {
    const selectedProjects = config.configFile ? settings.getObject(config.configFile + ":projects", void 0) : void 0;
    for (const projectName of projectFilters.keys()) {
      if (!rootSuite.suites.find((s) => s.title === projectName))
        projectFilters.delete(projectName);
    }
    for (const projectSuite of rootSuite.suites) {
      if (!projectFilters.has(projectSuite.title))
        projectFilters.set(projectSuite.title, !!(selectedProjects == null ? void 0 : selectedProjects.includes(projectSuite.title)));
    }
    if (!selectedProjects && projectFilters.size && ![...projectFilters.values()].includes(true))
      projectFilters.set(projectFilters.entries().next().value[0], true);
    setTestModel({ config, rootSuite, loadErrors });
    setProjectFilters(new Map(projectFilters));
    if (runningState && newProgress)
      setProgress({ ...newProgress, total: runningState.testIds.size });
    else if (!newProgress)
      setProgress(void 0);
  }, [projectFilters, runningState]);
  const runTests = React.useCallback((mode, testIds) => {
    if (mode === "bounce-if-busy" && runningState)
      return;
    runTestBacklog.current = /* @__PURE__ */ new Set([...runTestBacklog.current, ...testIds]);
    runTestPromiseChain.current = runTestPromiseChain.current.then(async () => {
      var _a2, _b, _c;
      const testIds2 = runTestBacklog.current;
      runTestBacklog.current = /* @__PURE__ */ new Set();
      if (!testIds2.size)
        return;
      {
        for (const test of ((_a2 = testModel.rootSuite) == null ? void 0 : _a2.allTests()) || []) {
          if (testIds2.has(test.id)) {
            test._clearResults();
            test._createTestResult("pending");
          }
        }
        setTestModel({ ...testModel });
      }
      const time = "  [" + (/* @__PURE__ */ new Date()).toLocaleTimeString() + "]";
      xtermDataSource.write("\x1B[2m—".repeat(Math.max(0, xtermSize.cols - time.length)) + time + "\x1B[22m");
      setProgress({ total: testIds2.size, passed: 0, failed: 0, skipped: 0 });
      setRunningState({ testIds: testIds2 });
      await sendMessage("run", { testIds: [...testIds2] });
      for (const test of ((_b = testModel.rootSuite) == null ? void 0 : _b.allTests()) || []) {
        if (((_c = test.results[0]) == null ? void 0 : _c.duration) === -1)
          test._clearResults();
      }
      setTestModel({ ...testModel });
      setRunningState(void 0);
    });
  }, [runningState, testModel]);
  const isRunningTest = !!runningState;
  return /* @__PURE__ */ jsxs("div", { className: "vbox ui-mode", children: [
    isDisconnected && /* @__PURE__ */ jsxs("div", { className: "drop-target", children: [
      /* @__PURE__ */ jsx("div", { className: "title", children: "UI Mode disconnected" }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("a", { href: "#", onClick: () => window.location.reload(), children: "Reload the page" }),
        " to reconnect"
      ] })
    ] }),
    /* @__PURE__ */ jsxs(SplitView, { sidebarSize: 250, orientation: "horizontal", sidebarIsFirst: true, children: [
      /* @__PURE__ */ jsxs("div", { className: "vbox", children: [
        /* @__PURE__ */ jsxs("div", { className: "vbox" + (isShowingOutput ? "" : " hidden"), children: [
          /* @__PURE__ */ jsxs(Toolbar, { children: [
            /* @__PURE__ */ jsx("div", { className: "section-title", style: { flex: "none" }, children: "Output" }),
            /* @__PURE__ */ jsx(ToolbarButton, { icon: "circle-slash", title: "Clear output", onClick: () => xtermDataSource.clear() }),
            /* @__PURE__ */ jsx("div", { className: "spacer" }),
            /* @__PURE__ */ jsx(ToolbarButton, { icon: "close", title: "Close", onClick: () => setIsShowingOutput(false) })
          ] }),
          /* @__PURE__ */ jsx(XtermWrapper, { source: xtermDataSource })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "vbox" + (isShowingOutput ? " hidden" : ""), children: /* @__PURE__ */ jsx(TraceView, { item: selectedItem, rootDir: (_a = testModel.config) == null ? void 0 : _a.rootDir }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "vbox ui-mode-sidebar", children: [
        /* @__PURE__ */ jsxs(Toolbar, { noShadow: true, noMinHeight: true, children: [
          /* @__PURE__ */ jsx("img", { src: "icon-32x32.png" }),
          /* @__PURE__ */ jsx("div", { className: "section-title", children: "Playwright" }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "color-mode", title: "Toggle color mode", onClick: () => toggleTheme() }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "refresh", title: "Reload", onClick: () => reloadTests(), disabled: isRunningTest || isLoading }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "terminal", title: "Toggle output", toggled: isShowingOutput, onClick: () => {
            setIsShowingOutput(!isShowingOutput);
          } })
        ] }),
        /* @__PURE__ */ jsx(
          FiltersView,
          {
            filterText,
            setFilterText,
            statusFilters,
            setStatusFilters,
            projectFilters,
            setProjectFilters,
            testModel,
            runTests: () => runTests("bounce-if-busy", visibleTestIds)
          }
        ),
        /* @__PURE__ */ jsxs(Toolbar, { noMinHeight: true, children: [
          !isRunningTest && !progress && /* @__PURE__ */ jsx("div", { className: "section-title", children: "Tests" }),
          !isRunningTest && progress && /* @__PURE__ */ jsx("div", { "data-testid": "status-line", className: "status-line", children: /* @__PURE__ */ jsxs("div", { children: [
            progress.passed,
            "/",
            progress.total,
            " passed (",
            progress.passed / progress.total * 100 | 0,
            "%)"
          ] }) }),
          isRunningTest && progress && /* @__PURE__ */ jsx("div", { "data-testid": "status-line", className: "status-line", children: /* @__PURE__ */ jsxs("div", { children: [
            "Running ",
            progress.passed,
            "/",
            runningState.testIds.size,
            " passed (",
            progress.passed / runningState.testIds.size * 100 | 0,
            "%)"
          ] }) }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "play", title: "Run all", onClick: () => runTests("bounce-if-busy", visibleTestIds), disabled: isRunningTest || isLoading }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "debug-stop", title: "Stop", onClick: () => sendMessageNoReply("stop"), disabled: !isRunningTest || isLoading }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "eye", title: "Watch all", toggled: watchAll, onClick: () => setWatchAll(!watchAll) }),
          /* @__PURE__ */ jsx(ToolbarButton, { icon: "collapse-all", title: "Collapse all", onClick: () => {
            setCollapseAllCount(collapseAllCount + 1);
          } })
        ] }),
        /* @__PURE__ */ jsx(
          TestList,
          {
            statusFilters,
            projectFilters,
            filterText,
            testModel,
            runningState,
            runTests,
            onItemSelected: setSelectedItem,
            setVisibleTestIds,
            watchAll,
            watchedTreeIds,
            setWatchedTreeIds,
            isLoading,
            requestedCollapseAllCount: collapseAllCount
          }
        )
      ] })
    ] })
  ] });
};
const FiltersView = ({ filterText, setFilterText, statusFilters, setStatusFilters, projectFilters, setProjectFilters, testModel, runTests }) => {
  const [expanded, setExpanded] = React.useState(false);
  const inputRef = React.useRef(null);
  React.useEffect(() => {
    var _a;
    (_a = inputRef.current) == null ? void 0 : _a.focus();
  }, []);
  const statusLine = [...statusFilters.entries()].filter(([_, v]) => v).map(([s]) => s).join(" ") || "all";
  const projectsLine = [...projectFilters.entries()].filter(([_, v]) => v).map(([p]) => p).join(" ") || "all";
  return /* @__PURE__ */ jsxs("div", { className: "filters", children: [
    /* @__PURE__ */ jsx(
      Expandable,
      {
        expanded,
        setExpanded,
        title: /* @__PURE__ */ jsx(
          "input",
          {
            ref: inputRef,
            type: "search",
            placeholder: "Filter (e.g. text, @tag)",
            spellCheck: false,
            value: filterText,
            onChange: (e) => {
              setFilterText(e.target.value);
            },
            onKeyDown: (e) => {
              if (e.key === "Enter")
                runTests();
            }
          }
        )
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "filter-summary", title: "Status: " + statusLine + "\nProjects: " + projectsLine, onClick: () => setExpanded(!expanded), children: [
      /* @__PURE__ */ jsx("span", { className: "filter-label", children: "Status:" }),
      " ",
      statusLine,
      /* @__PURE__ */ jsx("span", { className: "filter-label", children: "Projects:" }),
      " ",
      projectsLine
    ] }),
    expanded && /* @__PURE__ */ jsxs("div", { className: "hbox", style: { marginLeft: 14 }, children: [
      /* @__PURE__ */ jsx("div", { className: "filter-list", children: [...statusFilters.entries()].map(([status, value]) => {
        return /* @__PURE__ */ jsx("div", { className: "filter-entry", children: /* @__PURE__ */ jsxs("label", { children: [
          /* @__PURE__ */ jsx("input", { type: "checkbox", checked: value, onClick: () => {
            const copy = new Map(statusFilters);
            copy.set(status, !copy.get(status));
            setStatusFilters(copy);
          } }),
          /* @__PURE__ */ jsx("div", { children: status })
        ] }) });
      }) }),
      /* @__PURE__ */ jsx("div", { className: "filter-list", children: [...projectFilters.entries()].map(([projectName, value]) => {
        return /* @__PURE__ */ jsx("div", { className: "filter-entry", children: /* @__PURE__ */ jsxs("label", { children: [
          /* @__PURE__ */ jsx("input", { type: "checkbox", checked: value, onClick: () => {
            var _a;
            const copy = new Map(projectFilters);
            copy.set(projectName, !copy.get(projectName));
            setProjectFilters(copy);
            const configFile = (_a = testModel == null ? void 0 : testModel.config) == null ? void 0 : _a.configFile;
            if (configFile)
              settings.setObject(configFile + ":projects", [...copy.entries()].filter(([_, v]) => v).map(([k]) => k));
          } }),
          /* @__PURE__ */ jsx("div", { children: projectName })
        ] }) });
      }) })
    ] })
  ] });
};
const TestTreeView = TreeView;
const TestList = ({ statusFilters, projectFilters, filterText, testModel, runTests, runningState, watchAll, watchedTreeIds, setWatchedTreeIds, isLoading, onItemSelected, setVisibleTestIds, requestedCollapseAllCount }) => {
  const [treeState, setTreeState] = React.useState({ expandedItems: /* @__PURE__ */ new Map() });
  const [selectedTreeItemId, setSelectedTreeItemId] = React.useState();
  const [collapseAllCount, setCollapseAllCount] = React.useState(requestedCollapseAllCount);
  const { rootItem, treeItemMap, fileNames } = React.useMemo(() => {
    let rootItem2 = createTree(testModel.rootSuite, testModel.loadErrors, projectFilters);
    filterTree(rootItem2, filterText, statusFilters, runningState == null ? void 0 : runningState.testIds);
    sortAndPropagateStatus(rootItem2);
    rootItem2 = shortenRoot(rootItem2);
    hideOnlyTests(rootItem2);
    const treeItemMap2 = /* @__PURE__ */ new Map();
    const visibleTestIds = /* @__PURE__ */ new Set();
    const fileNames2 = /* @__PURE__ */ new Set();
    const visit = (treeItem) => {
      if (treeItem.kind === "group" && treeItem.location.file)
        fileNames2.add(treeItem.location.file);
      if (treeItem.kind === "case")
        treeItem.tests.forEach((t) => visibleTestIds.add(t.id));
      treeItem.children.forEach(visit);
      treeItemMap2.set(treeItem.id, treeItem);
    };
    visit(rootItem2);
    setVisibleTestIds(visibleTestIds);
    return { rootItem: rootItem2, treeItemMap: treeItemMap2, fileNames: fileNames2 };
  }, [filterText, testModel, statusFilters, projectFilters, setVisibleTestIds, runningState]);
  React.useEffect(() => {
    if (collapseAllCount !== requestedCollapseAllCount) {
      treeState.expandedItems.clear();
      for (const item of treeItemMap.keys())
        treeState.expandedItems.set(item, false);
      setCollapseAllCount(requestedCollapseAllCount);
      setSelectedTreeItemId(void 0);
      setTreeState({ ...treeState });
      return;
    }
    if (!runningState || runningState.itemSelectedByUser)
      return;
    let selectedTreeItem2;
    const visit = (treeItem) => {
      var _a;
      treeItem.children.forEach(visit);
      if (selectedTreeItem2)
        return;
      if (treeItem.status === "failed") {
        if (treeItem.kind === "test" && runningState.testIds.has(treeItem.test.id))
          selectedTreeItem2 = treeItem;
        else if (treeItem.kind === "case" && runningState.testIds.has((_a = treeItem.tests[0]) == null ? void 0 : _a.id))
          selectedTreeItem2 = treeItem;
      }
    };
    visit(rootItem);
    if (selectedTreeItem2)
      setSelectedTreeItemId(selectedTreeItem2.id);
  }, [runningState, setSelectedTreeItemId, rootItem, collapseAllCount, setCollapseAllCount, requestedCollapseAllCount, treeState, setTreeState, treeItemMap]);
  const { selectedTreeItem } = React.useMemo(() => {
    const selectedTreeItem2 = selectedTreeItemId ? treeItemMap.get(selectedTreeItemId) : void 0;
    let testFile;
    if (selectedTreeItem2) {
      testFile = {
        file: selectedTreeItem2.location.file,
        line: selectedTreeItem2.location.line,
        source: {
          errors: testModel.loadErrors.filter((e) => {
            var _a;
            return ((_a = e.location) == null ? void 0 : _a.file) === selectedTreeItem2.location.file;
          }).map((e) => ({ line: e.location.line, message: e.message })),
          content: void 0
        }
      };
    }
    let selectedTest;
    if ((selectedTreeItem2 == null ? void 0 : selectedTreeItem2.kind) === "test")
      selectedTest = selectedTreeItem2.test;
    else if ((selectedTreeItem2 == null ? void 0 : selectedTreeItem2.kind) === "case" && selectedTreeItem2.tests.length === 1)
      selectedTest = selectedTreeItem2.tests[0];
    onItemSelected({ testCase: selectedTest, testFile });
    return { selectedTreeItem: selectedTreeItem2 };
  }, [onItemSelected, selectedTreeItemId, testModel, treeItemMap]);
  React.useEffect(() => {
    if (isLoading)
      return;
    if (watchAll) {
      sendMessageNoReply("watch", { fileNames: [...fileNames] });
    } else {
      const fileNames2 = /* @__PURE__ */ new Set();
      for (const itemId of watchedTreeIds.value) {
        const treeItem = treeItemMap.get(itemId);
        const fileName = treeItem == null ? void 0 : treeItem.location.file;
        if (fileName)
          fileNames2.add(fileName);
      }
      sendMessageNoReply("watch", { fileNames: [...fileNames2] });
    }
  }, [isLoading, rootItem, fileNames, watchAll, watchedTreeIds, treeItemMap]);
  const runTreeItem = (treeItem) => {
    setSelectedTreeItemId(treeItem.id);
    runTests("bounce-if-busy", collectTestIds(treeItem));
  };
  runWatchedTests = (changedTestFiles) => {
    const testIds = [];
    const set = new Set(changedTestFiles);
    if (watchAll) {
      const visit = (treeItem) => {
        const fileName = treeItem.location.file;
        if (fileName && set.has(fileName))
          testIds.push(...collectTestIds(treeItem));
        if (treeItem.kind === "group" && treeItem.subKind === "folder")
          treeItem.children.forEach(visit);
      };
      visit(rootItem);
    } else {
      for (const treeId of watchedTreeIds.value) {
        const treeItem = treeItemMap.get(treeId);
        const fileName = treeItem == null ? void 0 : treeItem.location.file;
        if (fileName && set.has(fileName))
          testIds.push(...collectTestIds(treeItem));
      }
    }
    runTests("queue-if-busy", new Set(testIds));
  };
  return /* @__PURE__ */ jsx(
    TestTreeView,
    {
      treeState,
      setTreeState,
      rootItem,
      dataTestId: "test-tree",
      render: (treeItem) => {
        return /* @__PURE__ */ jsxs("div", { className: "hbox ui-mode-list-item", children: [
          /* @__PURE__ */ jsx("div", { className: "ui-mode-list-item-title", children: treeItem.title }),
          !!treeItem.duration && treeItem.status !== "skipped" && /* @__PURE__ */ jsx("div", { className: "ui-mode-list-item-time", children: msToString(treeItem.duration) }),
          /* @__PURE__ */ jsxs(Toolbar, { noMinHeight: true, noShadow: true, children: [
            /* @__PURE__ */ jsx(ToolbarButton, { icon: "play", title: "Run", onClick: () => runTreeItem(treeItem), disabled: !!runningState }),
            /* @__PURE__ */ jsx(ToolbarButton, { icon: "go-to-file", title: "Open in VS Code", onClick: () => sendMessageNoReply("open", { location: locationToOpen(treeItem) }), style: treeItem.kind === "group" && treeItem.subKind === "folder" ? { visibility: "hidden" } : {} }),
            !watchAll && /* @__PURE__ */ jsx(ToolbarButton, { icon: "eye", title: "Watch", onClick: () => {
              if (watchedTreeIds.value.has(treeItem.id))
                watchedTreeIds.value.delete(treeItem.id);
              else
                watchedTreeIds.value.add(treeItem.id);
              setWatchedTreeIds({ ...watchedTreeIds });
            }, toggled: watchedTreeIds.value.has(treeItem.id) })
          ] })
        ] });
      },
      icon: (treeItem) => {
        if (treeItem.status === "scheduled")
          return "codicon-clock";
        if (treeItem.status === "running")
          return "codicon-loading";
        if (treeItem.status === "failed")
          return "codicon-error";
        if (treeItem.status === "passed")
          return "codicon-check";
        if (treeItem.status === "skipped")
          return "codicon-circle-slash";
        return "codicon-circle-outline";
      },
      selectedItem: selectedTreeItem,
      onAccepted: runTreeItem,
      onSelected: (treeItem) => {
        if (runningState)
          runningState.itemSelectedByUser = true;
        setSelectedTreeItemId(treeItem.id);
      },
      isError: (treeItem) => treeItem.kind === "group" ? treeItem.hasLoadErrors : false,
      autoExpandDepth: filterText ? 5 : 1,
      noItemsMessage: isLoading ? "Loading…" : "No tests"
    }
  );
};
const TraceView = ({ item, rootDir }) => {
  const [model, setModel] = React.useState();
  const [counter, setCounter] = React.useState(0);
  const pollTimer = React.useRef(null);
  const { outputDir } = React.useMemo(() => {
    const outputDir2 = item.testCase ? outputDirForTestCase(item.testCase) : void 0;
    return { outputDir: outputDir2 };
  }, [item]);
  const [selectedActionId, setSelectedActionId] = React.useState();
  const onSelectionChanged = React.useCallback((action) => setSelectedActionId(idForAction(action)), [setSelectedActionId]);
  const initialSelection = selectedActionId ? model == null ? void 0 : model.model.actions.find((a) => idForAction(a) === selectedActionId) : void 0;
  React.useEffect(() => {
    var _a, _b;
    if (pollTimer.current)
      clearTimeout(pollTimer.current);
    const result = (_a = item.testCase) == null ? void 0 : _a.results[0];
    if (!result) {
      setModel(void 0);
      return;
    }
    const attachment = result && result.duration >= 0 && result.attachments.find((a) => a.name === "trace");
    if (attachment && attachment.path) {
      loadSingleTraceFile(attachment.path).then((model2) => setModel({ model: model2, isLive: false }));
      return;
    }
    if (!outputDir) {
      setModel(void 0);
      return;
    }
    const traceLocation = `${outputDir}/${artifactsFolderName(result.workerIndex)}/traces/${(_b = item.testCase) == null ? void 0 : _b.id}.json`;
    pollTimer.current = setTimeout(async () => {
      try {
        const model2 = await loadSingleTraceFile(traceLocation);
        setModel({ model: model2, isLive: true });
      } catch {
        setModel(void 0);
      } finally {
        setCounter(counter + 1);
      }
    }, 500);
    return () => {
      if (pollTimer.current)
        clearTimeout(pollTimer.current);
    };
  }, [outputDir, item, setModel, counter, setCounter]);
  return /* @__PURE__ */ jsx(
    Workbench,
    {
      model: model == null ? void 0 : model.model,
      hideTimelineBars: true,
      hideStackFrames: true,
      showSourcesFirst: true,
      rootDir,
      initialSelection,
      onSelectionChanged,
      fallbackLocation: item.testFile,
      isLive: model == null ? void 0 : model.isLive,
      drawer: "bottom"
    },
    "workbench"
  );
};
let receiver;
let throttleTimer;
let throttleData;
const throttledAction = () => {
  clearTimeout(throttleTimer);
  throttleTimer = void 0;
  updateRootSuite(throttleData.config, throttleData.rootSuite, throttleData.loadErrors, throttleData.progress);
};
const throttleUpdateRootSuite = (config, rootSuite, loadErrors, progress, immediate = false) => {
  throttleData = { config, rootSuite, loadErrors, progress };
  if (immediate)
    throttledAction();
  else if (!throttleTimer)
    throttleTimer = setTimeout(throttledAction, 250);
};
const refreshRootSuite = (eraseResults) => {
  if (!eraseResults)
    return sendMessage("list", {});
  let rootSuite;
  const loadErrors = [];
  const progress = {
    passed: 0,
    failed: 0,
    skipped: 0
  };
  let config;
  receiver = new TeleReporterReceiver(pathSeparator, {
    version: () => "v2",
    onConfigure: (c) => {
      config = c;
    },
    onBegin: (suite) => {
      if (!rootSuite)
        rootSuite = suite;
      progress.passed = 0;
      progress.failed = 0;
      progress.skipped = 0;
      throttleUpdateRootSuite(config, rootSuite, loadErrors, progress, true);
    },
    onEnd: () => {
      throttleUpdateRootSuite(config, rootSuite, loadErrors, progress, true);
    },
    onTestBegin: () => {
      throttleUpdateRootSuite(config, rootSuite, loadErrors, progress);
    },
    onTestEnd: (test) => {
      if (test.outcome() === "skipped")
        ++progress.skipped;
      else if (test.outcome() === "unexpected")
        ++progress.failed;
      else
        ++progress.passed;
      throttleUpdateRootSuite(config, rootSuite, loadErrors, progress);
    },
    onError: (error) => {
      xtermDataSource.write((error.stack || error.value || "") + "\n");
      loadErrors.push(error);
      throttleUpdateRootSuite(config, rootSuite ?? new TeleSuite("", "root"), loadErrors, progress);
    },
    printsToStdio: () => {
      return false;
    },
    onStdOut: () => {
    },
    onStdErr: () => {
    },
    onExit: () => {
    },
    onStepBegin: () => {
    },
    onStepEnd: () => {
    }
  }, true);
  receiver._setClearPreviousResultsWhenTestBegins();
  return sendMessage("list", {});
};
const sendMessageNoReply = (method, params) => {
  if (window._overrideProtocolForTest) {
    window._overrideProtocolForTest({ method, params }).catch(() => {
    });
    return;
  }
  sendMessage(method, params).catch((e) => {
    console.error(e);
  });
};
const dispatchEvent = (method, params) => {
  var _a;
  if (method === "listChanged") {
    refreshRootSuite(false).catch(() => {
    });
    return;
  }
  if (method === "testFilesChanged") {
    runWatchedTests(params.testFileNames);
    return;
  }
  if (method === "stdio") {
    if (params.buffer) {
      const data = atob(params.buffer);
      xtermDataSource.write(data);
    } else {
      xtermDataSource.write(params.text);
    }
    return;
  }
  (_a = receiver == null ? void 0 : receiver.dispatch({ method, params })) == null ? void 0 : _a.catch(() => {
  });
};
const outputDirForTestCase = (testCase) => {
  var _a;
  for (let suite = testCase.parent; suite; suite = suite.parent) {
    if (suite.project())
      return (_a = suite.project()) == null ? void 0 : _a.outputDir;
  }
  return void 0;
};
const locationToOpen = (treeItem) => {
  if (!treeItem)
    return;
  return treeItem.location.file + ":" + treeItem.location.line;
};
const collectTestIds = (treeItem) => {
  const testIds = /* @__PURE__ */ new Set();
  if (!treeItem)
    return testIds;
  const visit = (treeItem2) => {
    var _a;
    if (treeItem2.kind === "case")
      treeItem2.tests.map((t) => t.id).forEach((id) => testIds.add(id));
    else if (treeItem2.kind === "test")
      testIds.add(treeItem2.id);
    else
      (_a = treeItem2.children) == null ? void 0 : _a.forEach(visit);
  };
  visit(treeItem);
  return testIds;
};
function getFileItem(rootItem, filePath, isFile, fileItems) {
  if (filePath.length === 0)
    return rootItem;
  const fileName = filePath.join(pathSeparator);
  const existingFileItem = fileItems.get(fileName);
  if (existingFileItem)
    return existingFileItem;
  const parentFileItem = getFileItem(rootItem, filePath.slice(0, filePath.length - 1), false, fileItems);
  const fileItem = {
    kind: "group",
    subKind: isFile ? "file" : "folder",
    id: fileName,
    title: filePath[filePath.length - 1],
    location: { file: fileName, line: 0, column: 0 },
    duration: 0,
    parent: parentFileItem,
    children: [],
    status: "none",
    hasLoadErrors: false
  };
  parentFileItem.children.push(fileItem);
  fileItems.set(fileName, fileItem);
  return fileItem;
}
function createTree(rootSuite, loadErrors, projectFilters) {
  const filterProjects = [...projectFilters.values()].some(Boolean);
  const rootItem = {
    kind: "group",
    subKind: "folder",
    id: "root",
    title: "",
    location: { file: "", line: 0, column: 0 },
    duration: 0,
    parent: void 0,
    children: [],
    status: "none",
    hasLoadErrors: false
  };
  const visitSuite = (projectName, parentSuite, parentGroup) => {
    for (const suite of parentSuite.suites) {
      const title = suite.title || "<anonymous>";
      let group = parentGroup.children.find((item) => item.title === title);
      if (!group) {
        group = {
          kind: "group",
          subKind: "describe",
          id: parentGroup.id + "" + title,
          title,
          location: suite.location,
          duration: 0,
          parent: parentGroup,
          children: [],
          status: "none",
          hasLoadErrors: false
        };
        parentGroup.children.push(group);
      }
      visitSuite(projectName, suite, group);
    }
    for (const test of parentSuite.tests) {
      const title = test.title;
      let testCaseItem = parentGroup.children.find((t) => t.title === title);
      if (!testCaseItem) {
        testCaseItem = {
          kind: "case",
          id: parentGroup.id + "" + title,
          title,
          parent: parentGroup,
          children: [],
          tests: [],
          location: test.location,
          duration: 0,
          status: "none"
        };
        parentGroup.children.push(testCaseItem);
      }
      const result = test.results[0];
      let status = "none";
      if ((result == null ? void 0 : result.statusEx) === "scheduled")
        status = "scheduled";
      else if ((result == null ? void 0 : result.statusEx) === "running")
        status = "running";
      else if ((result == null ? void 0 : result.status) === "skipped")
        status = "skipped";
      else if ((result == null ? void 0 : result.status) === "interrupted")
        status = "none";
      else if (result && test.outcome() !== "expected")
        status = "failed";
      else if (result && test.outcome() === "expected")
        status = "passed";
      testCaseItem.tests.push(test);
      testCaseItem.children.push({
        kind: "test",
        id: test.id,
        title: projectName,
        location: test.location,
        test,
        parent: testCaseItem,
        children: [],
        status,
        duration: test.results.length ? Math.max(0, test.results[0].duration) : 0,
        project: projectName
      });
      testCaseItem.duration = testCaseItem.children.reduce((a, b) => a + b.duration, 0);
    }
  };
  const fileMap = /* @__PURE__ */ new Map();
  for (const projectSuite of (rootSuite == null ? void 0 : rootSuite.suites) || []) {
    if (filterProjects && !projectFilters.get(projectSuite.title))
      continue;
    for (const fileSuite of projectSuite.suites) {
      const fileItem = getFileItem(rootItem, fileSuite.location.file.split(pathSeparator), true, fileMap);
      visitSuite(projectSuite.title, fileSuite, fileItem);
    }
    for (const loadError of loadErrors) {
      if (!loadError.location)
        continue;
      const fileItem = getFileItem(rootItem, loadError.location.file.split(pathSeparator), true, fileMap);
      fileItem.hasLoadErrors = true;
    }
  }
  return rootItem;
}
function filterTree(rootItem, filterText, statusFilters, runningTestIds) {
  const tokens = filterText.trim().toLowerCase().split(" ");
  const filtersStatuses = [...statusFilters.values()].some(Boolean);
  const filter = (testCase) => {
    const title = testCase.tests[0].titlePath().join(" ").toLowerCase();
    if (!tokens.every((token) => title.includes(token)) && !testCase.tests.some((t) => runningTestIds == null ? void 0 : runningTestIds.has(t.id)))
      return false;
    testCase.children = testCase.children.filter((test) => {
      return !filtersStatuses || (runningTestIds == null ? void 0 : runningTestIds.has(test.id)) || statusFilters.get(test.status);
    });
    testCase.tests = testCase.children.map((c) => c.test);
    return !!testCase.children.length;
  };
  const visit = (treeItem) => {
    const newChildren = [];
    for (const child of treeItem.children) {
      if (child.kind === "case") {
        if (filter(child))
          newChildren.push(child);
      } else {
        visit(child);
        if (child.children.length || child.hasLoadErrors)
          newChildren.push(child);
      }
    }
    treeItem.children = newChildren;
  };
  visit(rootItem);
}
function sortAndPropagateStatus(treeItem) {
  for (const child of treeItem.children)
    sortAndPropagateStatus(child);
  if (treeItem.kind === "group") {
    treeItem.children.sort((a, b) => {
      const fc = a.location.file.localeCompare(b.location.file);
      return fc || a.location.line - b.location.line;
    });
  }
  let allPassed = treeItem.children.length > 0;
  let allSkipped = treeItem.children.length > 0;
  let hasFailed = false;
  let hasRunning = false;
  let hasScheduled = false;
  for (const child of treeItem.children) {
    allSkipped = allSkipped && child.status === "skipped";
    allPassed = allPassed && (child.status === "passed" || child.status === "skipped");
    hasFailed = hasFailed || child.status === "failed";
    hasRunning = hasRunning || child.status === "running";
    hasScheduled = hasScheduled || child.status === "scheduled";
  }
  if (hasRunning)
    treeItem.status = "running";
  else if (hasScheduled)
    treeItem.status = "scheduled";
  else if (hasFailed)
    treeItem.status = "failed";
  else if (allSkipped)
    treeItem.status = "skipped";
  else if (allPassed)
    treeItem.status = "passed";
}
function shortenRoot(rootItem) {
  let shortRoot = rootItem;
  while (shortRoot.children.length === 1 && shortRoot.children[0].kind === "group" && shortRoot.children[0].subKind === "folder")
    shortRoot = shortRoot.children[0];
  shortRoot.location = rootItem.location;
  return shortRoot;
}
function hideOnlyTests(rootItem) {
  const visit = (treeItem) => {
    if (treeItem.kind === "case" && treeItem.children.length === 1)
      treeItem.children = [];
    else
      treeItem.children.forEach(visit);
  };
  visit(rootItem);
}
async function loadSingleTraceFile(url) {
  const params = new URLSearchParams();
  params.set("trace", url);
  const response = await fetch(`contexts?${params.toString()}`);
  const contextEntries = await response.json();
  return new MultiTraceModel(contextEntries);
}
const pathSeparator = navigator.userAgent.toLowerCase().includes("windows") ? "\\" : "/";
(async () => {
  applyTheme();
  if (window.location.protocol !== "file:") {
    if (window.location.href.includes("isUnderTest=true"))
      await new Promise((f) => setTimeout(f, 1e3));
    navigator.serviceWorker.register("sw.bundle.js");
    if (!navigator.serviceWorker.controller) {
      await new Promise((f) => {
        navigator.serviceWorker.oncontrollerchange = () => f();
      });
    }
    setInterval(function() {
      fetch("ping");
    }, 1e4);
  }
  reactDomExports.render(/* @__PURE__ */ jsx(UIModeView, {}), document.querySelector("#root"));
})();
//# sourceMappingURL=uiMode.c451a0b2.js.map
